import React, { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Toaster } from "@/components/ui/sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard, ShoppingCart, ClipboardList, Table2,
  UtensilsCrossed, Users, Settings, ChefHat, BarChart2,
  UserCheck, Plug, ChevronLeft, ChevronRight, Menu, TrendingUp, DollarSign, Star,
  ChevronDown, Tag, Box, Sliders, Package, Layers,
  ShoppingBag, Truck, ArrowLeftRight, ClipboardCheck, CreditCard, RefreshCw, Factory, MoreHorizontal, List, Shield, Clock, Building2, QrCode
} from "lucide-react";
import { PermissionProvider } from "@/components/inventory/PermissionsProvider";
import BranchSelector from "@/components/BranchSelector";

const MENU_PAGES = ["Menu", "MenuCategories", "MenuModifiers", "MenuCombos", "MenuGroups", "Settings"];
const INVENTORY_PAGES = ["InventoryItems", "InventoryHub", "InventoryCount", "BranchTransferDashboard", "ReplenishmentReport", "WasteLog", "InventoryCategories", "Warehouses", "OrderTransaction", "Suppliers", "PurchaseOrders"];
const HR_PAGES = ["HRDashboard", "StaffManagement", "HRDepartments", "StaffTimecards", "StaffTimeClock", "StaffClockQR", "HRPayroll", "HRLaborReports", "Staff"];
const EXPENSE_PAGES = ["ExpenseDashboard", "Expenses", "ExpenseCategories"];

const NAV = [
  { label: "Dashboard", page: "Dashboard", icon: LayoutDashboard },
  { label: "Owner Dashboard", page: "OwnerDashboard", icon: TrendingUp },
  { label: "POS", page: "POS", icon: ShoppingCart },
  { label: "Orders", page: "Orders", icon: ClipboardList },
  { label: "End of Day", page: "EndOfDay", icon: BarChart2 },
  { label: "Kitchen", page: "Kitchen", icon: ChefHat },
  { label: "Waiter POS", page: "WaiterPOS", icon: UtensilsCrossed },
  { label: "Waiter Access", page: "WaiterAccess", icon: UtensilsCrossed },
  { label: "Management Access", page: "ManagementAccess", icon: LayoutDashboard },
  { label: "Tables", page: "Tables", icon: Table2 },
  {
    label: "Menu", icon: UtensilsCrossed, group: true,
    children: [
      {
        label: "Menu Builder", section: true,
        children: [
          { label: "Categories", page: "MenuCategories", icon: Tag },
          { label: "Products", page: "Menu", icon: Box },
          { label: "Modifiers", page: "MenuModifiers", icon: Sliders },
          { label: "Combos", page: "MenuCombos", icon: Package },
          { label: "Groups", page: "MenuGroups", icon: Layers },
        ]
      },
      { label: "Menu Settings", section: true, page: "Settings", children: [] }
    ]
  },
  {
    label: "Inventory", icon: ShoppingBag, group: true,
    groupKey: "Inventory",
    children: [
      {
        label: "Items", section: true,
        children: [
          { label: "Items", page: "InventoryItems", icon: List },
          { label: "Suppliers", page: "Suppliers", icon: Truck },
          { label: "Purchase Orders", page: "PurchaseOrders", icon: ShoppingBag },
          { label: "Transfer Orders", page: "BranchTransferDashboard", icon: ArrowLeftRight },
          { label: "Inventory Count", page: "InventoryCount", icon: ClipboardCheck },
        ]
      },
      {
        label: "Operations", section: true,
        children: [
          { label: "Purchasing", page: "InventoryHub", icon: CreditCard },
          { label: "Transfers", page: "BranchTransferDashboard", icon: RefreshCw },
          { label: "Production", page: "WasteLog", icon: Factory },
          { label: "More", page: "ReplenishmentReport", icon: MoreHorizontal },
        ]
      }
    ]
  },
  { label: "Customers", page: "Customers", icon: Users },
  { label: "Customer Feedback", page: "CustomerFeedback", icon: Star },
  { label: "Loyalty Program", page: "LoyaltyDashboard", icon: Star },
  { label: "Discounts", page: "Discounts", icon: DollarSign },
  {
    label: "Expenses", icon: DollarSign, group: true,
    groupKey: "Expenses",
    children: [
      {
        label: "Overview", section: true,
        children: [
          { label: "Dashboard", page: "ExpenseDashboard", icon: BarChart2 },
          { label: "Transactions", page: "Expenses", icon: ClipboardList },
          { label: "Categories", page: "ExpenseCategories", icon: Tag },
        ]
      }
    ]
  },
  { label: "Weekly Orders", page: "WeeklyOrders", icon: ShoppingBag },
  { label: "Weekly Orders QR", page: "WeeklyOrdersQR", icon: QrCode },
  { label: "Product Cost", page: "ProductCost", icon: DollarSign },
  { label: "Menu Engineering", page: "MenuEngineering", icon: TrendingUp },
  { label: "Branch Transfers", page: "BranchTransferDashboard", icon: BarChart2 },
  { label: "Replenishment", page: "ReplenishmentReport", icon: BarChart2 },
  { label: "Reports", page: "Reports", icon: BarChart2 },
  { label: "Discount Analytics", page: "DiscountAnalytics", icon: TrendingUp },
  { label: "Business Reports", page: "BusinessReports", icon: BarChart2 },
  { label: "Analytics", page: "Analytics", icon: TrendingUp },
  {
    label: "HR", icon: UserCheck, group: true,
    groupKey: "HR",
    children: [
      {
        label: "Overview", section: true,
        children: [
          { label: "HR Dashboard", page: "HRDashboard", icon: LayoutDashboard },
          { label: "Staff Members", page: "StaffManagement", icon: Users },
          { label: "Departments", page: "HRDepartments", icon: Building2 },
        ]
      },
      {
        label: "Time & Pay", section: true,
        children: [
          { label: "Time Clock", page: "StaffTimeClock", icon: Clock },
          { label: "QR Codes", page: "StaffClockQR", icon: QrCode },
          { label: "Timecards", page: "StaffTimecards", icon: Clock },
          { label: "Payroll", page: "HRPayroll", icon: DollarSign },
          { label: "Labor Reports", page: "HRLaborReports", icon: TrendingUp },
        ]
      }
    ]
  },
  { label: "Staff", page: "Staff", icon: UserCheck },
  { label: "POS Login", page: "POSLogin", icon: UserCheck },
  { label: "Branch Login", page: "BranchLogin", icon: UserCheck },
  { label: "Branches", page: "Branches", icon: UtensilsCrossed },
  { label: "Roles", page: "Roles", icon: UserCheck },
  { label: "Manage", page: "Manage", icon: Settings },
  { label: "Audit Log", page: "AuditLog", icon: Shield },
  { label: "Devices", page: "Devices", icon: Plug },
  { label: "Delivery", page: "DeliveryIntegrations", icon: Truck },
  { label: "Integrations", page: "Integrations", icon: Plug },
  { label: "Settings", page: "Settings", icon: Settings },
];

const NO_LAYOUT_PAGES = ["BranchLogin", "POSLogin", "Kitchen", "ManagementLogin", "WaiterAccess", "WaiterPOS", "POS", "POSv2", "DigitalReceipt", "StaffTimeClock", "LoyaltySignup", "InventoryCount", "WeeklyOrdersLogin", "WeeklyOrders"];

const MOBILE_NAV = [
  { label: "Dashboard", page: "Dashboard", icon: LayoutDashboard },
  { label: "POS", page: "POS", icon: ShoppingCart },
  { label: "Orders", page: "Orders", icon: ClipboardList },
  { label: "Tables", page: "Tables", icon: Table2 },
];

function MobileNavbar({ currentPageName }) {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 flex"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {MOBILE_NAV.map(({ label, page, icon: Icon }) => {
        const active = currentPageName === page;
        return (
          <Link
            key={page}
            to={createPageUrl(page)}
            className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-[10px] font-medium transition-colors ${
              active ? "text-violet-700" : "text-gray-400"
            }`}
          >
            <Icon className={`w-5 h-5 ${active ? "text-violet-700" : "text-gray-400"}`} />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}

function useSessionTracker() {
  useEffect(() => {
    const trackSessionEnd = () => {
      try {
        const raw = localStorage.getItem("pos_staff_session");
        if (!raw) return;
        const session = JSON.parse(raw);
        if (!session?.logged_in_at) return;
        const durationSeconds = Math.round((Date.now() - new Date(session.logged_in_at).getTime()) / 1000);
        base44.analytics.track({
          eventName: "cashier_session_end",
          properties: {
            staff_name: session.name || "",
            role_type: session.role_type || "",
            branch_name: session.branch_name || "",
            branch_id: session.branch_id || "",
            session_duration_seconds: durationSeconds,
          }
        });
      } catch {}
    };
    window.addEventListener("beforeunload", trackSessionEnd);
    return () => window.removeEventListener("beforeunload", trackSessionEnd);
  }, []);
}

function AppLayout({ children, currentPageName }) {
  const [collapsed, setCollapsed] = useState(false);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [openGroups, setOpenGroups] = useState({ Menu: true, Inventory: false, HR: false, Expenses: false });

  useSessionTracker();

  useEffect(() => {
    const saved = localStorage.getItem("selectedBranchId");
    if (saved) setSelectedBranchId(saved);
  }, []);

  const toggleGroup = (label) => setOpenGroups(prev => ({ ...prev, [label]: !prev[label] }));

  return (
    <PermissionProvider>
      <div className="flex h-screen bg-[#F4F5F7] overflow-hidden" style={{ fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>

        {/* Sidebar */}
      <aside
        className="desktop-sidebar flex-shrink-0 flex flex-col bg-white border-r border-gray-200 transition-all duration-300"
        style={{ width: collapsed ? 64 : 220 }}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-gray-100 gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <UtensilsCrossed className="w-4 h-4 text-white" />
          </div>
          {!collapsed && (
            <span className="font-bold text-gray-900 text-base tracking-tight">DENDAX</span>
          )}
          <button
            onClick={() => setCollapsed(v => !v)}
            className="ml-auto text-gray-400 hover:text-gray-600 transition"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Branch Selector */}
        {!collapsed && (
          <div className="px-3 py-2 border-b border-gray-100">
            <BranchSelector 
              currentBranchId={selectedBranchId} 
              onBranchChange={(branch) => setSelectedBranchId(branch.id)}
            />
          </div>
        )}

        {/* Nav */}
        <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
          {NAV.map((item) => {
            if (item.group) {
              const groupKey = item.groupKey || item.label;
              const isOpen = openGroups[groupKey];
              const Icon = item.icon;
              const isGroupActive = groupKey === "Inventory"
                ? INVENTORY_PAGES.includes(currentPageName)
                : groupKey === "HR"
                ? HR_PAGES.includes(currentPageName)
                : groupKey === "Expenses"
                ? EXPENSE_PAGES.includes(currentPageName)
                : MENU_PAGES.includes(currentPageName);
              return (
                <div key={item.label}>
                  <button
                    onClick={() => toggleGroup(groupKey)}
                    title={collapsed ? item.label : undefined}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium ${
                      isGroupActive && !isOpen ? "text-white" : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                    }`}
                    style={isGroupActive && !isOpen ? { background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" } : {}}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    {!collapsed && (
                      <>
                        <span className="flex-1 text-left">{item.label}</span>
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                      </>
                    )}
                  </button>
                  {isOpen && !collapsed && (
                    <div className="ml-2 mt-0.5 mb-1">
                      {item.children.map((section) => (
                        <div key={section.label}>
                          {/* Section header */}
                          <div className="flex items-center justify-between px-3 py-2 mt-1">
                            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">{section.label}</span>
                            {section.children?.length > 0 && (
                              <ChevronDown className="w-3 h-3 text-gray-300" />
                            )}
                          </div>
                          {/* Section children */}
                          {section.children?.map((child) => {
                            const ChildIcon = child.icon;
                            const active = currentPageName === child.page;
                            return (
                              <Link
                                key={child.page}
                                to={createPageUrl(child.page)}
                                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all text-sm ml-2 ${
                                  active
                                    ? "text-violet-700 bg-violet-50 font-semibold"
                                    : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                                }`}
                              >
                                <ChildIcon className="w-3.5 h-3.5 shrink-0" />
                                <span>{child.label}</span>
                              </Link>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            }

            const { label, page, icon: Icon } = item;
            const active = currentPageName === page;
            return (
              <Link
                key={page}
                to={createPageUrl(page)}
                title={collapsed ? label : undefined}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium group ${
                  active
                    ? "text-white"
                    : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                }`}
                style={active ? { background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" } : {}}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {!collapsed && <span>{label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Bottom brand */}
        {!collapsed && (
          <div className="px-4 py-3 border-t border-gray-100">
            <p className="text-[10px] text-gray-400 font-medium uppercase tracking-widest">Restaurant OS</p>
          </div>
        )}
      </aside>

        {/* Content */}
        <main className="main-content flex-1 overflow-auto" style={{ paddingTop: "env(safe-area-inset-top)" }}>
          {children}
        </main>
      </div>
    </PermissionProvider>
  );
}

const TRANSFER_MANAGER_PAGES = ["BranchTransferDashboard"];

function TransferManagerLayout({ children, currentPageName }) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="flex h-screen bg-[#F4F5F7] overflow-hidden" style={{ fontFamily: "'Inter', 'Segoe UI', sans-serif" }}>
      <aside
        className="flex-shrink-0 flex flex-col bg-white border-r border-gray-200 transition-all duration-300"
        style={{ width: collapsed ? 64 : 220 }}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-gray-100 gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <UtensilsCrossed className="w-4 h-4 text-white" />
          </div>
          {!collapsed && <span className="font-bold text-gray-900 text-base tracking-tight">DENDAX</span>}
          <button onClick={() => setCollapsed(v => !v)} className="ml-auto text-gray-400 hover:text-gray-600 transition">
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Nav — transfer manager only sees Inventory > Branch Transfers */}
        <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
          {!collapsed && (
            <div className="px-3 py-2 mt-1">
              <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Inventory</span>
            </div>
          )}
          <Link
            to={createPageUrl("BranchTransferDashboard")}
            title={collapsed ? "Branch Transfers" : undefined}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium ${
              currentPageName === "BranchTransferDashboard"
                ? "text-white"
                : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
            }`}
            style={currentPageName === "BranchTransferDashboard" ? { background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" } : {}}
          >
            <ArrowLeftRight className="w-4 h-4 shrink-0" />
            {!collapsed && <span>Branch Transfers</span>}
          </Link>
        </nav>

        {!collapsed && (
          <div className="px-4 py-3 border-t border-gray-100">
            <p className="text-[10px] text-gray-400 font-medium uppercase tracking-widest">Transfer Manager</p>
          </div>
        )}
      </aside>
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}

// Pages that cashiers can access (no sidebar)
const CASHIER_PAGES = ["POS", "Orders", "Tables"];
// Pages that kitchen staff can access (no sidebar)
const KITCHEN_PAGES = ["Kitchen"];

export default function Layout({ children, currentPageName }) {
  if (NO_LAYOUT_PAGES.includes(currentPageName)) {
    return <>{children}</>;
  }

  // Check staff session
  let session = null;
  try {
    const raw = localStorage.getItem("pos_staff_session");
    if (raw) session = JSON.parse(raw);
  } catch {}

  // No session — no sidebar
  if (!session) {
    return <><Toaster />{children}</>;
  }

  const roleType = session.role_type;

  // Kitchen staff — no sidebar, only kitchen pages
  if (roleType === "kitchen") {
    return <>{children}</>;
  }

  // Waiter — no sidebar, only Waiter POS
  if (roleType === "waiter") {
    return <>{children}</>;
  }

  // Cashier — no sidebar, only POS/Orders/Tables
  if (roleType === "cashier") {
    return <>{children}</>;
  }

  // Transfer Manager — restricted sidebar, redirect to BranchTransferDashboard if accessing unauthorized page
  if (roleType === "transfer_manager") {
    if (currentPageName !== "BranchTransferDashboard") {
      window.location.href = createPageUrl("BranchTransferDashboard");
      return null;
    }
    return <TransferManagerLayout currentPageName={currentPageName}>{children}</TransferManagerLayout>;
  }

  // Admin / Manager — full sidebar + mobile bottom nav
  return (
    <>
      <style>{`
        body { overscroll-behavior: none; -webkit-tap-highlight-color: transparent; }
        button, a { -webkit-user-select: none; user-select: none; }
        @media (prefers-color-scheme: dark) {
          :root {
            --background: 0 0% 3.9%; --foreground: 0 0% 98%;
            --card: 0 0% 3.9%; --card-foreground: 0 0% 98%;
            --border: 0 0% 14.9%; --input: 0 0% 14.9%;
            --muted: 0 0% 14.9%; --muted-foreground: 0 0% 63.9%;
            --accent: 0 0% 14.9%; --accent-foreground: 0 0% 98%;
          }
        }
        @media (max-width: 767px) {
          .desktop-sidebar { display: none !important; }
          .main-content { padding-bottom: calc(env(safe-area-inset-bottom) + 64px); }
        }
        @media (min-width: 768px) {
          .mobile-bottom-nav { display: none !important; }
        }
      `}</style>
      <AppLayout currentPageName={currentPageName}>{children}</AppLayout>
      <div className="mobile-bottom-nav">
        <MobileNavbar currentPageName={currentPageName} />
      </div>
      <Toaster />
    </>
  );
}

// Re-export Toaster at module level so it's always mounted