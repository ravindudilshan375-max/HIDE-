import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, Delete } from "lucide-react";

export default function InventoryPinLogin({ branchId, onLogin }) {
  const [staff, setStaff] = useState([]);
  const [selected, setSelected] = useState(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const query = branchId ? { branch_id: branchId, is_active: true } : { is_active: true };
    base44.entities.StaffMember.filter(query, "name").then(setStaff);
  }, [branchId]);

  const handleKey = (k) => {
    setError("");
    if (k === "back") { setPin(p => p.slice(0, -1)); return; }
    if (pin.length >= 6) return;
    setPin(p => p + k);
  };

  const handleLogin = async () => {
    if (!selected) { setError("Select a staff member"); return; }
    if (!pin) { setError("Enter your PIN"); return; }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("verifyStaffPin", {
        staff_id: selected.id,
        pin,
        branch_id: selected.branch_id,
      });
      if (res.data?.success) {
        onLogin({ name: selected.name, role: selected.role_type, id: selected.id });
      } else {
        setError(res.data?.message || "Invalid PIN");
        setPin("");
      }
    } catch {
      setError("Login failed. Try again.");
      setPin("");
    }
    setLoading(false);
  };

  const KEYS = ["1","2","3","4","5","6","7","8","9","","0","back"];

  return (
    <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl w-full max-w-sm p-6">
        <h2 className="text-xl font-bold text-gray-900 text-center mb-1">Inventory Login</h2>
        <p className="text-sm text-gray-400 text-center mb-5">Select your name and enter PIN</p>

        {/* Staff list */}
        <div className="grid grid-cols-2 gap-2 mb-5 max-h-40 overflow-y-auto">
          {staff.map(s => (
            <button key={s.id} onClick={() => { setSelected(s); setPin(""); setError(""); }}
              className={`px-3 py-2.5 rounded-xl text-sm font-semibold border-2 transition text-left ${
                selected?.id === s.id
                  ? "border-violet-500 bg-violet-50 text-violet-700"
                  : "border-gray-200 text-gray-700 hover:border-violet-300"
              }`}>
              <p className="truncate">{s.name}</p>
              <p className="text-[10px] font-normal text-gray-400 capitalize">{s.role_type}</p>
            </button>
          ))}
          {staff.length === 0 && (
            <p className="col-span-2 text-xs text-gray-400 text-center py-4">No staff found for this branch</p>
          )}
        </div>

        {/* PIN dots */}
        {selected && (
          <>
            <p className="text-xs text-gray-400 text-center mb-2">PIN for <strong className="text-gray-700">{selected.name}</strong></p>
            <div className="flex justify-center gap-2 mb-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className={`w-3 h-3 rounded-full transition-all ${
                  i < pin.length ? "bg-violet-600 scale-110" : "bg-gray-200"
                }`} />
              ))}
            </div>
          </>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          {KEYS.map((k, i) => (
            k === "" ? <div key={i} /> :
            k === "back" ? (
              <button key={i} onClick={() => handleKey("back")}
                className="h-12 rounded-xl bg-gray-100 active:bg-gray-200 flex items-center justify-center text-gray-500 transition active:scale-95">
                <Delete className="w-5 h-5" />
              </button>
            ) : (
              <button key={i} onClick={() => handleKey(k)}
                className="h-12 rounded-xl bg-gray-100 active:bg-gray-200 text-gray-800 font-bold text-lg transition active:scale-95">
                {k}
              </button>
            )
          ))}
        </div>

        {error && <p className="text-red-500 text-xs text-center mb-3">{error}</p>}

        <button onClick={handleLogin} disabled={loading || !selected || !pin}
          className="w-full py-3.5 rounded-2xl font-bold text-white text-base transition active:scale-95 disabled:opacity-40"
          style={{ background: "linear-gradient(135deg, #7C3AED, #5B21B6)" }}>
          {loading ? "Verifying…" : "Login"}
        </button>
      </div>
    </div>
  );
}