import { LockIcon, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AccessDenied({ feature, currentRole }) {
  return (
    <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center p-6">
      <div className="bg-white border border-gray-200 rounded-2xl p-12 max-w-sm text-center space-y-6">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
            <LockIcon className="w-8 h-8 text-red-600" />
          </div>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Access Denied</h1>
          <p className="text-gray-500 text-sm mt-2">
            You don't have permission to access this feature.
          </p>
        </div>
        <div className="bg-gray-50 rounded-lg p-4 text-xs text-gray-600 space-y-1">
          <p><strong>Feature:</strong> {feature}</p>
          <p><strong>Your Role:</strong> {currentRole.replace("_", " ")}</p>
        </div>
        <Link
          to={createPageUrl("InventoryManagement")}
          className="flex items-center justify-center gap-2 text-violet-600 hover:text-violet-700 font-medium text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Inventory
        </Link>
      </div>
    </div>
  );
}