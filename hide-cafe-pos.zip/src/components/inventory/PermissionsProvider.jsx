import React, { createContext, useContext, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

const PermissionContext = createContext(null);

export const usePermissions = () => {
  const context = useContext(PermissionContext);
  if (!context) {
    throw new Error("usePermissions must be used within PermissionProvider");
  }
  return context;
};

export const PermissionProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [permissions, setPermissions] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserAndPermissions();
  }, []);

  const loadUserAndPermissions = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // System admins always have full access
      if (currentUser?.role === 'admin') {
        setPermissions({ _full_access: true });
      } else if (currentUser?.role_ids?.length > 0) {
        // Load all roles and filter to the user's assigned ones
        const allRoles = await base44.entities.Role.list();
        const userRoles = allRoles.filter(r => currentUser.role_ids.includes(r.id));

        // Merge permissions from all assigned roles — highest level wins
        // Levels: none < view < manage
        const LEVEL_RANK = { none: 0, view: 1, manage: 2 };
        const merged = {};
        userRoles.forEach(role => {
          if (role.permissions) {
            Object.entries(role.permissions).forEach(([key, val]) => {
              // Support old boolean format (true = manage) and new string format
              const incoming = val === true ? "manage" : (val || "none");
              const existing = merged[key] || "none";
              if ((LEVEL_RANK[incoming] || 0) > (LEVEL_RANK[existing] || 0)) {
                merged[key] = incoming;
              }
            });
          }
        });
        setPermissions(merged);
      } else {
        setPermissions({});
      }
    } catch (e) {
      setUser(null);
      setPermissions({});
    } finally {
      setLoading(false);
    }
  };

  const LEVEL_RANK = { none: 0, view: 1, manage: 2 };

  // Check if user has at least a given level ("view" or "manage")
  const hasPermission = (permission, minLevel = "view") => {
    if (permissions._full_access) return true;
    const level = permissions[permission];
    // Support legacy boolean true from old data
    if (level === true) return true;
    return (LEVEL_RANK[level] || 0) >= (LEVEL_RANK[minLevel] || 1);
  };

  const canView = (permission) => hasPermission(permission, "view");
  const canManage = (permission) => hasPermission(permission, "manage");

  const value = {
    user,
    loading,
    permissions,
    hasPermission,
    canView,
    canManage,
    // Helpers — updated to new permission keys
    canAccessInventory: () => canView("inventory"),
    canManageInventory: () => canManage("inventory"),
    canAdjustQuantity: () => canManage("inventory"),
    canAdjustCost: () => canManage("inventory"),
    canManageCategories: () => canManage("inventory"),
    canManageWarehouses: () => canManage("inventory"),
    canCreateOrders: () => canView("orders"),
    canAccessPOS: () => canView("pos"),
    canAccessReports: () => canView("reports"),
    canManageStaff: () => canManage("staff"),
    canManageMenu: () => canManage("menu"),
    canManageDiscounts: () => canView("discounts"),
    canAccessSettings: () => canManage("settings"),
    // Legacy key support
    canAccessInventory_legacy: () => canView("inventory_access") || canView("inventory"),
  };

  return (
    <PermissionContext.Provider value={value}>
      {children}
    </PermissionContext.Provider>
  );
};