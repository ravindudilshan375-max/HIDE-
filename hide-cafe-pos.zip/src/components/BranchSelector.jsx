import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronDown, Building2 } from "lucide-react";

export default function BranchSelector({ currentBranchId, onBranchChange }) {
  const [branches, setBranches] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentBranch, setCurrentBranch] = useState(null);

  useEffect(() => {
    loadBranches();
  }, []);

  useEffect(() => {
    if (branches.length > 0) {
      const selected = branches.find(b => b.id === currentBranchId) || branches[0];
      setCurrentBranch(selected);
    }
  }, [branches, currentBranchId]);

  const loadBranches = async () => {
    setLoading(true);
    const data = await base44.entities.Branch.list();
    setBranches(data.filter(b => b.is_active));
    setLoading(false);
  };

  const handleSelectBranch = (branch) => {
    setCurrentBranch(branch);
    localStorage.setItem("selectedBranchId", branch.id);
    onBranchChange(branch);
    setOpen(false);
  };

  if (loading || branches.length === 0) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition text-sm font-medium text-gray-700"
      >
        <Building2 className="w-4 h-4" />
        {currentBranch ? (
          <>
            {currentBranch.name}
            <ChevronDown className="w-4 h-4 ml-1" />
          </>
        ) : (
          "Select Branch"
        )}
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-40">
          {branches.map(branch => (
            <button
              key={branch.id}
              onClick={() => handleSelectBranch(branch)}
              className={`w-full text-left px-4 py-2.5 transition-colors text-sm font-medium ${
                currentBranch?.id === branch.id
                  ? "bg-violet-100 text-violet-700 border-l-2 border-violet-600"
                  : "text-gray-700 hover:bg-gray-50"
              }`}
            >
              {branch.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}