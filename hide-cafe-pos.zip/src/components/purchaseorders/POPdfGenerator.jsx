import { jsPDF } from "jspdf";
import { format } from "date-fns";

export async function generatePOPdf(po) {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pageW = 210;
  const margin = 15;
  const contentW = pageW - margin * 2;

  // ─── Colors ───────────────────────────────────────────────
  const purple = [91, 44, 192];
  const lightGray = [245, 245, 250];
  const darkGray = [50, 50, 50];
  const midGray = [120, 120, 120];
  const white = [255, 255, 255];

  // ─── Header Bar ───────────────────────────────────────────
  doc.setFillColor(...purple);
  doc.rect(0, 0, pageW, 38, "F");

  // Company name
  doc.setTextColor(...white);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("HIDE CAFE LLC", margin, 15);

  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.text("PURCHASE ORDER", margin, 22);

  // PO meta (right side of header)
  const metaX = pageW - margin;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text(`PO Number: ${po.reference || "—"}`, metaX, 12, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.text(`PO Date: ${fmtDate(po.business_date)}`, metaX, 18, { align: "right" });
  doc.text(`Delivery Date: ${fmtDate(po.delivery_date)}`, metaX, 24, { align: "right" });
  doc.text(`Branch: ${po.destination_branch_name || "—"}`, metaX, 30, { align: "right" });

  // Status badge
  const statusColors = {
    draft: [150, 150, 150],
    approved: [37, 99, 235],
    sent: [124, 58, 237],
    received: [245, 158, 11],
    completed: [22, 163, 74],
    cancelled: [220, 38, 38],
  };
  const sc = statusColors[po.status] || [150, 150, 150];
  doc.setFillColor(...sc);
  doc.roundedRect(margin, 27, 32, 7, 2, 2, "F");
  doc.setTextColor(...white);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text((po.status || "draft").toUpperCase(), margin + 16, 32.2, { align: "center" });

  let y = 48;

  // ─── Supplier / Ship-To ───────────────────────────────────
  const colW = contentW / 2 - 3;

  // Supplier box
  doc.setFillColor(...lightGray);
  doc.roundedRect(margin, y, colW, 32, 3, 3, "F");
  doc.setTextColor(...purple);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text("SUPPLIER", margin + 5, y + 7);
  doc.setTextColor(...darkGray);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(po.supplier_name || "—", margin + 5, y + 15);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...midGray);
  if (po.supplier_email) doc.text(po.supplier_email, margin + 5, y + 22);

  // Ship-To box
  const shipX = margin + colW + 6;
  doc.setFillColor(...lightGray);
  doc.roundedRect(shipX, y, colW, 32, 3, 3, "F");
  doc.setTextColor(...purple);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text("SHIP TO", shipX + 5, y + 7);
  doc.setTextColor(...darkGray);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(po.destination_branch_name || "—", shipX + 5, y + 15);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...midGray);
  doc.text("Hide Cafe LLC", shipX + 5, y + 22);

  y += 40;

  // ─── Items Table ──────────────────────────────────────────
  const cols = [
    { label: "Item Description", x: margin, w: 70 },
    { label: "SKU", x: margin + 70, w: 28 },
    { label: "Qty", x: margin + 98, w: 20 },
    { label: "Unit", x: margin + 118, w: 18 },
    { label: "Unit Price", x: margin + 136, w: 26 },
    { label: "Total", x: margin + 162, w: 28 },
  ];

  // Table header
  doc.setFillColor(...purple);
  doc.rect(margin, y, contentW, 9, "F");
  doc.setTextColor(...white);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  cols.forEach(col => doc.text(col.label, col.x + 2, y + 6));

  y += 9;

  // Table rows
  const items = po.items || [];
  items.forEach((item, i) => {
    const rowH = 9;
    if (i % 2 === 0) {
      doc.setFillColor(250, 250, 255);
      doc.rect(margin, y, contentW, rowH, "F");
    }
    doc.setTextColor(...darkGray);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);

    const truncate = (str, maxLen) => str && str.length > maxLen ? str.slice(0, maxLen) + "…" : (str || "—");
    doc.text(truncate(item.item_name, 38), cols[0].x + 2, y + 6);
    doc.text(truncate(item.sku, 13), cols[1].x + 2, y + 6);
    doc.text(String(item.quantity ?? ""), cols[2].x + 2, y + 6);
    doc.text(item.unit || "", cols[3].x + 2, y + 6);
    doc.setFont("helvetica", "normal");
    doc.text(`${(item.cost_per_unit || 0).toFixed(2)}`, cols[4].x + cols[4].w - 2, y + 6, { align: "right" });
    doc.text(`${(item.total_cost || 0).toFixed(2)}`, cols[5].x + cols[5].w - 2, y + 6, { align: "right" });

    // bottom border
    doc.setDrawColor(230, 230, 235);
    doc.line(margin, y + rowH, margin + contentW, y + rowH);
    y += rowH;
  });

  if (items.length === 0) {
    doc.setTextColor(...midGray);
    doc.setFontSize(9);
    doc.text("No items", margin + contentW / 2, y + 8, { align: "center" });
    y += 12;
  }

  y += 6;

  // ─── Totals ───────────────────────────────────────────────
  const totalsX = margin + contentW - 80;
  const totalsW = 80;

  const subtotal = items.reduce((s, i) => s + (i.total_cost || 0), 0) + (po.additional_cost || 0);
  const taxRate = po.tax_rate ?? 5;
  const taxAmount = subtotal * (taxRate / 100);
  const total = subtotal + taxAmount;

  doc.setFillColor(...lightGray);
  doc.roundedRect(totalsX, y, totalsW, 32, 3, 3, "F");

  doc.setTextColor(...midGray);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text("Subtotal:", totalsX + 5, y + 9);
  doc.text(`VAT (${taxRate}%):`, totalsX + 5, y + 17);

  doc.setTextColor(...darkGray);
  doc.text(`AED ${subtotal.toFixed(2)}`, totalsX + totalsW - 5, y + 9, { align: "right" });
  doc.text(`AED ${taxAmount.toFixed(2)}`, totalsX + totalsW - 5, y + 17, { align: "right" });

  // Total line
  doc.setFillColor(...purple);
  doc.roundedRect(totalsX, y + 21, totalsW, 11, 3, 3, "F");
  doc.setTextColor(...white);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("TOTAL", totalsX + 5, y + 28.5);
  doc.text(`AED ${total.toFixed(2)}`, totalsX + totalsW - 5, y + 28.5, { align: "right" });

  // ─── Notes ────────────────────────────────────────────────
  if (po.notes) {
    doc.setTextColor(...midGray);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.text("NOTES", margin, y + 9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...darkGray);
    doc.text(po.notes, margin, y + 16, { maxWidth: totalsX - margin - 10 });
  }

  // Approval info
  if (po.approved_by) {
    const approvalY = y + (po.notes ? 24 : 9);
    doc.setTextColor(...midGray);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(`Approved by: ${po.approved_by}`, margin, approvalY);
    if (po.approved_date) doc.text(`Approved date: ${fmtDate(po.approved_date)}`, margin, approvalY + 6);
  }

  y += 44;

  // ─── Footer ───────────────────────────────────────────────
  const footerY = 277;
  doc.setFillColor(...purple);
  doc.rect(0, footerY, pageW, 20, "F");
  doc.setTextColor(...white);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text("Generated by Hide Cafe POS", margin, footerY + 8);
  doc.text("hide.uae@gmail.com", pageW / 2, footerY + 8, { align: "center" });
  doc.text(`${po.reference || ""}  ·  ${fmtDate(po.business_date)}`, pageW - margin, footerY + 8, { align: "right" });
  doc.setFontSize(7);
  doc.setTextColor(200, 180, 255);
  doc.text("This is a computer-generated document. No signature required.", pageW / 2, footerY + 15, { align: "center" });

  // ─── Save ─────────────────────────────────────────────────
  doc.save(`${po.reference || "PO"}.pdf`);
}

function fmtDate(d) {
  if (!d) return "—";
  try { return format(new Date(d), "d MMM yyyy"); } catch { return d; }
}