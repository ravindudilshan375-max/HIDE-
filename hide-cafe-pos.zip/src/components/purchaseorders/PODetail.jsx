import React, { useState } from "react";
import { ChevronLeft, Printer, Trash2, Pencil, CheckCircle2, Send, PackageCheck, XCircle, Copy, Download } from "lucide-react";
import { generatePOPdf } from "./POPdfGenerator";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import AddItemsModal from "./AddItemsModal";
import UpdateItemModal from "./UpdateItemModal";
import POInvoiceSection from "./POInvoiceSection";
import ReceiveOrderModal from "./ReceiveOrderModal";

const STATUS_BADGES = {
  draft:     "bg-gray-700 text-white",
  approved:  "bg-blue-600 text-white",
  sent:      "bg-violet-600 text-white",
  received:  "bg-amber-500 text-white",
  completed: "bg-green-600 text-white",
  cancelled: "bg-red-500 text-white",
};

function InfoField({ label, value }) {
  return (
    <div className="py-3 border-b border-gray-100 last:border-0">
      <p className="text-xs text-gray-400 mb-1">{label}</p>
      <p className="text-sm text-gray-800">{value || "—"}</p>
    </div>
  );
}

export default function PODetail({ po: initialPo, onBack, onDuplicate, onEdit, inventoryItems = [] }) {
  const [po, setPo] = useState(initialPo);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);

  const fmtDate = (d) => { if (!d) return "—"; try { return format(new Date(d), "d MMM yyyy"); } catch { return d; } };
  const fmtDateTime = (d) => { if (!d) return "—"; try { return format(new Date(d), "d MMM yyyy, HH:mm"); } catch { return d; } };

  const subtotal = (po.items || []).reduce((s, i) => s + (i.total_cost || 0), 0) + (po.additional_cost || 0);
  const taxRate = po.tax_rate ?? 5;
  const taxAmount = subtotal * (taxRate / 100);
  const total = subtotal + taxAmount;

  const persist = async (updatedPo) => {
    setPo(updatedPo);
    await base44.entities.PurchaseOrder.update(updatedPo.id, {
      items: updatedPo.items,
      total_cost: total,
      number_of_items: updatedPo.items.length,
    });
    toast.success("Purchase order updated");
  };

  const handleAddItem = (inv) => {
    const newItem = {
      inventory_item_id: inv.id,
      item_name: inv.name,
      sku: inv.sku || "",
      available_quantity: inv.current_quantity || 0,
      unit: inv.storage_unit || inv.unit || "",
      cost_per_unit: inv.unit_cost || 0,
      quantity: 1,
      total_cost: inv.unit_cost || 0,
      received_quantity: 0,
    };
    persist({ ...po, items: [...(po.items || []), newItem] });
  };

  const handleUpdateItem = (idx, updatedItem) => {
    const items = [...(po.items || [])];
    items[idx] = updatedItem;
    persist({ ...po, items });
  };

  const handleDeleteItem = (idx) => {
    persist({ ...po, items: (po.items || []).filter((_, i) => i !== idx) });
  };

  // Draft → Approved
  const handleApprove = async () => {
    setSaving(true);
    const user = await base44.auth.me().catch(() => null);
    const approvedBy = user?.full_name || user?.email || "Manager";
    const approvedDate = new Date().toISOString().split("T")[0];
    const updated = { ...po, status: "approved", approved_by: approvedBy, approved_date: approvedDate };
    setPo(updated);
    await base44.entities.PurchaseOrder.update(po.id, { status: "approved", approved_by: approvedBy, approved_date: approvedDate });
    toast.success("Purchase order approved!");
    setSaving(false);
  };

  // Approved → Sent (email vendor via backend function)
  const handleSendToVendor = async () => {
    if (!po.supplier_email) {
      toast.error("No supplier email on record. Edit the order to add one.");
      return;
    }
    setSaving(true);
    const res = await base44.functions.invoke("sendPurchaseOrderEmail", { po_id: po.id });
    if (res.data?.success) {
      const sentDate = new Date().toISOString();
      setPo({ ...po, status: "sent", sent_date: sentDate });
      toast.success(`Email sent to ${po.supplier_email}!`);
    } else {
      toast.error(res.data?.error || "Failed to send email");
    }
    setSaving(false);
  };

  // Sent → Received (update inventory) — called from ReceiveOrderModal
  const handleMarkReceived = async (receivedItems, invoiceUpdates = {}) => {
    setSaving(true);
    for (const item of receivedItems) {
      if (!item.inventory_item_id) continue;
      const qtyToAdd = item.received_quantity || 0;
      const invItem = await base44.entities.InventoryItem.get(item.inventory_item_id).catch(() => null);
      if (!invItem) continue;
      let targetItem = invItem;
      if (po.destination_branch_id && invItem.branch_id !== po.destination_branch_id) {
        const branchItems = await base44.entities.InventoryItem.filter({ name: invItem.name, branch_id: po.destination_branch_id });
        if (branchItems?.length > 0) targetItem = branchItems[0];
      }
      await base44.entities.InventoryItem.update(targetItem.id, { current_quantity: (targetItem.current_quantity || 0) + qtyToAdd });
    }
    const receivedDate = new Date().toISOString();
    const updates = { status: "received", received_date: receivedDate, items: receivedItems, ...invoiceUpdates };
    const updated = { ...po, ...updates };
    setPo(updated);
    await base44.entities.PurchaseOrder.update(po.id, updates);
    toast.success("Goods received — inventory updated!");
    setShowReceiveModal(false);
    setSaving(false);
  };

  // Received → Completed
  const handleComplete = async () => {
    const updated = { ...po, status: "completed" };
    setPo(updated);
    await base44.entities.PurchaseOrder.update(po.id, { status: "completed" });
    toast.success("Purchase order completed!");
  };

  const handleReject = async () => {
    if (!window.confirm("Cancel this purchase order?")) return;
    const updated = { ...po, status: "cancelled" };
    setPo(updated);
    await base44.entities.PurchaseOrder.update(po.id, { status: "cancelled" });
    toast.success("Purchase order cancelled");
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this purchase order permanently?")) return;
    await base44.entities.PurchaseOrder.delete(po.id);
    toast.success("Deleted");
    onBack();
  };

  const canEdit = po.status === "draft";

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <button onClick={onBack} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-3">
            <ChevronLeft className="w-4 h-4" /> Back to Purchase Orders
          </button>
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-2xl font-bold text-gray-900">{po.reference || "Purchase Order"}</h1>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize ${STATUS_BADGES[po.status] || "bg-gray-700 text-white"}`}>
                  {po.status}
                </span>
              </div>
              <p className="text-sm text-gray-400 mt-1">{po.supplier_name} · {po.destination_branch_name}</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Button variant="outline" onClick={() => window.print()} className="border-gray-200 rounded-xl gap-2 text-sm">
                <Printer className="w-4 h-4" /> Print
              </Button>
              <Button variant="outline" onClick={() => generatePOPdf(po)} className="border-gray-200 rounded-xl gap-2 text-sm">
                <Download className="w-4 h-4" /> Download PDF
              </Button>
              {onDuplicate && (
                <Button variant="outline" onClick={() => onDuplicate(po)} className="border-gray-200 rounded-xl gap-2 text-sm">
                  <Copy className="w-4 h-4" /> Duplicate
                </Button>
              )}
              {canEdit && (
                <>
                  <Button variant="outline" onClick={() => onEdit && onEdit(po)} className="border-gray-200 rounded-xl gap-2 text-sm">
                    <Pencil className="w-4 h-4" /> Edit
                  </Button>
                  <Button variant="outline" onClick={handleDelete} className="border-red-100 text-red-500 hover:bg-red-50 rounded-xl gap-2 text-sm">
                    <Trash2 className="w-4 h-4" /> Delete
                  </Button>
                  <Button onClick={handleApprove} disabled={saving} className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold gap-2">
                    <CheckCircle2 className="w-4 h-4" /> Approve
                  </Button>
                </>
              )}
              {po.status === "approved" && (
                <>
                  <Button variant="outline" onClick={handleReject} className="border-red-100 text-red-500 hover:bg-red-50 rounded-xl gap-2 text-sm">
                    <XCircle className="w-4 h-4" /> Cancel
                  </Button>
                  <Button onClick={handleSendToVendor} disabled={saving} className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl font-semibold gap-2">
                    <Send className="w-4 h-4" /> Send to Vendor
                  </Button>
                </>
              )}
              {(po.status === "sent" || po.status === "approved") && (
                <>
                  {po.status === "sent" && (
                    <Button onClick={handleSendToVendor} disabled={saving} variant="outline" className="border-violet-200 text-violet-600 hover:bg-violet-50 rounded-xl gap-2 text-sm">
                      <Send className="w-4 h-4" /> Resend Email
                    </Button>
                  )}
                  <Button onClick={() => setShowReceiveModal(true)} disabled={saving} className="bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-semibold gap-2">
                    <PackageCheck className="w-4 h-4" /> Receive Order
                  </Button>
                </>
              )}
              {po.status === "received" && (
                <Button onClick={handleComplete} disabled={saving} className="bg-green-600 hover:bg-green-700 text-white rounded-xl font-semibold gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Complete Order
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Workflow tracker */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-6 py-4">
          <div className="flex items-center gap-0">
            {["draft", "approved", "sent", "received", "completed"].map((step, idx, arr) => {
              const statusOrder = ["draft", "approved", "sent", "received", "completed"];
              const currentIdx = statusOrder.indexOf(po.status);
              const stepIdx = statusOrder.indexOf(step);
              const isActive = po.status === step;
              const isDone = currentIdx > stepIdx;
              const labels = { draft: "Draft", approved: "Approved", sent: "Sent", received: "Received", completed: "Completed" };
              return (
                <React.Fragment key={step}>
                  <div className="flex flex-col items-center flex-1 min-w-0">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mb-1 border-2 transition-all ${
                      isActive ? "bg-violet-600 border-violet-600 text-white" :
                      isDone ? "bg-green-500 border-green-500 text-white" :
                      "bg-white border-gray-200 text-gray-300"
                    }`}>
                      {isDone ? "✓" : idx + 1}
                    </div>
                    <span className={`text-[10px] font-semibold text-center truncate w-full px-1 ${isActive ? "text-violet-700" : isDone ? "text-green-600" : "text-gray-300"}`}>
                      {labels[step]}
                    </span>
                  </div>
                  {idx < arr.length - 1 && (
                    <div className={`h-0.5 flex-1 mt-[-14px] transition-all ${isDone ? "bg-green-400" : "bg-gray-200"}`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Info card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-12">
            <InfoField label="Supplier" value={po.supplier_name} />
            <InfoField label="Supplier Email" value={po.supplier_email} />
            <InfoField label="Destination Branch" value={po.destination_branch_name} />
            <InfoField label="Business Date" value={fmtDate(po.business_date)} />
            <InfoField label="Delivery Date" value={fmtDate(po.delivery_date)} />
            <InfoField label="Created By" value={po.creator_name} />
            {po.approved_by && <InfoField label="Approved By" value={po.approved_by} />}
            {po.approved_date && <InfoField label="Approved Date" value={fmtDate(po.approved_date)} />}
            {po.sent_date && <InfoField label="Sent to Vendor" value={fmtDateTime(po.sent_date)} />}
            {po.received_date && <InfoField label="Received Date" value={fmtDateTime(po.received_date)} />}
            {po.notes && <InfoField label="Notes" value={po.notes} />}
          </div>
        </div>

        {/* Items */}
        <div>
          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
            <h2 className="text-base font-semibold text-gray-800">Items</h2>
            {canEdit && (
              <Button onClick={() => setShowAddModal(true)} className="bg-violet-700 hover:bg-violet-800 text-white rounded-xl text-sm">Add Items</Button>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {(!po.items || po.items.length === 0) ? (
              <div className="py-12 text-center text-gray-400 text-sm">No items added yet</div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50">
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Item</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wider">Qty</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wider">Unit Cost</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {po.items.map((item, i) => (
                    <tr key={i} className={`border-b border-gray-50 last:border-0 transition ${canEdit ? "hover:bg-gray-50 cursor-pointer" : ""}`}
                      onClick={() => canEdit && setEditItem({ item, index: i })}>
                      <td className="px-5 py-3.5">
                        <p className="font-medium text-gray-800">{item.item_name}</p>
                        {item.sku && <p className="text-xs text-gray-400 font-mono">{item.sku}</p>}
                      </td>
                      <td className="px-4 py-3.5 text-center text-gray-700">{item.quantity} {item.unit}</td>
                      <td className="px-4 py-3.5 text-center text-gray-700">AED {(item.cost_per_unit || 0).toFixed(2)}</td>
                      <td className="px-4 py-3.5 text-right font-semibold text-gray-800">AED {(item.total_cost || 0).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Financial summary */}
          <div className="flex justify-end mt-3">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 w-full max-w-xs space-y-2 text-sm">
              <div className="flex justify-between text-gray-500">
                <span>Subtotal</span>
                <span>AED {subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>VAT ({taxRate}%)</span>
                <span>AED {taxAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-gray-900 text-base pt-2 border-t border-gray-100">
                <span>Total</span>
                <span>AED {total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Invoice Section */}
        <POInvoiceSection po={po} onUpdate={setPo} />

        {!po.supplier_email && (po.status === "approved" || po.status === "draft") && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-sm text-amber-700 flex items-start gap-3">
            <span className="text-lg">⚠️</span>
            <div>
              <p className="font-semibold">No supplier email — email cannot be sent</p>
              <p className="mt-1 text-amber-600">This PO was created from a weekly request without a vendor assigned. Click <strong>Edit</strong> to select a supplier with an email address before approving and sending.</p>
            </div>
          </div>
        )}
      </div>

      {showAddModal && (
        <AddItemsModal
          inventoryItems={inventoryItems.filter(i => !po.destination_branch_id || i.branch_id === po.destination_branch_id)}
          existingItems={po.items || []}
          onAdd={handleAddItem}
          onClose={() => setShowAddModal(false)}
        />
      )}

      {showReceiveModal && (
        <ReceiveOrderModal
          po={po}
          onConfirm={handleMarkReceived}
          onClose={() => setShowReceiveModal(false)}
        />
      )}

      {editItem && !editItem.bulkEdit && (
        <UpdateItemModal
          item={editItem.item}
          itemIndex={editItem.index}
          onSave={handleUpdateItem}
          onDelete={handleDeleteItem}
          onClose={() => setEditItem(null)}
        />
      )}
    </div>
  );
}