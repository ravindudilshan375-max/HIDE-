import React, { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function UpdateItemModal({ item, itemIndex, onSave, onDelete, onClose }) {
  const [quantity, setQuantity] = useState(item.quantity ?? 1);
  const [totalCost, setTotalCost] = useState(item.total_cost ?? 0);

  const handleSave = () => {
    onSave(itemIndex, {
      ...item,
      quantity: Number(quantity),
      total_cost: Number(totalCost),
      cost_per_unit: quantity > 0 ? Number(totalCost) / Number(quantity) : 0,
    });
    onClose();
  };

  const title = `Update Item: ${item.item_name}${item.sku ? ` (${item.sku})` : ""}`;

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="w-9 h-9 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-6 space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Quantity({item.unit || "Unit"})<span className="text-red-500">*</span>
            </label>
            <Input
              type="number"
              min="0"
              value={quantity}
              onChange={e => setQuantity(e.target.value)}
              className="border-gray-200 rounded-xl h-12 text-base"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Total Cost(฿)<span className="text-red-500">*</span>
            </label>
            <Input
              type="number"
              min="0"
              step="0.01"
              value={totalCost}
              onChange={e => setTotalCost(e.target.value)}
              className="border-gray-200 rounded-xl h-12 text-base"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100">
          <button onClick={() => { onDelete(itemIndex); onClose(); }} className="text-red-500 text-sm font-medium hover:text-red-700 transition">
            Delete Item
          </button>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="rounded-xl px-6">Close</Button>
            <Button onClick={handleSave} className="bg-violet-700 hover:bg-violet-800 text-white rounded-xl px-6">Save</Button>
          </div>
        </div>
      </div>
    </div>
  );
}