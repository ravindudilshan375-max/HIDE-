import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, Trash2, Plus, Search, X } from "lucide-react";
import { toast } from "sonner";

export default function POForm({ initialData, onSaved, onCancel }) {
  const [suppliers, setSuppliers] = useState([]);
  const [branches, setBranches] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    supplier_id: "",
    supplier_name: "",
    destination_branch_id: "",
    destination_branch_name: "",
    status: "draft",
    business_date: new Date().toISOString().split("T")[0],
    delivery_date: "",
    additional_cost: 0,
    notes: "",
    items: [],
    ...(initialData || {})
  });

  const [itemSearch, setItemSearch] = useState("");
  const [filteredInvItems, setFilteredInvItems] = useState([]);
  const [showSearch, setShowSearch] = useState(false);
  const [showItemModal, setShowItemModal] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.Supplier.list("name"),
      base44.entities.Branch.list("name"),
      base44.entities.InventoryItem.list("name"),
    ]).then(([s, b, inv]) => {
      setSuppliers(s);
      setBranches(b);
      setInventoryItems(inv);
    });
  }, []);

  useEffect(() => {
    if (itemSearch.trim()) {
      setFilteredInvItems(inventoryItems.filter(i =>
        i.name.toLowerCase().includes(itemSearch.toLowerCase())
      ));
    } else {
      setFilteredInvItems([]);
    }
  }, [itemSearch, inventoryItems]);

  const addItem = (invItem) => {
    const already = form.items.find(i => i.inventory_item_id === invItem.id);
    if (already) { toast.error("Item already added"); return; }
    setForm(prev => ({
      ...prev,
      items: [...prev.items, {
        inventory_item_id: invItem.id,
        item_name: invItem.name,
        sku: invItem.sku || "",
        available_quantity: invItem.current_quantity || 0,
        unit: invItem.storage_unit || invItem.unit || "",
        cost_per_unit: invItem.unit_cost || 0,
        quantity: 1,
        total_cost: invItem.unit_cost || 0,
        received_quantity: 0,
      }]
    }));
    setItemSearch("");
    setShowItemModal(false);
    toast.success(`${invItem.name} added`);
  };

  const updateItem = (idx, field, value) => {
    setForm(prev => {
      const items = [...prev.items];
      items[idx] = { ...items[idx], [field]: value };
      if (field === "quantity" || field === "cost_per_unit") {
        items[idx].total_cost = (items[idx].quantity || 0) * (items[idx].cost_per_unit || 0);
      }
      return { ...prev, items };
    });
  };

  const removeItem = (idx) => setForm(prev => ({ ...prev, items: prev.items.filter((_, i) => i !== idx) }));

  const subtotal = form.items.reduce((s, i) => s + (i.total_cost || 0), 0) + (Number(form.additional_cost) || 0);
  const taxRate = form.tax_rate ?? 5;
  const taxAmount = subtotal * (taxRate / 100);
  const totalCost = subtotal + taxAmount;

  const save = async () => {
    if (!form.supplier_name) { toast.error("Select a supplier"); return; }
    setSaving(true);

    // Generate reference if new
    let reference = form.reference;
    if (!reference) {
      const existing = await base44.entities.PurchaseOrder.list("-created_date", 1);
      const last = existing[0]?.reference;
      let num = 1;
      if (last) {
        const match = last.match(/PO-(\d+)/);
        if (match) num = parseInt(match[1]) + 1;
      }
      reference = `PO-${String(num).padStart(6, "0")}`;
    }

    const data = {
      ...form,
      reference,
      subtotal,
      tax_rate: taxRate,
      tax_amount: taxAmount,
      total_cost: totalCost,
      number_of_items: form.items.length,
      additional_cost: Number(form.additional_cost) || 0,
    };

    if (initialData?.id) {
      await base44.entities.PurchaseOrder.update(initialData.id, data);
    } else {
      await base44.entities.PurchaseOrder.create(data);
    }

    toast.success("Purchase order saved");
    setSaving(false);
    onSaved();
  };

  return (
    <>
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <button onClick={onCancel} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-2">
            <ChevronLeft className="w-4 h-4" /> Back
          </button>
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900">
              {initialData ? `Edit Purchase Order` : "New Purchase Order"}
            </h1>
            <Button disabled={saving} onClick={save} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
              {saving ? "Saving..." : "Save Purchase Order"}
            </Button>
          </div>
        </div>

        {/* Info */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Supplier</label>
              <select
                value={form.supplier_id}
                onChange={e => {
                  const s = suppliers.find(x => x.id === e.target.value);
                  setForm(prev => ({ ...prev, supplier_id: e.target.value, supplier_name: s?.name || "", supplier_email: s?.email || prev.supplier_email || "" }));
                }}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="">Select supplier</option>
                {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              {form.supplier_email && <p className="text-xs text-gray-400 mt-1">📧 {form.supplier_email}</p>}
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Destination Branch</label>
              <select
                value={form.destination_branch_id}
                onChange={e => {
                  const b = branches.find(x => x.id === e.target.value);
                  setForm(prev => ({ ...prev, destination_branch_id: e.target.value, destination_branch_name: b?.name || "" }));
                }}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="">Select branch</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Business Date</label>
              <Input type="date" value={form.business_date} onChange={e => setForm(prev => ({ ...prev, business_date: e.target.value }))} className="border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Delivery Date</label>
              <Input type="date" value={form.delivery_date} onChange={e => setForm(prev => ({ ...prev, delivery_date: e.target.value }))} className="border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Additional Cost (฿)</label>
              <Input type="number" step="0.01" value={form.additional_cost} onChange={e => setForm(prev => ({ ...prev, additional_cost: e.target.value }))} className="border-gray-200 rounded-xl" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">VAT %</label>
              <Input type="number" step="0.01" value={form.tax_rate ?? 5} onChange={e => setForm(prev => ({ ...prev, tax_rate: Number(e.target.value) }))} className="border-gray-200 rounded-xl" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs text-gray-400 mb-1">Notes</label>
              <Input value={form.notes || ""} onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))} className="border-gray-200 rounded-xl" placeholder="Optional notes..." />
            </div>
          </div>
        </div>

        {/* Items */}
        <div>
          <h2 className="text-base font-semibold text-gray-800 mb-3">Items</h2>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {form.items.length > 0 && (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Name</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">SKU</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Available Qty</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Cost / Unit</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Quantity</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Total Cost</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Received Qty</th>
                    <th className="px-3 py-3 w-10" />
                  </tr>
                </thead>
                <tbody>
                  {form.items.map((item, i) => (
                    <tr key={i} className="border-b border-gray-50 last:border-0">
                      <td className="px-5 py-3 text-gray-800 font-medium text-sm">{item.item_name}</td>
                      <td className="px-4 py-3 text-gray-500 font-mono text-xs">{item.sku || "—"}</td>
                      <td className="px-4 py-3 text-gray-600 text-sm">{item.available_quantity} {item.unit}</td>
                      <td className="px-4 py-3">
                        <Input type="number" step="0.01" value={item.cost_per_unit} onChange={e => updateItem(i, "cost_per_unit", Number(e.target.value))} className="border-gray-200 rounded-lg h-8 w-24 text-sm" />
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <Input type="number" min="0" value={item.quantity} onChange={e => updateItem(i, "quantity", Number(e.target.value))} className="border-gray-200 rounded-lg h-8 w-20 text-sm" />
                          <span className="text-xs text-gray-400">{item.unit}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-gray-800 font-medium text-sm">฿ {(item.total_cost || 0).toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          <Input type="number" min="0" value={item.received_quantity} onChange={e => updateItem(i, "received_quantity", Number(e.target.value))} className="border-gray-200 rounded-lg h-8 w-20 text-sm" />
                          <span className="text-xs text-gray-400">{item.unit}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <button onClick={() => removeItem(i)} className="text-gray-300 hover:text-red-500 transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {/* Add item button */}
            <div className="p-4 border-t border-gray-50">
              <button
                onClick={() => { setItemSearch(""); setShowItemModal(true); }}
                className="flex items-center gap-2 text-sm text-violet-600 hover:text-violet-800 font-medium transition"
              >
                <Plus className="w-4 h-4" /> Add Item
              </button>
            </div>
          </div>

          {/* Total summary */}
          <div className="flex justify-end mt-3">
            <div className="bg-white rounded-2xl border border-gray-100 px-6 py-4 space-y-2 text-sm w-full max-w-xs">
              <div className="flex justify-between text-gray-500"><span>Subtotal</span><span>AED {subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-500"><span>VAT ({taxRate}%)</span><span>AED {taxAmount.toFixed(2)}</span></div>
              <div className="flex justify-between font-bold text-gray-900 text-base pt-2 border-t border-gray-100"><span>Total</span><span>AED {totalCost.toFixed(2)}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Item picker modal */}
    {showItemModal && (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg flex flex-col" style={{ maxHeight: "80vh" }}>
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h3 className="text-base font-semibold text-gray-900">Add Item</h3>
            <button onClick={() => setShowItemModal(false)} className="text-gray-400 hover:text-gray-600">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Search */}
          <div className="px-4 py-3 border-b border-gray-100">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                autoFocus
                placeholder="Search items..."
                value={itemSearch}
                onChange={e => setItemSearch(e.target.value)}
                className="pl-9 border-gray-200 rounded-xl"
              />
            </div>
          </div>

          {/* Results */}
          <div className="flex-1 overflow-y-auto">
            {(() => {
              const results = itemSearch.trim()
                ? inventoryItems.filter(i => i.name.toLowerCase().includes(itemSearch.toLowerCase()))
                : inventoryItems;
              if (results.length === 0) return (
                <p className="text-center text-sm text-gray-400 py-10">No items found</p>
              );
              return results.map(item => {
                const alreadyAdded = form.items.some(i => i.inventory_item_id === item.id);
                return (
                  <button
                    key={item.id}
                    disabled={alreadyAdded}
                    onClick={() => addItem(item)}
                    className={`w-full text-left px-5 py-3 flex items-center justify-between border-b border-gray-50 last:border-0 transition ${
                      alreadyAdded ? "opacity-40 cursor-not-allowed" : "hover:bg-violet-50"
                    }`}
                  >
                    <div>
                      <p className="text-sm font-medium text-gray-800">{item.name}</p>
                      <p className="text-xs text-gray-400">{item.sku ? `SKU: ${item.sku} · ` : ""}Storage: {item.storage_unit || item.unit || "—"} · Stock: {item.current_quantity ?? 0}</p>
                    </div>
                    {alreadyAdded ? (
                      <span className="text-xs text-gray-400">Added</span>
                    ) : (
                      <Plus className="w-4 h-4 text-violet-500 shrink-0" />
                    )}
                  </button>
                );
              });
            })()}
          </div>
        </div>
      </div>
    )}
    </>
  );
}