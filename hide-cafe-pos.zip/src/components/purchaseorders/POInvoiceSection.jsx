import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Upload, FileText, Eye, Download, X, Loader2, Scan, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";

export default function POInvoiceSection({ po, onUpdate }) {
  const [uploading, setUploading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(!po.invoice_file_url);
  const [invoiceNumber, setInvoiceNumber] = useState(po.invoice_number || "");
  const [invoiceDate, setInvoiceDate] = useState(po.invoice_date || "");
  const [invoiceTotal, setInvoiceTotal] = useState(po.invoice_total || "");
  const [fileUrl, setFileUrl] = useState(po.invoice_file_url || "");
  const [scanResult, setScanResult] = useState(null);

  const hasInvoice = !!po.invoice_file_url;

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowed = ["application/pdf", "image/jpeg", "image/png", "image/jpg"];
    if (!allowed.includes(file.type)) {
      toast.error("Only PDF, JPG, or PNG files are allowed");
      return;
    }
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFileUrl(file_url);
    setUploading(false);
    toast.success("File uploaded — click 'Scan with AI' to extract invoice data");
  };

  const handleAIScan = async () => {
    if (!fileUrl) { toast.error("Upload an invoice file first"); return; }
    setScanning(true);
    setScanResult(null);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an invoice data extractor. Analyze this supplier invoice image/document and extract the following fields. Return ONLY a JSON object with these exact keys:
- invoice_number: the invoice/tax invoice number (string)
- invoice_date: date in YYYY-MM-DD format (string)
- supplier_name: supplier/vendor company name (string)
- subtotal: subtotal amount before tax (number)
- tax_amount: VAT/tax amount (number)
- total: final total amount (number)
- currency: currency code e.g. AED, USD (string)

If a field is not found, set it to null. Do not include any explanation, only return the JSON.`,
      file_urls: [fileUrl],
      response_json_schema: {
        type: "object",
        properties: {
          invoice_number: { type: "string" },
          invoice_date: { type: "string" },
          supplier_name: { type: "string" },
          subtotal: { type: "number" },
          tax_amount: { type: "number" },
          total: { type: "number" },
          currency: { type: "string" },
        }
      }
    });

    if (result) {
      setScanResult(result);
      if (result.invoice_number) setInvoiceNumber(result.invoice_number);
      if (result.invoice_date) setInvoiceDate(result.invoice_date);
      if (result.total) setInvoiceTotal(result.total);
      toast.success("Invoice scanned — please verify the extracted data");
    } else {
      toast.error("Could not extract data from invoice");
    }
    setScanning(false);
  };

  const handleSave = async () => {
    if (!fileUrl) { toast.error("Please upload an invoice file first"); return; }
    setSaving(true);
    const user = await base44.auth.me().catch(() => null);
    const updates = {
      invoice_number: invoiceNumber,
      invoice_date: invoiceDate,
      invoice_total: invoiceTotal ? Number(invoiceTotal) : null,
      invoice_file_url: fileUrl,
      invoice_uploaded_by: user?.full_name || user?.email || "Staff",
      invoice_uploaded_at: new Date().toISOString(),
    };
    await base44.entities.PurchaseOrder.update(po.id, updates);
    onUpdate({ ...po, ...updates });
    setEditMode(false);
    toast.success("Invoice saved to purchase order");
    setSaving(false);
  };

  const handleRemove = async () => {
    if (!window.confirm("Remove invoice from this PO?")) return;
    const updates = { invoice_number: null, invoice_date: null, invoice_total: null, invoice_file_url: null, invoice_uploaded_by: null, invoice_uploaded_at: null };
    await base44.entities.PurchaseOrder.update(po.id, updates);
    onUpdate({ ...po, ...updates });
    setFileUrl("");
    setInvoiceNumber("");
    setInvoiceDate("");
    setInvoiceTotal("");
    setEditMode(true);
    toast.success("Invoice removed");
  };

  const isImage = fileUrl && (fileUrl.includes(".jpg") || fileUrl.includes(".jpeg") || fileUrl.includes(".png") || fileUrl.includes("image"));

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      {/* Section header */}
      <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-violet-500" />
          <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wider">Supplier Invoice</h2>
        </div>
        {hasInvoice && !editMode && (
          <button onClick={() => setEditMode(true)} className="text-xs text-violet-600 hover:underline font-medium">
            Edit
          </button>
        )}
      </div>

      <div className="p-6">
        {/* Saved invoice view */}
        {hasInvoice && !editMode ? (
          <div className="space-y-4">
            {/* Info row */}
            <div className="grid grid-cols-3 gap-4 text-sm">
              {po.invoice_number && (
                <div>
                  <p className="text-xs text-gray-400 mb-1">Invoice Number</p>
                  <p className="font-semibold text-gray-800">{po.invoice_number}</p>
                </div>
              )}
              {po.invoice_date && (
                <div>
                  <p className="text-xs text-gray-400 mb-1">Invoice Date</p>
                  <p className="font-semibold text-gray-800">
                    {(() => { try { return format(new Date(po.invoice_date), "d MMM yyyy"); } catch { return po.invoice_date; } })()}
                  </p>
                </div>
              )}
              {po.invoice_total != null && (
                <div>
                  <p className="text-xs text-gray-400 mb-1">Invoice Total</p>
                  <p className="font-bold text-violet-700 text-base">AED {Number(po.invoice_total).toFixed(2)}</p>
                </div>
              )}
            </div>

            {/* File preview */}
            <div className="border border-gray-200 rounded-xl overflow-hidden">
              {isImage ? (
                <img src={po.invoice_file_url} alt="Invoice" className="w-full max-h-64 object-contain bg-gray-50" />
              ) : (
                <div className="flex items-center justify-between px-4 py-3 bg-gray-50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-red-500" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-800">Invoice PDF</p>
                      {po.invoice_number && <p className="text-xs text-gray-400">{po.invoice_number}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <a href={po.invoice_file_url} target="_blank" rel="noopener noreferrer">
                      <Button variant="outline" size="sm" className="rounded-lg gap-1.5 text-xs border-gray-200">
                        <Eye className="w-3.5 h-3.5" /> View
                      </Button>
                    </a>
                    <a href={po.invoice_file_url} download>
                      <Button variant="outline" size="sm" className="rounded-lg gap-1.5 text-xs border-gray-200">
                        <Download className="w-3.5 h-3.5" /> Download
                      </Button>
                    </a>
                  </div>
                </div>
              )}
              {isImage && (
                <div className="flex items-center justify-end gap-2 px-4 py-2 border-t border-gray-100 bg-white">
                  <a href={po.invoice_file_url} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm" className="rounded-lg gap-1.5 text-xs border-gray-200">
                      <Eye className="w-3.5 h-3.5" /> View Full
                    </Button>
                  </a>
                  <a href={po.invoice_file_url} download>
                    <Button variant="outline" size="sm" className="rounded-lg gap-1.5 text-xs border-gray-200">
                      <Download className="w-3.5 h-3.5" /> Download
                    </Button>
                  </a>
                </div>
              )}
            </div>

            {/* Upload meta */}
            {po.invoice_uploaded_by && (
              <p className="text-xs text-gray-400">
                Uploaded by <span className="font-medium text-gray-600">{po.invoice_uploaded_by}</span>
                {po.invoice_uploaded_at && <> · {(() => { try { return format(new Date(po.invoice_uploaded_at), "d MMM yyyy, HH:mm"); } catch { return ""; } })()}</>}
              </p>
            )}

            <button onClick={handleRemove} className="text-xs text-red-400 hover:text-red-600 flex items-center gap-1 transition">
              <X className="w-3 h-3" /> Remove invoice
            </button>
          </div>
        ) : (
          /* Upload / Edit form */
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Invoice Number</label>
                <Input value={invoiceNumber} onChange={e => setInvoiceNumber(e.target.value)} placeholder="INV-55313" className="border-gray-200 rounded-xl" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Invoice Date</label>
                <Input type="date" value={invoiceDate} onChange={e => setInvoiceDate(e.target.value)} className="border-gray-200 rounded-xl" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Invoice Total (AED)</label>
                <Input type="number" step="0.01" value={invoiceTotal} onChange={e => setInvoiceTotal(e.target.value)} placeholder="0.00" className="border-gray-200 rounded-xl" />
              </div>
            </div>

            {/* File upload area */}
            {fileUrl ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-4 py-3">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-700 font-medium">File uploaded successfully</span>
                  </div>
                  <button onClick={() => { setFileUrl(""); setScanResult(null); }} className="text-gray-400 hover:text-red-400 transition">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* AI Scan button */}
                <Button
                  variant="outline"
                  onClick={handleAIScan}
                  disabled={scanning}
                  className="w-full border-violet-200 text-violet-700 hover:bg-violet-50 rounded-xl gap-2 font-semibold"
                >
                  {scanning ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Scanning with AI...</>
                  ) : (
                    <><Sparkles className="w-4 h-4" /> Scan with AI — Extract Invoice Data</>
                  )}
                </Button>

                {/* Scan result summary */}
                {scanResult && (
                  <div className="bg-violet-50 border border-violet-100 rounded-xl p-4 text-sm space-y-1">
                    <p className="text-xs font-bold text-violet-600 uppercase tracking-wider mb-2 flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> AI Extracted — verify below
                    </p>
                    {scanResult.supplier_name && <p className="text-gray-700"><span className="text-gray-400">Supplier:</span> <strong>{scanResult.supplier_name}</strong></p>}
                    {scanResult.subtotal != null && <p className="text-gray-700"><span className="text-gray-400">Subtotal:</span> {scanResult.currency || "AED"} {scanResult.subtotal?.toFixed(2)}</p>}
                    {scanResult.tax_amount != null && <p className="text-gray-700"><span className="text-gray-400">VAT:</span> {scanResult.currency || "AED"} {scanResult.tax_amount?.toFixed(2)}</p>}
                    {scanResult.total != null && <p className="text-gray-700"><span className="text-gray-400">Total:</span> <strong>{scanResult.currency || "AED"} {scanResult.total?.toFixed(2)}</strong></p>}
                  </div>
                )}
              </div>
            ) : (
              <label className="block cursor-pointer">
                <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center hover:border-violet-400 hover:bg-violet-50 transition">
                  {uploading ? (
                    <div className="flex flex-col items-center gap-2">
                      <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
                      <p className="text-sm text-gray-500">Uploading...</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                      <Upload className="w-8 h-8 text-gray-300" />
                      <p className="text-sm font-medium text-gray-600">Upload Invoice</p>
                      <p className="text-xs text-gray-400">PDF, JPG, or PNG</p>
                    </div>
                  )}
                </div>
                <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileUpload} className="hidden" disabled={uploading} />
              </label>
            )}

            <div className="flex items-center gap-2">
              <Button onClick={handleSave} disabled={saving || uploading || !fileUrl}
                className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl font-semibold gap-2">
                {saving ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</> : "Save Invoice"}
              </Button>
              {hasInvoice && (
                <Button variant="outline" onClick={() => { setEditMode(false); setFileUrl(po.invoice_file_url); }} className="rounded-xl border-gray-200">
                  Cancel
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}