import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function AddItemsModal({ inventoryItems, existingItems, onAdd, onClose }) {
  const [selectedId, setSelectedId] = useState("");

  const available = inventoryItems.filter(
    inv => !existingItems.find(e => e.inventory_item_id === inv.id)
  );

  const handleSave = () => {
    if (!selectedId) { toast.error("Please choose an item"); return; }
    const inv = inventoryItems.find(i => i.id === selectedId);
    if (!inv) return;
    onAdd(inv);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">Add Items</h2>
          <button onClick={onClose} className="w-9 h-9 rounded-full border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-6">
          <div className="mb-1 flex items-center justify-between">
            <label className="text-sm font-medium text-gray-700">Items</label>
          </div>
          <select
            value={selectedId}
            onChange={e => setSelectedId(e.target.value)}
            className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 bg-white appearance-none"
          >
            <option value="">Choose...</option>
            {available.map(inv => (
              <option key={inv.id} value={inv.id}>
                {inv.name}{inv.sku ? ` (${inv.sku})` : ""}
              </option>
            ))}
          </select>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-100">
          <Button variant="outline" onClick={onClose} className="rounded-xl px-6">Close</Button>
          <Button onClick={handleSave} className="bg-violet-700 hover:bg-violet-800 text-white rounded-xl px-6">Save</Button>
        </div>
      </div>
    </div>
  );
}