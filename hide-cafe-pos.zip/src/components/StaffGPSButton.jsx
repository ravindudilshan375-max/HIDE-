import React, { useState } from "react";
import { MapPin, Loader2 } from "lucide-react";

export default function StaffGPSButton({ staffName, branchName, onClockInSuccess, onError }) {
  const [loading, setLoading] = useState(false);

  const captureGPSAndClockIn = async () => {
    setLoading(true);

    try {
      // Request GPS permission and get position
      const position = await new Promise((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        })
      );

      const { latitude, longitude } = position.coords;

      // For testing purposes, you can optionally log GPS data
      console.log('GPS captured:', { latitude, longitude });

      // Return GPS coordinates to parent component
      onClockInSuccess({ latitude, longitude });

    } catch (error) {
      console.error('GPS error:', error);
      let errorMsg = 'GPS permission denied or unavailable';
      if (error.code === 1) errorMsg = 'Location permission denied. Enable location in settings.';
      if (error.code === 3) errorMsg = 'GPS request timeout. Try again.';
      onError(errorMsg);
      setLoading(false);
    }
  };

  return (
    <button
      onClick={captureGPSAndClockIn}
      disabled={loading}
      className={`flex items-center gap-4 w-full px-6 py-5 rounded-2xl text-white font-bold text-xl transition-all active:scale-[0.98] shadow-lg ${
        loading
          ? "bg-blue-600/50 cursor-not-allowed"
          : "bg-blue-600 hover:bg-blue-500 active:bg-blue-700 shadow-blue-900/40"
      }`}
    >
      <div className="w-12 h-12 rounded-xl bg-black/20 flex items-center justify-center shrink-0">
        {loading ? (
          <Loader2 className="w-6 h-6 animate-spin" />
        ) : (
          <MapPin className="w-6 h-6" />
        )}
      </div>
      <div className="text-left">
        <div>{loading ? "Capturing location..." : "Clock In with GPS"}</div>
        <div className="text-sm font-normal opacity-70 mt-0.5">{branchName}</div>
      </div>
    </button>
  );
}