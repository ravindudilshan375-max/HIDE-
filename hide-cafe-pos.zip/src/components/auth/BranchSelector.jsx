import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Building2 } from "lucide-react";

export default function BranchSelector({ user, onBranchSelect }) {
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(user?.branch_id || null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBranches();
  }, []);

  const loadBranches = async () => {
    setLoading(true);
    const data = await base44.entities.Branch.filter({ is_active: true });
    setBranches(data);
    setLoading(false);
  };

  const handleSelect = async () => {
    if (!selectedBranch) return;
    await base44.auth.updateMe({ branch_id: selectedBranch });
    onBranchSelect(selectedBranch);
  };

  if (loading) return <div className="text-center text-gray-400">Loading branches...</div>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 to-purple-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full space-y-6">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-violet-100 rounded-full flex items-center justify-center">
            <Building2 className="w-8 h-8 text-violet-600" />
          </div>
        </div>

        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Select Branch</h1>
          <p className="text-sm text-gray-500 mt-1">Welcome, {user?.full_name}</p>
        </div>

        <div className="space-y-2">
          {branches.length === 0 ? (
            <p className="text-center text-gray-400 py-6">No branches available</p>
          ) : (
            branches.map(branch => (
              <button
                key={branch.id}
                onClick={() => setSelectedBranch(branch.id)}
                className={`w-full p-4 border rounded-xl transition-all text-left ${
                  selectedBranch === branch.id
                    ? "bg-violet-50 border-violet-400 shadow-sm"
                    : "bg-white border-gray-200 hover:border-violet-200"
                }`}
              >
                <p className="font-medium text-gray-900">{branch.name}</p>
                <p className="text-xs text-gray-500 mt-0.5">{branch.location}</p>
              </button>
            ))
          )}
        </div>

        <Button
          onClick={handleSelect}
          disabled={!selectedBranch || branches.length === 0}
          className="w-full bg-violet-600 hover:bg-violet-700 disabled:opacity-50 text-white font-semibold rounded-xl h-11"
        >
          Continue
        </Button>
      </div>
    </div>
  );
}