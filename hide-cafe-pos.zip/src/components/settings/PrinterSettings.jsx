import React, { useState, useEffect } from "react";
import { Printer, Plus, Trash2, CheckCircle2, AlertCircle, Wifi, ChefHat, Receipt, Info, Tag, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { checkBridgeAvailable, testPrinter as bridgeTestPrinter } from "@/components/pos/printBridge";

const PRINTER_TYPES = [
  { key: "receipt", label: "Receipt", icon: Receipt, color: "text-violet-600 bg-violet-50 border-violet-200" },
  { key: "kitchen", label: "Kitchen", icon: ChefHat, color: "text-orange-600 bg-orange-50 border-orange-200" },
  { key: "kot", label: "KOT", icon: Tag, color: "text-blue-600 bg-blue-50 border-blue-200" },
];

const PAPER_SIZES = ["58mm", "80mm"];

const CONNECTION_TYPES = [
  { key: "ethernet", label: "Ethernet (LAN)", description: "Wired network connection" },
  { key: "wifi", label: "Wi-Fi (LAN)", description: "Wireless network connection" },
  { key: "usb", label: "USB", description: "Direct USB connection" },
];

export default function PrinterSettings() {
  const [printers, setPrinters] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pos_printers") || "[]"); } catch { return []; }
  });
  const [printSettings, setPrintSettings] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pos_print_settings") || '{"autoReceipt":true,"autoKitchen":true}'); } catch { return { autoReceipt: true, autoKitchen: true }; }
  });
  // categoryRoutes: { [category]: printerId }
  const [categoryRoutes, setCategoryRoutes] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pos_category_routes") || "{}"); } catch { return {}; }
  });
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ name: "", ip: "", port: "9100", type: "receipt", connectionType: "ethernet", paperSize: "80mm", autoCut: true });
  const [pingResults, setPingResults] = useState({});
  const [pinging, setPinging] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [testing, setTesting] = useState(null);
  const [testResults, setTestResults] = useState({});
  const [bridgeStatus, setBridgeStatus] = useState(null); // null | true | false

  useEffect(() => {
    import("@/api/base44Client").then(({ base44 }) => {
      base44.entities.MenuItem.list().then(items => {
        const cats = [...new Set(items.map(i => i.category).filter(Boolean))].sort();
        setCategories(cats);
      }).catch(() => {});
    });
    checkBridgeAvailable().then(setBridgeStatus);
  }, []);

  const saveRoute = (category, printerId) => {
    const updated = { ...categoryRoutes, [category]: printerId };
    if (!printerId) delete updated[category];
    setCategoryRoutes(updated);
    localStorage.setItem("pos_category_routes", JSON.stringify(updated));
  };

  const updatePrintSetting = (key, value) => {
    const updated = { ...printSettings, [key]: value };
    setPrintSettings(updated);
    localStorage.setItem("pos_print_settings", JSON.stringify(updated));
  };

  const save = (updated) => {
    setPrinters(updated);
    localStorage.setItem("pos_printers", JSON.stringify(updated));
  };

  const addPrinter = () => {
    if (!form.name.trim() || (form.connectionType !== "usb" && !form.ip.trim())) return;
    const updated = [...printers, { ...form, id: Date.now().toString(), status: "unknown" }];
    save(updated);
    setForm({ name: "", ip: "", port: "9100", type: "receipt", connectionType: "ethernet", paperSize: "80mm", autoCut: true, stationName: "" });
    setShowForm(false);
  };

  const pingPrinter = async (printer) => {
    if (printer.connectionType === "usb") return;
    setPinging(printer.id);
    setPingResults(r => ({ ...r, [printer.id]: null }));
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 3000);
      const res = await fetch(`http://localhost:3001/ping`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({ printer_ip: printer.ip, port: parseInt(printer.port) || 9100 }),
      });
      clearTimeout(timer);
      const data = await res.json();
      setPingResults(r => ({ ...r, [printer.id]: data.success ? "online" : "offline" }));
    } catch {
      setPingResults(r => ({ ...r, [printer.id]: "failed" }));
    }
    setPinging(null);
  };

  const removePrinter = (id) => save(printers.filter(p => p.id !== id));

  const testPrinter = async (printer) => {
    setTesting(printer.id);
    setTestResults(r => ({ ...r, [printer.id]: null }));
    try {
      const result = await bridgeTestPrinter(printer);
      setTestResults(r => ({ ...r, [printer.id]: { ok: true, via: result.via } }));
    } catch (error) {
      setTestResults(r => ({ ...r, [printer.id]: { error: error.message || "Test failed" } }));
    }
    setTesting(null);
  };

  return (
    <div className="space-y-4">

      {/* Bridge Status */}
      <div className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-sm ${
        bridgeStatus === true
          ? "bg-green-50 border-green-200 text-green-700"
          : bridgeStatus === false
          ? "bg-amber-50 border-amber-200 text-amber-700"
          : "bg-gray-50 border-gray-200 text-gray-500"
      }`}>
        <Radio className="w-4 h-4 shrink-0" />
        <div className="flex-1">
          {bridgeStatus === true && <><span className="font-semibold">Local Print Bridge connected</span> — printing via localhost:3001</>}
          {bridgeStatus === false && <><span className="font-semibold">Local Print Bridge not detected</span> — falling back to cloud printing. <a href="https://github.com/dendax/print-bridge/releases" target="_blank" rel="noreferrer" className="underline">Download Bridge</a></>}
          {bridgeStatus === null && "Checking local print bridge…"}
        </div>
        <button onClick={() => checkBridgeAvailable().then(setBridgeStatus)} className="text-xs underline opacity-70 hover:opacity-100 shrink-0">Refresh</button>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Printers & Devices</h2>
        <Button size="sm" onClick={() => setShowForm(!showForm)}
          className="bg-violet-600 hover:bg-violet-700 text-white gap-1.5 text-xs h-8 px-3 rounded-xl">
          <Plus className="w-3.5 h-3.5" /> Add Printer
        </Button>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5 space-y-3">
          <p className="text-sm font-semibold text-gray-700">New Printer / Device</p>
          
          {/* Connection Type Selection */}
          <div>
            <label className="text-xs text-gray-400 mb-2 block font-medium">Connection Type</label>
            <div className="grid grid-cols-3 gap-2">
              {CONNECTION_TYPES.map(conn => (
                <button key={conn.key} onClick={() => setForm(f => ({ ...f, connectionType: conn.key }))}
                  className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl border text-center transition-all ${
                    form.connectionType === conn.key 
                      ? "bg-violet-50 border-violet-200" 
                      : "bg-gray-50 border-gray-200 hover:border-gray-300"
                  }`}>
                  <Wifi className={`w-4 h-4 ${form.connectionType === conn.key ? "text-violet-600" : "text-gray-400"}`} />
                  <span className={`text-xs font-medium ${form.connectionType === conn.key ? "text-violet-700" : "text-gray-600"}`}>
                    {conn.label}
                  </span>
                  <span className="text-[10px] text-gray-500">{conn.description}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Printer Name</label>
              <Input placeholder="e.g. Front Counter Receipt" value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                className="border-gray-200 rounded-xl text-sm" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Type</label>
              <div className="flex gap-2">
                {PRINTER_TYPES.map(t => (
                  <button key={t.key} onClick={() => setForm(f => ({ ...f, type: t.key }))}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl border text-xs font-medium transition-all ${
                      form.type === t.key ? t.color : "bg-gray-50 border-gray-200 text-gray-400 hover:text-gray-700"
                    }`}>
                    <t.icon className="w-3.5 h-3.5" /> {t.label}
                  </button>
                ))}
              </div>
            </div>
            {form.connectionType !== "usb" && (
              <>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">IP Address</label>
                  <Input placeholder="192.168.1.100" value={form.ip}
                    onChange={e => setForm(f => ({ ...f, ip: e.target.value }))}
                    className="border-gray-200 rounded-xl text-sm" />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Port</label>
                  <Input placeholder="9100" value={form.port}
                    onChange={e => setForm(f => ({ ...f, port: e.target.value }))}
                    className="border-gray-200 rounded-xl text-sm" />
                </div>
              </>
            )}
            {(form.type === "kitchen" || form.type === "kot") && (
              <div className="col-span-2">
                <label className="text-xs text-gray-400 mb-1 block">Station Label <span className="text-gray-300">(shown on ticket header)</span></label>
                <Input placeholder="e.g. Kitchen, Bar, Grill" value={form.stationName || ""}
                  onChange={e => setForm(f => ({ ...f, stationName: e.target.value }))}
                  className="border-gray-200 rounded-xl text-sm" />
              </div>
            )}
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Paper Size</label>
              <div className="flex gap-2">
                {PAPER_SIZES.map(size => (
                  <button key={size} onClick={() => setForm(f => ({ ...f, paperSize: size }))}
                    className={`flex-1 py-2 rounded-xl border text-xs font-medium transition-all ${
                      form.paperSize === size ? "bg-violet-50 border-violet-200 text-violet-700" : "bg-gray-50 border-gray-200 text-gray-400 hover:text-gray-700"
                    }`}>
                    {size}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Auto Cut</label>
              <div className="flex gap-2">
                {[{ v: true, l: "Yes" }, { v: false, l: "No" }].map(({ v, l }) => (
                  <button key={l} onClick={() => setForm(f => ({ ...f, autoCut: v }))}
                    className={`flex-1 py-2 rounded-xl border text-xs font-medium transition-all ${
                      form.autoCut === v ? "bg-violet-50 border-violet-200 text-violet-700" : "bg-gray-50 border-gray-200 text-gray-400 hover:text-gray-700"
                    }`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <Button onClick={addPrinter} disabled={!form.name.trim() || (form.connectionType !== "usb" && !form.ip.trim())}
              className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl text-sm">
              Add Printer
            </Button>
            <Button variant="outline" onClick={() => setShowForm(false)} className="rounded-xl text-sm">Cancel</Button>
          </div>
        </div>
      )}

      {/* Printer list */}
      <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
        {printers.length === 0 ? (
          <div className="py-12 flex flex-col items-center gap-2 text-gray-300">
            <Printer className="w-8 h-8" />
            <p className="text-sm">No printers configured</p>
            <p className="text-xs text-gray-400">Add a receipt or kitchen printer to get started</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {printers.map(printer => {
              const type = PRINTER_TYPES.find(t => t.key === printer.type) || PRINTER_TYPES[0];
              const result = testResults[printer.id];
              return (
                <div key={printer.id} className="flex items-center gap-4 px-5 py-4">
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${type.color}`}>
                    <type.icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">{printer.name}</p>
                    <p className="text-xs text-gray-400">
                      {printer.connectionType === "usb" ? "USB" : `${printer.ip}:${printer.port}`} · {type.label}
                      {printer.paperSize && <span className="ml-1">· {printer.paperSize}</span>}
                      {printer.autoCut === false && <span className="ml-1">· No Cut</span>}
                      {printer.connectionType && (
                        <span className="ml-1">
                          {printer.connectionType === "ethernet" && "· 🔌 Ethernet"}
                          {printer.connectionType === "wifi" && "· 📡 Wi-Fi"}
                          {printer.connectionType === "usb" && "· 🔗 USB"}
                        </span>
                      )}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {result?.ok && (
                      <span className="flex items-center gap-1 text-green-600 text-xs font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" /> {result.via === "bridge" ? "Bridge OK" : "Cloud OK"}
                      </span>
                    )}
                    {result?.error && (
                      <span className="flex items-center gap-1 text-red-500 text-xs font-medium" title={result.error}>
                        <AlertCircle className="w-3.5 h-3.5" /> Failed
                      </span>
                    )}
                    {pingResults[printer.id] === "online" && (
                      <span className="flex items-center gap-1 text-green-600 text-xs font-medium bg-green-50 border border-green-200 px-2 py-0.5 rounded-lg">
                        <CheckCircle2 className="w-3 h-3" /> ONLINE
                      </span>
                    )}
                    {pingResults[printer.id] === "offline" && (
                      <span className="flex items-center gap-1 text-red-500 text-xs font-medium bg-red-50 border border-red-200 px-2 py-0.5 rounded-lg">
                        <AlertCircle className="w-3 h-3" /> OFFLINE
                      </span>
                    )}
                    {pingResults[printer.id] === "failed" && (
                      <span className="flex items-center gap-1 text-amber-600 text-xs font-medium bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-lg">
                        <AlertCircle className="w-3 h-3" /> NO BRIDGE
                      </span>
                    )}
                    {printer.connectionType !== "usb" && (
                      <Button size="sm" variant="outline" onClick={() => pingPrinter(printer)}
                        disabled={pinging === printer.id}
                        className="text-xs rounded-xl border-gray-200 h-8 px-3">
                        {pinging === printer.id ? "Pinging..." : "Ping"}
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => testPrinter(printer)}
                      disabled={testing === printer.id}
                      className="text-xs rounded-xl border-gray-200 h-8 px-3">
                      {testing === printer.id ? "Testing..." : "Test Print"}
                    </Button>
                  </div>
                  <button onClick={() => removePrinter(printer.id)} className="text-gray-300 hover:text-red-500 transition ml-1">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Auto Print Settings */}
      <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5 space-y-3">
        <p className="text-sm font-semibold text-gray-700">Auto Print Settings</p>
        <div className="space-y-2">
          {[
            { key: "autoReceipt", label: "Auto-print receipt after payment", desc: "Automatically sends to receipt printer when order is paid" },
            { key: "autoKitchen", label: "Auto-print kitchen ticket when order is placed", desc: "Automatically sends to kitchen printer on new order" },
          ].map(({ key, label, desc }) => (
            <div key={key} className="flex items-start justify-between gap-3 py-2 border-b border-gray-50 last:border-0">
              <div>
                <p className="text-sm font-medium text-gray-800">{label}</p>
                <p className="text-xs text-gray-400">{desc}</p>
              </div>
              <button
                onClick={() => updatePrintSetting(key, !printSettings[key])}
                className={`relative w-11 h-6 rounded-full transition-colors shrink-0 mt-0.5 ${printSettings[key] ? "bg-violet-600" : "bg-gray-200"}`}
              >
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${printSettings[key] ? "translate-x-5" : "translate-x-0.5"}`} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Category Routing */}
      {categories.length > 0 && (
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-gray-400" />
            <p className="text-sm font-semibold text-gray-700">Category Routing</p>
          </div>
          <p className="text-xs text-gray-400">Route items from each menu category to a specific kitchen/bar printer when an order is placed.</p>
          <div className="space-y-2">
            {categories.map(cat => {
              const kitchenPrinters = printers.filter(p => p.type === "kitchen");
              return (
                <div key={cat} className="flex items-center justify-between gap-3 py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-violet-300 shrink-0" />
                    <span className="text-sm font-medium text-gray-800">{cat}</span>
                  </div>
                  <select
                    value={categoryRoutes[cat] || ""}
                    onChange={e => saveRoute(cat, e.target.value)}
                    className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:border-violet-400 text-gray-700 min-w-[160px]"
                  >
                    <option value="">— Not routed —</option>
                    {kitchenPrinters.map(p => (
                      <option key={p.id} value={p.id}>{p.name}{p.stationName ? ` (${p.stationName})` : ""}</option>
                    ))}
                  </select>
                </div>
              );
            })}
          </div>
          {printers.filter(p => p.type === "kitchen").length === 0 && (
            <p className="text-xs text-amber-600 bg-amber-50 rounded-lg px-3 py-2">Add at least one Kitchen/Bar printer above to configure routing.</p>
          )}
        </div>
      )}

      <div className="bg-blue-50 border border-blue-100 rounded-2xl px-4 py-3 text-xs space-y-2">
        <div className="flex gap-2 items-start">
          <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <div className="text-blue-600 space-y-1">
            <p className="font-semibold">Local Network Printing</p>
            <p className="text-blue-500">
              <strong>Ethernet/Wi-Fi:</strong> Printers must be on the same local network with a static IP. Ensure your printer supports ESC/POS over TCP (default port 9100).
            </p>
            <p className="text-blue-500">
              <strong>USB:</strong> Direct connection via USB cable to the device running this app.
            </p>
            <p className="text-blue-500">
              <strong>iOS Local Network:</strong> Go to Settings &gt; {'{'}Your App{'}'} &gt; Toggle ON Local Network, then relaunch the app.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}