import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Printer, Pencil, ExternalLink, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { printReceipt } from "@/components/pos/printBridge";

const DEFAULT_SETTINGS = {
  business_name: "",
  address: "",
  phone: "",
  facebook: "",
  instagram: "",
  twitter: "",
  website: "",
  logo: null,
  trn_number: "",
  vat_rate: 5,
  show_vat_breakdown: true,
  footer: "Thank you for your visit!",
  show_order_number: true,
  show_table_number: true,
  show_customer_name: true,
  show_cashier_name: true,
  show_item_description: false,
  show_discounts: true,
  show_tax_breakdown: true,
  show_payment_method: true,
  show_location: true,
  show_total_savings: false,
  show_cart_discounts: true,
  paper_size: "80mm",
};

function Toggle({ value, onChange }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors shrink-0 ${value ? "bg-violet-600" : "bg-gray-200"}`}
    >
      <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${value ? "translate-x-6" : "translate-x-1"}`} />
    </button>
  );
}

function ReceiptPreview({ settings }) {
  const now = new Date();
  const dateStr = now.toLocaleDateString("en-AE", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });

  const sampleItems = [
    { name: "Green Tea", qty: 1, price: 4.00, finalPrice: 2.20, discount: 1.80 },
    { name: "Latte", qty: 1, price: 6.00, finalPrice: 4.80, discount: 1.20 },
  ];
  const subtotal = sampleItems.reduce((s, i) => s + i.price, 0);
  const discountTotal = sampleItems.reduce((s, i) => s + (i.discount || 0), 0);
  const vatRate = parseFloat(settings.vat_rate) || 5;
  const tax = (subtotal - discountTotal) * (vatRate / 100);
  const total = subtotal - discountTotal + tax;

  return (
    <div className="bg-gray-900 rounded-2xl overflow-hidden">
      <div className="flex justify-center p-6">
        <div
          className="bg-white shadow-2xl rounded-sm w-56"
          style={{ fontFamily: "'Courier New', monospace", fontSize: "11px", lineHeight: "1.6" }}
        >
          {/* Header */}
          <div className="px-4 pt-4 pb-2 text-center">
            {settings.logo ? (
              <div className="flex justify-center mb-2">
                <img src={settings.logo} alt="logo" className="h-10 object-contain" style={{ filter: "grayscale(100%)" }} />
              </div>
            ) : (
              <div className="w-10 h-10 bg-gray-100 rounded mx-auto mb-2 flex items-center justify-center text-[8px] font-bold text-gray-500">
                {(settings.business_name || "CAFE").slice(0, 4).toUpperCase()}
              </div>
            )}
            <div className="font-black text-xs tracking-widest">{settings.business_name || "HIDE CAFE"}</div>
            {settings.address && <div className="text-gray-500 text-[10px] uppercase tracking-wider">{settings.address}</div>}
            {settings.trn_number && <div className="text-gray-400 text-[10px]">TRN: {settings.trn_number}</div>}
          </div>

          <div className="border-t-2 border-dashed border-gray-300 mx-3 my-1" />

          {/* Items */}
          <div className="px-3 space-y-1.5 py-1">
            {sampleItems.map((item, i) => (
              <div key={i}>
                <div className="flex justify-between text-[10px]">
                  <span className="font-bold">{item.name}</span>
                  <span>{item.finalPrice.toFixed(2)}|د.إ</span>
                </div>
                {settings.show_discounts && (
                  <>
                    <div className="flex justify-between text-[10px] text-gray-400">
                      <span>Reg price</span>
                      <span className="line-through">{item.price.toFixed(2)}|د.إ</span>
                    </div>
                    <div className="flex justify-between text-[10px] text-gray-400">
                      <span>Discount: Item Sale</span>
                      <span>{item.discount.toFixed(2)}|د.إ</span>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>

          <div className="border-t-2 border-dashed border-gray-300 mx-3 my-1" />

          {/* Totals */}
          <div className="px-3 space-y-0.5 pb-2 text-[10px]">
            <div className="flex justify-between"><span>Subtotal</span><span>{subtotal.toFixed(2)}|د.إ</span></div>
            {settings.show_tax_breakdown && (
              <div className="flex justify-between text-gray-500"><span>Tax ({vatRate}%)</span><span>{tax.toFixed(2)}|د.إ</span></div>
            )}
            <div className="flex justify-between font-black border-t border-gray-200 pt-0.5"><span>Total</span><span>{total.toFixed(2)}|د.إ</span></div>
            {settings.show_payment_method && (
              <div className="flex justify-between text-gray-500 mt-1"><span>Credit Card</span><span>{dateStr}</span></div>
            )}
          </div>

          {/* Map placeholder */}
          {settings.show_location && settings.address && (
            <div className="mx-3 mb-2 h-12 bg-gray-100 rounded flex items-center justify-center">
              <span className="text-gray-400 text-[9px]">📍 {settings.address}</span>
            </div>
          )}

          {/* Footer */}
          <div className="text-center pb-3 px-3 border-t border-gray-100 pt-2">
            <div className="font-black text-[10px] tracking-widest mb-1">
              {(settings.business_name || "RESTAURANT").toUpperCase()}
            </div>
            {settings.footer && (
              <div className="text-[9px] text-gray-400 whitespace-pre-line">{settings.footer}</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ReceiptBrandingSettings() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [recordId, setRecordId] = useState(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testPrinting, setTestPrinting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const records = await base44.entities.ReceiptSettings.list('-updated_date', 1);
      if (records && records.length > 0) {
        setSettings({ ...DEFAULT_SETTINGS, ...records[0] });
        setRecordId(records[0].id);
        // Also sync to localStorage for offline/POS use
        localStorage.setItem("receipt_branding_v2", JSON.stringify(toLegacyFormat(records[0])));
      } else {
        // Fall back to localStorage if no DB record yet
        const saved = JSON.parse(localStorage.getItem("receipt_branding_v2") || "{}");
        if (Object.keys(saved).length > 0) {
          setSettings(prev => ({ ...prev, ...fromLegacyFormat(saved) }));
        }
      }
    } catch (e) {
      console.error("Error loading receipt settings", e);
    }
    setLoading(false);
  };

  // Convert new DB format → old localStorage format (for POS/DigitalReceipt compatibility)
  const toLegacyFormat = (s) => ({
    businessName: s.business_name,
    address: s.address,
    phone: s.phone,
    facebook: s.facebook,
    instagram: s.instagram,
    twitter: s.twitter,
    website: s.website,
    logo: s.logo,
    trnNumber: s.trn_number,
    vatRate: String(s.vat_rate || 5),
    footer: s.footer,
    showVatBreakdown: s.show_vat_breakdown,
    showOrderNumber: s.show_order_number,
    showTableNumber: s.show_table_number,
    showCustomerName: s.show_customer_name,
    showCashierName: s.show_cashier_name,
    showItemDescription: s.show_item_description,
    showDiscounts: s.show_discounts,
    showTaxBreakdown: s.show_tax_breakdown,
    showPaymentMethod: s.show_payment_method,
    showLocation: s.show_location,
    showTotalSavings: s.show_total_savings,
    showCartDiscounts: s.show_cart_discounts,
  });

  // Convert old localStorage format → new DB format
  const fromLegacyFormat = (s) => ({
    business_name: s.businessName || "",
    address: s.address || "",
    phone: s.phone || "",
    logo: s.logo || null,
    trn_number: s.trnNumber || "",
    vat_rate: parseFloat(s.vatRate) || 5,
    footer: s.footer || "Thank you for your visit!",
    show_discounts: s.showDiscounts !== false,
    show_tax_breakdown: s.showTaxBreakdown !== false,
    show_payment_method: s.showPaymentMethod !== false,
    show_location: s.showLocation !== false,
  });

  const set = (key, val) => setSettings(prev => ({ ...prev, [key]: val }));

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) { toast.error("Image must be under 10MB"); return; }
    setUploadingLogo(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set("logo", file_url);
    setUploadingLogo(false);
    toast.success("Logo uploaded");
  };

  const save = async () => {
    setSaving(true);
    try {
      let saved;
      if (recordId) {
        saved = await base44.entities.ReceiptSettings.update(recordId, settings);
      } else {
        saved = await base44.entities.ReceiptSettings.create(settings);
        setRecordId(saved.id);
      }
      // Sync to localStorage so POS/DigitalReceipt can use offline
      localStorage.setItem("receipt_branding_v2", JSON.stringify(toLegacyFormat(settings)));
      toast.success("Receipt settings saved");
    } catch (e) {
      toast.error("Failed to save: " + e.message);
    }
    setSaving(false);
  };

  const testPrint = async () => {
    const printers = JSON.parse(localStorage.getItem("pos_printers") || "[]");
    const receiptPrinter = printers.find(p => p.type === "receipt" || p.printerType === "receipt");
    if (!receiptPrinter) { toast.error("No receipt printer configured."); return; }
    setTestPrinting(true);
    const testOrder = {
      order_number: "TEST-001",
      restaurant_name: settings.business_name || "RESTAURANT",
      items: [{ name: "Green Tea", quantity: 1, price: 2.20, subtotal: 2.20 }],
      subtotal: 2.20, tax: 0.11, discount: 0, total: 2.31, payment_method: "card",
    };
    await printReceipt(testOrder, receiptPrinter);
    toast.success("Test receipt sent to printer");
    setTestPrinting(false);
  };

  const previewReceipt = () => {
    const sampleOrder = {
      order_number: "ORD-PREVIEW",
      items: [
        { name: "Green Tea", price: 4.00, quantity: 1, subtotal: 2.20 },
        { name: "Latte", price: 6.00, quantity: 1, subtotal: 4.80 }
      ],
      subtotal: 10.00, tax: 0.35, discount: 3.00, total: 7.35, payment_method: "card",
    };
    const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(sampleOrder))));
    window.open(`/DigitalReceipt?data=${encodeURIComponent(encoded)}`, "_blank");
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
    </div>
  );

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
      {/* Left: Live Preview */}
      <div className="xl:sticky xl:top-6 xl:self-start space-y-3">
        <ReceiptPreview settings={settings} />
        <p className="text-xs text-center text-gray-400">Preview updates instantly as you change settings</p>
      </div>

      {/* Right: Settings */}
      <div className="space-y-0 bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden divide-y divide-gray-100">

        <div className="px-6 pt-6 pb-4">
          <h2 className="text-xl font-bold text-gray-900">Receipt Settings</h2>
          <p className="text-sm text-gray-500 mt-1">Settings are saved to the database and apply to all POS stations automatically.</p>
        </div>

        {/* Logo */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-3">Logo</h3>
          <div className="border border-gray-200 rounded-xl p-4 flex items-center gap-4">
            <div className="w-16 h-16 rounded-lg border border-gray-200 bg-gray-50 flex items-center justify-center overflow-hidden shrink-0">
              {settings.logo
                ? <img src={settings.logo} alt="logo" className="w-full h-full object-contain" />
                : <span className="text-gray-300 text-2xl">🏪</span>}
            </div>
            <div className="flex-1">
              <p className="font-semibold text-gray-800 text-sm">{settings.business_name || "Brand"}</p>
              <p className="text-xs text-gray-400 mt-0.5">PNG / JPEG · Max 10MB</p>
            </div>
            <label className={`cursor-pointer p-2 rounded-lg hover:bg-gray-100 transition ${uploadingLogo ? "opacity-50" : ""}`}>
              <Pencil className="w-4 h-4 text-gray-500" />
              <input type="file" accept="image/png,image/jpeg" onChange={handleLogoUpload} className="hidden" disabled={uploadingLogo} />
            </label>
          </div>
        </div>

        {/* Business */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-4">Business</h3>
          <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
            {[
              { key: "business_name", label: "Business Name", placeholder: "Your business name" },
              { key: "address", label: "Address", placeholder: "Your address" },
              { key: "phone", label: "Phone", placeholder: "+971 50 000 0000" },
              { key: "trn_number", label: "TRN Number", placeholder: "100XXXXXXXXX00003" },
            ].map(({ key, label, placeholder }) => (
              <div key={key} className="flex">
                <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-36 shrink-0">{label}</span>
                <input
                  value={settings[key] || ""}
                  onChange={e => set(key, e.target.value)}
                  placeholder={placeholder}
                  className="flex-1 px-4 py-3 text-sm focus:outline-none"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Contact Links */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-4">Contact Links</h3>
          <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
            {[
              { key: "facebook", placeholder: "facebook.com/example" },
              { key: "instagram", placeholder: "Instagram username" },
              { key: "twitter", placeholder: "Twitter username" },
              { key: "website", placeholder: "Website URL" },
            ].map(({ key, placeholder }) => (
              <div key={key} className="flex">
                <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-28 shrink-0 capitalize">{key}</span>
                <input
                  value={settings[key] || ""}
                  onChange={e => set(key, e.target.value)}
                  placeholder={placeholder}
                  className="flex-1 px-4 py-3 text-sm focus:outline-none text-gray-400"
                />
              </div>
            ))}
          </div>
        </div>

        {/* VAT / Tax */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-4">VAT / Tax</h3>
          <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
            <div className="flex">
              <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-36 shrink-0">VAT Rate (%)</span>
              <input
                value={settings.vat_rate}
                onChange={e => set("vat_rate", parseFloat(e.target.value) || 0)}
                placeholder="5"
                type="number"
                className="flex-1 px-4 py-3 text-sm focus:outline-none"
              />
            </div>
            <div className="flex items-center justify-between px-4 py-3">
              <span className="text-sm text-gray-700">Show VAT breakdown line</span>
              <Toggle value={settings.show_vat_breakdown} onChange={v => set("show_vat_breakdown", v)} />
            </div>
          </div>
        </div>

        {/* Paper Size */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-4">Paper Size</h3>
          <div className="flex gap-3">
            {["58mm", "80mm"].map(size => (
              <button
                key={size}
                onClick={() => set("paper_size", size)}
                className={`flex-1 py-3 rounded-xl border text-sm font-medium transition-all ${settings.paper_size === size ? "bg-violet-600 border-violet-600 text-white" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* What to show */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-4">Receipt Content</h3>
          <div className="border border-gray-200 rounded-xl overflow-hidden divide-y divide-gray-100">
            {[
              { key: "show_order_number", label: "Order Number" },
              { key: "show_cashier_name", label: "Cashier Name" },
              { key: "show_customer_name", label: "Customer Name" },
              { key: "show_table_number", label: "Table Number" },
              { key: "show_discounts", label: "Item Discounts" },
              { key: "show_tax_breakdown", label: "Tax Breakdown" },
              { key: "show_payment_method", label: "Payment Method" },
              { key: "show_location", label: "Location Map" },
              { key: "show_total_savings", label: "Total Savings Row" },
            ].map(({ key, label }) => (
              <div key={key} className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-gray-700">{label}</span>
                <Toggle value={settings[key]} onChange={v => set(key, v)} />
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-5">
          <h3 className="text-base font-semibold text-gray-900 mb-4">Footer Text</h3>
          <textarea
            value={settings.footer}
            onChange={e => set("footer", e.target.value)}
            placeholder="Thank you for visiting!"
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-violet-400 resize-none"
            rows={3}
          />
        </div>

        {/* Actions */}
        <div className="px-6 py-5 flex gap-3 flex-wrap">
          <Button variant="outline" onClick={testPrint} disabled={testPrinting} className="gap-2">
            <Printer className="w-4 h-4" />
            {testPrinting ? "Printing..." : "Test Print"}
          </Button>
          <Button variant="outline" onClick={previewReceipt} className="gap-2">
            <ExternalLink className="w-4 h-4" />
            Preview Receipt
          </Button>
          <Button onClick={save} disabled={saving} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-semibold">
            {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</> : "Save Settings"}
          </Button>
        </div>
      </div>
    </div>
  );
}