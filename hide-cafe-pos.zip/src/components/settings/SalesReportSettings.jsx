import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Clock, Mail } from "lucide-react";
import { toast } from "sonner";

export default function SalesReportSettings() {
  const [config, setConfig] = useState({ send_time: "08:00", recipient_emails: [] });
  const [newEmail, setNewEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    setLoading(true);
    const user = await base44.auth.me();
    if (user?.sales_report_config) {
      setConfig(user.sales_report_config);
    }
    setLoading(false);
  };

  const saveConfig = async () => {
    if (config.recipient_emails.length === 0) {
      toast.error("Add at least one recipient email");
      return;
    }
    setIsSaving(true);
    await base44.auth.updateMe({ sales_report_config: config });
    setIsSaving(false);
    toast.success("Report settings saved");
  };

  const addEmail = () => {
    if (!newEmail.trim()) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) {
      toast.error("Invalid email address");
      return;
    }
    if (config.recipient_emails.includes(newEmail)) {
      toast.error("Email already added");
      return;
    }
    setConfig(c => ({ ...c, recipient_emails: [...c.recipient_emails, newEmail] }));
    setNewEmail("");
  };

  const removeEmail = (email) => {
    setConfig(c => ({ ...c, recipient_emails: c.recipient_emails.filter(e => e !== email) }));
  };

  return (
    <div className="space-y-5">
      <div>
        <label className="text-xs font-semibold text-gray-600 mb-2 block uppercase tracking-widest">Send Time (UTC)</label>
        <div className="flex items-center gap-3">
          <Clock className="w-5 h-5 text-gray-400" />
          <Input
            type="time"
            value={config.send_time}
            onChange={e => setConfig(c => ({ ...c, send_time: e.target.value }))}
            className="border-gray-200 rounded-xl"
          />
          <span className="text-xs text-gray-400">Daily</span>
        </div>
      </div>

      <div>
        <label className="text-xs font-semibold text-gray-600 mb-2 block uppercase tracking-widest">Recipients</label>
        <div className="flex gap-2 mb-3">
          <Input
            type="email"
            placeholder="finance@example.com"
            value={newEmail}
            onChange={e => setNewEmail(e.target.value)}
            onKeyPress={e => e.key === "Enter" && addEmail()}
            className="border-gray-200 rounded-xl flex-1"
          />
          <Button onClick={addEmail} variant="outline" className="border-gray-200 rounded-xl">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {config.recipient_emails.length === 0 ? (
          <p className="text-xs text-gray-400 italic">No recipients added yet</p>
        ) : (
          <div className="space-y-2">
            {config.recipient_emails.map(email => (
              <div
                key={email}
                className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
              >
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-800">{email}</span>
                </div>
                <button
                  onClick={() => removeEmail(email)}
                  className="p-1 rounded hover:bg-red-50 text-gray-300 hover:text-red-500 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="flex gap-2 pt-3">
        <Button
          onClick={saveConfig}
          disabled={isSaving || loading || config.recipient_emails.length === 0}
          className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl"
        >
          {isSaving ? "Saving..." : "Save Settings"}
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-800">
        <p className="font-medium mb-1">ℹ️ How it works</p>
        <p>Daily sales reports will be sent via Gmail at the specified time (UTC). Enable the Gmail integration first by authorizing your Google account.</p>
      </div>
    </div>
  );
}