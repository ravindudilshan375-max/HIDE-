import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Search, Loader2, Trash2, Plus, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function InvoiceEditor() {
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [order, setOrder] = useState(null);
  const [editOrder, setEditOrder] = useState(null);
  const [saving, setSaving] = useState(false);

  const search = async () => {
    if (!query.trim()) return;
    setSearching(true);
    setOrder(null);
    setEditOrder(null);
    const results = await base44.entities.Order.filter({ order_number: query.trim() });
    const found = results?.[0];
    if (!found) {
      toast.error("Order not found");
    } else {
      setOrder(found);
      setEditOrder(JSON.parse(JSON.stringify(found)));
    }
    setSearching(false);
  };

  const recalcTotals = (o) => {
    const subtotal = (o.items || []).reduce((sum, item) => {
      return sum + (parseFloat(item.subtotal) || 0);
    }, 0);
    const discount = parseFloat(o.discount) || 0;
    const taxRate = subtotal > 0 ? ((parseFloat(o.tax) || 0) / (parseFloat(o.subtotal) || subtotal || 1)) : 0.05;
    const tax = (subtotal - discount) * taxRate;
    const total = subtotal - discount + tax;
    return { ...o, subtotal: +subtotal.toFixed(2), tax: +tax.toFixed(2), total: +total.toFixed(2) };
  };

  const updateItem = (index, field, value) => {
    const items = [...editOrder.items];
    items[index] = { ...items[index], [field]: field === "name" || field === "notes" ? value : parseFloat(value) || 0 };
    if (field === "price" || field === "quantity") {
      items[index].subtotal = +(items[index].price * items[index].quantity).toFixed(2);
    }
    setEditOrder(recalcTotals({ ...editOrder, items }));
  };

  const removeItem = (index) => {
    const items = editOrder.items.filter((_, i) => i !== index);
    setEditOrder(recalcTotals({ ...editOrder, items }));
  };

  const addItem = () => {
    const items = [...(editOrder.items || []), { name: "New Item", price: 0, quantity: 1, subtotal: 0 }];
    setEditOrder(recalcTotals({ ...editOrder, items }));
  };

  const save = async () => {
    setSaving(true);
    await base44.entities.Order.update(editOrder.id, editOrder);
    setOrder(editOrder);
    toast.success("Invoice updated successfully");
    setSaving(false);
  };

  const cancel = () => {
    setEditOrder(JSON.parse(JSON.stringify(order)));
    toast("Changes discarded");
  };

  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6">
        <h2 className="text-lg font-bold text-gray-900 mb-1">Invoice Editor</h2>
        <p className="text-sm text-gray-400 mb-4">Search an order by order number to edit its invoice details</p>
        <div className="flex gap-3">
          <Input
            placeholder="Order number (e.g. ORD-000123)"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === "Enter" && search()}
            className="rounded-xl border-gray-200"
          />
          <Button onClick={search} disabled={searching} className="bg-violet-600 hover:bg-violet-700 text-white gap-2 shrink-0">
            {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Search
          </Button>
        </div>
      </div>

      {editOrder && (
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 space-y-6">
          {/* Order meta */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400">Order</p>
              <p className="font-bold text-gray-900 text-lg">#{editOrder.order_number}</p>
              {editOrder.created_date && (
                <p className="text-xs text-gray-400 mt-0.5">{new Date(editOrder.created_date).toLocaleDateString()}</p>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={cancel} className="gap-1.5">
                <X className="w-3.5 h-3.5" /> Discard
              </Button>
              <Button size="sm" onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-700 text-white gap-1.5">
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                Save
              </Button>
            </div>
          </div>

          {/* Items */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Items</h3>
            <div className="space-y-3">
              {(editOrder.items || []).map((item, i) => (
                <div key={i} className="bg-gray-50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <input
                      className="flex-1 text-sm font-semibold bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                      value={item.name}
                      onChange={e => updateItem(i, "name", e.target.value)}
                      placeholder="Item name"
                    />
                    <button onClick={() => removeItem(i)} className="text-red-400 hover:text-red-600 transition">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wide block mb-1">Qty</label>
                      <input
                        type="number"
                        className="w-full text-sm bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                        value={item.quantity}
                        onChange={e => updateItem(i, "quantity", e.target.value)}
                        min="0"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wide block mb-1">Unit Price</label>
                      <input
                        type="number"
                        className="w-full text-sm bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                        value={item.price}
                        onChange={e => updateItem(i, "price", e.target.value)}
                        min="0" step="0.01"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wide block mb-1">Subtotal</label>
                      <input
                        type="number"
                        className="w-full text-sm bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                        value={item.subtotal ?? (item.price * item.quantity)}
                        onChange={e => updateItem(i, "subtotal", e.target.value)}
                        min="0" step="0.01"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 uppercase tracking-wide block mb-1">Notes</label>
                    <input
                      className="w-full text-sm bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                      value={item.notes || ""}
                      onChange={e => updateItem(i, "notes", e.target.value)}
                      placeholder="Optional notes"
                    />
                  </div>
                </div>
              ))}
              <button onClick={addItem} className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-violet-200 rounded-xl text-violet-500 hover:border-violet-400 hover:text-violet-700 transition text-sm font-medium">
                <Plus className="w-4 h-4" /> Add Item
              </button>
            </div>
          </div>

          {/* Totals */}
          <div className="bg-gray-50 rounded-xl p-4 space-y-3">
            <h3 className="text-sm font-semibold text-gray-700">Totals</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-gray-400 uppercase tracking-wide block mb-1">Discount</label>
                <input
                  type="number"
                  className="w-full text-sm bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                  value={editOrder.discount || 0}
                  onChange={e => setEditOrder(recalcTotals({ ...editOrder, discount: parseFloat(e.target.value) || 0 }))}
                  min="0" step="0.01"
                />
              </div>
              <div>
                <label className="text-[10px] text-gray-400 uppercase tracking-wide block mb-1">Customer Name</label>
                <input
                  className="w-full text-sm bg-white border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:border-violet-400"
                  value={editOrder.customer_name || ""}
                  onChange={e => setEditOrder({ ...editOrder, customer_name: e.target.value })}
                  placeholder="Customer name"
                />
              </div>
            </div>
            <div className="pt-2 border-t border-gray-200 space-y-1.5 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span><span>{(editOrder.subtotal || 0).toFixed(2)} AED</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Discount</span><span>-{(editOrder.discount || 0).toFixed(2)} AED</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Tax</span><span>{(editOrder.tax || 0).toFixed(2)} AED</span>
              </div>
              <div className="flex justify-between font-bold text-gray-900 text-base pt-1 border-t border-gray-200">
                <span>Total</span><span>{(editOrder.total || 0).toFixed(2)} AED</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={cancel}>Discard Changes</Button>
            <Button onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-700 text-white gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              Save Invoice
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}