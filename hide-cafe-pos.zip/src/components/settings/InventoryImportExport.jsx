import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Upload, Download, FileText, CheckCircle2, AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function InventoryImportExport() {
  const [importing, setImporting] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [importResult, setImportResult] = useState(null);

  const exportCSV = async () => {
    setExporting(true);
    const items = await base44.entities.MenuItem.list();
    const headers = ["name", "category", "price", "description", "prep_time", "stock_quantity", "is_available"];
    const rows = items.map(item =>
      headers.map(h => {
        const v = item[h] ?? "";
        return typeof v === "string" && v.includes(",") ? `"${v}"` : v;
      }).join(",")
    );
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "menu_inventory.csv";
    a.click();
    URL.revokeObjectURL(url);
    setExporting(false);
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    setImportResult(null);
    const text = await file.text();
    const lines = text.trim().split("\n");
    const headers = lines[0].split(",").map(h => h.trim().toLowerCase().replace(/"/g, ""));
    let created = 0, errors = 0;
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map(v => v.trim().replace(/"/g, ""));
      const obj = {};
      headers.forEach((h, idx) => {
        const v = values[idx] ?? "";
        if (h === "price" || h === "prep_time" || h === "stock_quantity") obj[h] = v ? parseFloat(v) : undefined;
        else if (h === "is_available") obj[h] = v.toLowerCase() !== "false";
        else if (v) obj[h] = v;
      });
      if (!obj.name || !obj.price) { errors++; continue; }
      await base44.entities.MenuItem.create(obj);
      created++;
    }
    setImportResult({ created, errors });
    setImporting(false);
    e.target.value = "";
  };

  return (
    <div className="space-y-4">
      <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Menu & Inventory Import / Export</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Export */}
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-50 border border-green-200 flex items-center justify-center">
              <Download className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900 text-sm">Export Menu</p>
              <p className="text-xs text-gray-400">Download all menu items as CSV</p>
            </div>
          </div>
          <p className="text-xs text-gray-500">
            Exports: name, category, price, description, prep time, stock, availability.
            Use to back up your menu or edit items in bulk in Excel / Google Sheets.
          </p>
          <Button onClick={exportCSV} disabled={exporting}
            className="w-full bg-green-600 hover:bg-green-700 text-white rounded-xl gap-2 text-sm">
            <Download className="w-4 h-4" />
            {exporting ? "Exporting..." : "Download CSV"}
          </Button>
        </div>

        {/* Import */}
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-50 border border-violet-200 flex items-center justify-center">
              <Upload className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900 text-sm">Import Menu</p>
              <p className="text-xs text-gray-400">Upload a CSV to bulk-add menu items</p>
            </div>
          </div>
          <p className="text-xs text-gray-500">
            CSV must include at minimum: <strong>name</strong> and <strong>price</strong>.
            Optional: category, description, prep_time, stock_quantity, is_available.
          </p>
          <label className={`w-full flex items-center justify-center gap-2 h-10 rounded-xl border-2 border-dashed cursor-pointer text-sm font-medium transition-all ${
            importing ? "border-gray-200 text-gray-300" : "border-violet-200 text-violet-600 hover:bg-violet-50"
          }`}>
            <Upload className="w-4 h-4" />
            {importing ? "Importing..." : "Choose CSV File"}
            <input type="file" accept=".csv" className="hidden" onChange={handleImport} disabled={importing} />
          </label>

          {importResult && (
            <div className={`flex items-start gap-2 text-xs rounded-xl px-3 py-2 border ${
              importResult.errors > 0
                ? "bg-amber-50 border-amber-200 text-amber-700"
                : "bg-green-50 border-green-200 text-green-700"
            }`}>
              {importResult.errors === 0 ? <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />}
              <span>
                {importResult.created} item{importResult.created !== 1 ? "s" : ""} imported.
                {importResult.errors > 0 ? ` ${importResult.errors} row${importResult.errors !== 1 ? "s" : ""} skipped (missing name or price).` : ""}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* CSV Template hint */}
      <div className="bg-gray-50 border border-gray-100 rounded-2xl px-4 py-3 text-xs text-gray-500 space-y-1">
        <p className="font-semibold text-gray-600 flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> CSV Format Example</p>
        <code className="block font-mono bg-white border border-gray-200 rounded-lg px-3 py-2 text-gray-600 text-xs whitespace-pre overflow-x-auto">
{`name,category,price,description,prep_time,stock_quantity,is_available
Espresso,Drinks,3.50,Double shot espresso,3,,true
Croissant,Bakery,4.00,Butter croissant,5,50,true`}
        </code>
      </div>
    </div>
  );
}