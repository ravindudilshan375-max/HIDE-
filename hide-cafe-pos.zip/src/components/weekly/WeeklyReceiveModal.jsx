import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { X, Upload, Sparkles, Loader2, PackageCheck, Camera, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function WeeklyReceiveModal({ order, onConfirm, onClose }) {
  const [po, setPo] = useState(null);
  const [loadingPo, setLoadingPo] = useState(true);
  const [items, setItems] = useState([]);

  // Invoice state
  const [fileUrl, setFileUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [invoiceDate, setInvoiceDate] = useState("");
  const [invoiceTotal, setInvoiceTotal] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadPo = async () => {
      setLoadingPo(true);
      if (order.po_id) {
        const poData = await base44.entities.PurchaseOrder.get(order.po_id).catch(() => null);
        if (poData) {
          setPo(poData);
          setItems((poData.items || []).map(i => ({ ...i, received_quantity: i.received_quantity ?? i.quantity ?? 0 })));
          setInvoiceNumber(poData.invoice_number || "");
          setInvoiceDate(poData.invoice_date || "");
          setInvoiceTotal(poData.invoice_total || "");
        }
      } else {
        // Fallback: build items from weekly request items
        setItems((order.items || []).map(i => ({
          inventory_item_id: i.inventory_item_id,
          item_name: i.item_name,
          quantity: i.requested_qty || 0,
          received_quantity: i.requested_qty || 0,
          unit: i.unit || "",
        })));
      }
      setLoadingPo(false);
    };
    loadPo();
  }, [order]);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowed = ["application/pdf", "image/jpeg", "image/png", "image/jpg"];
    if (!allowed.includes(file.type)) { toast.error("Only PDF, JPG, or PNG"); return; }
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFileUrl(file_url);
    setUploading(false);
    toast.success("Uploaded — tap 'Scan with AI' to extract invoice data");
  };

  const handleAIScan = async () => {
    if (!fileUrl) { toast.error("Upload an invoice first"); return; }
    setScanning(true);
    setScanResult(null);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Extract data from this supplier invoice. Return a JSON with: invoice_number (string), invoice_date (YYYY-MM-DD), supplier_name (string), subtotal (number), tax_amount (number), total (number), currency (string). Set null for missing fields.`,
      file_urls: [fileUrl],
      response_json_schema: {
        type: "object",
        properties: {
          invoice_number: { type: "string" },
          invoice_date: { type: "string" },
          supplier_name: { type: "string" },
          subtotal: { type: "number" },
          tax_amount: { type: "number" },
          total: { type: "number" },
          currency: { type: "string" },
        }
      }
    });
    if (result) {
      setScanResult(result);
      if (result.invoice_number) setInvoiceNumber(result.invoice_number);
      if (result.invoice_date) setInvoiceDate(result.invoice_date);
      if (result.total) setInvoiceTotal(result.total);
      toast.success("Invoice scanned — verify the details below");
    } else {
      toast.error("Could not read invoice");
    }
    setScanning(false);
  };

  const updateReceived = (idx, val) => {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, received_quantity: Number(val) } : it));
  };

  const handleConfirm = async () => {
    if (order.status !== "ready_to_receive") {
      toast.error("Order must be Ready to Receive before confirming delivery.");
      return;
    }
    if (po && po.status === "draft") {
      toast.error("Purchase Order must be approved before receiving items.");
      return;
    }
    setSaving(true);
    const user = await base44.auth.me().catch(() => null);
    const now = new Date().toISOString();

    const invoiceUpdates = fileUrl ? {
      invoice_number: invoiceNumber || null,
      invoice_date: invoiceDate || null,
      invoice_total: invoiceTotal ? Number(invoiceTotal) : null,
      invoice_file_url: fileUrl,
      invoice_uploaded_by: user?.full_name || user?.email || "Staff",
      invoice_uploaded_at: now,
    } : {};

    // Update inventory quantities
    for (const item of items) {
      if (!item.inventory_item_id) continue;
      const qtyToAdd = item.received_quantity || 0;
      const invItem = await base44.entities.InventoryItem.get(item.inventory_item_id).catch(() => null);
      if (!invItem) continue;
      let targetItem = invItem;
      if (order.branch_id && invItem.branch_id !== order.branch_id) {
        const branchItems = await base44.entities.InventoryItem.filter({ name: invItem.name, branch_id: order.branch_id });
        if (branchItems?.length > 0) targetItem = branchItems[0];
      }
      await base44.entities.InventoryItem.update(targetItem.id, { current_quantity: (targetItem.current_quantity || 0) + qtyToAdd });
    }

    // Update PO to received/completed
    if (po) {
      await base44.entities.PurchaseOrder.update(po.id, {
        status: "completed",
        received_date: now,
        items,
        ...invoiceUpdates,
      });
    }

    // Update weekly order to received
    await base44.entities.WeeklyOrderRequest.update(order.id, {
      status: "received",
      received_date: now,
    });

    toast.success("Delivery confirmed — inventory updated!");
    onConfirm();
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4">
      <div className="bg-white w-full sm:max-w-2xl rounded-t-3xl sm:rounded-2xl shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 shrink-0">
          <div className="flex items-center gap-2">
            <PackageCheck className="w-5 h-5 text-amber-500" />
            <div>
              <h2 className="text-base font-bold text-gray-900">Receive Order</h2>
              <p className="text-xs text-gray-400">{po?.reference || order.branch_name} · {order.branch_name}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1"><X className="w-5 h-5" /></button>
        </div>

        {loadingPo ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 text-violet-400 animate-spin" />
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto">
            {/* Items */}
            <div className="px-5 pt-4 pb-2">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Verify Received Quantities</p>
              <div className="space-y-2">
                {items.map((item, i) => {
                  const shortage = (item.quantity || 0) - item.received_quantity;
                  return (
                    <div key={i} className="bg-gray-50 rounded-xl px-4 py-3 flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-800 truncate">{item.item_name}</p>
                        <p className="text-xs text-gray-400">Ordered: {item.quantity} {item.unit}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Input
                          type="number"
                          min="0"
                          value={item.received_quantity}
                          onChange={e => updateReceived(i, e.target.value)}
                          className="w-20 h-8 text-sm text-center border-gray-200 rounded-lg"
                        />
                        <span className="text-xs text-gray-400 w-6">{item.unit}</span>
                      </div>
                      {shortage > 0 && (
                        <span className="text-[10px] font-bold text-red-500 bg-red-50 px-2 py-0.5 rounded-full shrink-0">
                          -{shortage}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Invoice Upload */}
            <div className="px-5 pt-4 pb-5">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Supplier Invoice (Optional)</p>

              {!fileUrl ? (
                <div className="grid grid-cols-2 gap-3">
                  <label className="cursor-pointer">
                    <div className="border-2 border-dashed border-gray-200 rounded-xl p-5 text-center hover:border-violet-400 hover:bg-violet-50 transition flex flex-col items-center gap-2">
                      <Camera className="w-7 h-7 text-gray-300" />
                      <p className="text-xs font-semibold text-gray-500">Take Photo</p>
                      <p className="text-[10px] text-gray-400">Camera</p>
                    </div>
                    <input type="file" accept="image/*" capture="environment" onChange={handleFileUpload} className="hidden" disabled={uploading} />
                  </label>
                  <label className="cursor-pointer">
                    <div className="border-2 border-dashed border-gray-200 rounded-xl p-5 text-center hover:border-violet-400 hover:bg-violet-50 transition flex flex-col items-center gap-2">
                      {uploading ? <Loader2 className="w-7 h-7 text-violet-400 animate-spin" /> : <Upload className="w-7 h-7 text-gray-300" />}
                      <p className="text-xs font-semibold text-gray-500">{uploading ? "Uploading..." : "Upload File"}</p>
                      <p className="text-[10px] text-gray-400">PDF · JPG · PNG</p>
                    </div>
                    <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileUpload} className="hidden" disabled={uploading} />
                  </label>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-xl px-4 py-3">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-green-600" />
                      <span className="text-sm text-green-700 font-medium">Invoice uploaded</span>
                    </div>
                    <button onClick={() => { setFileUrl(""); setScanResult(null); }} className="text-gray-400 hover:text-red-400">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <Button variant="outline" onClick={handleAIScan} disabled={scanning}
                    className="w-full border-violet-200 text-violet-700 hover:bg-violet-50 rounded-xl gap-2 font-semibold">
                    {scanning
                      ? <><Loader2 className="w-4 h-4 animate-spin" /> Reading invoice with AI...</>
                      : <><Sparkles className="w-4 h-4" /> Scan with AI</>
                    }
                  </Button>

                  {scanResult && (
                    <div className="bg-violet-50 border border-violet-100 rounded-xl p-3 text-xs space-y-1">
                      <p className="font-bold text-violet-600 flex items-center gap-1 mb-2"><Sparkles className="w-3 h-3" /> AI Extracted — verify & edit below</p>
                      {scanResult.supplier_name && <p className="text-gray-600">Supplier: <strong>{scanResult.supplier_name}</strong></p>}
                      {scanResult.subtotal != null && <p className="text-gray-600">Subtotal: {scanResult.currency || "AED"} {scanResult.subtotal?.toFixed(2)}</p>}
                      {scanResult.tax_amount != null && <p className="text-gray-600">VAT: {scanResult.currency || "AED"} {scanResult.tax_amount?.toFixed(2)}</p>}
                      {scanResult.total != null && <p className="text-gray-600">Total: <strong>{scanResult.currency || "AED"} {scanResult.total?.toFixed(2)}</strong></p>}
                    </div>
                  )}

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[10px] text-gray-400 mb-1">Invoice #</label>
                      <Input value={invoiceNumber} onChange={e => setInvoiceNumber(e.target.value)} placeholder="INV-001" className="border-gray-200 rounded-lg h-8 text-xs" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 mb-1">Date</label>
                      <Input type="date" value={invoiceDate} onChange={e => setInvoiceDate(e.target.value)} className="border-gray-200 rounded-lg h-8 text-xs" />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 mb-1">Total (AED)</label>
                      <Input type="number" step="0.01" value={invoiceTotal} onChange={e => setInvoiceTotal(e.target.value)} placeholder="0.00" className="border-gray-200 rounded-lg h-8 text-xs" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-5 py-4 border-t border-gray-100 shrink-0">
          <Button onClick={handleConfirm} disabled={saving || loadingPo}
            className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl h-12 text-base gap-2">
            {saving ? <><Loader2 className="w-5 h-5 animate-spin" /> Saving...</> : <><PackageCheck className="w-5 h-5" /> Confirm Delivery Received</>}
          </Button>
        </div>
      </div>
    </div>
  );
}