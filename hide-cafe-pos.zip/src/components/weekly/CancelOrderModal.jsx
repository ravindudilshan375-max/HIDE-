import React, { useState } from "react";
import { X, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const CANCEL_REASONS = [
  { value: "supplier_issue", label: "Supplier Issue" },
  { value: "wrong_item", label: "Wrong Item" },
  { value: "duplicate", label: "Duplicate" },
  { value: "other", label: "Other" },
];

export default function CancelOrderModal({ order, onClose, onCanceled }) {
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const handleCancel = async () => {
    if (!reason) {
      toast.error("Please select a reason");
      return;
    }

    setSaving(true);
    try {
      // Get current user for canceled_by
      const user = await base44.auth.me().catch(() => null);
      const canceledBy = user?.full_name || user?.email || "Manager";

      // Update WeeklyOrderRequest
      await base44.entities.WeeklyOrderRequest.update(order.id, {
        status: "canceled",
        canceled_by: canceledBy,
        canceled_at: new Date().toISOString(),
        cancel_reason: reason,
      });

      // Update linked PurchaseOrder if it exists
      if (order.po_id) {
        await base44.entities.PurchaseOrder.update(order.po_id, {
          status: "cancelled",
          canceled_by: canceledBy,
          canceled_at: new Date().toISOString(),
          cancel_reason: reason,
        });
      }

      toast.success("Order canceled successfully");
      onCanceled();
      onClose();
    } catch (error) {
      console.error("Error canceling order:", error);
      toast.error("Failed to cancel order");
    }
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-red-600" />
            </div>
            <h2 className="font-bold text-gray-900">Cancel Purchase Order?</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <p className="text-sm text-gray-600">
            This action will cancel the weekly order and linked purchase order. This cannot be undone.
          </p>

          <div>
            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">
              Cancellation Reason *
            </label>
            <div className="space-y-2">
              {CANCEL_REASONS.map((opt) => (
                <label key={opt.value} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition">
                  <input
                    type="radio"
                    name="reason"
                    value={opt.value}
                    checked={reason === opt.value}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium text-gray-700">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Warning */}
          <div className="bg-red-50 border border-red-100 rounded-lg p-3">
            <p className="text-xs text-red-700 font-medium">
              ⚠️ Both the weekly order and linked PO will be marked as canceled.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t border-gray-100">
          <Button onClick={onClose} variant="outline" className="flex-1 rounded-lg">
            Keep Order
          </Button>
          <Button
            onClick={handleCancel}
            disabled={saving || !reason}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white rounded-lg gap-2"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Canceling...
              </>
            ) : (
              "Cancel Order"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}