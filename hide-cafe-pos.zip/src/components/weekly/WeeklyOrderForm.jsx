import React, { useState, useMemo, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Search, X, Package, Minus, Save, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { format, startOfWeek, endOfWeek, addWeeks } from "date-fns";

function getWeekRange(offset = 1) {
  const base = addWeeks(new Date(), offset);
  return {
    start: startOfWeek(base, { weekStartsOn: 1 }),
    end: endOfWeek(base, { weekStartsOn: 1 }),
  };
}

function QtyControl({ value, onChange }) {
  return (
    <div className="flex items-center gap-0 border-2 border-gray-200 rounded-xl overflow-hidden focus-within:border-violet-400 transition-colors">
      <button
        type="button"
        onClick={() => onChange(Math.max(0, (value || 0) - 1))}
        className="w-10 h-10 flex items-center justify-center bg-gray-50 hover:bg-gray-100 text-gray-600 text-lg font-bold transition active:bg-gray-200 flex-shrink-0"
      >
        <Minus className="w-4 h-4" />
      </button>
      <input
        type="number"
        min="0"
        value={value || ""}
        onChange={e => onChange(Math.max(0, Number(e.target.value) || 0))}
        onFocus={e => e.target.select()}
        className="w-14 h-10 text-center text-base font-bold text-gray-800 focus:outline-none bg-white border-x border-gray-200"
      />
      <button
        type="button"
        onClick={() => onChange((value || 0) + 1)}
        className="w-10 h-10 flex items-center justify-center bg-gray-50 hover:bg-gray-100 text-gray-600 text-lg font-bold transition active:bg-gray-200 flex-shrink-0"
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}

export default function WeeklyOrderForm({ branches, inventoryItems, onSaved, onCancel, editingOrder }) {
  const [branchId, setBranchId] = useState(editingOrder?.branch_id || branches[0]?.id || "");
  const [weekOffset, setWeekOffset] = useState(1);
  const [requestedBy, setRequestedBy] = useState(editingOrder?.requested_by || "");
  const [notes, setNotes] = useState(editingOrder?.notes || "");
  const [items, setItems] = useState(editingOrder?.items || []);
  const [itemSearch, setItemSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [saving, setSaving] = useState(false);
  const searchRef = useRef(null);

  const { start, end } = useMemo(() => getWeekRange(weekOffset), [weekOffset]);
  const branchName = branches.find(b => b.id === branchId)?.name || "";

  const searchResults = useMemo(() => {
    const all = itemSearch.trim()
      ? inventoryItems.filter(i => i.name?.toLowerCase().includes(itemSearch.toLowerCase()))
      : inventoryItems.slice(0, 12);
    return all.filter(i => !items.find(x => x.inventory_item_id === i.id)).slice(0, 10);
  }, [itemSearch, inventoryItems, items]);

  const addItem = (inv) => {
    setItems(prev => [...prev, {
      inventory_item_id: inv.id,
      item_name: inv.name,
      current_stock: inv.current_quantity || 0,
      requested_qty: 1,
      unit: inv.storage_unit || inv.unit || "pcs",
      unit_cost: inv.unit_cost || 0,
      estimated_cost: inv.unit_cost || 0,
    }]);
    setItemSearch("");
  };

  const updateQty = (idx, qty) => {
    setItems(prev => prev.map((item, i) => {
      if (i !== idx) return item;
      const q = Math.max(0, qty);
      return { ...item, requested_qty: q, estimated_cost: q * (item.unit_cost || 0) };
    }));
  };

  const removeItem = (idx) => setItems(prev => prev.filter((_, i) => i !== idx));

  const totalCost = items.reduce((s, i) => s + (i.estimated_cost || 0), 0);

  const buildPayload = (status) => ({
    branch_id: branchId,
    branch_name: branchName,
    week_start: format(start, "yyyy-MM-dd"),
    week_end: format(end, "yyyy-MM-dd"),
    requested_by: requestedBy,
    status,
    notes,
    items,
    total_estimated_cost: totalCost,
  });

  const saveDraft = async () => {
    if (!branchId) { toast.error("Select a branch"); return; }
    if (!requestedBy.trim()) { toast.error("Enter your name"); return; }
    setSaving(true);
    if (editingOrder) {
      await base44.entities.WeeklyOrderRequest.update(editingOrder.id, buildPayload("draft"));
    } else {
      await base44.entities.WeeklyOrderRequest.create(buildPayload("draft"));
    }
    toast.success("Draft saved");
    setSaving(false);
    onSaved();
  };

  const submitRequest = async () => {
    if (!branchId) { toast.error("Select a branch"); return; }
    if (!requestedBy.trim()) { toast.error("Enter your name"); return; }
    if (items.length === 0) { toast.error("Add at least one item"); return; }
    setSaving(true);
    let reqId = editingOrder?.id;
    if (reqId) {
      await base44.entities.WeeklyOrderRequest.update(reqId, buildPayload("draft"));
    } else {
      const created = await base44.entities.WeeklyOrderRequest.create(buildPayload("draft"));
      reqId = created.id;
    }
    const res = await base44.functions.invoke("submitWeeklyOrder", { request_id: reqId });
    if (res.data?.success) {
      toast.success(`Request submitted! Draft PO ${res.data.po_reference} created for manager.`);
    } else {
      toast.error(res.data?.error || "Submitted but PO creation failed");
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] flex flex-col">

      {/* ── TOP HEADER BAR ── */}
      <div className="bg-white border-b border-gray-100 shadow-sm px-4 md:px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-start justify-between gap-4 flex-wrap">
          {/* Left: info */}
          <div>
            <div className="flex items-center gap-2 mb-1">
              <button onClick={onCancel} className="text-gray-400 hover:text-gray-700 transition mr-1">
                <X className="w-4 h-4" />
              </button>
              <h1 className="text-lg font-bold text-gray-900">Weekly Order Request</h1>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-gray-500 ml-6">
              {/* Branch */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-gray-400">Branch:</span>
                <select
                  value={branchId}
                  onChange={e => setBranchId(e.target.value)}
                  className="bg-transparent font-semibold text-gray-800 text-sm focus:outline-none border-b border-dashed border-gray-300 pb-0.5"
                >
                  {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              {/* Week */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-gray-400">Week:</span>
                <button onClick={() => setWeekOffset(w => w - 1)} className="text-gray-400 hover:text-gray-600 font-bold px-1">‹</button>
                <span className="font-semibold text-gray-800">{format(start, "d MMM")} – {format(end, "d MMM")}</span>
                <button onClick={() => setWeekOffset(w => w + 1)} className="text-gray-400 hover:text-gray-600 font-bold px-1">›</button>
              </div>
              {/* Name */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-gray-400">By:</span>
                <input
                  value={requestedBy}
                  onChange={e => setRequestedBy(e.target.value)}
                  placeholder="Your name"
                  className="bg-transparent font-semibold text-gray-800 text-sm focus:outline-none border-b border-dashed border-gray-300 pb-0.5 w-32 placeholder:text-gray-300"
                />
              </div>
            </div>
          </div>
          {/* Right: action buttons */}
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={saveDraft}
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 border-2 border-gray-200 text-gray-600 font-semibold rounded-xl hover:bg-gray-50 transition text-sm"
            >
              <Save className="w-4 h-4" /> Save Draft
            </button>
            <button
              onClick={submitRequest}
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition text-sm shadow-sm"
            >
              <Send className="w-4 h-4" /> {saving ? "Submitting..." : "Submit Request"}
            </button>
          </div>
        </div>
      </div>

      {/* ── MAIN CONTENT ── */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-4 md:px-6 py-5 space-y-4">

        {/* Search bar */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              ref={searchRef}
              value={itemSearch}
              onChange={e => { setItemSearch(e.target.value); setShowSearch(true); }}
              onFocus={() => setShowSearch(true)}
              placeholder="Search item or scan barcode..."
              className="w-full pl-10 pr-10 py-3 bg-gray-50 border-2 border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 focus:bg-white transition"
            />
            {itemSearch && (
              <button onClick={() => { setItemSearch(""); setShowSearch(false); }}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Search results dropdown */}
          {showSearch && searchResults.length > 0 && (
            <div className="mt-2 border border-gray-200 rounded-xl overflow-hidden shadow-md">
              {searchResults.map(inv => (
                <button
                  key={inv.id}
                  onClick={() => { addItem(inv); setShowSearch(false); setItemSearch(""); }}
                  className="w-full flex items-center justify-between px-4 py-3 hover:bg-violet-50 transition text-left border-b border-gray-50 last:border-0"
                >
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{inv.name}</p>
                    <p className="text-xs text-gray-400">Stock: {inv.current_quantity || 0} {inv.storage_unit || inv.unit} {inv.unit_cost ? `· AED ${inv.unit_cost.toFixed(2)}/${inv.storage_unit || inv.unit}` : ""}</p>
                  </div>
                  <div className="flex items-center gap-1.5 text-violet-600 font-semibold text-xs bg-violet-50 border border-violet-200 rounded-lg px-2.5 py-1.5">
                    <Plus className="w-3 h-3" /> Add
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Items list */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {/* Table header — desktop */}
          <div className="hidden md:grid grid-cols-12 text-[10px] font-bold text-gray-400 uppercase tracking-wider px-5 py-3 bg-gray-50 border-b border-gray-100">
            <span className="col-span-4">Item</span>
            <span className="col-span-2 text-center">Current Stock</span>
            <span className="col-span-3 text-center">Request Qty</span>
            <span className="col-span-1 text-center">Unit</span>
            <span className="col-span-1 text-right">Est. Cost</span>
            <span className="col-span-1" />
          </div>

          {items.length === 0 ? (
            <div className="py-16 text-center">
              <Package className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm font-medium text-gray-400">No items added yet</p>
              <p className="text-xs text-gray-300 mt-1">Use the search bar above to add items</p>
            </div>
          ) : (
            <>
              {/* Desktop rows */}
              <div className="hidden md:block">
                {items.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 items-center px-5 py-3.5 border-b border-gray-50 last:border-0 hover:bg-gray-50/50 transition">
                    <div className="col-span-4">
                      <p className="text-sm font-bold text-gray-800">{item.item_name}</p>
                      {item.unit_cost > 0 && <p className="text-xs text-gray-400 mt-0.5">AED {item.unit_cost.toFixed(2)} / {item.unit}</p>}
                    </div>
                    <div className="col-span-2 text-center text-sm text-gray-500 font-medium">
                      {item.current_stock} <span className="text-xs text-gray-400">{item.unit}</span>
                    </div>
                    <div className="col-span-3 flex justify-center">
                      <QtyControl value={item.requested_qty} onChange={qty => updateQty(idx, qty)} />
                    </div>
                    <div className="col-span-1 text-center text-xs text-gray-400 font-medium">{item.unit}</div>
                    <div className="col-span-1 text-right text-sm font-bold text-violet-700">
                      {item.estimated_cost > 0 ? `${item.estimated_cost.toFixed(0)}` : "—"}
                    </div>
                    <div className="col-span-1 flex justify-end">
                      <button onClick={() => removeItem(idx)} className="text-gray-300 hover:text-red-400 transition p-1.5 rounded-lg hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Mobile / tablet cards */}
              <div className="md:hidden divide-y divide-gray-50">
                {items.map((item, idx) => (
                  <div key={idx} className="px-4 py-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="text-base font-bold text-gray-800">{item.item_name}</p>
                        <p className="text-xs text-gray-400 mt-0.5">
                          Stock: <span className="font-semibold text-gray-600">{item.current_stock} {item.unit}</span>
                          {item.unit_cost > 0 && <> · AED {item.unit_cost.toFixed(2)}/{item.unit}</>}
                        </p>
                      </div>
                      <button onClick={() => removeItem(idx)} className="text-gray-300 hover:text-red-400 transition p-1.5">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-gray-400 font-medium">Request Qty:</span>
                      <QtyControl value={item.requested_qty} onChange={qty => updateQty(idx, qty)} />
                      <span className="text-xs text-gray-400">{item.unit}</span>
                      {item.estimated_cost > 0 && (
                        <span className="ml-auto text-sm font-bold text-violet-700">AED {item.estimated_cost.toFixed(0)}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Add more button inside table */}
          <button
            onClick={() => { setShowSearch(true); searchRef.current?.focus(); searchRef.current?.scrollIntoView({ behavior: "smooth" }); }}
            className="w-full flex items-center justify-center gap-2 py-3.5 text-violet-600 hover:bg-violet-50 transition font-semibold text-sm border-t border-gray-100"
          >
            <Plus className="w-4 h-4" /> Add Item
          </button>
        </div>

        {/* Notes */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Notes</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Special notes or instructions for this order..."
            rows={3}
            className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400 resize-none"
          />
        </div>

        {/* Summary */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-6 text-sm">
            <div>
              <p className="text-xs text-gray-400">Items Requested</p>
              <p className="text-xl font-bold text-gray-800">{items.length}</p>
            </div>
            <div className="w-px h-10 bg-gray-100" />
            <div>
              <p className="text-xs text-gray-400">Estimated Cost</p>
              <p className="text-xl font-bold text-violet-700">AED {totalCost.toFixed(2)}</p>
            </div>
          </div>
          {/* Repeat buttons for easy access */}
          <div className="hidden sm:flex items-center gap-2">
            <button onClick={saveDraft} disabled={saving}
              className="flex items-center gap-2 px-4 py-2 border-2 border-gray-200 text-gray-600 font-semibold rounded-xl hover:bg-gray-50 transition text-sm">
              <Save className="w-4 h-4" /> Save Draft
            </button>
            <button onClick={submitRequest} disabled={saving}
              className="flex items-center gap-2 px-5 py-2 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition text-sm">
              <Send className="w-4 h-4" /> {saving ? "Submitting..." : "Submit Request"}
            </button>
          </div>
        </div>

        {/* Mobile bottom buttons */}
        <div className="sm:hidden flex gap-3 pb-6">
          <button onClick={saveDraft} disabled={saving}
            className="flex-1 flex items-center justify-center gap-2 py-3 border-2 border-gray-200 text-gray-700 font-bold rounded-xl hover:bg-gray-50 transition">
            <Save className="w-4 h-4" /> Save Draft
          </button>
          <button onClick={submitRequest} disabled={saving}
            className="flex-1 flex items-center justify-center gap-2 py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition">
            <Send className="w-4 h-4" /> {saving ? "Submitting..." : "Submit"}
          </button>
        </div>
      </div>
    </div>
  );
}