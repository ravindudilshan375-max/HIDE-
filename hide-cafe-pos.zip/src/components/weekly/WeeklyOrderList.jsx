import React from "react";
import { format } from "date-fns";
import { ClipboardList, ChevronRight } from "lucide-react";

const STATUS_CONFIG = {
  draft:            { label: "Processing",      bg: "bg-amber-100",  text: "text-amber-700" },
  pending:          { label: "Processing",      bg: "bg-amber-100",  text: "text-amber-700" },
  approved:         { label: "Approved",        bg: "bg-blue-100",   text: "text-blue-700" },
  rejected:         { label: "Rejected",        bg: "bg-red-100",    text: "text-red-600" },
  sent:             { label: "Sent",            bg: "bg-blue-100",   text: "text-blue-700" },
  ready_to_receive: { label: "Ready to Receive", bg: "bg-orange-100", text: "text-orange-600" },
  received:         { label: "Received",        bg: "bg-green-100",  text: "text-green-700" },
};

function EmptyState() {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm py-16 text-center">
      <ClipboardList className="w-12 h-12 text-gray-200 mx-auto mb-3" />
      <p className="text-gray-400 text-sm font-medium">No requests found</p>
      <p className="text-gray-300 text-xs mt-1">Click "New Request" to create one</p>
    </div>
  );
}

export default function WeeklyOrderList({ orders, onSelect }) {
  if (!orders?.length) return <EmptyState />;

  return (
    <div className="space-y-2">
      {orders.map(order => {
        const cfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.draft;
        const weekLabel = order.week_start && order.week_end
          ? `${format(new Date(order.week_start), "d MMM")} – ${format(new Date(order.week_end), "d MMM")}`
          : "—";
        return (
          <button
            key={order.id}
            onClick={() => onSelect(order)}
            className="w-full bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-left hover:shadow-md hover:border-violet-200 transition-all group"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-gray-900 text-sm">{order.branch_name || "—"}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.text}`}>
                    {cfg.label}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mb-2">Week: {weekLabel}</p>
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  <span>👤 {order.requested_by || "—"}</span>
                  <span>📦 {order.items?.length || 0} items</span>
                  {order.total_estimated_cost > 0 && (
                    <span className="font-semibold text-violet-600">AED {(order.total_estimated_cost || 0).toFixed(0)}</span>
                  )}
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-violet-500 transition flex-shrink-0 mt-1" />
            </div>
          </button>
        );
      })}
    </div>
  );
}