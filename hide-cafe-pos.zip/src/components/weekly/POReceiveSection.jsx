import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { PackageCheck, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function POReceiveSection({ po_id, po_reference, onReceiveClick }) {
  const [po, setPo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPO = async () => {
      if (po_id) {
        const poData = await base44.entities.PurchaseOrder.get(po_id).catch(() => null);
        setPo(poData);
      }
      setLoading(false);
    };
    loadPO();
  }, [po_id]);

  const isApproved = po && (po.status === "approved" || po.status === "ready_to_receive" || po.status === "received" || po.status === "completed");
  const isDraft = po && po.status === "draft";

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-5 h-5 text-violet-500 animate-spin" />
      </div>
    );
  }

  if (isDraft) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 shrink-0" />
        <div>
          <p className="text-sm font-semibold text-red-700">Cannot Receive — PO Not Approved</p>
          <p className="text-xs text-red-600 mt-0.5">The linked Purchase Order (PO: {po_reference}) is still in Draft status. A manager must approve it before you can receive items.</p>
        </div>
      </div>
    );
  }

  if (isApproved) {
    return (
      <div className="space-y-3">
        <Button onClick={onReceiveClick}
          className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl h-12 gap-2 text-base">
          <PackageCheck className="w-5 h-5" /> Receive Order
        </Button>
        {po_reference && (
          <p className="text-xs text-gray-400 text-center">Linked PO: {po_reference} · Status: {po?.status}</p>
        )}
      </div>
    );
  }

  return null;
}