import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { ChevronLeft, Edit2, ExternalLink, PackageCheck, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import WeeklyReceiveModal from "./WeeklyReceiveModal";
import POReceiveSection from "./POReceiveSection";
import CancelOrderModal from "./CancelOrderModal";

const STATUS_CONFIG = {
  draft:            { label: "Processing",      bg: "bg-amber-100",  text: "text-amber-700" },
  pending:          { label: "Processing",      bg: "bg-amber-100",  text: "text-amber-700" },
  approved:         { label: "Approved",        bg: "bg-blue-100",   text: "text-blue-700" },
  rejected:         { label: "Rejected",        bg: "bg-red-100",    text: "text-red-600" },
  sent:             { label: "Sent",            bg: "bg-blue-100",   text: "text-blue-700" },
  ready_to_receive: { label: "Ready to Receive", bg: "bg-orange-100", text: "text-orange-600" },
  received:         { label: "Received",        bg: "bg-green-100",  text: "text-green-700" },
  canceled:         { label: "Canceled",        bg: "bg-gray-200",   text: "text-gray-700" },
};

const WORKFLOW_STEPS = [
  { key: "processing", label: "Processing", statuses: ["draft", "pending"] },
  { key: "approved",   label: "Approved",   statuses: ["approved"] },
  { key: "ready",      label: "Ready",      statuses: ["ready_to_receive"] },
  { key: "received",   label: "Received",   statuses: ["received"] },
];

const STATUS_ORDER = ["draft", "pending", "approved", "ready_to_receive", "received"];

function WorkflowTracker({ status }) {
  const currentIdx = STATUS_ORDER.indexOf(status);
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-5 py-4">
      <div className="flex items-center gap-0">
        {WORKFLOW_STEPS.map((step, i) => {
          const stepIdx = STATUS_ORDER.indexOf(step.statuses[0]);
          const isActive = step.statuses.includes(status);
          const isDone = currentIdx > stepIdx || (status === "received" && step.key === "received");
          const colors = {
            processing: "bg-amber-500 border-amber-500",
            approved:   "bg-blue-500 border-blue-500",
            ready:      "bg-orange-500 border-orange-500",
            received:   "bg-green-500 border-green-500",
          };
          const activeColor = colors[step.key];
          return (
            <React.Fragment key={step.key}>
              <div className="flex flex-col items-center flex-1 min-w-0">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mb-1 border-2 transition-all ${
                  isActive ? `${activeColor} text-white` :
                  isDone   ? "bg-green-500 border-green-500 text-white" :
                             "bg-white border-gray-200 text-gray-300"
                }`}>
                  {isDone && !isActive ? "✓" : i + 1}
                </div>
                <span className={`text-[10px] font-semibold text-center truncate w-full px-1 ${
                  isActive ? "text-gray-800" : isDone ? "text-green-600" : "text-gray-300"
                }`}>{step.label}</span>
              </div>
              {i < WORKFLOW_STEPS.length - 1 && (
                <div className={`h-0.5 flex-1 mt-[-14px] transition-all ${
                  STATUS_ORDER.indexOf(WORKFLOW_STEPS[i + 1].statuses[0]) <= currentIdx ? "bg-green-400" : "bg-gray-200"
                }`} />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

export default function WeeklyOrderDetail({ order, onBack, onEdit, onRefresh, isManager }) {
  const [saving, setSaving] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);

  const weekLabel = order.week_start && order.week_end
    ? `${format(new Date(order.week_start), "d MMM")} – ${format(new Date(order.week_end), "d MMM yyyy")}`
    : "—";

  const cfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.draft;

  const convertToPO = async () => {
    setSaving(true);
    const res = await base44.functions.invoke("submitWeeklyOrder", { request_id: order.id });
    if (res.data?.success) {
      toast.success(`Draft PO ${res.data.po_reference} created successfully!`);
      onRefresh();
      onBack();
    } else {
      toast.error(res.data?.error || "Failed to create PO");
    }
    setSaving(false);
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Top bar */}
      <div className="sticky top-0 z-10 bg-white border-b border-gray-100 shadow-sm px-4 py-3 flex items-center gap-3">
        <button onClick={onBack} className="text-gray-400 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100 transition">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h1 className="text-base font-bold text-gray-900">{order.branch_name}</h1>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.text}`}>
              {cfg.label}
            </span>
          </div>
          <p className="text-xs text-gray-400">Week: {weekLabel}</p>
        </div>
        {(order.status === "draft" || order.status === "pending") && (
          <button onClick={onEdit} className="text-violet-600 hover:text-violet-800 p-1.5 border border-violet-200 rounded-xl hover:bg-violet-50 transition">
            <Edit2 className="w-4 h-4" />
          </button>
        )}
        {isManager && order.status !== "canceled" && order.status !== "received" && (
          <button onClick={() => setShowCancelModal(true)} className="text-red-600 hover:text-red-800 p-1.5 border border-red-200 rounded-xl hover:bg-red-50 transition">
            <AlertCircle className="w-4 h-4" />
          </button>
        )}

      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4 pb-6">

        {/* Info */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-xs text-gray-400">Requested By</p>
              <p className="font-semibold text-gray-800 mt-0.5">{order.requested_by || "—"}</p>
            </div>
            <div>
              <p className="text-xs text-gray-400">Submitted</p>
              <p className="font-semibold text-gray-800 mt-0.5">
                {order.created_date ? format(new Date(order.created_date), "d MMM yyyy") : "—"}
              </p>
            </div>
          </div>
          {order.notes && (
            <div className="mt-3 pt-3 border-t border-gray-100">
              <p className="text-xs text-gray-400">Notes</p>
              <p className="text-sm text-gray-700 mt-0.5">{order.notes}</p>
            </div>
          )}
          {order.manager_notes && (
            <div className="mt-3 pt-3 border-t border-gray-100">
              <p className="text-xs text-gray-400">Manager Notes</p>
              <p className="text-sm text-amber-700 mt-0.5">{order.manager_notes}</p>
            </div>
          )}
        </div>

        {/* Items */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-50">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Items ({order.items?.length || 0})</h2>
          </div>

          {/* Header */}
          <div className="grid grid-cols-12 text-[10px] font-bold text-gray-400 uppercase tracking-wider px-5 py-2 bg-gray-50">
            <span className="col-span-5">Item</span>
            <span className="col-span-2 text-center">In Stock</span>
            <span className="col-span-2 text-center">Requested</span>
            <span className="col-span-2 text-center">Unit</span>
            <span className="col-span-1 text-right">Est.</span>
          </div>

          {(order.items || []).map((item, idx) => (
            <div key={idx} className="grid grid-cols-12 items-center px-5 py-3 border-t border-gray-50">
              <div className="col-span-5">
                <p className="text-sm font-semibold text-gray-800">{item.item_name}</p>
                {item.unit_cost > 0 && <p className="text-[10px] text-gray-400">AED {item.unit_cost?.toFixed(2)}/{item.unit}</p>}
              </div>
              <div className="col-span-2 text-center text-xs text-gray-500">{item.current_stock}</div>
              <div className="col-span-2 text-center">
                <span className="text-sm font-bold text-violet-700">{item.requested_qty}</span>
              </div>
              <div className="col-span-2 text-center text-xs text-gray-400">{item.unit}</div>
              <div className="col-span-1 text-right text-xs font-semibold text-gray-600">
                {(item.estimated_cost || 0).toFixed(0)}
              </div>
            </div>
          ))}

          <div className="flex items-center justify-between px-5 py-3 border-t border-gray-100 bg-gray-50">
            <span className="text-sm font-semibold text-gray-600">Estimated Total</span>
            <span className="text-base font-bold text-violet-700">AED {(order.total_estimated_cost || 0).toFixed(2)}</span>
          </div>
        </div>

        {/* Workflow Progress Bar */}
        <WorkflowTracker status={order.status} />

        {/* Manager: Approve Request */}
        {isManager && (order.status === "draft" || order.status === "pending") && (
          <div className="space-y-3">
            <Button onClick={convertToPO} disabled={saving}
              className="w-full bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl h-12 gap-2 text-base">
              <ExternalLink className="w-5 h-5" /> {saving ? "Creating..." : "Approve & Create Purchase Order"}
            </Button>
            <p className="text-xs text-gray-400 text-center">Approves this request, creates a PO, and marks it as Ready to Receive</p>
          </div>
        )}

        {/* Staff: blocked if not yet approved */}
        {!isManager && (order.status === "draft" || order.status === "pending") && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
            <Clock className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-amber-700">Awaiting Manager Approval</p>
              <p className="text-xs text-amber-600 mt-0.5">A manager must approve this request before you can receive items.</p>
            </div>
          </div>
        )}

        {/* Blocked: approved but PO not yet sent */}
        {order.status === "approved" && (
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3">
            <Clock className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-blue-700">Purchase Order Created</p>
              <p className="text-xs text-blue-600 mt-0.5">The PO must be sent to the supplier before you can receive items. Status will change to <strong>Ready</strong> once sent.</p>
              {order.po_reference && <p className="text-xs text-blue-500 mt-1">PO: {order.po_reference}</p>}
            </div>
          </div>
        )}

        {/* Ready to Receive — check PO status */}
        {order.status === "ready_to_receive" && order.po_id && (
          <POReceiveSection po_id={order.po_id} po_reference={order.po_reference} onReceiveClick={() => setShowReceiveModal(true)} />
        )}

        {/* Received confirmation */}
        {order.status === "received" && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4 text-center">
            <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-green-700 font-bold text-sm">Delivery Confirmed</p>
            {order.received_date && (
              <p className="text-xs text-green-600 mt-1">{format(new Date(order.received_date), "d MMM yyyy, HH:mm")}</p>
            )}
          </div>
        )}

        {/* Canceled status */}
        {order.status === "canceled" && (
          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-3">
            <div className="text-center">
              <p className="text-gray-700 font-bold text-sm">Order Canceled</p>
              <p className="text-xs text-gray-500 mt-1">This order was canceled and cannot be received.</p>
            </div>
            {order.canceled_by && (
              <div className="pt-3 border-t border-gray-200 space-y-1 text-xs text-gray-600">
                <p><strong>Canceled By:</strong> {order.canceled_by}</p>
                {order.canceled_at && <p><strong>Date:</strong> {format(new Date(order.canceled_at), "d MMM yyyy, HH:mm")}</p>}
                {order.cancel_reason && <p><strong>Reason:</strong> {order.cancel_reason.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}</p>}
              </div>
            )}
          </div>
        )}
        </div>

      {showReceiveModal && (
        <WeeklyReceiveModal
          order={order}
          onConfirm={() => { setShowReceiveModal(false); onRefresh(); onBack(); }}
          onClose={() => setShowReceiveModal(false)}
        />
      )}

      {showCancelModal && (
        <CancelOrderModal
          order={order}
          onClose={() => setShowCancelModal(false)}
          onCanceled={() => { setShowCancelModal(false); onRefresh(); }}
        />
      )}
    </div>
  );
}