import React from "react";
import {
  BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg p-3 text-xs">
      <p className="font-semibold text-gray-700 mb-1">{payload[0]?.payload?.fullLabel || label}</p>
      <p className="text-violet-600">Sales: AED {Number(payload[0]?.value || 0).toFixed(2)}</p>
      {payload[1] && <p className="text-blue-500">Orders: {payload[1]?.value}</p>}
    </div>
  );
};

export default function SalesTrendChart({ data, period }) {
  const isToday = period === "today";
  const totalSales = data.reduce((s, d) => s + (d.sales || 0), 0);
  const totalOrders = data.reduce((s, d) => s + (d.orders || 0), 0);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 h-full">
      <div className="flex items-start justify-between mb-5">
        <div>
          <h3 className="font-semibold text-gray-900">Sales Revenue</h3>
          <p className="text-xs text-gray-400 mt-0.5">{isToday ? "Hourly breakdown" : "Daily trend"}</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-gray-900">AED {totalSales.toFixed(0)}</p>
          <p className="text-xs text-gray-400">{totalOrders} orders</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={200}>
        {isToday ? (
          <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="sales" fill="#7C3AED" radius={[4, 4, 0, 0]} />
          </BarChart>
        ) : (
          <AreaChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#7C3AED" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="sales" stroke="#7C3AED" strokeWidth={2.5} fill="url(#salesGrad)" dot={{ r: 3, fill: "#7C3AED", strokeWidth: 0 }} />
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}