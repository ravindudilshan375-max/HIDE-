import React from "react";
import { DollarSign, ShoppingBag, TrendingUp, Receipt, Tag, Building2 } from "lucide-react";

const CARDS = [
  { key: "totalSales", label: "Total Sales", icon: DollarSign, bg: "bg-violet-50", text: "text-violet-600", format: v => `AED ${v.toFixed(2)}` },
  { key: "totalOrders", label: "Total Orders", icon: ShoppingBag, bg: "bg-blue-50", text: "text-blue-600", format: v => v },
  { key: "avgOrder", label: "Avg Order", icon: TrendingUp, bg: "bg-emerald-50", text: "text-emerald-600", format: v => `AED ${v.toFixed(2)}` },
  { key: "vatCollected", label: "VAT (5%)", icon: Receipt, bg: "bg-orange-50", text: "text-orange-600", format: v => `AED ${v.toFixed(2)}` },
  { key: "discounts", label: "Discounts", icon: Tag, bg: "bg-rose-50", text: "text-rose-600", format: v => `AED ${v.toFixed(2)}` },
  { key: "activeBranches", label: "Active Branches", icon: Building2, bg: "bg-indigo-50", text: "text-indigo-600", format: v => v },
];

export default function KPICards({ data, loading }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-4">
      {CARDS.map(card => {
        const Icon = card.icon;
        const val = data[card.key] ?? 0;
        return (
          <div key={card.key} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${card.bg}`}>
              <Icon className={`w-4 h-4 ${card.text}`} />
            </div>
            <p className="text-xs font-medium text-gray-400 mb-1">{card.label}</p>
            {loading ? (
              <div className="h-7 bg-gray-100 rounded animate-pulse w-20" />
            ) : (
              <p className="text-xl font-bold text-gray-900 leading-tight">{card.format(val)}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}