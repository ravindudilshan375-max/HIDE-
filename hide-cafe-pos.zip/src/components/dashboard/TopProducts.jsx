import React from "react";
import { BarChart2 } from "lucide-react";

export default function TopProducts({ data, loading }) {
  const maxRevenue = data[0]?.revenue || 1;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-gray-900">Top Selling Products</h3>
        <BarChart2 className="w-4 h-4 text-violet-500" />
      </div>
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map(i => <div key={i} className="h-10 bg-gray-50 rounded-xl animate-pulse" />)}
        </div>
      ) : data.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-8">No product data yet</p>
      ) : (
        <div className="space-y-3">
          {data.map((product, idx) => (
            <div key={product.name} className="flex items-center gap-3">
              <span className="text-xs font-bold text-gray-300 w-4 shrink-0">{idx + 1}</span>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium text-gray-800 truncate">{product.name}</span>
                  <span className="text-sm font-semibold text-violet-700 shrink-0 ml-2">AED {product.revenue.toFixed(0)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-100 rounded-full h-1.5">
                    <div
                      className="h-1.5 rounded-full bg-violet-400"
                      style={{ width: `${Math.max(4, Math.round((product.revenue / maxRevenue) * 100))}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-gray-400 shrink-0">{product.qty} sold</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}