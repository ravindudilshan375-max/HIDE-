import React from "react";
import { AlertTriangle, AlertCircle, XCircle } from "lucide-react";

function getAlert(item) {
  const qty = item.current_quantity || 0;
  if (qty <= 0) return { label: "Out of Stock", Icon: XCircle, bg: "bg-red-50", border: "border-red-200", text: "text-red-600" };
  if (qty <= (item.low_stock_threshold || 5) * 0.5) return { label: "Critical", Icon: AlertCircle, bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-600" };
  return { label: "Low Stock", Icon: AlertTriangle, bg: "bg-yellow-50", border: "border-yellow-200", text: "text-yellow-600" };
}

export default function InventoryAlerts({ items }) {
  if (!items.length) return null;
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="w-4 h-4 text-amber-500" />
        <h3 className="font-semibold text-gray-900">Inventory Alerts</h3>
        <span className="bg-red-100 text-red-600 text-xs font-bold px-2 py-0.5 rounded-full">{items.length}</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {items.map(item => {
          const { label, Icon, bg, border, text } = getAlert(item);
          return (
            <div key={item.id} className={`border rounded-xl p-3 ${bg} ${border}`}>
              <div className={`flex items-center gap-1.5 mb-1 ${text}`}>
                <Icon className="w-3.5 h-3.5" />
                <span className="text-[10px] font-semibold uppercase tracking-wide">{label}</span>
              </div>
              <p className="text-sm font-semibold text-gray-900 truncate">{item.name}</p>
              <p className="text-xs text-gray-500 mt-0.5">{item.current_quantity || 0} {item.unit}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}