import React from "react";
import { Award } from "lucide-react";

export default function BranchPerformance({ data, loading }) {
  const maxSales = data[0]?.sales || 1;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-gray-900">Branch Performance</h3>
        <Award className="w-4 h-4 text-amber-500" />
      </div>
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => <div key={i} className="h-14 bg-gray-50 rounded-xl animate-pulse" />)}
        </div>
      ) : data.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-8">No branch data</p>
      ) : (
        <div className="space-y-4">
          {data.map((branch, idx) => (
            <div key={branch.id} className="space-y-1.5">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                    idx === 0 ? "bg-amber-100 text-amber-700" :
                    idx === data.length - 1 && data.length > 1 ? "bg-red-100 text-red-600" :
                    "bg-gray-100 text-gray-500"
                  }`}>{idx + 1}</span>
                  <span className="font-medium text-gray-800 truncate max-w-[110px]">{branch.name}</span>
                </div>
                <div className="text-right shrink-0">
                  <p className="font-semibold text-gray-900 text-xs">AED {branch.sales.toFixed(0)}</p>
                  <p className="text-[10px] text-gray-400">{branch.orders} orders · avg AED {branch.avgOrder.toFixed(0)}</p>
                </div>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-1.5">
                <div
                  className={`h-1.5 rounded-full transition-all ${idx === 0 ? "bg-violet-500" : "bg-gray-300"}`}
                  style={{ width: `${Math.max(4, Math.round((branch.sales / maxSales) * 100))}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}