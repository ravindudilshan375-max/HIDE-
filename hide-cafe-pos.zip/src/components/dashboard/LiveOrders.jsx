import React from "react";

const STATUS_CONFIG = {
  pending:   { label: "Pending",   color: "bg-yellow-100 text-yellow-700" },
  preparing: { label: "Preparing", color: "bg-blue-100 text-blue-700" },
  ready:     { label: "Ready",     color: "bg-purple-100 text-purple-700" },
  served:    { label: "Served",    color: "bg-indigo-100 text-indigo-700" },
};

export default function LiveOrders({ orders, branches, loading }) {
  const getBranchName = id => branches.find(b => b.id === id)?.name || "—";

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-gray-900">Live Orders</h3>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs text-green-600 font-medium">Live · {orders.length} active</span>
        </div>
      </div>
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-10 bg-gray-50 rounded-xl animate-pulse" />)}
        </div>
      ) : orders.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-8">No active orders right now</p>
      ) : (
        <div className="space-y-1 max-h-72 overflow-y-auto">
          {orders.map(order => {
            const cfg = STATUS_CONFIG[order.status] || { label: order.status, color: "bg-gray-100 text-gray-600" };
            return (
              <div key={order.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-violet-50 flex items-center justify-center text-[10px] font-bold text-violet-600 shrink-0">
                    {order.type === "dine-in" ? `T${order.table_number || "?"}` : "TO"}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-800 leading-tight">{order.order_number || `#${order.id?.slice(-6)}`}</p>
                    <p className="text-[10px] text-gray-400">{getBranchName(order.branch_id)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${cfg.color}`}>{cfg.label}</span>
                  <span className="text-sm font-semibold text-gray-900">AED {(order.total || 0).toFixed(0)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}