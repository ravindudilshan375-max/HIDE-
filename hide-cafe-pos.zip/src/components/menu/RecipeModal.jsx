import React, { useState } from "react";
import { X, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function RecipeModal({ recipe, inventoryItems, onSave, onClose }) {
  const [items, setItems] = useState(recipe || []);
  const [search, setSearch] = useState("");
  const [pending, setPending] = useState(null);

  const filtered = inventoryItems.filter(inv =>
    inv.name.toLowerCase().includes(search.toLowerCase()) &&
    !items.some(r => r.inventory_item_id === inv.id)
  ).slice(0, 10);

  const handleAdd = () => {
    if (!pending?.qty) return;
    setItems(prev => [...prev, {
      inventory_item_id: pending.inv.id,
      inventory_item_name: pending.inv.name,
      quantity: parseFloat(pending.qty),
      unit: pending.unit,
    }]);
    setPending(null);
    setSearch("");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div>
            <h2 className="font-bold text-gray-900 text-lg">Recipe / Ingredients</h2>
            <p className="text-xs text-gray-400 mt-0.5">Add ingredients used to make this product</p>
          </div>
          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {/* Current ingredients */}
          {items.length > 0 && (
            <div className="space-y-2">
              {items.map((r, i) => (
                <div key={i} className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-2.5">
                  <span className="flex-1 text-sm font-medium text-gray-800">{r.inventory_item_name}</span>
                  <span className="text-sm text-violet-600 font-semibold">{r.quantity} {r.unit}</span>
                  <button onClick={() => setItems(prev => prev.filter((_, j) => j !== i))} className="text-gray-300 hover:text-red-500 transition">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search inventory items..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPending(null); }}
              className="pl-9 border-gray-200 rounded-xl text-gray-900"
            />
          </div>

          {/* Search results */}
          {search && !pending && filtered.length > 0 && (
            <div className="border border-gray-100 rounded-xl overflow-hidden divide-y divide-gray-50">
              {filtered.map(inv => (
                <button key={inv.id} type="button"
                  onClick={() => { setPending({ inv, qty: "", unit: inv.unit || "" }); setSearch(inv.name); }}
                  className="w-full text-left px-4 py-2.5 hover:bg-violet-50 transition flex items-center justify-between">
                  <span className="text-sm text-gray-800 font-medium">{inv.name}</span>
                  <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{inv.unit}</span>
                </button>
              ))}
            </div>
          )}

          {/* Quantity input */}
          {pending && (
            <div className="bg-violet-50 border border-violet-200 rounded-xl p-4 space-y-3">
              <p className="text-sm font-semibold text-violet-800">{pending.inv.name}</p>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="text-xs text-gray-500 mb-1 block">Quantity</label>
                  <Input
                    type="number" min="0" step="0.001" placeholder="0.00"
                    value={pending.qty}
                    onChange={e => setPending(p => ({ ...p, qty: e.target.value }))}
                    className="border-gray-200 rounded-xl text-gray-900"
                    autoFocus
                  />
                </div>
                <div className="flex-1">
                  <label className="text-xs text-gray-500 mb-1 block">Unit</label>
                  <Input
                    placeholder="Unit"
                    value={pending.unit}
                    onChange={e => setPending(p => ({ ...p, unit: e.target.value }))}
                    className="border-gray-200 rounded-xl text-gray-900"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAdd} disabled={!pending.qty}
                  className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl flex-1">
                  Add Ingredient
                </Button>
                <Button variant="outline" onClick={() => { setPending(null); setSearch(""); }} className="rounded-xl border-gray-200">
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {items.length === 0 && !search && (
            <div className="text-center py-8 text-gray-300 text-sm">
              No ingredients added yet. Search above to add items.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose} className="rounded-xl border-gray-200">Cancel</Button>
          <Button onClick={() => onSave(items)} className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl">
            Save Recipe ({items.length} items)
          </Button>
        </div>
      </div>
    </div>
  );
}