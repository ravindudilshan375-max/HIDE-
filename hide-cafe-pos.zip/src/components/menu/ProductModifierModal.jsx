import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Search } from "lucide-react";
import { toast } from "sonner";

export default function ProductModifierModal({ productId, modifierGroups, linkedGroupIds = [], onClose, onSave }) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(new Set(linkedGroupIds));
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => {
    return modifierGroups.filter(g => 
      g.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [modifierGroups, search]);

  const handleToggle = (groupId) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(groupId)) {
        next.delete(groupId);
      } else {
        next.add(groupId);
      }
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const selectedIds = Array.from(selected);
      await base44.entities.MenuItem.update(productId, { modifier_groups: selectedIds });
      toast.success("Modifiers updated");
      onSave(selectedIds);
    } catch (error) {
      toast.error("Failed to update modifiers");
      console.error(error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-96">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h3 className="font-bold text-gray-900">Add Modifier Groups</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="px-5 py-3 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search modifiers..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 border-gray-200 rounded-xl text-sm"
            />
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filtered.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-4">No modifier groups found</p>
          ) : (
            filtered.map(group => {
              const isSelected = selected.has(group.id);
              return (
                <label key={group.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer transition">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => handleToggle(group.id)}
                    className="mt-1 rounded w-4 h-4"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-gray-800 text-sm">{group.name}</div>
                    <div className="text-xs text-gray-400 mt-0.5">
                      {group.options?.length || 0} options • Min: {group.min_select ?? 0}, Max: {group.max_select ?? 1}
                    </div>
                  </div>
                </label>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose} className="rounded-xl border-gray-200">
            Cancel
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={saving}
            className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl"
          >
            {saving ? "Saving..." : "Save"}
          </Button>
        </div>
      </div>
    </div>
  );
}