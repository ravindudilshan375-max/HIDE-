import React, { useState, useRef } from "react";
import * as XLSX from "xlsx";
import { base44 } from "@/api/base44Client";
import {
  Upload, Download, X, AlertCircle, CheckCircle2,
  FileText, Loader2, ChevronDown, ChevronRight, FileDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

// ── CSV helpers ────────────────────────────────────────────────
function parseCSVLine(line) {
  const result = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
      else { inQuotes = !inQuotes; }
    } else if (ch === "," && !inQuotes) {
      result.push(current.trim()); current = "";
    } else { current += ch; }
  }
  result.push(current.trim());
  return result;
}

function parseCSV(text) {
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter(l => l.trim());
  if (lines.length < 2) return [];
  const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase().trim().replace(/\s+/g, "_"));
  return lines.slice(1).map((line, idx) => {
    const vals = parseCSVLine(line);
    const obj = { _row: idx + 2 };
    headers.forEach((h, i) => { obj[h] = vals[i] ?? ""; });
    return obj;
  });
}

function parseXLSX(buffer) {
  const wb = XLSX.read(buffer, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json(ws, { defval: "" });
  return raw.map((row, i) => {
    const normalized = { _row: i + 2 };
    for (const key of Object.keys(row)) {
      normalized[key.toLowerCase().trim().replace(/\s+/g, "_")] = row[key];
    }
    return normalized;
  });
}

async function readFile(file) {
  const name = file.name.toLowerCase();
  if (name.endsWith(".json")) {
    const text = await file.text();
    const parsed = JSON.parse(text);
    return (Array.isArray(parsed) ? parsed : parsed.items || []).map((r, i) => ({ _row: i + 2, ...r }));
  } else if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
    const buffer = await file.arrayBuffer();
    return parseXLSX(new Uint8Array(buffer));
  } else {
    return parseCSV(await file.text());
  }
}

function toCSV(rows, headers) {
  const escape = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [headers.join(","), ...rows.map(r => headers.map(h => escape(r[h])).join(","))].join("\n");
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ── Type configs ───────────────────────────────────────────────
const TYPE_CONFIG = {
  products: {
    title: "Products",
    importLabel: "Import Products",
    exportLabel: "Export Products",
    csvExample: `category_name,item_name,description,price,sku,active\nCoffee,Latte,Hot milk coffee,18,LAT001,true\nCoffee,Espresso,Strong coffee,12,ESP001,true`,
    exportHeaders: ["category_name", "item_name", "description", "price", "sku", "active"],
  },
  recipes: {
    title: "Recipes",
    importLabel: "Import Recipes",
    exportLabel: "Export Recipes",
    csvExample: `product_sku,ingredient_name,quantity,unit\nLAT001,Espresso Shot,30,ml\nLAT001,Oat Milk,200,ml`,
    exportHeaders: ["product_sku", "product_name", "ingredient_name", "quantity", "unit"],
  },
  modifiers: {
    title: "Modifier Groups",
    importLabel: "Import Modifier Groups",
    exportLabel: "Export Modifier Groups",
    csvExample: `group_name,option_name,option_price,required,max_select\nMilk Options,Oat Milk,3,false,1\nMilk Options,Almond Milk,3,false,1\nSize,Small,0,true,1`,
    exportHeaders: ["group_name", "option_name", "option_price", "required", "max_select"],
  },
};

// ── Import handlers ────────────────────────────────────────────
async function importProducts(rows, branches, onProgress) {
  const branchId = branches?.[0]?.id || "";
  let existing = [];
  try { existing = await base44.entities.MenuItem.list(); } catch {}
  const skuMap = new Map(existing.filter(i => i.sku).map(i => [String(i.sku).trim(), i.id]));
  const nameMap = new Map(existing.map(i => [`${i.category || ""}|||${i.name || ""}`, i.id]));

  let success = 0; const errors = [];
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    try {
      const sku = String(row.sku || "").trim();
      const itemName = String(row.item_name || row.name || "").trim();
      const category = String(row.category_name || row.category || "").trim();
      if (!itemName) { errors.push(`Row ${row._row}: Missing item_name`); continue; }
      const price = parseFloat(row.price);
      if (isNaN(price)) { errors.push(`Row ${row._row}: Invalid price`); continue; }
      const payload = { name: itemName, category, base_price: price, description: String(row.description || "").trim(), is_available: String(row.active).toLowerCase() !== "false", branch_id: branchId, ...(sku ? { sku } : {}) };
      const existingId = sku ? skuMap.get(sku) : nameMap.get(`${category}|||${itemName}`);
      if (existingId) { await base44.entities.MenuItem.update(existingId, payload); }
      else { const c = await base44.entities.MenuItem.create(payload); if (sku) skuMap.set(sku, c.id); nameMap.set(`${category}|||${itemName}`, c.id); }
      success++;
    } catch (err) { errors.push(`Row ${row._row}: ${err.message || "Failed"}`); }
    onProgress(i + 1, rows.length);
  }
  return { success, errors };
}

async function importRecipes(rows, onProgress) {
  let menuItems = [];
  try { menuItems = await base44.entities.MenuItem.list(); } catch {}
  let invItems = [];
  try { invItems = await base44.entities.InventoryItem.list(); } catch {}
  const skuMap = new Map(menuItems.filter(i => i.sku).map(i => [String(i.sku).trim(), i]));
  const nameMap = new Map(menuItems.map(i => [String(i.name).toLowerCase().trim(), i]));
  const invNameMap = new Map(invItems.map(i => [String(i.name).toLowerCase().trim(), i]));

  // Group rows by product
  const grouped = new Map();
  for (const row of rows) {
    const key = String(row.product_sku || row.product_name || "").trim();
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }

  let success = 0; const errors = [];
  let idx = 0;
  for (const [key, group] of grouped) {
    const product = skuMap.get(key) || nameMap.get(key.toLowerCase());
    if (!product) { errors.push(`Product "${key}" not found`); idx += group.length; onProgress(idx, rows.length); continue; }
    const recipe = group.map(row => {
      const invName = String(row.ingredient_name || "").trim();
      const inv = invNameMap.get(invName.toLowerCase());
      return { inventory_item_id: inv?.id || "", inventory_item_name: invName, quantity: parseFloat(row.quantity) || 0, unit: String(row.unit || "").trim() };
    }).filter(r => r.inventory_item_name);
    try {
      await base44.entities.MenuItem.update(product.id, { recipe });
      success++;
    } catch (err) { errors.push(`Product "${key}": ${err.message}`); }
    idx += group.length;
    onProgress(idx, rows.length);
  }
  return { success, errors };
}

async function importModifiers(rows, onProgress) {
  // Group rows by group_name
  const grouped = new Map();
  for (const row of rows) {
    const key = String(row.group_name || "").trim();
    if (!key) continue;
    if (!grouped.has(key)) grouped.set(key, { name: key, required: String(row.required).toLowerCase() === "true", max_select: parseInt(row.max_select) || 1, options: [] });
    const optName = String(row.option_name || "").trim();
    if (optName) grouped.get(key).options.push({ name: optName, price: parseFloat(row.option_price) || 0 });
  }

  let existing = [];
  try { existing = await base44.entities.ModifierGroup.list(); } catch {}
  const existingMap = new Map(existing.map(g => [g.name.toLowerCase().trim(), g.id]));

  let success = 0; const errors = [];
  let idx = 0;
  for (const [, group] of grouped) {
    try {
      const existingId = existingMap.get(group.name.toLowerCase());
      if (existingId) { await base44.entities.ModifierGroup.update(existingId, group); }
      else { await base44.entities.ModifierGroup.create(group); }
      success++;
    } catch (err) { errors.push(`Group "${group.name}": ${err.message}`); }
    idx++;
    onProgress(idx, grouped.size);
  }
  return { success, errors };
}

// ── Export handlers ────────────────────────────────────────────
async function exportProducts(format) {
  const items = await base44.entities.MenuItem.list();
  const rows = items.map(item => ({ category_name: item.category || "", item_name: item.name || "", description: item.description || "", price: item.base_price ?? "", sku: item.sku || "", active: item.is_available !== false ? "true" : "false" }));
  exportData(rows, TYPE_CONFIG.products.exportHeaders, "products_export", format);
  return items.length;
}

async function exportRecipes(format) {
  const items = await base44.entities.MenuItem.list();
  const rows = [];
  for (const item of items) {
    for (const r of (item.recipe || [])) {
      rows.push({ product_sku: item.sku || "", product_name: item.name || "", ingredient_name: r.inventory_item_name || "", quantity: r.quantity || "", unit: r.unit || "" });
    }
  }
  exportData(rows, TYPE_CONFIG.recipes.exportHeaders, "recipes_export", format);
  return rows.length;
}

async function exportModifiers(format) {
  const groups = await base44.entities.ModifierGroup.list();
  const rows = [];
  for (const group of groups) {
    for (const opt of (group.options || [])) {
      rows.push({ group_name: group.name || "", option_name: opt.name || "", option_price: opt.price ?? 0, required: group.required ? "true" : "false", max_select: group.max_select ?? 1 });
    }
  }
  exportData(rows, TYPE_CONFIG.modifiers.exportHeaders, "modifier_groups_export", format);
  return rows.length;
}

function exportData(rows, headers, basename, format) {
  let blob, filename;
  if (format === "xlsx") {
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Data");
    const buf = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    filename = `${basename}.xlsx`;
  } else if (format === "json") {
    blob = new Blob([JSON.stringify(rows, null, 2)], { type: "application/json" });
    filename = `${basename}.json`;
  } else {
    blob = new Blob([toCSV(rows, headers)], { type: "text/csv" });
    filename = `${basename}.csv`;
  }
  downloadBlob(blob, filename);
}

// ── Main component ─────────────────────────────────────────────
export default function MenuImportExport({ type = "products", branches, inventoryItems, modifierGroups, onClose, onImportComplete }) {
  const config = TYPE_CONFIG[type];
  const [mode, setMode] = useState("export"); // export | import
  const [step, setStep] = useState("idle");
  const [preview, setPreview] = useState([]);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [result, setResult] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [showErrors, setShowErrors] = useState(false);
  const fileRef = useRef(null);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    try {
      const rows = await readFile(file);
      if (rows.length === 0) { toast.error("No data found in file"); return; }
      setPreview(rows);
      setStep("preview");
    } catch { toast.error("Could not parse file"); }
  };

  const handleImport = async () => {
    setStep("importing");
    setProgress({ done: 0, total: preview.length });
    const onProgress = (done, total) => setProgress({ done, total });
    let res;
    if (type === "products") res = await importProducts(preview, branches, onProgress);
    else if (type === "recipes") res = await importRecipes(preview, onProgress);
    else res = await importModifiers(preview, onProgress);
    setResult({ total: preview.length, imported: res.success, failed: preview.length - res.success, errors: res.errors });
    setStep("done");
    if (res.success > 0) onImportComplete?.();
  };

  const handleExport = async (format) => {
    setExporting(true);
    try {
      let count;
      if (type === "products") count = await exportProducts(format);
      else if (type === "recipes") count = await exportRecipes(format);
      else count = await exportModifiers(format);
      toast.success(`Exported ${count} rows`);
    } catch { toast.error("Export failed"); }
    setExporting(false);
  };

  const reset = () => { setStep("idle"); setPreview([]); setResult(null); };
  const pct = progress.total > 0 ? Math.round((progress.done / progress.total) * 100) : 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="font-bold text-gray-900">{config.title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
        </div>

        {/* Mode tabs */}
        <div className="flex border-b border-gray-100">
          {["export", "import"].map(m => (
            <button
              key={m}
              onClick={() => { setMode(m); reset(); }}
              className={`flex-1 py-3 text-sm font-semibold capitalize transition border-b-2 ${mode === m ? "border-violet-600 text-violet-700" : "border-transparent text-gray-400 hover:text-gray-600"}`}
            >
              {m === "export" ? <><Download className="inline w-4 h-4 mr-1.5" />{config.exportLabel}</> : <><Upload className="inline w-4 h-4 mr-1.5" />{config.importLabel}</>}
            </button>
          ))}
        </div>

        <div className="overflow-y-auto flex-1 p-6 space-y-4">

          {/* ── EXPORT ── */}
          {mode === "export" && (
            <div className="space-y-4">
              <p className="text-sm text-gray-500">Download your {config.title.toLowerCase()} data as CSV, XLSX, or JSON.</p>
              <div className="flex gap-2">
                <Button onClick={() => handleExport("csv")} disabled={exporting} className="flex-1 bg-green-600 hover:bg-green-700 text-white rounded-xl text-sm gap-2">
                  <FileDown className="w-4 h-4" /> {exporting ? "Exporting..." : "CSV"}
                </Button>
                <Button onClick={() => handleExport("xlsx")} disabled={exporting} variant="outline" className="flex-1 rounded-xl text-sm gap-2 border-gray-200">
                  <FileDown className="w-4 h-4" /> XLSX
                </Button>
                <Button onClick={() => handleExport("json")} disabled={exporting} variant="outline" className="flex-1 rounded-xl text-sm gap-2 border-gray-200">
                  <FileText className="w-4 h-4" /> JSON
                </Button>
              </div>
            </div>
          )}

          {/* ── IMPORT ── */}
          {mode === "import" && (
            <div className="space-y-4">
              {step === "idle" && (
                <>
                  <div
                    onClick={() => fileRef.current?.click()}
                    className="border-2 border-dashed border-violet-200 rounded-xl py-8 flex flex-col items-center gap-2 cursor-pointer hover:bg-violet-50 transition"
                  >
                    <Upload className="w-8 h-8 text-violet-300" />
                    <p className="text-sm font-medium text-gray-600">Click to upload file</p>
                    <p className="text-xs text-gray-400">Supports: .csv, .xlsx, .xls, .json</p>
                  </div>
                  <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls,.json" className="hidden" onChange={handleFile} />
                  <div className="bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-xs text-gray-500 space-y-1">
                    <p className="font-semibold text-gray-600 flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> CSV Format Example</p>
                    <code className="block font-mono bg-white border border-gray-200 rounded-lg px-3 py-2 text-gray-600 whitespace-pre overflow-x-auto text-[10px]">{config.csvExample}</code>
                  </div>
                </>
              )}

              {step === "preview" && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-700">{preview.length} rows detected</p>
                    <button onClick={reset} className="text-xs text-gray-400 hover:text-gray-600">← Change file</button>
                  </div>
                  <div className="border border-gray-100 rounded-xl overflow-hidden max-h-52 overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>{Object.keys(preview[0] || {}).filter(k => k !== "_row").slice(0, 5).map(h => (
                          <th key={h} className="text-left px-3 py-2 text-gray-500 font-semibold capitalize">{h.replace(/_/g, " ")}</th>
                        ))}</tr>
                      </thead>
                      <tbody>
                        {preview.slice(0, 50).map((row, i) => (
                          <tr key={i} className="border-t border-gray-50">
                            {Object.entries(row).filter(([k]) => k !== "_row").slice(0, 5).map(([k, v]) => (
                              <td key={k} className="px-3 py-2 text-gray-600">{String(v) || "—"}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Button onClick={handleImport} className="w-full bg-violet-600 hover:bg-violet-700 text-white rounded-xl gap-2">
                    <Upload className="w-4 h-4" /> Import {preview.length} rows
                  </Button>
                </div>
              )}

              {step === "importing" && (
                <div className="space-y-3 py-4">
                  <div className="flex items-center justify-center gap-3">
                    <Loader2 className="w-5 h-5 text-violet-600 animate-spin" />
                    <p className="text-sm font-medium text-gray-700">Importing... {progress.done} / {progress.total}</p>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                    <div className="bg-violet-600 h-3 rounded-full transition-all duration-300" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-center text-xs text-gray-400">{pct}% complete</p>
                </div>
              )}

              {step === "done" && result && (
                <div className="space-y-3">
                  <div className={`rounded-xl p-4 border ${result.failed === 0 ? "bg-green-50 border-green-200" : "bg-amber-50 border-amber-200"}`}>
                    <p className={`font-bold text-sm mb-3 flex items-center gap-2 ${result.failed === 0 ? "text-green-700" : "text-amber-700"}`}>
                      {result.failed === 0 ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                      Import Complete
                    </p>
                    <div className="grid grid-cols-3 gap-3 text-xs text-center">
                      <div className="bg-white rounded-lg p-2 border border-gray-100"><p className="font-bold text-gray-800 text-lg">{result.total}</p><p className="text-gray-500">Total</p></div>
                      <div className="bg-white rounded-lg p-2 border border-green-100"><p className="font-bold text-green-700 text-lg">{result.imported}</p><p className="text-green-600">Imported</p></div>
                      <div className="bg-white rounded-lg p-2 border border-red-100"><p className="font-bold text-red-600 text-lg">{result.failed}</p><p className="text-red-500">Failed</p></div>
                    </div>
                  </div>
                  {result.errors.length > 0 && (
                    <div className="border border-red-100 rounded-xl overflow-hidden">
                      <button onClick={() => setShowErrors(v => !v)} className="w-full flex items-center justify-between px-4 py-2.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition">
                        <span>{result.errors.length} error{result.errors.length !== 1 ? "s" : ""}</span>
                        {showErrors ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </button>
                      {showErrors && (
                        <div className="max-h-36 overflow-y-auto px-4 py-2 space-y-1 bg-white">
                          {result.errors.map((e, i) => <p key={i} className="text-xs text-red-500 font-mono">{e}</p>)}
                        </div>
                      )}
                    </div>
                  )}
                  <Button onClick={reset} variant="outline" className="w-full rounded-xl border-gray-200 text-sm">Import Another File</Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}