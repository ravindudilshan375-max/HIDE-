import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, Plus, UtensilsCrossed } from "lucide-react";
import RecipeModal from "@/components/menu/RecipeModal";
import { toast } from "sonner";

export default function ProductForm({ item, branches, inventoryItems, onSaved, onCancel }) {
  const [form, setForm] = useState({
    name: item?.name || "",
    name_localized: item?.name_localized || "",
    base_price: item?.base_price ?? "",
    category: item?.category || "",
    description: item?.description || "",
    image_url: item?.image_url || "",
    prep_time: item?.prep_time || "",
    is_available: item?.is_available !== false,
    variants: item?.variants || [],
    modifiers: item?.modifiers || [],
    recipe: item?.recipe || [],
    branch_id: item?.branch_id || branches[0]?.id || "",
    sku: item?.sku || "",
    barcode: item?.barcode || "",
    cost_price: item?.cost_price ?? 0,
    pricing_method: item?.pricing_method || "Fixed Price",
    selling_method: item?.selling_method || "Unit",
    costing_method: item?.costing_method || "Fixed",
    nutrition: item?.nutrition || {},
    branch_prices: item?.branch_prices || [],
    inactive_branches: item?.inactive_branches || [],
    out_of_stock_branches: item?.out_of_stock_branches || [],
  });
  const [categories, setCategories] = useState([]);
  const [showNewCat, setShowNewCat] = useState(false);
  const [newCatName, setNewCatName] = useState("");
  const [savingCat, setSavingCat] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    base44.entities.MenuCategory.filter({ is_deleted: false }, "reference").then(setCategories);
  }, []);

  // Auto-set branch_id once branches load if not already set
  useEffect(() => {
    if (!form.branch_id && branches.length > 0) {
      setForm(f => ({ ...f, branch_id: branches[0].id }));
    }
  }, [branches]);
  const [saving, setSaving] = useState(false);
  const [newVariant, setNewVariant] = useState({ name: "", price: "" });
  const [newMod, setNewMod] = useState({ name: "", price: "" });
  const [showRecipeModal, setShowRecipeModal] = useState(false);

  const save = async () => {
    if (!form.name.trim()) { toast.error("Product name is required"); return; }
    if (form.base_price === "" || form.base_price === null) { toast.error("Price is required"); return; }
    const branchId = form.branch_id || branches[0]?.id;
    if (!branchId) { toast.error("No branch found"); return; }
    setSaving(true);
    const data = { ...form, branch_id: branchId, base_price: parseFloat(form.base_price), prep_time: parseInt(form.prep_time) || null };
    if (item) {
      await base44.entities.MenuItem.update(item.id, data);
      toast.success("Product updated");
    } else {
      await base44.entities.MenuItem.create(data);
      toast.success("Product created");
    }
    setSaving(false);
    onSaved();
  };

  return (
    <>
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-5">

        {/* Back */}
        <button onClick={onCancel} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 transition">
          <ChevronLeft className="w-4 h-4" /> Back
        </button>

        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">{item ? "Edit Product" : "Create Product"}</h1>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onCancel} className="border-gray-200 rounded-xl text-gray-900">Cancel</Button>
            <Button onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
              {saving ? "Saving..." : item ? "Save Changes" : "Create Product"}
            </Button>
          </div>
        </div>

        {/* Basic Info */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4">
          <h3 className="font-semibold text-gray-800">Basic Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Name *</label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Product name" className="border-gray-200 rounded-xl text-gray-900" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Name Localized</label>
              <Input value={form.name_localized} onChange={e => setForm(f => ({ ...f, name_localized: e.target.value }))} placeholder="e.g. Arabic name" className="border-gray-200 rounded-xl text-gray-900" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Category</label>
              <div className="flex gap-2">
                <select
                  value={form.category}
                  onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                  className="flex-1 bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-800 focus:outline-none focus:ring-1 focus:ring-violet-400"
                >
                  <option value="">Select Category</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowNewCat(v => !v)}
                  className="p-2 border border-gray-200 rounded-xl text-gray-400 hover:text-violet-600 hover:border-violet-300 transition"
                  title="Add new category"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              {showNewCat && (
                <div className="mt-2 flex gap-2">
                  <Input
                    placeholder="New category name"
                    value={newCatName}
                    onChange={e => setNewCatName(e.target.value)}
                    className="border-gray-200 rounded-xl flex-1"
                  />
                  <Button
                    type="button"
                    disabled={savingCat || !newCatName.trim()}
                    onClick={async () => {
                      setSavingCat(true);
                      const created = await base44.entities.MenuCategory.create({ name: newCatName.trim() });
                      setCategories(prev => [...prev, created]);
                      setForm(f => ({ ...f, category: created.name }));
                      setNewCatName("");
                      setShowNewCat(false);
                      setSavingCat(false);
                      toast.success("Category added");
                    }}
                    className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl text-sm"
                  >
                    {savingCat ? "Saving..." : "Save"}
                  </Button>
                </div>
              )}
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Price *</label>
              <Input type="number" value={form.base_price} onChange={e => setForm(f => ({ ...f, base_price: e.target.value }))} placeholder="0.00" className="border-gray-200 rounded-xl text-gray-900" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Cost Price</label>
              <Input type="number" value={form.cost_price} onChange={e => setForm(f => ({ ...f, cost_price: parseFloat(e.target.value) || 0 }))} placeholder="0.00" className="border-gray-200 rounded-xl text-gray-900" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">SKU</label>
              <div className="flex gap-2">
                <Input value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} placeholder="e.g. PRD-0001" className="border-gray-200 rounded-xl text-gray-900 flex-1" />
                <Button type="button" variant="outline" size="sm" className="border-gray-200 rounded-xl text-xs whitespace-nowrap"
                  onClick={async () => {
                    const all = await base44.entities.MenuItem.list();
                    const nums = all.map(i => parseInt((i.sku || "").replace("PRD-", ""))).filter(n => !isNaN(n));
                    const next = (nums.length > 0 ? Math.max(...nums) : 0) + 1;
                    setForm(f => ({ ...f, sku: `PRD-${String(next).padStart(4, "0")}` }));
                  }}>
                  Generate
                </Button>
              </div>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Barcode</label>
              <Input value={form.barcode} onChange={e => setForm(f => ({ ...f, barcode: e.target.value }))} placeholder="Barcode" className="border-gray-200 rounded-xl text-gray-900" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Pricing Method</label>
              <select value={form.pricing_method} onChange={e => setForm(f => ({ ...f, pricing_method: e.target.value }))} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-800 focus:outline-none">
                <option>Fixed Price</option>
                <option>Open Price</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Selling Method</label>
              <select value={form.selling_method} onChange={e => setForm(f => ({ ...f, selling_method: e.target.value }))} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-800 focus:outline-none">
                <option>Unit</option>
                <option>Weight</option>
                <option>Volume</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Costing Method</label>
              <select value={form.costing_method} onChange={e => setForm(f => ({ ...f, costing_method: e.target.value }))} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-800 focus:outline-none">
                <option>Fixed</option>
                <option>From Ingredients</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Prep Time (min)</label>
              <Input type="number" value={form.prep_time} onChange={e => setForm(f => ({ ...f, prep_time: e.target.value }))} placeholder="e.g. 5" className="border-gray-200 rounded-xl text-gray-900" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Branch</label>
              <select value={form.branch_id} onChange={e => setForm(f => ({ ...f, branch_id: e.target.value }))} className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-800 focus:outline-none">
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs text-gray-400 mb-1.5 block">Description</label>
              <Input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Short description..." className="border-gray-200 rounded-xl text-gray-900" />
            </div>
          </div>

          {/* Image upload */}
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Product Image</label>
            <div className="flex items-center gap-3">
              {form.image_url && (
                <img src={form.image_url} alt="preview" className="w-16 h-16 object-cover rounded-xl border border-gray-200" />
              )}
              <label className="cursor-pointer flex items-center gap-2 px-4 py-2 border border-dashed border-gray-300 rounded-xl text-sm text-gray-500 hover:border-violet-400 hover:text-violet-600 transition">
                {uploadingImage ? "Uploading..." : form.image_url ? "Change Image" : "Upload Image"}
                <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setUploadingImage(true);
                  const { file_url } = await base44.integrations.Core.UploadFile({ file });
                  setForm(f => ({ ...f, image_url: file_url }));
                  setUploadingImage(false);
                }} />
              </label>
              {form.image_url && (
                <button type="button" onClick={() => setForm(f => ({ ...f, image_url: "" }))} className="text-xs text-red-400 hover:text-red-600">Remove</button>
              )}
            </div>
          </div>

          {/* Active toggle */}
          <div className="flex items-center gap-3">
            <label className="text-xs text-gray-400">Status</label>
            <button
              type="button"
              onClick={() => setForm(f => ({ ...f, is_available: !f.is_available }))}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition ${form.is_available ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}
            >
              {form.is_available ? "Active" : "Inactive"}
            </button>
          </div>
        </div>

        {/* Variants */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-3">
          <h3 className="font-semibold text-gray-800">Variants</h3>
          {form.variants.map((v, i) => (
            <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-xl px-3 py-2 text-sm">
              <span className="flex-1 text-gray-700">{v.name}</span>
              <span className="text-violet-600 font-semibold">฿ {v.price}</span>
              <button onClick={() => setForm(f => ({ ...f, variants: f.variants.filter((_, j) => j !== i) }))} className="text-gray-300 hover:text-red-500 text-xs ml-1">✕</button>
            </div>
          ))}
          <div className="flex gap-2">
            <Input placeholder="Size name (e.g. Small)" value={newVariant.name} onChange={e => setNewVariant(v => ({ ...v, name: e.target.value }))} className="border-gray-200 rounded-xl flex-1" />
            <Input type="number" placeholder="Price" value={newVariant.price} onChange={e => setNewVariant(v => ({ ...v, price: e.target.value }))} className="border-gray-200 rounded-xl w-24" />
            <Button variant="outline" className="rounded-xl border-gray-200" onClick={() => {
              if (!newVariant.name || !newVariant.price) return;
              setForm(f => ({ ...f, variants: [...f.variants, { name: newVariant.name, price: parseFloat(newVariant.price) || 0 }] }));
              setNewVariant({ name: "", price: "" });
            }}>Add</Button>
          </div>
        </div>

        {/* Modifiers */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-3">
          <h3 className="font-semibold text-gray-800">Modifiers</h3>
          {form.modifiers.map((m, i) => (
            <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-xl px-3 py-2 text-sm">
              <span className="flex-1 text-gray-700">{m.name}</span>
              <span className="text-violet-600 font-semibold">{m.price > 0 ? `+฿ ${m.price}` : "Free"}</span>
              <button onClick={() => setForm(f => ({ ...f, modifiers: f.modifiers.filter((_, j) => j !== i) }))} className="text-gray-300 hover:text-red-500 text-xs ml-1">✕</button>
            </div>
          ))}
          <div className="flex gap-2">
            <Input placeholder="Add-on name" value={newMod.name} onChange={e => setNewMod(m => ({ ...m, name: e.target.value }))} className="border-gray-200 rounded-xl flex-1" />
            <Input type="number" placeholder="Price" value={newMod.price} onChange={e => setNewMod(m => ({ ...m, price: e.target.value }))} className="border-gray-200 rounded-xl w-24" />
            <Button variant="outline" className="rounded-xl border-gray-200" onClick={() => {
              if (!newMod.name) return;
              setForm(f => ({ ...f, modifiers: [...f.modifiers, { name: newMod.name, price: parseFloat(newMod.price) || 0 }] }));
              setNewMod({ name: "", price: "" });
            }}>Add</Button>
          </div>
        </div>

        {/* Nutritional Values */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-3">
          <h3 className="font-semibold text-gray-800">Nutritional Values</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { key: "calories", label: "Calories (kCal)" },
              { key: "cholesterol", label: "Cholesterol (mg)" },
              { key: "carbohydrate", label: "Carbohydrate (g)" },
              { key: "fiber", label: "Fiber (g)" },
              { key: "sugars", label: "Total Sugars (g)" },
              { key: "added_sugars", label: "Added Sugars (g)" },
              { key: "salt", label: "Salt (g)" },
              { key: "sodium", label: "Sodium (mg)" },
              { key: "caffeine", label: "Caffeine (mg)" },
            ].map(nf => (
              <div key={nf.key}>
                <label className="text-xs text-gray-400 mb-1.5 block">{nf.label}</label>
                <Input
                  type="number"
                  value={form.nutrition[nf.key] ?? ""}
                  onChange={e => setForm(f => ({ ...f, nutrition: { ...f.nutrition, [nf.key]: e.target.value === "" ? undefined : parseFloat(e.target.value) } }))}
                  placeholder="—"
                  className="border-gray-200 rounded-xl text-gray-900"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Recipe */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-800">Recipe / Ingredients</h3>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowRecipeModal(true)}
              className="border-gray-200 rounded-xl gap-2 text-sm"
            >
              <UtensilsCrossed className="w-4 h-4" />
              {form.recipe.length > 0 ? `Edit Ingredients (${form.recipe.length})` : "Add Ingredients"}
            </Button>
          </div>
          {form.recipe.length > 0 ? (
            <div className="space-y-2">
              {form.recipe.map((r, i) => {
                const invItem = inventoryItems.find(inv => inv.id === r.inventory_item_id);
                const ingredientCost = r.quantity * ((invItem?.unit_cost || 0) / (invItem?.factor || 1));
                return (
                  <div key={i} className="flex items-center gap-3 bg-gray-50 rounded-xl px-3 py-2 text-sm">
                    <span className="flex-1 text-gray-700">{r.inventory_item_name}</span>
                    <span className="text-gray-500">{r.quantity} {r.unit}</span>
                    <span className="text-violet-600 font-semibold">฿ {ingredientCost.toFixed(2)}</span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-gray-400">No ingredients added yet.</p>
          )}
        </div>

      </div>
    </div>

    {showRecipeModal && (
      <RecipeModal
        recipe={form.recipe}
        inventoryItems={inventoryItems}
        onSave={(updated) => { setForm(f => ({ ...f, recipe: updated })); setShowRecipeModal(false); }}
        onClose={() => setShowRecipeModal(false)}
      />
    )}
    </>
  );
}