import React, { useState } from "react";
import { X, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

export default function ModifierGroupModal({ group, onSave, onClose }) {
  const [name, setName] = useState(group?.name || "");
  const [reference, setReference] = useState(group?.reference || "");
  const [required, setRequired] = useState(group?.required ?? false);
  const [minSelect, setMinSelect] = useState(group?.min_select ?? 0);
  const [maxSelect, setMaxSelect] = useState(group?.max_select ?? 1);
  const [options, setOptions] = useState(group?.options || []);
  const [saving, setSaving] = useState(false);
  const [generatingSku, setGeneratingSku] = useState(false);

  const generateReference = async () => {
    setGeneratingSku(true);
    const all = await base44.entities.ModifierGroup.list();
    const nums = all.map(g => parseInt((g.reference || "").replace("MOD-", ""))).filter(n => !isNaN(n));
    const next = (nums.length > 0 ? Math.max(...nums) : 0) + 1;
    setReference(`MOD-${String(next).padStart(4, "0")}`);
    setGeneratingSku(false);
  };

  const addOption = () => setOptions(prev => [...prev, { name: "", price: 0 }]);

  const updateOption = (idx, field, value) => {
    setOptions(prev => prev.map((o, i) => i === idx ? { ...o, [field]: field === "price" ? parseFloat(value) || 0 : value } : o));
  };

  const removeOption = (idx) => setOptions(prev => prev.filter((_, i) => i !== idx));

  const handleSave = async () => {
    if (!name.trim()) return;
    setSaving(true);
    await onSave({
      name: name.trim(),
      reference: reference.trim(),
      required,
      min_select: required ? Math.max(1, minSelect) : minSelect,
      max_select: maxSelect,
      options,
    });
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="font-bold text-gray-900 text-lg">{group ? "Edit Modifier Group" : "Create Modifier Group"}</h2>
          <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Name */}
          <div>
            <label className="text-xs font-semibold text-gray-500 mb-1.5 block">Group Name *</label>
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Burger Addons" className="text-gray-900" />
          </div>

          {/* Reference / SKU */}
          <div>
            <label className="text-xs font-semibold text-gray-500 mb-1.5 block">Reference / SKU</label>
            <div className="flex gap-2">
              <Input value={reference} onChange={e => setReference(e.target.value)} placeholder="e.g. MOD-0001" className="text-gray-900 flex-1" />
              <Button type="button" variant="outline" size="sm" disabled={generatingSku} onClick={generateReference} className="text-xs whitespace-nowrap">
                {generatingSku ? "..." : "Generate"}
              </Button>
            </div>
          </div>

          {/* Required + Min/Max */}
          <div className="bg-gray-50 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-gray-700">Required</p>
                <p className="text-xs text-gray-400">Customer must select from this group</p>
              </div>
              <button
                type="button"
                onClick={() => setRequired(v => !v)}
                className={`relative w-10 h-5 rounded-full transition-colors ${required ? "bg-violet-600" : "bg-gray-200"}`}
              >
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${required ? "translate-x-5" : "translate-x-0.5"}`} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-gray-500 mb-1 block">Min Select</label>
                <Input
                  type="number"
                  min={0}
                  max={maxSelect}
                  value={minSelect}
                  onChange={e => setMinSelect(Math.max(0, parseInt(e.target.value) || 0))}
                  className="text-gray-900"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 mb-1 block">Max Select</label>
                <Input
                  type="number"
                  min={1}
                  value={maxSelect}
                  onChange={e => setMaxSelect(Math.max(1, parseInt(e.target.value) || 1))}
                  className="text-gray-900"
                />
              </div>
            </div>
            <p className="text-xs text-gray-400">
              {required ? `Customer must pick ${minSelect === maxSelect ? minSelect : `${minSelect}–${maxSelect}`} option(s)` : `Customer can pick up to ${maxSelect} option(s)`}
            </p>
          </div>

          {/* Options */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-gray-500">Options</label>
              <button onClick={addOption} className="flex items-center gap-1 text-xs text-violet-600 font-semibold hover:text-violet-800">
                <Plus className="w-3.5 h-3.5" /> Add Option
              </button>
            </div>
            <div className="space-y-2">
              {options.map((opt, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Input
                   value={opt.name}
                   onChange={e => updateOption(idx, "name", e.target.value)}
                   placeholder="Option name"
                   className="flex-1 text-gray-900"
                  />
                  <Input
                   type="number"
                   value={opt.price}
                   onChange={e => updateOption(idx, "price", e.target.value)}
                   placeholder="Price"
                   className="w-24 text-gray-900"
                    min="0"
                    step="0.01"
                  />
                  <button onClick={() => removeOption(idx)} className="text-gray-300 hover:text-red-500 p-1">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {options.length === 0 && (
                <p className="text-xs text-gray-400 py-2 text-center">No options yet. Click "Add Option" to start.</p>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            onClick={handleSave}
            disabled={!name.trim() || saving}
            className="bg-violet-600 hover:bg-violet-700 text-white"
          >
            {saving ? "Saving..." : group ? "Save Changes" : "Create Group"}
          </Button>
        </div>
      </div>
    </div>
  );
}