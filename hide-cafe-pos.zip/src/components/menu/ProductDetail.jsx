import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft, X } from "lucide-react";
import { toast } from "sonner";
import ProductForm from "./ProductForm.jsx";
import ProductModifierModal from "./ProductModifierModal.jsx";

function InfoRow({ label, value }) {
  return (
    <div className="py-3 border-b border-gray-100 last:border-0">
      <p className="text-xs text-gray-400 mb-0.5">{label}</p>
      <p className="text-sm text-gray-800">{value ?? "—"}</p>
    </div>
  );
}

const ORDER_TYPES = [
  { key: "dine-in", label: "Dine In" },
  { key: "pickup", label: "Pick Up" },
  { key: "delivery", label: "Delivery" },
  { key: "drive-thru", label: "Drive Thru" },
];

const NUTRITION_FIELDS = [
  { key: "calories", label: "Calories", unit: "kCal" },
  { key: "cholesterol", label: "Cholesterol", unit: "mg" },
  { key: "carbohydrate", label: "Carbohydrate", unit: "g" },
  { key: "fiber", label: "Fiber", unit: "g" },
  { key: "sugars", label: "Total Sugars", unit: "g" },
  { key: "added_sugars", label: "Added Sugars", unit: "g" },
  { key: "salt", label: "Salt", unit: "g" },
  { key: "sodium", label: "Sodium", unit: "mg" },
  { key: "caffeine", label: "Caffeine", unit: "mg" },
];

function BranchModal({ type, branches, branchPrices, inactiveBranches, outOfStockBranches, saving, onClose, onSave }) {
  const [prices, setPrices] = useState(branchPrices);
  const [inactive, setInactive] = useState(inactiveBranches);
  const [outofstock, setOutofstock] = useState(outOfStockBranches);

  const titles = {
    price: "Custom Price Per Branch",
    inactive: "Inactive In Branches",
    outofstock: "Out Of Stock Branches",
  };

  const handleSave = () => {
    if (type === "price") onSave("price", prices);
    else if (type === "inactive") onSave("inactive", inactive);
    else onSave("outofstock", outofstock);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h3 className="font-bold text-gray-900">{titles[type]}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-3 max-h-96 overflow-y-auto">
          {type === "price" && branches.map(b => {
            const existing = prices.find(p => p.branch_id === b.id);
            return (
              <div key={b.id} className="flex items-center gap-3">
                <span className="flex-1 text-sm text-gray-700">{b.name}</span>
                <Input
                  type="number"
                  placeholder="Leave blank for default"
                  value={existing?.price ?? ""}
                  onChange={e => {
                    const val = e.target.value;
                    setPrices(prev => {
                      const filtered = prev.filter(p => p.branch_id !== b.id);
                      return val ? [...filtered, { branch_id: b.id, price: parseFloat(val) }] : filtered;
                    });
                  }}
                  className="w-36 border-gray-200 rounded-xl text-sm"
                />
              </div>
            );
          })}
          {(type === "inactive" || type === "outofstock") && branches.map(b => {
            const list = type === "inactive" ? inactive : outofstock;
            const isChecked = list.includes(b.id);
            const toggle = () => {
              const setter = type === "inactive" ? setInactive : setOutofstock;
              setter(prev => isChecked ? prev.filter(id => id !== b.id) : [...prev, b.id]);
            };
            return (
              <label key={b.id} className="flex items-center gap-3 cursor-pointer py-1">
                <input type="checkbox" checked={isChecked} onChange={toggle} className="rounded w-4 h-4" />
                <span className="text-sm text-gray-700">{b.name}</span>
              </label>
            );
          })}
        </div>
        <div className="px-5 py-4 border-t border-gray-100 flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose} className="rounded-xl border-gray-200">Cancel</Button>
          <Button onClick={handleSave} disabled={saving} className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl">
            {saving ? "Saving..." : "Save"}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function ProductDetail({ item, branches, inventoryItems, modifierGroups = [], onBack, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [branchModal, setBranchModal] = useState(null);
  const [modifierModal, setModifierModal] = useState(false);
  const [branchPrices, setBranchPrices] = useState(item.branch_prices || []);
  const [inactiveBranches, setInactiveBranches] = useState(item.inactive_branches || []);
  const [outOfStockBranches, setOutOfStockBranches] = useState(item.out_of_stock_branches || []);
  const [linkedModifiers, setLinkedModifiers] = useState(item.modifier_groups || []);
  const [savingBranch, setSavingBranch] = useState(false);

  const handleDeactivate = async () => {
    await base44.entities.MenuItem.update(item.id, { is_available: !item.is_available });
    toast.success(item.is_available !== false ? "Product deactivated" : "Product activated");
    onSaved();
  };

  const invMap = useMemo(() => {
    const byId = new Map();
    const byName = new Map();
    (inventoryItems || []).forEach(inv => {
      byId.set(inv.id, inv);
      byName.set(inv.name?.toLowerCase().trim(), inv);
    });
    return { byId, byName };
  }, [inventoryItems]);

  const getInv = (r) => invMap.byId.get(r.inventory_item_id) || invMap.byName.get(r.inventory_item_name?.toLowerCase().replace(/^"|"$/g, "").trim());

  const ingredientsCost = useMemo(() => {
    return (item.recipe || []).reduce((sum, r) => {
      const inv = getInv(r);
      const costPerUnit = (inv?.unit_cost || 0) / (inv?.factor || 1);
      return sum + r.quantity * costPerUnit;
    }, 0);
  }, [item.recipe, invMap]);

  const costPct = item.base_price > 0 ? (ingredientsCost / item.base_price) * 100 : 0;

  const saveBranchData = async (field, value) => {
    setSavingBranch(true);
    await base44.entities.MenuItem.update(item.id, { [field]: value });
    toast.success("Saved");
    setSavingBranch(false);
    setBranchModal(null);
    onSaved();
  };

  if (editing) {
    return (
      <ProductForm
        item={{ ...item, branch_prices: branchPrices, inactive_branches: inactiveBranches, out_of_stock_branches: outOfStockBranches }}
        branches={branches}
        inventoryItems={inventoryItems}
        onSaved={() => { setEditing(false); onSaved(); }}
        onCancel={() => setEditing(false)}
      />
    );
  }

  const isActive = item.is_available !== false;
  const nutrition = item.nutrition || {};

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-5">

        <button onClick={onBack} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 transition">
          <ChevronLeft className="w-4 h-4" /> Back
        </button>

        {item.image_url && (
          <div className="w-full h-48 rounded-2xl overflow-hidden bg-gray-100">
            <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
          </div>
        )}

        {/* Title + Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-900">{item.name}</h1>
            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
              {isActive ? "Active" : "Inactive"}
            </span>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleDeactivate} className="border-gray-200 rounded-xl gap-2 text-sm">
              <X className="w-4 h-4" />
              {isActive ? "Deactivate Product" : "Activate Product"}
            </Button>
            <Button onClick={() => setEditing(true)} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
              Edit Product
            </Button>
          </div>
        </div>

        {/* Basic Info Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-12">
            <InfoRow label="Name" value={item.name} />
            <InfoRow label="Name Localized" value={item.name_localized} />
            <InfoRow label="Category" value={item.category} />
            <InfoRow label="SKU" value={item.sku} />
            <InfoRow label="Barcode" value={item.barcode} />
            <InfoRow label="Tax Group" value="VAT" />
            <InfoRow label="Pricing Method" value={item.pricing_method || "Fixed Price"} />
            <InfoRow label="Selling Method" value={item.selling_method || "Unit"} />
            <InfoRow label="Costing Method" value={item.costing_method || (item.recipe?.length > 0 ? "From Ingredients" : "Fixed")} />
            <InfoRow label="Preparation Time" value={item.prep_time ? `${item.prep_time} min` : null} />
            <InfoRow label="Price" value={item.base_price != null ? `฿ ${item.base_price}` : null} />
            <InfoRow label="Ingredients Cost" value={`฿ ${ingredientsCost.toFixed(5)}`} />
            <InfoRow label="Calories" value={nutrition.calories ?? null} />
            <InfoRow label="High Salt Content" value={nutrition.salt > 0 ? "Yes" : "No"} />
            <InfoRow label="Walk time" value={null} />
            <InfoRow label="Cost %" value={item.base_price > 0 ? `${costPct.toFixed(3)} %` : null} />
            {item.description && (
              <div className="sm:col-span-2">
                <InfoRow label="Description" value={item.description} />
              </div>
            )}
          </div>
        </div>

        {/* Ingredients */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800 text-base">Ingredients</h3>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setEditing(true)} className="border-gray-200 rounded-xl text-xs">Edit Quantities</Button>
              <Button variant="outline" size="sm" onClick={() => setEditing(true)} className="border-gray-200 rounded-xl text-xs">Add Ingredients</Button>
            </div>
          </div>
          {(item.recipe || []).length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-4">No ingredients added yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="pb-3 w-8"></th>
                    <th className="pb-3 text-left font-semibold text-gray-700">Name</th>
                    <th className="pb-3 text-left font-semibold text-gray-700">SKU</th>
                    <th className="pb-3 text-left font-semibold text-gray-700">Quantity</th>
                    <th className="pb-3 text-left font-semibold text-gray-700">Cost</th>
                    <th className="pb-3 text-left font-semibold text-gray-700">Applies On</th>
                  </tr>
                </thead>
                <tbody>
                  {(item.recipe || []).map((r, i) => {
                    const inv = getInv(r);
                    const costPerUnit = (inv?.unit_cost || 0) / (inv?.factor || 1);
                    const cost = r.quantity * costPerUnit;
                    const appliesOn = r.applies_on || ["dine-in", "pickup", "delivery", "drive-thru"];
                    return (
                      <tr key={i} className="border-b border-gray-50 last:border-0">
                        <td className="py-3"><input type="checkbox" className="rounded w-4 h-4" /></td>
                        <td className="py-3 text-gray-700">{r.inventory_item_name}</td>
                        <td className="py-3 text-gray-500 font-mono text-xs">{inv?.sku || invMap.byId.get(r.inventory_item_id)?.sku || "—"}</td>
                        <td className="py-3 text-gray-700">{r.quantity} {r.unit}</td>
                        <td className="py-3 text-gray-700">฿ {cost.toFixed(2)}</td>
                        <td className="py-3">
                          <div className="flex flex-wrap gap-1">
                            {ORDER_TYPES.map(ot => (
                              <span key={ot.key} className={`px-2 py-0.5 rounded border text-xs ${appliesOn.includes(ot.key) ? "border-gray-300 text-gray-600" : "border-gray-100 text-gray-300 line-through"}`}>
                                {ot.label}
                              </span>
                            ))}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Custom Price */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-800 text-base">Custom Price</h3>
            <Button variant="outline" size="sm" onClick={() => setBranchModal("price")} className="border-gray-200 rounded-xl text-xs">Select Branches</Button>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            {branchPrices.length === 0 ? (
              <p className="text-sm text-gray-400 text-center">Set a different price for this product in the branches you select here.</p>
            ) : (
              <table className="w-full text-sm">
                <thead><tr className="border-b border-gray-100"><th className="pb-2 text-left text-gray-600 font-semibold">Branch</th><th className="pb-2 text-right text-gray-600 font-semibold">Price</th></tr></thead>
                <tbody>
                  {branchPrices.map((bp, i) => {
                    const branch = branches.find(b => b.id === bp.branch_id);
                    return (
                      <tr key={i} className="border-b border-gray-50 last:border-0">
                        <td className="py-2.5 text-gray-700">{branch?.name || bp.branch_id}</td>
                        <td className="py-2.5 text-right font-semibold text-gray-800">฿ {bp.price}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Inactive In Branches */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-800 text-base">Inactive In Branches</h3>
            <Button variant="outline" size="sm" onClick={() => setBranchModal("inactive")} className="border-gray-200 rounded-xl text-xs">Select Branches</Button>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            {inactiveBranches.length === 0 ? (
              <p className="text-sm text-gray-400 text-center">Deactivate this product in the branches you select here to hide it from the menu.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {inactiveBranches.map(bid => {
                  const branch = branches.find(b => b.id === bid);
                  return <span key={bid} className="px-3 py-1 bg-red-50 text-red-700 rounded-full text-xs font-medium">{branch?.name || bid}</span>;
                })}
              </div>
            )}
          </div>
        </div>

        {/* Out Of Stock */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-800 text-base">Out Of Stock</h3>
            <Button variant="outline" size="sm" onClick={() => setBranchModal("outofstock")} className="border-gray-200 rounded-xl text-xs">Select Branches</Button>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            {outOfStockBranches.length === 0 ? (
              <p className="text-sm text-gray-400 text-center">Set this product as Out of Stock in the branches you select here, the Cashier can still sell Out of Stock products.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {outOfStockBranches.map(bid => {
                  const branch = branches.find(b => b.id === bid);
                  return <span key={bid} className="px-3 py-1 bg-amber-50 text-amber-700 rounded-full text-xs font-medium">{branch?.name || bid}</span>;
                })}
              </div>
            )}
          </div>
        </div>

        {/* Modifier Groups */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-800 text-base">Modifier Groups</h3>
            <Button variant="outline" size="sm" onClick={() => setModifierModal(true)} className="border-gray-200 rounded-xl text-xs">
              {linkedModifiers.length > 0 ? `Edit Groups (${linkedModifiers.length})` : "Add Groups"}
            </Button>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {linkedModifiers.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-6">No modifier groups assigned.</p>
            ) : (
              <table className="w-full text-sm">
                <thead className="border-b border-gray-100">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700">Name</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700 w-16">Min</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700 w-16">Max</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700 w-20">Options</th>
                  </tr>
                </thead>
                <tbody>
                  {linkedModifiers.map((modId, i) => {
                    const mod = modifierGroups.find(m => m.id === modId);
                    if (!mod) return null;
                    return (
                      <tr key={i} className="border-b border-gray-50 last:border-0">
                        <td className="px-4 py-3 text-gray-700 font-medium">{mod.name}</td>
                        <td className="px-4 py-3 text-gray-600">{mod.min_select || 0}</td>
                        <td className="px-4 py-3 text-gray-600">{mod.max_select || 1}</td>
                        <td className="px-4 py-3 text-gray-600">{mod.options?.length || 0}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Timed Events */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-800 text-base">Timed Events</h3>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <p className="text-sm text-gray-400 text-center">Here you'll see if this product is assigned to any timed events.</p>
          </div>
        </div>

        {/* Nutritional Values */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-gray-800 text-base">Nutritional Values</h3>
            <Button variant="outline" size="sm" onClick={() => setEditing(true)} className="border-gray-200 rounded-xl text-xs">Edit Nutritional Values</Button>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead className="border-b border-gray-100">
                <tr>
                  <th className="px-4 py-3 text-left font-semibold text-gray-700">Ingredient</th>
                  <th className="px-4 py-3 text-left font-semibold text-gray-700">Value</th>
                  <th className="px-4 py-3 text-left font-semibold text-gray-700">Unit</th>
                </tr>
              </thead>
              <tbody>
                {NUTRITION_FIELDS.map(nf => (
                  <tr key={nf.key} className="border-b border-gray-50 last:border-0">
                    <td className="px-4 py-3 text-gray-700">{nf.label}</td>
                    <td className="px-4 py-3 text-gray-600">{nutrition[nf.key] ?? "-"}</td>
                    <td className="px-4 py-3 text-gray-400">{nf.unit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {branchModal && (
        <BranchModal
          type={branchModal}
          branches={branches}
          branchPrices={branchPrices}
          inactiveBranches={inactiveBranches}
          outOfStockBranches={outOfStockBranches}
          saving={savingBranch}
          onClose={() => setBranchModal(null)}
          onSave={async (type, value) => {
            if (type === "price") { setBranchPrices(value); await saveBranchData("branch_prices", value); }
            else if (type === "inactive") { setInactiveBranches(value); await saveBranchData("inactive_branches", value); }
            else { setOutOfStockBranches(value); await saveBranchData("out_of_stock_branches", value); }
          }}
        />
      )}

      {modifierModal && (
        <ProductModifierModal
          productId={item.id}
          modifierGroups={modifierGroups}
          linkedGroupIds={linkedModifiers}
          onClose={() => setModifierModal(false)}
          onSave={(modIds) => {
            setLinkedModifiers(modIds);
            setModifierModal(false);
            onSaved();
          }}
        />
      )}
    </div>
  );
}