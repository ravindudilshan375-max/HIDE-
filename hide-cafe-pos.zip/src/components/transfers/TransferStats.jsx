import React from "react";
import { ArrowLeftRight, AlertCircle, CheckCircle2, Clock, Package, TrendingDown } from "lucide-react";

export default function TransferStats({ branches, inventoryItems, transfers, pendingCount, approvedCount, completedCount }) {
  const totalStock = inventoryItems.reduce((s, i) => s + (i.current_quantity || 0), 0);
  const lowStockItems = inventoryItems.filter(i => (i.current_quantity || 0) <= (i.low_stock_threshold || 5) && (i.current_quantity || 0) > 0);
  const outOfStockItems = inventoryItems.filter(i => (i.current_quantity || 0) === 0);

  const stats = [
    {
      label: "Pending Approval",
      value: pendingCount,
      icon: Clock,
      color: "text-amber-600",
      bg: "bg-amber-50",
      border: "border-amber-200",
    },
    {
      label: "In Progress",
      value: approvedCount,
      icon: ArrowLeftRight,
      color: "text-blue-600",
      bg: "bg-blue-50",
      border: "border-blue-200",
    },
    {
      label: "Completed",
      value: completedCount,
      icon: CheckCircle2,
      color: "text-green-600",
      bg: "bg-green-50",
      border: "border-green-200",
    },
    {
      label: "Active Branches",
      value: branches.filter(b => b.is_active !== false).length,
      icon: Package,
      color: "text-violet-600",
      bg: "bg-violet-50",
      border: "border-violet-200",
    },
    {
      label: "Low Stock Items",
      value: lowStockItems.length,
      icon: TrendingDown,
      color: "text-orange-600",
      bg: "bg-orange-50",
      border: "border-orange-200",
    },
    {
      label: "Out of Stock",
      value: outOfStockItems.length,
      icon: AlertCircle,
      color: "text-red-600",
      bg: "bg-red-50",
      border: "border-red-200",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {stats.map(s => {
        const Icon = s.icon;
        return (
          <div key={s.label} className={`bg-white rounded-2xl p-4 border ${s.border}`}>
            <div className={`w-9 h-9 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
              <Icon className={`w-4 h-4 ${s.color}`} />
            </div>
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-gray-500 mt-1 leading-tight">{s.label}</div>
          </div>
        );
      })}
    </div>
  );
}