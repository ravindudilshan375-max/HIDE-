import React from "react";
import { Search } from "lucide-react";

const STATUSES = ["all", "pending", "approved", "in_transit", "completed", "cancelled"];

export default function TransferFilters({ filters, setFilters, branches }) {
  return (
    <div className="flex flex-wrap gap-3 items-center">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          placeholder="Search transfers..."
          value={filters.search}
          onChange={e => setFilters({ ...filters, search: e.target.value })}
          className="pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400 bg-white w-48"
        />
      </div>

      <select
        value={filters.status}
        onChange={e => setFilters({ ...filters, status: e.target.value })}
        className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400 bg-white capitalize"
      >
        {STATUSES.map(s => (
          <option key={s} value={s}>{s === "all" ? "All Statuses" : s.charAt(0).toUpperCase() + s.slice(1)}</option>
        ))}
      </select>

      <select
        value={filters.branch}
        onChange={e => setFilters({ ...filters, branch: e.target.value })}
        className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400 bg-white"
      >
        <option value="all">All Branches</option>
        {branches.map(b => (
          <option key={b.id} value={b.id}>{b.name}</option>
        ))}
      </select>
    </div>
  );
}