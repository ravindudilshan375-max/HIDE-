import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, Plus, Trash2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CreateTransferModal({ branches, inventoryItems, user, onClose, onCreated }) {
  const [form, setForm] = useState({
    from_branch_id: "",
    to_branch_id: "",
    items: [{ inventory_item_id: "", quantity: 1 }],
    notes: "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const fromBranchItems = form.from_branch_id
    ? inventoryItems.filter(i => i.branch_id === form.from_branch_id && (i.current_quantity || 0) > 0)
    : [];

  const handleSubmit = async () => {
    const validItems = form.items.filter(i => i.inventory_item_id && i.quantity > 0);
    if (!form.from_branch_id || !form.to_branch_id || validItems.length === 0) {
      setError("Please fill in all required fields");
      return;
    }
    if (form.from_branch_id === form.to_branch_id) {
      setError("Cannot transfer to the same branch");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const fromBranch = branches.find(b => b.id === form.from_branch_id);
      const toBranch = branches.find(b => b.id === form.to_branch_id);

      await base44.entities.BranchTransfer.create({
        from_branch_id: form.from_branch_id,
        from_branch_name: fromBranch?.name,
        to_branch_id: form.to_branch_id,
        to_branch_name: toBranch?.name,
        items: validItems.map(item => {
          const inv = inventoryItems.find(i => i.id === item.inventory_item_id);
          return {
            inventory_item_id: item.inventory_item_id,
            item_name: inv?.name || "",
            quantity: item.quantity,
            quantity_sent: item.quantity,
            unit: inv?.unit || "unit",
          };
        }),
        status: "pending",
        requested_by: user?.email,
        requested_by_name: user?.full_name || user?.email,
        notes: form.notes,
        request_date: new Date().toISOString(),
      });
      onCreated();
    } catch (e) {
      setError("Failed to create transfer: " + (e?.message || "Unknown error"));
    } finally {
      setSaving(false);
    }
  };

  const addItem = () => setForm({ ...form, items: [...form.items, { inventory_item_id: "", quantity: 1 }] });
  const removeItem = (idx) => setForm({ ...form, items: form.items.filter((_, i) => i !== idx) });
  const updateItem = (idx, field, val) => {
    const items = [...form.items];
    items[idx] = { ...items[idx], [field]: val };
    setForm({ ...form, items });
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="font-bold text-gray-900 text-lg">New Transfer Request</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {error && <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-xl px-4 py-2">{error}</div>}

          {/* Branch selector */}
          <div className="grid grid-cols-5 gap-2 items-center">
            <div className="col-span-2">
              <label className="text-xs font-semibold text-gray-600 mb-1.5 block">From Branch *</label>
              <select
                value={form.from_branch_id}
                onChange={e => setForm({ ...form, from_branch_id: e.target.value, items: [{ inventory_item_id: "", quantity: 1 }] })}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="">Select branch</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div className="flex justify-center pt-5">
              <ArrowRight className="w-5 h-5 text-gray-400" />
            </div>
            <div className="col-span-2">
              <label className="text-xs font-semibold text-gray-600 mb-1.5 block">To Branch *</label>
              <select
                value={form.to_branch_id}
                onChange={e => setForm({ ...form, to_branch_id: e.target.value })}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="">Select branch</option>
                {branches.filter(b => b.id !== form.from_branch_id).map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Items */}
          <div>
            <label className="text-xs font-semibold text-gray-600 mb-2 block">Items to Transfer *</label>
            <div className="space-y-2">
              {form.items.map((item, idx) => {
                const selected = inventoryItems.find(i => i.id === item.inventory_item_id);
                return (
                  <div key={idx} className="flex gap-2 items-center">
                    <select
                      value={item.inventory_item_id}
                      onChange={e => updateItem(idx, "inventory_item_id", e.target.value)}
                      disabled={!form.from_branch_id}
                      className="flex-1 border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400 disabled:bg-gray-50 disabled:text-gray-400"
                    >
                      <option value="">{!form.from_branch_id ? "Select source branch first" : "Select item"}</option>
                      {fromBranchItems.map(i => (
                        <option key={i.id} value={i.id}>{i.name} (Stock: {i.current_quantity})</option>
                      ))}
                    </select>
                    <input
                      type="number"
                      min="1"
                      max={selected?.current_quantity || 9999}
                      value={item.quantity}
                      onChange={e => updateItem(idx, "quantity", parseInt(e.target.value) || 1)}
                      placeholder="Qty"
                      className="w-20 border border-gray-200 rounded-xl px-3 py-2 text-sm text-center focus:outline-none focus:border-violet-400"
                    />
                    {form.items.length > 1 && (
                      <button onClick={() => removeItem(idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            <button
              onClick={addItem}
              className="mt-2 flex items-center gap-1.5 text-xs text-violet-600 font-semibold hover:text-violet-800 transition"
            >
              <Plus className="w-3.5 h-3.5" /> Add another item
            </button>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-gray-600 mb-1.5 block">Notes</label>
            <textarea
              value={form.notes}
              onChange={e => setForm({ ...form, notes: e.target.value })}
              placeholder="Optional reason or notes..."
              rows={2}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400 resize-none"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 px-6 py-4 border-t border-gray-100">
          <Button onClick={onClose} variant="outline" className="flex-1 rounded-xl border-gray-200">Cancel</Button>
          <Button onClick={handleSubmit} disabled={saving} className="flex-1 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-semibold">
            {saving ? "Creating..." : "Create Transfer"}
          </Button>
        </div>
      </div>
    </div>
  );
}