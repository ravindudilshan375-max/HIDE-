import React, { useState } from "react";
import { ChevronDown, ChevronRight, AlertCircle, Package } from "lucide-react";

export default function BranchStockTable({ branches, inventoryItems }) {
  const [expandedBranch, setExpandedBranch] = useState(null);
  const [search, setSearch] = useState("");

  const branchStock = branches.map(branch => {
    const items = inventoryItems.filter(i => i.branch_id === branch.id);
    const lowStock = items.filter(i => (i.current_quantity || 0) > 0 && (i.current_quantity || 0) <= (i.low_stock_threshold || 5));
    const outOfStock = items.filter(i => (i.current_quantity || 0) === 0);
    const totalQty = items.reduce((s, i) => s + (i.current_quantity || 0), 0);
    return { branch, items, lowStock, outOfStock, totalQty };
  });

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between flex-wrap gap-3">
          <h2 className="font-bold text-gray-900">Stock Levels by Branch</h2>
          <input
            placeholder="Search items..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400 w-48"
          />
        </div>

        {/* Summary table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left py-3 px-4 font-semibold text-gray-600">Branch</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-600">Items</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-600">Total Qty</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-600">Low Stock</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-600">Out of Stock</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-600">Details</th>
              </tr>
            </thead>
            <tbody>
              {branchStock.map(({ branch, items, lowStock, outOfStock, totalQty }) => (
                <React.Fragment key={branch.id}>
                  <tr className="border-b border-gray-100 hover:bg-gray-50 transition">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-violet-100 flex items-center justify-center">
                          <Package className="w-3.5 h-3.5 text-violet-600" />
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{branch.name}</div>
                          {branch.location && <div className="text-xs text-gray-400">{branch.location}</div>}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center text-gray-700 font-semibold">{items.length}</td>
                    <td className="py-3 px-4 text-center text-gray-700 font-semibold">{totalQty}</td>
                    <td className="py-3 px-4 text-center">
                      {lowStock.length > 0 ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-semibold">
                          <AlertCircle className="w-3 h-3" />{lowStock.length}
                        </span>
                      ) : <span className="text-gray-300">—</span>}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {outOfStock.length > 0 ? (
                        <span className="inline-block px-2.5 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">{outOfStock.length}</span>
                      ) : <span className="text-gray-300">—</span>}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => setExpandedBranch(expandedBranch === branch.id ? null : branch.id)}
                        className="text-violet-600 hover:text-violet-800 transition"
                      >
                        {expandedBranch === branch.id
                          ? <ChevronDown className="w-4 h-4 mx-auto" />
                          : <ChevronRight className="w-4 h-4 mx-auto" />}
                      </button>
                    </td>
                  </tr>

                  {/* Expanded item list */}
                  {expandedBranch === branch.id && (
                    <tr>
                      <td colSpan={6} className="p-0">
                        <div className="bg-gray-50 border-t border-gray-100 px-6 py-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                            {items
                              .filter(i => !search || i.name?.toLowerCase().includes(search.toLowerCase()))
                              .map(item => {
                                const qty = item.current_quantity || 0;
                                const threshold = item.low_stock_threshold || 5;
                                const isLow = qty > 0 && qty <= threshold;
                                const isEmpty = qty === 0;
                                return (
                                  <div key={item.id} className={`flex items-center justify-between px-3 py-2 rounded-xl bg-white border ${isEmpty ? "border-red-200" : isLow ? "border-amber-200" : "border-gray-100"}`}>
                                    <div className="min-w-0">
                                      <div className="text-xs font-semibold text-gray-800 truncate">{item.name}</div>
                                      {item.sku && <div className="text-[10px] text-gray-400">SKU: {item.sku}</div>}
                                    </div>
                                    <div className="shrink-0 ml-2 text-right">
                                      <div className={`text-sm font-bold ${isEmpty ? "text-red-600" : isLow ? "text-amber-600" : "text-gray-900"}`}>
                                        {qty}
                                      </div>
                                      <div className="text-[10px] text-gray-400">{item.unit || "units"}</div>
                                    </div>
                                  </div>
                                );
                              })}
                            {items.filter(i => !search || i.name?.toLowerCase().includes(search.toLowerCase())).length === 0 && (
                              <div className="col-span-3 text-center text-gray-400 text-xs py-4">No items match search</div>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}