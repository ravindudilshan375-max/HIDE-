import React from "react";
import { Check, X, Eye, ArrowLeftRight, Package } from "lucide-react";
import { StatusBadge } from "@/pages/BranchTransferDashboard";

export default function TransferList({ transfers, onApprove, onReject, onComplete, onView, user, compact }) {
  if (transfers.length === 0) {
    return (
      <div className="py-12 text-center text-gray-400">
        <ArrowLeftRight className="w-8 h-8 mx-auto mb-2 opacity-30" />
        <p className="text-sm">No transfers found</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-gray-100">
      {transfers.map(t => (
        <div key={t.id} className="flex items-start gap-4 px-6 py-4 hover:bg-gray-50 transition">
          {/* Icon */}
          <div className="w-9 h-9 rounded-xl bg-violet-50 flex items-center justify-center shrink-0 mt-0.5">
            <Package className="w-4 h-4 text-violet-600" />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-gray-900 text-sm">
                {t.from_branch_name} → {t.to_branch_name}
              </span>
              <StatusBadge status={t.status} />
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {t.items?.length || 0} item{t.items?.length !== 1 ? "s" : ""}
              {!compact && t.items?.length > 0 && (
                <span className="ml-1 text-gray-400">
                  ({t.items.slice(0, 2).map(i => `${i.item_name} ×${i.quantity}`).join(", ")}{t.items.length > 2 ? ` +${t.items.length - 2} more` : ""})
                </span>
              )}
              {t.requested_by_name && <span className="ml-2">· By {t.requested_by_name}</span>}
              {t.created_date && (
                <span className="ml-2">· {new Date(t.created_date).toLocaleDateString("en-AE", { day: "numeric", month: "short" })}</span>
              )}
            </div>
            {t.notes && <div className="text-xs text-amber-600 mt-1 italic">"{t.notes}"</div>}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => onView(t)}
              className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-violet-600 transition"
              title="View details"
            >
              <Eye className="w-4 h-4" />
            </button>
            {t.status === "pending" && (
              <>
                <button
                  onClick={() => onApprove(t)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-green-600 hover:bg-green-700 text-white text-xs font-semibold transition"
                >
                  <Check className="w-3 h-3" /> Approve
                </button>
                <button
                  onClick={() => onReject(t)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 text-xs font-semibold transition border border-red-200"
                >
                  <X className="w-3 h-3" /> Reject
                </button>
              </>
            )}
            {t.status === "approved" && (
              <button
                onClick={() => onComplete(t)}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition"
              >
                <Check className="w-3 h-3" /> Complete
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}