import React from "react";
import { X, Check, AlertTriangle, Package, User, Calendar, MapPin, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/pages/BranchTransferDashboard";

export default function TransferDetailModal({ transfer: t, onClose, onApprove, onReject, onComplete, user }) {
  if (!t) return null;

  const infoRows = [
    { icon: MapPin, label: "From", value: t.from_branch_name },
    { icon: MapPin, label: "To", value: t.to_branch_name },
    { icon: User, label: "Requested By", value: t.requested_by_name || t.requested_by || "—" },
    { icon: Calendar, label: "Requested On", value: t.created_date ? new Date(t.created_date).toLocaleString("en-AE") : "—" },
    t.approved_by_name && { icon: User, label: "Approved By", value: t.approved_by_name },
    t.approval_date && { icon: Calendar, label: "Approved On", value: new Date(t.approval_date).toLocaleString("en-AE") },
    t.completion_date && { icon: Calendar, label: "Completed On", value: new Date(t.completion_date).toLocaleString("en-AE") },
    t.notes && { icon: MessageSquare, label: "Notes", value: t.notes },
  ].filter(Boolean);

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between px-6 py-4 border-b border-gray-100">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-bold text-gray-900 text-lg">Transfer Details</h2>
              <StatusBadge status={t.status} />
            </div>
            <p className="text-sm text-gray-500 mt-0.5">
              {t.from_branch_name} → {t.to_branch_name}
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition ml-4">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Info grid */}
          <div className="grid grid-cols-2 gap-3">
            {infoRows.map((row, i) => {
              const Icon = row.icon;
              return (
                <div key={i} className="bg-gray-50 rounded-xl p-3">
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 font-semibold mb-1">
                    <Icon className="w-3 h-3" />{row.label}
                  </div>
                  <div className="text-sm font-medium text-gray-900">{row.value}</div>
                </div>
              );
            })}
          </div>

          {/* Items table */}
          <div>
            <h3 className="text-sm font-bold text-gray-800 mb-2 flex items-center gap-2">
              <Package className="w-4 h-4 text-violet-600" /> Items ({t.items?.length || 0})
            </h3>
            <div className="border border-gray-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="text-left py-2 px-4 text-xs font-semibold text-gray-600">Item</th>
                    <th className="text-center py-2 px-4 text-xs font-semibold text-gray-600">Qty</th>
                    <th className="text-center py-2 px-4 text-xs font-semibold text-gray-600">Unit</th>
                  </tr>
                </thead>
                <tbody>
                  {(t.items || []).map((item, idx) => (
                    <tr key={idx} className="border-b border-gray-100 last:border-0">
                      <td className="py-2.5 px-4 font-medium text-gray-900">{item.item_name}</td>
                      <td className="py-2.5 px-4 text-center font-bold text-gray-900">{item.quantity}</td>
                      <td className="py-2.5 px-4 text-center text-gray-500">{item.unit || "unit"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="px-6 py-4 border-t border-gray-100 flex gap-2 flex-wrap">
          <Button onClick={onClose} variant="outline" className="flex-1 rounded-xl border-gray-200">Close</Button>
          {t.status === "pending" && (
            <>
              <Button
                onClick={() => { onReject(t); onClose(); }}
                className="flex-1 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 border border-red-200"
                variant="outline"
              >
                <AlertTriangle className="w-4 h-4 mr-1" /> Reject
              </Button>
              <Button
                onClick={() => { onApprove(t); onClose(); }}
                className="flex-1 rounded-xl bg-green-600 hover:bg-green-700 text-white"
              >
                <Check className="w-4 h-4 mr-1" /> Approve
              </Button>
            </>
          )}
          {t.status === "approved" && (
            <Button
              onClick={() => { onComplete(t); onClose(); }}
              className="flex-1 rounded-xl bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Check className="w-4 h-4 mr-1" /> Mark as Completed
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}