import React, { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function CustomItemModal({ onAdd, onClose }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [notes, setNotes] = useState("");
  const [quantity, setQuantity] = useState(1);

  const handleAdd = () => {
    if (!name || !price) return;
    onAdd({
      menu_item_id: `custom_${Date.now()}`,
      name,
      price: parseFloat(price),
      quantity,
      notes,
      modifiers: [],
      subtotal: parseFloat(price) * quantity,
      isCustom: true,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[#1a1a24] border border-white/10 rounded-3xl w-full max-w-sm text-white overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <h2 className="font-bold text-base">Custom Item</h2>
          <button onClick={onClose} className="text-white/30 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="px-5 py-4 space-y-3">
          <div>
            <label className="text-xs text-white/40 mb-1.5 block">Item Name *</label>
            <Input
              placeholder="e.g. Chef's Special"
              value={name}
              onChange={e => setName(e.target.value)}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl"
            />
          </div>
          <div>
            <label className="text-xs text-white/40 mb-1.5 block">Price *</label>
            <Input
              type="number"
              placeholder="0.00"
              value={price}
              onChange={e => setPrice(e.target.value)}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl"
            />
          </div>
          <div>
            <label className="text-xs text-white/40 mb-1.5 block">Notes</label>
            <Input
              placeholder="Any special instructions..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl"
            />
          </div>
          <div>
            <label className="text-xs text-white/40 mb-1.5 block">Quantity</label>
            <div className="flex items-center gap-3">
              <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition text-lg font-bold">−</button>
              <span className="text-xl font-bold w-8 text-center">{quantity}</span>
              <button onClick={() => setQuantity(q => q + 1)} className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition text-lg font-bold">+</button>
            </div>
          </div>
        </div>
        <div className="px-5 pb-5 border-t border-white/10 pt-3">
          <Button
            onClick={handleAdd}
            disabled={!name || !price}
            className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11 disabled:opacity-30"
          >
            Add to Order · ${(parseFloat(price || 0) * quantity).toFixed(2)}
          </Button>
        </div>
      </div>
    </div>
  );
}