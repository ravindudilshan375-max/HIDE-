import React, { useState, useEffect } from "react";
import { X, Plus, Minus, PenLine, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";

export default function ItemCustomizerModal({ item, onAdd, onClose }) {
  const [modifierGroups, setModifierGroups] = useState([]);
  // selectedMods: { [groupId]: [{ name, price }] }
  const [selectedMods, setSelectedMods] = useState({});
  const [notes, setNotes] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Load linked modifier groups from DB
    base44.entities.ModifierGroup.list().then(groups => {
      const linked = groups.filter(g => g.linked_product_ids?.includes(item.id));
      if (linked.length > 0) {
        setModifierGroups(linked);
      } else if (item?.modifiers?.length > 0) {
        // Fallback to item.modifiers flat list
        setModifierGroups([{
          id: "_flat",
          name: "Add-ons",
          required: false,
          min_select: 0,
          max_select: item.modifiers.length,
          options: item.modifiers,
        }]);
      }
    }).catch(() => {
      if (item?.modifiers?.length > 0) {
        setModifierGroups([{
          id: "_flat",
          name: "Add-ons",
          required: false,
          min_select: 0,
          max_select: item.modifiers.length,
          options: item.modifiers,
        }]);
      }
    });
  }, [item]);

  const getSelected = (groupId) => selectedMods[groupId] || [];

  const toggleMod = (group, opt) => {
    const groupId = group.id;
    const current = getSelected(groupId);
    const alreadySelected = current.find(m => m.name === opt.name);
    const maxSelect = group.max_select ?? 1;

    if (alreadySelected) {
      setSelectedMods(prev => ({ ...prev, [groupId]: current.filter(m => m.name !== opt.name) }));
    } else {
      if (maxSelect === 1) {
        // Radio behavior
        setSelectedMods(prev => ({ ...prev, [groupId]: [opt] }));
      } else if (current.length < maxSelect) {
        setSelectedMods(prev => ({ ...prev, [groupId]: [...current, opt] }));
      }
    }
    // Clear error on selection
    if (errors[groupId]) setErrors(prev => { const e = { ...prev }; delete e[groupId]; return e; });
  };

  const validate = () => {
    const newErrors = {};
    for (const group of modifierGroups) {
      const selected = getSelected(group.id);
      const minSelect = group.required ? Math.max(1, group.min_select ?? 0) : (group.min_select ?? 0);
      if (selected.length < minSelect) {
        newErrors[group.id] = `Please select at least ${minSelect} option(s)`;
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const basePrice = item?.base_price ?? item?.price ?? 0;
  const allSelectedMods = Object.values(selectedMods).flat();
  const modTotal = allSelectedMods.reduce((s, m) => s + (m.price || 0), 0);
  const unitPrice = basePrice + modTotal;
  const total = unitPrice * quantity;

  const handleAdd = () => {
    if (!validate()) return;
    onAdd({
      menu_item_id: item.id,
      name: item.name,
      price: unitPrice,
      quantity,
      notes,
      modifiers: allSelectedMods,
      subtotal: total,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[9999] p-4">
      <div className="bg-[#1a1a24] border border-white/10 rounded-3xl w-full max-w-sm text-white overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div>
            <h2 className="font-bold text-base">{item?.name}</h2>
            <p className="text-xs text-white/40 mt-0.5">Base AED {(item?.base_price ?? item?.price ?? 0).toFixed(2)}</p>
          </div>
          <button onClick={onClose} className="text-white/30 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-4 space-y-5 max-h-[60vh] overflow-y-auto">
          {/* Modifier Groups */}
          {modifierGroups.map(group => {
            const selected = getSelected(group.id);
            const maxSelect = group.max_select ?? 1;
            const minSelect = group.required ? Math.max(1, group.min_select ?? 0) : (group.min_select ?? 0);

            return (
              <div key={group.id}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-semibold text-white/60 uppercase tracking-wider">{group.name}</p>
                    {group.required && (
                      <span className="text-[10px] bg-red-500/20 text-red-400 border border-red-400/30 px-1.5 py-0.5 rounded-full font-semibold">Required</span>
                    )}
                  </div>
                  <span className="text-[10px] text-white/30">
                    {maxSelect === 1 ? "Pick 1" : `Pick ${minSelect}–${maxSelect}`}
                    {selected.length > 0 && <span className="text-amber-400 ml-1">({selected.length} selected)</span>}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {(group.options || []).map((opt, i) => {
                    const isSelected = !!selected.find(m => m.name === opt.name);
                    const isDisabled = !isSelected && selected.length >= maxSelect;
                    return (
                      <button
                        key={i}
                        onClick={() => !isDisabled && toggleMod(group, opt)}
                        disabled={isDisabled}
                        className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl border text-sm transition-all ${
                          isSelected
                            ? "bg-amber-400/10 border-amber-400/50 text-amber-300"
                            : isDisabled
                            ? "bg-white/2 border-white/5 text-white/20 cursor-not-allowed"
                            : "bg-white/5 border-white/10 text-white/70 hover:bg-white/10"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded-${maxSelect === 1 ? "full" : "md"} border-2 flex items-center justify-center shrink-0 transition ${isSelected ? "border-amber-400 bg-amber-400" : "border-white/20"}`}>
                            {isSelected && <div className={`${maxSelect === 1 ? "w-1.5 h-1.5 rounded-full bg-black" : "text-black text-[8px] font-bold leading-none"}`}>{maxSelect > 1 && "✓"}</div>}
                          </div>
                          <span className="font-medium">{opt.name}</span>
                        </div>
                        <span className={`text-xs font-semibold ${opt.price > 0 ? "text-amber-400" : "text-white/30"}`}>
                          {opt.price > 0 ? `+AED ${opt.price.toFixed(2)}` : "Free"}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {errors[group.id] && (
                  <div className="flex items-center gap-1.5 mt-2 text-red-400 text-xs">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    {errors[group.id]}
                  </div>
                )}
              </div>
            );
          })}

          {/* Special Instructions */}
          <div>
            <p className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">Special Instructions</p>
            <div className="relative">
              <PenLine className="absolute left-3 top-2.5 w-3.5 h-3.5 text-white/20" />
              <Input
                placeholder="e.g. no onions, extra spicy..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="bg-white/5 border-white/10 text-white text-sm placeholder:text-white/20 rounded-xl pl-8 h-9"
              />
            </div>
          </div>

          {/* Quantity */}
          <div>
            <p className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">Quantity</p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-xl font-bold w-8 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(q => q + 1)}
                className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 pb-5 pt-3 border-t border-white/10">
          <Button
            onClick={handleAdd}
            className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11 text-sm"
          >
            Add to Order · AED {total.toFixed(2)}
          </Button>
        </div>
      </div>
    </div>
  );
}