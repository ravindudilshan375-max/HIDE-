import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Sparkles, Plus, X } from "lucide-react";

export default function AISuggestions({ cartItems, menuItems, onAdd }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const debounceRef = useRef(null);

  useEffect(() => {
    if (cartItems.length === 0) {
      setSuggestions([]);
      setDismissed(false);
      return;
    }
    setDismissed(false);

    // Debounce so we don't fire on every single item add
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => fetchSuggestions(), 800);
    return () => clearTimeout(debounceRef.current);
  }, [cartItems.map(i => i.menu_item_id).join(",")]);

  const fetchSuggestions = async () => {
    if (menuItems.length === 0) return;
    setLoading(true);

    // Get recent orders for context (last 50)
    let recentOrders = [];
    try {
      recentOrders = await base44.entities.Order.list("-created_date", 50);
    } catch (_) {}

    // Build a frequency map of co-purchased items
    const cartNames = cartItems.map(i => i.name);
    const cartIds = cartItems.map(i => i.menu_item_id);
    const availableItems = menuItems.filter(m => !cartIds.includes(m.id));

    const coFreq = {};
    for (const order of recentOrders) {
      if (!order.items?.length) continue;
      const orderItemNames = order.items.map(i => i.name);
      const hasCartItem = cartNames.some(n => orderItemNames.includes(n));
      if (hasCartItem) {
        for (const oi of order.items) {
          if (!cartNames.includes(oi.name)) {
            coFreq[oi.name] = (coFreq[oi.name] || 0) + 1;
          }
        }
      }
    }

    const prompt = `You are a smart POS upsell engine for a café/restaurant.

Current cart items: ${cartNames.join(", ")}

Available menu items (not in cart): ${availableItems.map(m => `${m.name} ($${m.price})`).join(", ")}

Co-purchase frequency from recent orders: ${JSON.stringify(coFreq)}

Suggest exactly 3 items from the available menu that would pair well with the current cart, prioritizing items with high co-purchase frequency. Consider complementary flavors, common combos (e.g. coffee + pastry), and upsell value.

Return JSON only.`;

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  reason: { type: "string" }
                }
              }
            }
          }
        }
      });

      const names = (result.suggestions || []).map(s => s.name);
      const reasons = Object.fromEntries((result.suggestions || []).map(s => [s.name, s.reason]));

      const matched = names
        .map(n => {
          const item = availableItems.find(m => m.name.toLowerCase() === n.toLowerCase());
          return item ? { ...item, reason: reasons[n] } : null;
        })
        .filter(Boolean)
        .slice(0, 3);

      setSuggestions(matched);
    } catch (_) {
      setSuggestions([]);
    }
    setLoading(false);
  };

  if (cartItems.length === 0 || dismissed) return null;

  return (
    <div className="mx-4 mb-2 bg-gradient-to-br from-violet-500/10 to-amber-400/5 border border-violet-400/20 rounded-2xl p-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span className="text-xs font-semibold text-violet-300">AI Suggestions</span>
        </div>
        <button onClick={() => setDismissed(true)} className="text-white/20 hover:text-white/50 transition">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 py-1">
          <div className="flex gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: "0ms" }} />
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: "150ms" }} />
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: "300ms" }} />
          </div>
          <span className="text-xs text-white/30">Analyzing order history...</span>
        </div>
      ) : suggestions.length > 0 ? (
        <div className="space-y-1.5">
          {suggestions.map(item => (
            <div key={item.id} className="flex items-center gap-2 group">
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white truncate">{item.name}</p>
                <p className="text-xs text-white/30 truncate">{item.reason}</p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="text-xs text-amber-400 font-semibold">${item.price?.toFixed(2)}</span>
                <button
                  onClick={() => onAdd(item)}
                  className="w-6 h-6 rounded-lg bg-violet-500 hover:bg-violet-400 flex items-center justify-center transition-all"
                >
                  <Plus className="w-3.5 h-3.5 text-white" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}