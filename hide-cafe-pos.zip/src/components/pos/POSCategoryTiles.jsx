import React from "react";

export default function POSCategoryTiles({ categories, activeCategory, onSelectCategory }) {
  const colors = [
    "from-red-500 to-red-600",
    "from-orange-500 to-orange-600",
    "from-amber-500 to-amber-600",
    "from-green-500 to-green-600",
    "from-blue-500 to-blue-600",
    "from-purple-500 to-purple-600",
    "from-pink-500 to-pink-600",
    "from-indigo-500 to-indigo-600",
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-3">
      {categories.map((cat, idx) => {
        const colorClass = colors[idx % colors.length];
        const isActive = activeCategory === cat;

        return (
          <button
            key={cat}
            onClick={() => onSelectCategory(cat)}
            className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl font-bold text-white text-left transition-all duration-150 active:scale-95 shadow-md hover:shadow-lg ${
              isActive
                ? `bg-gradient-to-br ${colorClass} ring-4 ring-offset-2 ring-gray-400`
                : `bg-gradient-to-br ${colorClass} opacity-80 hover:opacity-100`
            }`}
          >
            <span className="text-lg">{cat}</span>
            <span className="text-2xl">📦</span>
          </button>
        );
      })}
    </div>
  );
}