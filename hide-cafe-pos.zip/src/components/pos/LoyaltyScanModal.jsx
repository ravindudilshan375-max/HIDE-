import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Star, QrCode, Search, UserPlus, Award } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const TIER_STYLES = {
  Platinum: { bg: "bg-gradient-to-r from-slate-600 to-slate-800", badge: "bg-slate-500 text-white", icon: "💎" },
  Gold: { bg: "bg-gradient-to-r from-amber-500 to-yellow-600", badge: "bg-amber-500 text-white", icon: "🥇" },
  Silver: { bg: "bg-gradient-to-r from-gray-400 to-gray-500", badge: "bg-gray-400 text-white", icon: "🥈" },
};

export default function LoyaltyScanModal({ onSelect, onClose }) {
  const [query, setQuery] = useState("");
  const [customer, setCustomer] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const [searching, setSearching] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const lookup = async (val) => {
    const q = val.trim();
    if (!q) return;
    setSearching(true);
    setNotFound(false);
    setCustomer(null);
    const all = await base44.entities.Customer.list();
    const match = all.find(c =>
      c.loyalty_id === q ||
      (c.phone || "").replace(/\s/g, "") === q.replace(/\s/g, "") ||
      c.name.toLowerCase() === q.toLowerCase()
    );
    if (match) {
      setCustomer(match);
    } else {
      setNotFound(true);
    }
    setSearching(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") lookup(query);
  };

  const tier = customer?.tier || "Silver";
  const tierStyle = TIER_STYLES[tier] || TIER_STYLES.Silver;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[#16161d] border border-white/10 rounded-3xl w-full max-w-sm text-white overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <QrCode className="w-4 h-4 text-amber-400" />
            <h2 className="font-bold text-base">Scan Loyalty Card</h2>
          </div>
          <button onClick={onClose} className="text-white/30 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-xs text-white/40">Scan QR, or enter phone / Loyalty ID</p>

          <div className="flex gap-2">
            <Input
              ref={inputRef}
              placeholder="LOY-12345 or phone number..."
              value={query}
              onChange={e => { setQuery(e.target.value); setNotFound(false); setCustomer(null); }}
              onKeyDown={handleKeyDown}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl flex-1"
            />
            <Button onClick={() => lookup(query)} disabled={searching || !query.trim()}
              className="bg-amber-400 hover:bg-amber-300 text-black rounded-xl px-3">
              <Search className="w-4 h-4" />
            </Button>
          </div>

          {searching && (
            <div className="text-center text-white/40 text-sm py-4">Searching...</div>
          )}

          {notFound && (
            <div className="bg-red-400/10 border border-red-400/20 rounded-xl p-3 text-center">
              <p className="text-red-400 text-sm font-medium">Customer not found</p>
              <p className="text-white/40 text-xs mt-1">Check the ID or phone number</p>
            </div>
          )}

          {customer && (
            <div className={`rounded-2xl p-4 ${tierStyle.bg}`}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-xs text-white/60 uppercase tracking-wider">Loyalty Member</p>
                  <p className="text-lg font-bold text-white mt-0.5">{customer.name}</p>
                  {customer.phone && <p className="text-xs text-white/60">{customer.phone}</p>}
                </div>
                <span className="text-2xl">{tierStyle.icon}</span>
              </div>
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-2xl font-black text-white">{(customer.points || 0).toLocaleString()}</p>
                  <p className="text-xs text-white/60">points</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${tierStyle.badge}`}>{tier}</span>
                  <p className="text-xs text-white/50 mt-1">{customer.loyalty_id || "—"}</p>
                </div>
              </div>
            </div>
          )}

          {customer && (
            <Button onClick={() => onSelect(customer)} className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11">
              Apply to Order ✓
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}