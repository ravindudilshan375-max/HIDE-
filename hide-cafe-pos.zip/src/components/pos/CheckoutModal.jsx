import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { printReceipt, printKitchenTicket } from "./printBridge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PrintBillModal from "./PrintBillModal";
import DigitalReceiptModal from "./DigitalReceiptModal";
import SignatureModal from "./SignatureModal";

const SIGNATURE_DISCOUNT_THRESHOLD = 10; // % of order total
import {
  X, CreditCard, Banknote, Smartphone, SplitSquareVertical,
  ExternalLink, Star, CheckCircle2, ChevronRight, ChevronLeft,
  ShoppingBag, Receipt, Wallet, Tag, Printer, Mail, QrCode
} from "lucide-react";

const POINTS_PER_AED = 1; // 1 point per AED
const POINTS_PER_REDEEM = 1000;

const ICON_MAP = {
  "Cash": Banknote,
  "Card": CreditCard,
  "Mobile Wallet": Smartphone,
  "Gift Card": CreditCard,
  "House Account": Wallet,
  "Check": CreditCard,
  "3rd Party": ExternalLink,
};

const DEFAULT_PAYMENT_METHODS = [
  { key: "cash", label: "Cash", icon: Banknote },
  { key: "card", label: "Card", icon: CreditCard },
  { key: "online", label: "Online", icon: ExternalLink },
];

const STEPS = ["Review", "Payment", "Confirmation"];

export default function CheckoutModal({
  cartItems, orderType, selectedTable, customerName,
  subtotal, tax, total, cashierName, tables,
  loyaltyCustomer, branchId, selectedTaxGroup,
  onClose, onSuccess
}) {
  const [step, setStep] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [amountPaid, setAmountPaid] = useState("");
  const [discount, setDiscount] = useState(0);
  const [appliedDiscountId, setAppliedDiscountId] = useState(null);
  const [redeemPoints, setRedeemPoints] = useState(0);
  const [loading, setLoading] = useState(false);
  const [earnedPoints, setEarnedPoints] = useState(0);
  const [availableDiscounts, setAvailableDiscounts] = useState([]);
  const [discountsLoading, setDiscountsLoading] = useState(true);
  const [paymentMethods, setPaymentMethods] = useState(DEFAULT_PAYMENT_METHODS);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [showDigitalModal, setShowDigitalModal] = useState(false);
  const [lastOrder, setLastOrder] = useState(null);
  const [taxGroups, setTaxGroups] = useState([]);
  const [currentTaxGroup, setCurrentTaxGroup] = useState(selectedTaxGroup || null);
  const [showSignatureModal, setShowSignatureModal] = useState(false);
  const [signatureTrigger, setSignatureTrigger] = useState(null);
  const [pendingOrderData, setPendingOrderData] = useState(null);
  const [emailInput, setEmailInput] = useState("");
  const [showEmailInput, setShowEmailInput] = useState(false);
  const [emailSending, setEmailSending] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  useEffect(() => {
    loadAvailableDiscounts();
    loadPaymentMethods();
    loadTaxGroups();
  }, []);

  const loadTaxGroups = async () => {
    try {
      const groups = await base44.entities.TaxGroup.list();
      const activeGroups = groups.filter(g => g.is_active !== false);
      setTaxGroups(activeGroups);
      // Auto-apply first active tax group if none selected
      if (!selectedTaxGroup && activeGroups.length > 0) {
        setCurrentTaxGroup(activeGroups[0]);
      }
    } catch (e) {
      console.log("Error loading tax groups", e);
    }
  };

  const loadPaymentMethods = () => {
    const saved = JSON.parse(localStorage.getItem("paymentMethods") || "[]");
    const activeMethods = saved.filter(m => !m.deleted && m.is_active);
    
    if (activeMethods.length === 0) {
      setPaymentMethods(DEFAULT_PAYMENT_METHODS);
      return;
    }

    const mapped = activeMethods.map(m => ({
      key: m.id,
      label: m.name,
      icon: ICON_MAP[m.type] || CreditCard,
    }));
    setPaymentMethods(mapped);
  };

  const loadAvailableDiscounts = async () => {
    try {
      const allDiscounts = await base44.entities.Discount.list();
      const today = new Date().toISOString().split("T")[0];
      
      const applicable = allDiscounts.filter(d => {
        if (!d.is_active) return false;
        if (d.start_date && d.start_date > today) return false;
        if (d.end_date && d.end_date < today) return false;
        if (d.usage_limit > 0 && d.times_used >= d.usage_limit) return false;
        if (d.applicable_branches?.length > 0 && !d.applicable_branches.includes(branchId)) return false;
        if (d.min_order_amount > 0 && total < d.min_order_amount) return false;
        return true;
      });
      
      setAvailableDiscounts(applicable);
    } catch (e) {
      console.log("Error loading discounts");
    }
    setDiscountsLoading(false);
  };

  const applyDiscount = (discountId) => {
    if (appliedDiscountId === discountId) {
      setAppliedDiscountId(null);
      setDiscount(0);
      return;
    }

    const selected = availableDiscounts.find(d => d.id === discountId);
    if (!selected) return;

    let discountAmount = 0;
    if (selected.type === "percentage") {
      discountAmount = (total * selected.value) / 100;
      if (selected.max_discount_amount) {
        discountAmount = Math.min(discountAmount, selected.max_discount_amount);
      }
    } else if (selected.type === "fixed_amount") {
      discountAmount = selected.value;
    }

    setAppliedDiscountId(discountId);
    setDiscount(discountAmount);
  };

  // Recalculate tax and total based on selected tax group, fallback to passed tax prop
  const effectiveTaxRate = currentTaxGroup ? currentTaxGroup.rate : 0;
  const effectiveTax = currentTaxGroup
    ? parseFloat((subtotal * effectiveTaxRate / 100).toFixed(2))
    : parseFloat((tax || 0).toFixed(2));
  const effectiveTotal = parseFloat((subtotal + effectiveTax).toFixed(2));

  const maxRedeemPoints = loyaltyCustomer
    ? Math.min(loyaltyCustomer.points || 0, Math.floor(effectiveTotal / 10) * POINTS_PER_REDEEM)
    : 0;
  const pointsDiscount = (redeemPoints / POINTS_PER_REDEEM) * 10;
  const discountedTotal = Math.max(0, effectiveTotal - discount - pointsDiscount);
  const change = paymentMethod === "cash" ? (parseFloat(amountPaid) || 0) - discountedTotal : 0;

  const generateOrderNumber = () => `ORD-${Date.now().toString().slice(-6)}`;

  const handleStripeCheckout = async () => {
    if (window.self !== window.top) {
      alert("Online payment works only from the published app, not from the preview.");
      return;
    }
    setLoading(true);
    const res = await base44.functions.invoke("createStripeCheckout", {
      cartItems, orderType,
      tableNumber: selectedTable?.number || null,
      customerName: loyaltyCustomer?.name || customerName || null,
      subtotal, tax, total: discountedTotal,
    });
    setLoading(false);
    if (res.data?.url) window.location.href = res.data.url;
  };

  const getSignatureTrigger = (totalDiscount, discountedTotal) => {
    if (discountedTotal === 0 && total > 0) return "foc";
    const discountPct = total > 0 ? (totalDiscount / total) * 100 : 0;
    if (discountPct > SIGNATURE_DISCOUNT_THRESHOLD) return "high_discount";
    return null;
  };

  const handleConfirm = async () => {
    if (paymentMethod === "online") {
      await handleStripeCheckout();
      return;
    }
    const totalDiscount = discount + pointsDiscount;
    const trigger = getSignatureTrigger(totalDiscount, discountedTotal);
    if (trigger) {
      const orderNumber = generateOrderNumber();
      setPendingOrderData({ orderNumber, totalDiscount, trigger });
      setSignatureTrigger(trigger);
      setShowSignatureModal(true);
      return;
    }
    await finalizeOrder(generateOrderNumber(), totalDiscount, null);
  };

  const finalizeOrder = async (orderNumber, totalDiscount, signatureData) => {
    setLoading(true);
    const createdOrder = await base44.entities.Order.create({
      order_number: orderNumber,
      type: orderType,
      table_number: selectedTable?.number || null,
      customer_name: loyaltyCustomer?.name || customerName || null,
      items: cartItems,
      status: "paid",
      payment_method: paymentMethod,
      subtotal, tax: effectiveTax,
      discount: totalDiscount,
      total: discountedTotal,
      amount_paid: paymentMethod === "cash" ? parseFloat(amountPaid) || discountedTotal : discountedTotal,
      change_due: change > 0 ? change : 0,
      cashier_name: cashierName,
      branch_id: branchId,
      tax_group_id: currentTaxGroup?.id || null,
    });

    if (signatureData) {
      base44.entities.InvoiceSignature.create({
        order_id: createdOrder.id,
        order_number: orderNumber,
        signed_by_name: signatureData.signedByName,
        signature_image: signatureData.signatureImage,
        signed_at: new Date().toISOString(),
        trigger_reason: signatureData.trigger,
        discount_amount: totalDiscount,
        order_total: discountedTotal,
        cashier_name: cashierName,
        branch_id: branchId,
      }).catch(() => {});
    }

    if (appliedDiscountId) {
      const discountRecord = availableDiscounts.find(d => d.id === appliedDiscountId);
      if (discountRecord) {
        await base44.entities.Discount.update(appliedDiscountId, {
          times_used: (discountRecord.times_used || 0) + 1
        });
      }
    }

    for (const item of cartItems) {
      const menuItem = await base44.entities.MenuItem.filter({ id: item.menu_item_id }).then(i => i[0]);
      if (menuItem && menuItem.stock_quantity != null) {
        await base44.entities.MenuItem.update(item.menu_item_id, {
          stock_quantity: Math.max(0, (menuItem.stock_quantity || 0) - item.quantity)
        });
      }
      // Deduct raw inventory items based on recipe
      if (menuItem && menuItem.recipe?.length > 0) {
        for (const ingredient of menuItem.recipe) {
          const invItem = await base44.entities.InventoryItem.filter({ id: ingredient.inventory_item_id }).then(i => i[0]);
          if (invItem) {
            const deduction = ingredient.quantity * item.quantity;
            await base44.entities.InventoryItem.update(ingredient.inventory_item_id, {
              current_quantity: Math.max(0, (invItem.current_quantity || 0) - deduction)
            });
          }
        }
      }
    }

    if (loyaltyCustomer) {
      const pts = Math.floor(discountedTotal * POINTS_PER_AED);
      setEarnedPoints(pts);
      const newPoints = Math.max(0, (loyaltyCustomer.points || 0) - redeemPoints + pts);
      // Determine new tier
      let newTier = "Silver";
      if (newPoints >= 500) newTier = "Platinum";
      else if (newPoints >= 200) newTier = "Gold";
      await base44.entities.Customer.update(loyaltyCustomer.id, {
        points: newPoints,
        tier: newTier,
        total_spent: (loyaltyCustomer.total_spent || 0) + discountedTotal,
        visit_count: (loyaltyCustomer.visit_count || 0) + 1,
      });
      // Record loyalty transaction
      if (pts > 0) {
        base44.entities.LoyaltyTransaction.create({
          customer_id: loyaltyCustomer.id,
          customer_name: loyaltyCustomer.name,
          order_id: createdOrder.id,
          order_number: orderNumber,
          points_change: pts,
          type: "earn",
          description: `Earned ${pts} pts on order ${orderNumber} (AED ${discountedTotal.toFixed(2)})`,
          branch_id: branchId,
        }).catch(() => {});
      }
      if (redeemPoints > 0) {
        base44.entities.LoyaltyTransaction.create({
          customer_id: loyaltyCustomer.id,
          customer_name: loyaltyCustomer.name,
          order_id: createdOrder.id,
          order_number: orderNumber,
          points_change: -redeemPoints,
          type: "redeem",
          description: `Redeemed ${redeemPoints} pts on order ${orderNumber}`,
          branch_id: branchId,
        }).catch(() => {});
      }
    }

    if (orderType === "dine-in" && selectedTable) {
      await base44.entities.Table.update(selectedTable.id, { status: "available", current_order_id: null });
    }

    const posSettings = JSON.parse(localStorage.getItem("pos_settings") || "{}");
    const branding = JSON.parse(localStorage.getItem("receipt_branding_v2") || "{}");
    const orderData = {
      order_number: orderNumber,
      customer_name: loyaltyCustomer?.name || customerName || null,
      table_number: selectedTable?.number || null,
      items: cartItems,
      subtotal,
      tax: effectiveTax,
      discount: totalDiscount,
      total: discountedTotal,
      payment_method: paymentMethod,
      cashier_name: cashierName,
      email: loyaltyCustomer?.email || null,
      restaurant_name: branding.businessName || posSettings.restaurantName || "DENDAX",
      branch_name: branding.address || posSettings.branchName || "",
    };

    setLastOrder(orderData);
    // Pre-fill email from loyalty customer
    if (loyaltyCustomer?.email) setEmailInput(loyaltyCustomer.email);

    // Auto-print receipt if configured
    const printers = JSON.parse(localStorage.getItem("pos_printers") || "[]");
    const autoSettings = JSON.parse(localStorage.getItem("pos_print_settings") || "{}");
    const receiptPrinter = printers.find(p => p.type === "receipt");
    const kitchenPrinter = printers.find(p => p.type === "kitchen");

    if (autoSettings.autoReceipt !== false && receiptPrinter?.ip) {
      printReceipt(orderData, receiptPrinter).catch(() => {});
    }

    if (autoSettings.autoKitchen !== false) {
      const categoryRoutes = JSON.parse(localStorage.getItem("pos_category_routes") || "{}");
      const kitchenPrinters = printers.filter(p => p.type === "kitchen" && p.ip);
      const printerItemsMap = {};
      for (const item of cartItems) {
        const routedPrinterId = categoryRoutes[item.category];
        const printer = routedPrinterId
          ? kitchenPrinters.find(p => p.id === routedPrinterId)
          : kitchenPrinter;
        if (!printer?.ip) continue;
        if (!printerItemsMap[printer.id]) printerItemsMap[printer.id] = { printer, items: [] };
        printerItemsMap[printer.id].items.push(item);
      }
      for (const { printer, items } of Object.values(printerItemsMap)) {
        printKitchenTicket({
          items, orderType, orderNumber,
          tableNumber: selectedTable?.number || null,
          customerName: loyaltyCustomer?.name || customerName || null,
        }, printer).catch(() => {});
      }
    }

    setLoading(false);
    setStep(2);
  };

  // ── Step indicator ──
  const StepIndicator = () => (
    <div className="flex items-center justify-center gap-2 mb-6">
      {STEPS.map((s, i) => (
        <React.Fragment key={s}>
          <div className={`flex items-center gap-1.5 ${i === step ? "text-amber-400" : i < step ? "text-green-400" : "text-white/20"}`}>
            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold border
              ${i === step ? "border-amber-400 bg-amber-400/10" : i < step ? "border-green-400 bg-green-400/10" : "border-white/20"}`}>
              {i < step ? "✓" : i + 1}
            </div>
            <span className="text-xs font-medium">{s}</span>
          </div>
          {i < STEPS.length - 1 && <div className={`h-px w-6 ${i < step ? "bg-green-400/50" : "bg-white/10"}`} />}
        </React.Fragment>
      ))}
    </div>
  );

  // ── STEP 0: Review ──
  const ReviewStep = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-1">
        <Receipt className="w-4 h-4 text-amber-400" />
        <span className="text-sm font-semibold text-white">Order Summary</span>
      </div>

      <div className="bg-white/5 rounded-2xl divide-y divide-white/5">
        {cartItems.map(item => (
          <div key={item.menu_item_id} className="flex justify-between items-center px-4 py-3 text-sm">
            <div>
              <span className="text-white font-medium">{item.name}</span>
              <span className="text-white/40 ml-2">× {item.quantity}</span>
              {item.modifiers?.length > 0 && (
                <div className="text-xs text-white/30 mt-0.5">{item.modifiers.map(m => m.name).join(", ")}</div>
              )}
            </div>
            <span className="text-white/70 font-semibold">${(item.subtotal ?? item.price * item.quantity).toFixed(2)}</span>
          </div>
        ))}
      </div>

      {/* Totals */}
      <div className="bg-white/5 rounded-2xl px-4 py-3 space-y-2 text-sm">
        <div className="flex justify-between text-white/50"><span>Subtotal</span><span>AED {subtotal.toFixed(2)}</span></div>
        {currentTaxGroup ? (
          <div className="flex justify-between text-white/50">
            <span>Tax ({currentTaxGroup.name} · {currentTaxGroup.rate}%)</span>
            <span>AED {effectiveTax.toFixed(2)}</span>
          </div>
        ) : effectiveTax > 0 ? (
          <div className="flex justify-between text-white/50">
            <span>Tax</span>
            <span>AED {effectiveTax.toFixed(2)}</span>
          </div>
        ) : (
          <div className="flex justify-between text-white/30 italic text-xs">
            <span>No Tax Applied</span><span>AED 0.00</span>
          </div>
        )}
        <div className="border-t border-white/10 pt-2 flex justify-between font-bold text-base">
          <span className="text-white">Total</span>
          <span className="text-amber-400">AED {effectiveTotal.toFixed(2)}</span>
        </div>
      </div>

      {/* Order info */}
      <div className="flex gap-2 text-xs">
        <div className="flex-1 bg-white/5 rounded-xl px-3 py-2">
          <p className="text-white/40 mb-0.5">Order Type</p>
          <p className="text-white font-medium capitalize">{orderType === "dine-in" ? `Dine-In · Table ${selectedTable?.number}` : "Takeaway"}</p>
        </div>
        {(loyaltyCustomer || customerName) && (
          <div className="flex-1 bg-white/5 rounded-xl px-3 py-2">
            <p className="text-white/40 mb-0.5">Customer</p>
            <p className="text-white font-medium">{loyaltyCustomer?.name || customerName}</p>
          </div>
        )}
      </div>

      {/* Tax Group selector */}
      {taxGroups.length > 0 && (
        <div className="bg-violet-400/10 border border-violet-400/30 rounded-xl p-3">
          <label className="text-xs text-white/40 mb-2 block">Tax Group</label>
          <select
            value={currentTaxGroup?.id || ""}
            onChange={e => setCurrentTaxGroup(taxGroups.find(t => t.id === e.target.value) || null)}
            className="w-full border border-white/10 rounded-lg px-3 py-2 text-xs bg-white/5 text-white focus:outline-none focus:ring-2 focus:ring-violet-400"
          >
            <option value="">No Tax Group</option>
            {taxGroups.map(group => (
              <option key={group.id} value={group.id}>{group.name}</option>
            ))}
          </select>
          {currentTaxGroup && (
            <p className="text-xs text-violet-400 mt-2 font-medium">✓ {currentTaxGroup.name} applied</p>
          )}
        </div>
      )}

      <Button onClick={() => setStep(1)} className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-12">
        Proceed to Payment <ChevronRight className="w-4 h-4 ml-1" />
      </Button>
    </div>
  );

  // ── STEP 1: Payment ──
  const PaymentStep = () => (
    <div className="space-y-4">
      {/* Loyalty */}
      {loyaltyCustomer && (
        <div className="bg-amber-400/5 border border-amber-400/20 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Star className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs text-amber-400 font-medium">{loyaltyCustomer.name}</span>
            </div>
            <span className="text-xs text-amber-400">{loyaltyCustomer.points?.toLocaleString() || 0} pts</span>
          </div>
          {maxRedeemPoints > 0 && (
            <div>
              <label className="text-xs text-white/40 mb-1 block">Redeem points (per {POINTS_PER_REDEEM} pts = AED 10 off)</label>
              <div className="flex gap-2 flex-wrap">
                {Array.from({ length: Math.min(Math.floor(maxRedeemPoints / POINTS_PER_REDEEM), 5) }, (_, i) => (i + 1) * POINTS_PER_REDEEM).map(pts => (
                  <button key={pts} onClick={() => setRedeemPoints(redeemPoints === pts ? 0 : pts)}
                    className={`text-xs px-2.5 py-1.5 rounded-lg border transition-all ${redeemPoints === pts ? "bg-amber-400 border-amber-400 text-black font-semibold" : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10"}`}>
                    {pts.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Promotional Discounts */}
      {!discountsLoading && availableDiscounts.length > 0 && (
        <div>
          <label className="text-xs text-white/40 mb-2 flex items-center gap-1"><Tag className="w-3 h-3" /> Promo Discounts</label>
          <div className="space-y-1.5 max-h-28 overflow-y-auto">
            {availableDiscounts.map(d => {
              const discountLabel = d.type === "percentage" ? `${d.value}%` : `AED ${d.value.toFixed(2)}`;
              return (
                <button
                  key={d.id}
                  onClick={() => applyDiscount(d.id)}
                  className={`w-full px-3 py-2 rounded-lg border text-xs transition-all text-left ${
                    appliedDiscountId === d.id
                      ? "bg-green-400 border-green-400 text-black font-semibold"
                      : "bg-white/5 border-white/10 text-white/70 hover:bg-white/10"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{d.name}</span>
                    <span className="text-xs">{discountLabel}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Manual Discount */}
      <div>
        <label className="text-xs text-white/40 mb-1.5 block">Manual Discount (AED)</label>
        <Input type="number" min={0} max={total} placeholder="0.00" value={discount || ""}
          onChange={e => { setDiscount(parseFloat(e.target.value) || 0); setAppliedDiscountId(null); }}
          className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-9 rounded-xl" />
      </div>

      {/* Total after discounts */}
      {(discount > 0 || pointsDiscount > 0) && (
        <div className="bg-green-400/5 border border-green-400/20 rounded-xl px-4 py-2.5 flex justify-between items-center">
          <span className="text-xs text-green-400">Discount applied</span>
          <div className="text-right">
            <span className="text-xs text-green-400 line-through mr-2">AED {total.toFixed(2)}</span>
            <span className="text-base font-bold text-amber-400">AED {discountedTotal.toFixed(2)}</span>
          </div>
        </div>
      )}

      {/* Payment method */}
      <div>
        <label className="text-xs text-white/40 mb-2 block">Payment Method</label>
        <div className={`grid ${paymentMethods.length > 5 ? "grid-cols-3" : "grid-cols-5"} gap-2`}>
          {paymentMethods.map(({ key, label, icon: Icon }) => (
            <button key={key} onClick={() => setPaymentMethod(key)}
              className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border text-xs font-medium transition-all
                ${paymentMethod === key ? "bg-amber-400 border-amber-400 text-black" : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10"}`}>
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {paymentMethod === "online" && (
        <div className="bg-blue-400/10 border border-blue-400/20 rounded-xl p-3 text-xs text-blue-300">
          Customer will be redirected to a secure Stripe payment page.
        </div>
      )}

      {paymentMethod === "cash" && (
        <div>
          <label className="text-xs text-white/40 mb-1.5 block">Amount Received ($)</label>
          <Input type="number" placeholder={discountedTotal.toFixed(2)} value={amountPaid}
            onChange={e => setAmountPaid(e.target.value)}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/20 h-9 rounded-xl" />
          {change > 0 && <p className="text-sm text-green-400 mt-2 font-semibold">Change: AED {change.toFixed(2)}</p>}
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <Button variant="outline" onClick={() => setStep(0)}
          className="flex-1 border-white/10 text-white/60 hover:bg-white/5 rounded-xl h-11 bg-transparent">
          <ChevronLeft className="w-4 h-4 mr-1" /> Back
        </Button>
        <Button onClick={handleConfirm} disabled={loading || (paymentMethod === "cash" && amountPaid !== "" && parseFloat(amountPaid) < discountedTotal)}
          className="flex-[2] bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11">
          {loading ? "Processing..." : `Confirm · AED ${discountedTotal.toFixed(2)}`}
        </Button>
      </div>
    </div>
  );

  // ── STEP 2: Confirmation ──
  const ConfirmationStep = () => (
    <div className="flex flex-col items-center gap-5 py-4 text-center">
      <div className="w-20 h-20 rounded-full bg-green-400/10 border border-green-400/20 flex items-center justify-center">
        <CheckCircle2 className="w-10 h-10 text-green-400" />
      </div>
      <div>
        <h3 className="text-xl font-bold text-white">Payment Complete!</h3>
        <p className="text-white/40 text-sm mt-1">Order processed successfully</p>
      </div>

      <div className="w-full bg-white/5 rounded-2xl px-4 py-3 space-y-2 text-sm text-left">
        <div className="flex justify-between">
          <span className="text-white/40">Amount Paid</span>
          <span className="text-white font-semibold">AED {discountedTotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-white/40">Method</span>
          <span className="text-white font-semibold capitalize">
            {paymentMethods.find(m => m.key === paymentMethod)?.label || paymentMethod}
          </span>
        </div>
        {change > 0 && (
          <div className="flex justify-between border-t border-white/10 pt-2">
            <span className="text-amber-400">Change Due</span>
            <span className="text-amber-400 font-bold">AED {change.toFixed(2)}</span>
          </div>
        )}
      </div>

      {loyaltyCustomer && earnedPoints > 0 && (
        <div className="flex items-center gap-2 bg-amber-400/10 border border-amber-400/30 rounded-xl px-4 py-2.5 w-full">
          <Star className="w-4 h-4 text-amber-400 shrink-0" />
          <p className="text-amber-400 font-semibold text-sm">+{earnedPoints} points for {loyaltyCustomer.name}!</p>
        </div>
      )}

      <div className="grid grid-cols-2 gap-2 w-full">
        <Button onClick={() => setShowPrintModal(true)} variant="outline" className="border-white/10 text-white/60 hover:bg-white/5 rounded-xl h-11 bg-transparent gap-2">
          <Printer className="w-4 h-4" /> Print
        </Button>
        <Button onClick={() => setShowDigitalModal(true)} variant="outline" className="border-violet-400/40 text-violet-300 hover:bg-violet-400/10 rounded-xl h-11 bg-transparent gap-2">
          <QrCode className="w-4 h-4" /> QR / Send
        </Button>
      </div>

      {/* Email Invoice */}
      {emailSent ? (
        <div className="w-full flex items-center justify-center gap-2 bg-green-400/10 border border-green-400/20 rounded-xl px-4 py-2.5">
          <CheckCircle2 className="w-4 h-4 text-green-400" />
          <span className="text-green-400 text-sm font-medium">Invoice sent to {emailInput}</span>
        </div>
      ) : showEmailInput ? (
        <div className="w-full space-y-2">
          <Input
            type="email"
            placeholder="customer@email.com"
            value={emailInput}
            onChange={e => setEmailInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSendEmail()}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl"
            autoFocus
          />
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowEmailInput(false)}
              className="flex-1 border-white/10 text-white/40 bg-transparent hover:bg-white/5 rounded-xl h-9 text-xs">
              Cancel
            </Button>
            <Button onClick={handleSendEmail} disabled={emailSending || !emailInput.trim()}
              className="flex-[2] bg-violet-500 hover:bg-violet-400 text-white rounded-xl h-9 text-xs gap-2">
              {emailSending ? 'Sending...' : <><Mail className="w-3.5 h-3.5" /> Send Invoice</>}
            </Button>
          </div>
        </div>
      ) : (
        <Button onClick={() => setShowEmailInput(true)} variant="outline"
          className="w-full border-white/10 text-white/60 hover:bg-white/5 rounded-xl h-11 bg-transparent gap-2">
          <Mail className="w-4 h-4" /> Email Invoice
        </Button>
      )}

      <Button onClick={onSuccess} className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11">
        New Order
      </Button>
    </div>
  );

  const handleSendEmail = async () => {
    if (!emailInput.trim() || !lastOrder) return;
    setEmailSending(true);
    try {
      // Fetch signature if exists
      let signature = null;
      if (lastOrder.order_id) {
        const sigs = await base44.entities.InvoiceSignature.filter({ order_id: lastOrder.order_id }).catch(() => []);
        if (sigs.length > 0) signature = sigs[0];
      }
      await base44.functions.invoke('emailInvoice', { email: emailInput.trim(), order: lastOrder, signature });
      setEmailSent(true);
      setShowEmailInput(false);
    } catch (e) {
      console.error(e);
    }
    setEmailSending(false);
  };

  const handleSignatureComplete = async ({ signatureImage, signedByName }) => {
    setShowSignatureModal(false);
    const { orderNumber, totalDiscount, trigger } = pendingOrderData;
    setPendingOrderData(null);
    await finalizeOrder(orderNumber, totalDiscount, { signatureImage, signedByName, trigger });
  };

  const handleSignatureSkip = async () => {
    setShowSignatureModal(false);
    const { orderNumber, totalDiscount } = pendingOrderData;
    setPendingOrderData(null);
    await finalizeOrder(orderNumber, totalDiscount, null);
  };

  const signatureOrderPreview = pendingOrderData ? {
    order_number: pendingOrderData.orderNumber,
    cashier_name: cashierName,
    discount: pendingOrderData.totalDiscount,
    total: discountedTotal,
  } : null;

  return (
    <>
      {showPrintModal && lastOrder && (
        <PrintBillModal order={lastOrder} onClose={() => setShowPrintModal(false)} />
      )}
      {showDigitalModal && lastOrder && (
        <DigitalReceiptModal order={lastOrder} onClose={() => setShowDigitalModal(false)} />
      )}
      {showSignatureModal && signatureOrderPreview && (
        <SignatureModal
          order={signatureOrderPreview}
          triggerReason={signatureTrigger}
          onComplete={handleSignatureComplete}
          onSkip={handleSignatureSkip}
        />
      )}
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-[#16161d] border border-white/10 rounded-3xl w-full max-w-md text-white overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Wallet className="w-4 h-4 text-amber-400" />
              <h2 className="font-bold text-base">Checkout</h2>
            </div>
            {step < 2 && (
              <button onClick={onClose} className="text-white/30 hover:text-white transition">
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          <div className="px-6 py-5">
            <StepIndicator />
            {step === 0 && <ReviewStep />}
            {step === 1 && <PaymentStep />}
            {step === 2 && <ConfirmationStep />}
          </div>
        </div>
      </div>
    </>
  );
}