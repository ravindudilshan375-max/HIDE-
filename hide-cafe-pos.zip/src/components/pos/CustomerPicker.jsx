import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Search, UserPlus, X, Star } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function CustomerPicker({ selectedCustomer, onSelect }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setShowDropdown(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const search = async (val) => {
    setQuery(val);
    if (val.length < 1) { setResults([]); return; }
    const all = await base44.entities.Customer.list();
    setResults(all.filter(c =>
      c.name.toLowerCase().includes(val.toLowerCase()) ||
      (c.phone || "").includes(val)
    ).slice(0, 5));
    setShowDropdown(true);
  };

  const createCustomer = async () => {
    if (!newName.trim()) return;
    const c = await base44.entities.Customer.create({ name: newName.trim(), phone: newPhone.trim(), points: 0, total_spent: 0, visit_count: 0 });
    onSelect(c);
    setCreating(false);
    setQuery(c.name);
    setShowDropdown(false);
  };

  if (selectedCustomer) {
    return (
      <div className="flex items-center justify-between bg-amber-400/10 border border-amber-400/30 rounded-xl px-3 py-2">
        <div>
          <p className="text-sm font-medium text-amber-400">{selectedCustomer.name}</p>
          <p className="text-xs text-white/40 flex items-center gap-1">
            <Star className="w-3 h-3 text-amber-400" />
            {selectedCustomer.points?.toLocaleString() || 0} pts
          </p>
        </div>
        <button onClick={() => { onSelect(null); setQuery(""); }} className="text-white/30 hover:text-white transition">
          <X className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div ref={ref} className="relative">
      {!creating ? (
        <>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
            <Input
              placeholder="Search loyalty customer..."
              value={query}
              onChange={e => search(e.target.value)}
              onFocus={() => query && setShowDropdown(true)}
              className="bg-white/5 border-white/10 text-white text-xs placeholder:text-white/20 h-8 rounded-xl pl-8"
            />
          </div>
          {showDropdown && (
            <div className="absolute top-full mt-1 left-0 right-0 bg-[#1e1e28] border border-white/10 rounded-xl overflow-hidden z-50 shadow-xl">
              {results.map(c => (
                <button key={c.id} onClick={() => { onSelect(c); setQuery(c.name); setShowDropdown(false); }}
                  className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-white/5 transition text-left">
                  <div>
                    <p className="text-sm text-white">{c.name}</p>
                    <p className="text-xs text-white/30">{c.phone || "No phone"}</p>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-medium">
                    <Star className="w-3 h-3" />{c.points?.toLocaleString() || 0}
                  </div>
                </button>
              ))}
              <button onClick={() => { setCreating(true); setShowDropdown(false); setNewName(query); }}
                className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-white/5 transition text-white/50 hover:text-white text-sm border-t border-white/10">
                <UserPlus className="w-3.5 h-3.5" /> New customer
              </button>
            </div>
          )}
        </>
      ) : (
        <div className="bg-white/5 rounded-xl p-3 space-y-2">
          <p className="text-xs text-white/40 font-medium">New Customer</p>
          <Input placeholder="Name *" value={newName} onChange={e => setNewName(e.target.value)}
            className="bg-white/5 border-white/10 text-white text-xs placeholder:text-white/20 h-8 rounded-lg" />
          <Input placeholder="Phone" value={newPhone} onChange={e => setNewPhone(e.target.value)}
            className="bg-white/5 border-white/10 text-white text-xs placeholder:text-white/20 h-8 rounded-lg" />
          <div className="flex gap-2">
            <Button size="sm" onClick={createCustomer} className="flex-1 h-7 text-xs bg-amber-400 hover:bg-amber-300 text-black">Create</Button>
            <Button size="sm" variant="ghost" onClick={() => setCreating(false)} className="flex-1 h-7 text-xs text-white/40">Cancel</Button>
          </div>
        </div>
      )}
    </div>
  );
}