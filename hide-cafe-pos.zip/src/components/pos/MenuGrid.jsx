import React, { useState } from "react";
import { Plus, Clock, PenSquare } from "lucide-react";
import ItemCustomizerModal from "@/components/pos/ItemCustomizerModal";
import CustomItemModal from "@/components/pos/CustomItemModal";

export default function MenuGrid({ menuItems, onAdd }) {
  const [activeCategory, setActiveCategory] = useState("All");

  const CATEGORIES = ["All", ...Array.from(new Set(menuItems.map(i => i.category).filter(Boolean)))];
  const [search, setSearch] = useState("");
  const [customizerItem, setCustomizerItem] = useState(null);
  const [showCustomItem, setShowCustomItem] = useState(false);

  const filtered = menuItems.filter(item => {
    const matchCat = activeCategory === "All" || item.category === activeCategory;
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleItemClick = (item) => {
    if (item.modifiers?.length > 0) {
      setCustomizerItem(item);
    } else {
      onAdd({ menu_item_id: item.id, name: item.name, price: item.price, quantity: 1, notes: "", modifiers: [], subtotal: item.price });
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden px-4 pb-4">
      {customizerItem && (
        <ItemCustomizerModal item={customizerItem} onAdd={onAdd} onClose={() => setCustomizerItem(null)} />
      )}
      {showCustomItem && (
        <CustomItemModal onAdd={onAdd} onClose={() => setShowCustomItem(false)} />
      )}
      {/* Search */}
      <div className="py-3 flex gap-2">
        <input
          placeholder="Search menu..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/30 transition"
        />
        <button
          onClick={() => setShowCustomItem(true)}
          className="flex items-center gap-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-3 py-2 text-xs text-white/50 hover:text-white transition"
        >
          <PenSquare className="w-3.5 h-3.5" /> Custom
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-3 scrollbar-none">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-medium transition-all ${
              activeCategory === cat
                ? "bg-amber-400 text-black"
                : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 overflow-y-auto flex-1 pr-1">
        {filtered.length === 0 && (
          <div className="col-span-full text-center text-white/30 py-16 text-sm">No items found</div>
        )}
        {filtered.map(item => (
          <button
            key={item.id}
            onClick={() => handleItemClick(item)}
            className="group relative bg-white/5 hover:bg-white/10 border border-white/10 hover:border-amber-400/50 rounded-2xl p-4 text-left transition-all duration-200 active:scale-95"
          >
            <div className="flex flex-col h-full gap-2">
              {item.image_url && (
                <img src={item.image_url} alt={item.name} className="w-full h-24 object-cover rounded-xl mb-1" />
              )}
              {!item.image_url && (
                <div className="w-full h-20 rounded-xl bg-gradient-to-br from-amber-400/20 to-orange-500/10 flex items-center justify-center text-3xl mb-1">
                  🍽
                </div>
              )}
              <span className="text-sm font-medium text-white leading-tight">{item.name}</span>
              {item.category && (
                <span className="text-xs text-white/30">{item.category}</span>
              )}
              <div className="flex items-center justify-between mt-auto pt-1">
                <span className="text-amber-400 font-bold text-sm">${item.price?.toFixed(2)}</span>
                {item.prep_time && (
                  <span className="flex items-center gap-1 text-xs text-white/30">
                    <Clock className="w-3 h-3" />{item.prep_time}m
                  </span>
                )}
              </div>
            </div>
            <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-amber-400 text-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Plus className="w-4 h-4" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}