import React, { useState } from "react";
import { X, QrCode, MessageCircle, MessageSquare, Copy, Check, Smartphone, Star } from "lucide-react";
import FeedbackForm from "./FeedbackForm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

function getReceiptUrl(order) {
  const base = window.location.origin;
  // Embed minimal receipt data in URL to avoid auth issues for customers
  const receiptData = {
    order_number: order.order_number,
    created_date: order.created_date,
    type: order.type,
    table_number: order.table_number,
    customer_name: order.customer_name,
    items: order.items,
    subtotal: order.subtotal,
    tax: order.tax,
    discount: order.discount,
    total: order.total,
    payment_method: order.payment_method,
    cashier_name: order.cashier_name,
  };
  const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(receiptData))));
  const pageUrl = createPageUrl("DigitalReceipt");
  // createPageUrl returns hash-based URLs like /#/DigitalReceipt
  // We need to append query params inside the hash: /#/DigitalReceipt?data=...
  const separator = pageUrl.includes('?') ? '&' : '?';
  return `${base}${pageUrl}${separator}data=${encodeURIComponent(encoded)}`;
}

export default function DigitalReceiptModal({ order, onClose }) {
  const [phone, setPhone] = useState(order.customer_phone || "");
  const [copied, setCopied] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);

  const receiptUrl = getReceiptUrl(order);
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(receiptUrl)}&margin=10`;

  const branding = JSON.parse(localStorage.getItem("receipt_branding_v2") || "{}");
  const businessName = branding.businessName || order.restaurant_name || "RESTAURANT";

  const copyLink = () => {
    navigator.clipboard.writeText(receiptUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Link copied!");
  };

  const sendWhatsApp = () => {
    if (!phone.trim()) { toast.error("Please enter a phone number"); return; }
    const cleanPhone = phone.replace(/\D/g, "");
    const message = `Thank you for visiting ${businessName}! 🙏\n\nYour receipt for order ${order.order_number}:\n${receiptUrl}`;
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  };

  const sendSMS = () => {
    if (!phone.trim()) { toast.error("Please enter a phone number"); return; }
    const message = `${businessName}\nOrder ${order.order_number} · AED ${(order.total || 0).toFixed(2)}\nView receipt: ${receiptUrl}`;
    window.open(`sms:${phone}?body=${encodeURIComponent(message)}`, "_blank");
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[60] p-4">
      <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-violet-600" />
            <h2 className="font-bold text-gray-900">Digital Receipt</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* QR Code */}
          <div className="flex flex-col items-center gap-3">
            <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100">
              <img src={qrUrl} alt="Receipt QR" className="w-44 h-44" />
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-gray-700">Scan to view receipt</p>
              <p className="text-xs text-gray-400 mt-0.5">Order {order.order_number} · AED {(order.total || 0).toFixed(2)}</p>
            </div>
          </div>

          {/* Copy link */}
          <div className="flex gap-2">
            <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-xs text-gray-500 truncate font-mono">
              {receiptUrl}
            </div>
            <button
              onClick={copyLink}
              className={`px-3 py-2.5 rounded-xl border text-xs font-medium transition-all shrink-0 flex items-center gap-1.5 ${copied ? "bg-green-500 border-green-500 text-white" : "border-gray-200 hover:bg-gray-50 text-gray-600"}`}
            >
              {copied ? <><Check className="w-3.5 h-3.5" /> Copied</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
            </button>
          </div>

          {/* Phone input */}
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1.5 flex items-center gap-1.5 block">
              <Smartphone className="w-3.5 h-3.5" /> Customer Phone Number
            </label>
            <Input
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="+971 50 000 0000"
              className="rounded-xl border-gray-200"
            />
          </div>

          {/* Send buttons */}
          <div className="grid grid-cols-2 gap-2">
            <Button
              onClick={sendWhatsApp}
              className="bg-green-500 hover:bg-green-600 text-white rounded-xl h-11 gap-2 font-semibold"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp
            </Button>
            <Button
              onClick={sendSMS}
              variant="outline"
              className="border-gray-200 text-gray-700 rounded-xl h-11 gap-2 font-semibold hover:bg-gray-50"
            >
              <MessageSquare className="w-4 h-4" />
              SMS
            </Button>
          </div>

          <p className="text-center text-xs text-gray-400">
            WhatsApp opens the app with a pre-filled message.
            SMS opens your default messaging app.
          </p>

          {/* Feedback */}
          {showFeedback ? (
            <div className="border border-violet-100 bg-violet-50/50 rounded-2xl p-4">
              <FeedbackForm order={order} onClose={() => setShowFeedback(false)} />
            </div>
          ) : (
            <button
              onClick={() => setShowFeedback(true)}
              className="w-full flex items-center justify-center gap-2 border border-dashed border-amber-300 text-amber-600 hover:bg-amber-50 rounded-xl py-3 text-sm font-medium transition"
            >
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              Rate your experience
            </button>
          )}
        </div>
      </div>
    </div>
  );
}