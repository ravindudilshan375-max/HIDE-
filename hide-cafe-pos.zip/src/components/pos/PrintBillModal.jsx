import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Mail, Printer, X, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function PrintBillModal({ order, onClose }) {
  const [method, setMethod] = useState(null);
  const [email, setEmail] = useState(order?.email || "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleEmailPrint = async () => {
    if (!email.trim()) {
      setError("Please enter a valid email address");
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const billContent = formatBillContent(order);
      const res = await base44.functions.invoke("sendBillEmail", {
        to: email,
        subject: `Bill #${order.order_number || "Receipt"}`,
        body: billContent,
      });
      if (res.data?.success) {
        alert("Bill sent to email successfully!");
        onClose();
      } else {
        setError(res.data?.error || "Failed to send email");
      }
    } catch (err) {
      setError(err.message || "Failed to send email");
    } finally {
      setLoading(false);
    }
  };

  const handlePrinterPrint = async () => {
    setLoading(true);
    setError(null);
    try {
      const printers = JSON.parse(localStorage.getItem("pos_printers") || "[]");
      const receiptPrinter = printers.find(p => p.type === "receipt");

      if (!receiptPrinter) {
        setError("No receipt printer configured. Please set up a printer in settings.");
        setLoading(false);
        return;
      }

      // Call backend to handle ESC/POS printing
      const res = await base44.functions.invoke("printBill", {
        order,
        printerIp: receiptPrinter.ip,
        printerPort: receiptPrinter.port,
        connectionType: receiptPrinter.connectionType,
      });

      if (res.data?.success) {
        alert("Bill sent to printer!");
        onClose();
      } else {
        setError(res.data?.error || "Failed to print bill");
      }
    } catch (err) {
      setError(err.response?.data?.error || err.message || "Failed to connect to printer. Check IP address and ensure printer is online.");
    } finally {
      setLoading(false);
    }
  };

  const formatBillContent = (order) => {
    const items = (order.items || [])
      .map(item => `${item.quantity}x ${item.name}: AED ${(item.subtotal || item.price * item.quantity).toFixed(2)}`)
      .join("\n");

    return `
RESTAURANT BILL
================
Order #: ${order.order_number || "N/A"}
Date: ${new Date().toLocaleString()}

ITEMS:
${items}

Subtotal: AED ${(order.subtotal || 0).toFixed(2)}
Tax: AED ${(order.tax || 0).toFixed(2)}
Total: AED ${(order.total || 0).toFixed(2)}

Thank you for your order!
    `.trim();
  };

  if (!method) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl max-w-md w-full">
          <div className="border-b border-gray-200 p-6 flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Print Bill</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-3">
            <button
              onClick={() => setMethod("email")}
              className="w-full flex items-center gap-3 p-4 border-2 border-gray-200 rounded-xl hover:border-violet-400 hover:bg-violet-50 transition group"
            >
              <Mail className="w-5 h-5 text-violet-600 group-hover:text-violet-700" />
              <div className="text-left">
                <p className="font-semibold text-gray-900">Send via Email</p>
                <p className="text-xs text-gray-500">Bill will be emailed to customer</p>
              </div>
            </button>

            <button
              onClick={() => setMethod("printer")}
              className="w-full flex items-center gap-3 p-4 border-2 border-gray-200 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition group"
            >
              <Printer className="w-5 h-5 text-blue-600 group-hover:text-blue-700" />
              <div className="text-left">
                <p className="font-semibold text-gray-900">Print Receipt</p>
                <p className="text-xs text-gray-500">Send to configured printer</p>
              </div>
            </button>
          </div>

          <div className="border-t border-gray-200 p-6">
            <button
              onClick={onClose}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full">
        <div className="border-b border-gray-200 p-6 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">
            {method === "email" ? "Send Bill via Email" : "Print Receipt"}
          </h2>
          <button
            onClick={onClose}
            disabled={loading}
            className="text-gray-400 hover:text-gray-600 disabled:opacity-40"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {error && (
            <div className="flex gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {method === "email" && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Customer Email
              </label>
              <Input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="customer@example.com"
                disabled={loading}
                className="border-gray-200 rounded-lg"
              />
            </div>
          )}

          {method === "printer" && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-700">
                Bill will be printed to the configured receipt printer.
              </p>
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 p-6 flex gap-3">
          <button
            onClick={() => (error ? setError(null) : setMethod(null))}
            disabled={loading}
            className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 disabled:opacity-40 transition"
          >
            {error ? "Clear" : "Back"}
          </button>
          <button
            onClick={method === "email" ? handleEmailPrint : handlePrinterPrint}
            disabled={loading || (method === "email" && !email.trim())}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {method === "email" ? "Send Email" : "Print Now"}
          </button>
        </div>
      </div>
    </div>
  );
}