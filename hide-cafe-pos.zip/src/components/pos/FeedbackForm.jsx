import React, { useState } from "react";
import { Star, X, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";

export default function FeedbackForm({ order, onClose }) {
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!rating) return;
    setSubmitting(true);
    await base44.entities.CustomerFeedback.create({
      order_id: order.id || order.order_id || null,
      order_number: order.order_number,
      branch_id: order.branch_id || null,
      customer_name: order.customer_name || null,
      rating,
      comment: comment.trim() || null,
      submitted_at: new Date().toISOString(),
    });
    setSubmitting(false);
    setSubmitted(true);
  };

  const labels = ["", "Poor", "Fair", "Good", "Very Good", "Excellent"];

  if (submitted) {
    return (
      <div className="flex flex-col items-center gap-4 py-6 text-center">
        <div className="w-16 h-16 rounded-full bg-green-50 border border-green-200 flex items-center justify-center">
          <CheckCircle2 className="w-8 h-8 text-green-500" />
        </div>
        <div>
          <p className="text-base font-bold text-gray-900">Thank you!</p>
          <p className="text-sm text-gray-400 mt-1">Your feedback has been recorded.</p>
        </div>
        <Button onClick={onClose} className="mt-2 bg-violet-600 hover:bg-violet-700 text-white rounded-xl px-8">
          Done
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-gray-900">Rate Your Experience</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
          <X className="w-4 h-4" />
        </button>
      </div>

      <p className="text-sm text-gray-500">Order {order.order_number}</p>

      {/* Stars */}
      <div className="flex flex-col items-center gap-2">
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map(s => (
            <button
              key={s}
              onClick={() => setRating(s)}
              onMouseEnter={() => setHovered(s)}
              onMouseLeave={() => setHovered(0)}
              className="transition-transform hover:scale-110"
            >
              <Star
                className={`w-9 h-9 transition-colors ${
                  s <= (hovered || rating)
                    ? "fill-amber-400 text-amber-400"
                    : "text-gray-200"
                }`}
              />
            </button>
          ))}
        </div>
        <span className="text-sm font-medium text-amber-500 h-5">
          {labels[hovered || rating] || ""}
        </span>
      </div>

      {/* Comment */}
      <textarea
        value={comment}
        onChange={e => setComment(e.target.value)}
        placeholder="Share your thoughts (optional)..."
        rows={3}
        className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-violet-400 resize-none"
      />

      <Button
        onClick={handleSubmit}
        disabled={!rating || submitting}
        className="w-full bg-violet-600 hover:bg-violet-700 text-white rounded-xl h-11 font-semibold"
      >
        {submitting ? "Submitting..." : "Submit Feedback"}
      </Button>
    </div>
  );
}