import React from "react";
import { Printer, Ban, Percent, Ticket, MoreHorizontal, X, Zap } from "lucide-react";

const ACTION_BTNS = [
  { icon: Printer, label: "Print" },
  { icon: Ban, label: "Void" },
  { icon: Percent, label: "Discount" },
  { icon: Ticket, label: "Tickets" },
  { icon: MoreHorizontal, label: "More" },
];

export default function POSActionBar({
  cartItems,
  activePromos,
  discountPct,
  onDiscountChange,
  onShowPromoMenu,
  showPromoMenu,
  onPrint,
  onVoid,
  onTickets,
  onMore,
}) {
  const handleActionBtn = (label) => {
    if (label === "Discount") onShowPromoMenu(v => !v);
    else if (label === "Print") onPrint();
    else if (label === "Void") onVoid();
    else if (label === "Tickets") onTickets();
    else if (label === "More") onMore();
  };

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-2 overflow-x-auto">
      {ACTION_BTNS.map(({ icon: Icon, label }) => (
        <button
          key={label}
          onClick={() => handleActionBtn(label)}
          className={`flex flex-col items-center justify-center gap-1 min-w-[56px] px-3 py-2 rounded-xl transition-all relative min-h-[48px] ${
            label === "Discount" && showPromoMenu ? "bg-violet-800 text-white" : "bg-violet-600 text-white hover:bg-violet-700"
          }`}
        >
          <Icon className="w-5 h-5" />
          <span className="text-[10px] font-semibold whitespace-nowrap">{label}</span>
        </button>
      ))}

      {/* Promos Menu */}
      {showPromoMenu && activePromos.length > 0 && (
        <div className="absolute top-full right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-2xl z-40 min-w-80 p-3 max-h-64 overflow-y-auto">
          <div className="flex items-center justify-between mb-3 sticky top-0 bg-white pb-2 border-b border-gray-100">
            <span className="text-sm font-bold text-gray-900 flex items-center gap-1">
              <Zap className="w-4 h-4 text-amber-500" /> Active Promos
            </span>
            <button onClick={() => onShowPromoMenu(false)} className="text-gray-400 hover:text-gray-600">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-2">
            {activePromos.map(promo => {
              const promoValue = promo.type === "percentage" ? `${promo.value}%` : `AED ${promo.value.toFixed(2)}`;
              return (
                <button
                  key={promo.id}
                  onClick={() => {
                    const currentSubtotal = cartItems.reduce((s, i) => s + i.subtotal, 0);
                    let discountAmount = 0;
                    
                    if (promo.type === "percentage") {
                      discountAmount = (currentSubtotal * promo.value) / 100;
                      if (promo.max_discount_amount) {
                        discountAmount = Math.min(discountAmount, promo.max_discount_amount);
                      }
                    } else if (promo.type === "fixed_amount") {
                      discountAmount = promo.value;
                    }
                    
                    const discountPctNew = currentSubtotal > 0 ? (discountAmount / currentSubtotal) * 100 : 0;
                    onDiscountChange(discountPctNew);
                    onShowPromoMenu(false);
                  }}
                  className="w-full text-left px-4 py-3 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 hover:from-amber-100 hover:to-orange-100 border-2 border-transparent hover:border-amber-400 transition group"
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1">
                      <div className="font-bold text-gray-900 group-hover:text-amber-700 text-sm">{promo.name}</div>
                      {promo.description && <div className="text-xs text-gray-600 mt-0.5">{promo.description}</div>}
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-bold text-lg text-orange-600">{promoValue}</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Manual discount */}
      {showPromoMenu && activePromos.length === 0 && (
        <div className="flex items-center gap-2 ml-2">
          <input
            type="number"
            min="0"
            max="100"
            value={discountPct}
            onChange={e => onDiscountChange(Math.min(100, Math.max(0, Number(e.target.value))))}
            className="w-16 border border-gray-200 rounded-lg px-2 py-1.5 text-sm text-center focus:outline-none focus:border-violet-400"
            placeholder="%"
          />
          <span className="text-xs text-gray-500">% off</span>
        </div>
      )}
    </div>
  );
}