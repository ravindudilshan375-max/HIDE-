import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

export default function VariantSelector({ item, onSelect, onClose }) {
  const variants = item.variants || [];
  const [selectedVariant, setSelectedVariant] = useState(variants[0] || null);

  const handleSelect = () => {
    if (!selectedVariant) return;
    onSelect({
      menu_item_id: item.id,
      name: item.name,
      price: selectedVariant.price,
      quantity: 1,
      notes: "",
      modifiers: [],
      subtotal: selectedVariant.price,
      variant_name: selectedVariant.name,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-2xl w-full max-w-sm shadow-lg">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
          <h3 className="font-semibold text-gray-900">{item.name}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 py-4 space-y-3">
          {variants.length === 0 ? (
            <p className="text-sm text-gray-500">No variants available</p>
          ) : (
            variants.map((variant) => (
              <button
                key={variant.name}
                onClick={() => setSelectedVariant(variant)}
                className={`w-full flex items-center justify-between p-3 rounded-lg border-2 transition-all ${
                  selectedVariant?.name === variant.name
                    ? "border-violet-600 bg-violet-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <span className="font-medium text-gray-800">{variant.name}</span>
                <span className="font-bold text-violet-600">${variant.price.toFixed(2)}</span>
              </button>
            ))
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-200 flex gap-2">
          <Button onClick={onClose} variant="ghost" className="flex-1 rounded-xl border border-gray-200">
            Cancel
          </Button>
          <Button
            onClick={handleSelect}
            disabled={!selectedVariant}
            className="flex-1 bg-violet-600 hover:bg-violet-700 text-white rounded-xl font-semibold"
          >
            Add to Order
          </Button>
        </div>
      </div>
    </div>
  );
}