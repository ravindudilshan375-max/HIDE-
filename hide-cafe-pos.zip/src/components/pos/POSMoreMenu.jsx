import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import {
  X, BarChart2, Printer, CreditCard, Package, FileText,
  Plug, ClipboardList, RefreshCw, Wrench, HelpCircle,
  UserCheck, LogOut, DollarSign, ArrowDownCircle, ArrowUpCircle
} from "lucide-react";

function DrawerOpsModal({ onClose }) {
  const [type, setType] = useState("cash_in");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!amount || isNaN(parseFloat(amount))) return;
    setSaving(true);
    const user = await base44.auth.me().catch(() => null);
    await base44.entities.AuditLog.create({
      actor_email: user?.email || "pos",
      actor_name: user?.full_name || "POS",
      action: "other",
      entity_type: "Drawer",
      entity_name: type === "cash_in" ? "Cash In" : "Cash Out",
      description: `${type === "cash_in" ? "Cash In" : "Cash Out"}: AED ${parseFloat(amount).toFixed(2)}${note ? ` — ${note}` : ""}`,
      severity: "info",
    });
    setSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold">Drawer Operations</h3>
          <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setType("cash_in")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-sm transition ${type === "cash_in" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-600"}`}
          >
            <ArrowDownCircle className="w-4 h-4" /> Cash In
          </button>
          <button
            onClick={() => setType("cash_out")}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-sm transition ${type === "cash_out" ? "bg-red-600 text-white" : "bg-gray-100 text-gray-600"}`}
          >
            <ArrowUpCircle className="w-4 h-4" /> Cash Out
          </button>
        </div>
        <div>
          <label className="text-xs font-semibold text-gray-600 block mb-1">Amount (AED)</label>
          <input
            type="number"
            value={amount}
            onChange={e => setAmount(e.target.value)}
            placeholder="0.00"
            className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-violet-400"
          />
        </div>
        <div>
          <label className="text-xs font-semibold text-gray-600 block mb-1">Note (optional)</label>
          <input
            type="text"
            value={note}
            onChange={e => setNote(e.target.value)}
            placeholder="Add a note..."
            className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-violet-400"
          />
        </div>
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 border border-gray-200 rounded-xl py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition">Cancel</button>
          <button
            onClick={handleSubmit}
            disabled={saving || !amount}
            className="flex-1 bg-violet-600 hover:bg-violet-700 disabled:opacity-50 rounded-xl py-2.5 text-sm font-semibold text-white transition"
          >
            {saving ? "Saving..." : "Confirm"}
          </button>
        </div>
      </div>
    </div>
  );
}

const SECTIONS = [
  {
    title: "Operations",
    items: [
      { icon: BarChart2, label: "End of Day", page: "EndOfDay" },
      { icon: DollarSign, label: "Drawer Operations", action: "drawer" },
      { icon: Printer, label: "Print Bill", action: "printbill" },
    ]
  },
  {
    title: "Management",
    items: [
      { icon: Package, label: "Product Availability", page: "Menu" },
      { icon: FileText, label: "Reports", page: "Reports" },
      { icon: Plug, label: "Devices", page: "Devices" },
      { icon: ClipboardList, label: "Orders", page: "Orders" },
    ]
  },
  {
    title: "System",
    items: [
      { icon: RefreshCw, label: "Sync Data", action: "sync" },
      { icon: Wrench, label: "Diagnostics", action: "diagnostics" },
    ]
  },
  {
    title: "Account",
    items: [
      { icon: UserCheck, label: "Switch Staff", page: "POSLogin" },
      { icon: LogOut, label: "Log Out", action: "logout" },
    ]
  }
];

export default function POSMoreMenu({ onClose }) {
  const [showDrawer, setShowDrawer] = useState(false);
  const [syncMsg, setSyncMsg] = useState(null);

  const handleAction = async (action) => {
    if (action === "drawer") { setShowDrawer(true); return; }
    if (action === "logout") {
      localStorage.removeItem("pos_staff_session");
      window.location.href = createPageUrl("BranchLogin");
      return;
    }
    if (action === "sync") {
      setSyncMsg("Syncing...");
      await new Promise(r => setTimeout(r, 1200));
      setSyncMsg("Synced!");
      setTimeout(() => setSyncMsg(null), 2000);
      return;
    }
    if (action === "diagnostics") {
      alert("Network: OK\nDatabase: OK\nPrinter: Check device settings");
      return;
    }
    if (action === "printbill") {
      alert("Print Bill: Please use the Print button in the action bar.");
      return;
    }
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 p-4" onClick={onClose}>
        <div
          className="bg-white rounded-2xl w-full max-w-md max-h-[85vh] overflow-y-auto"
          onClick={e => e.stopPropagation()}
        >
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
            <h2 className="text-base font-bold text-gray-900">More Options</h2>
            <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
          </div>

          {syncMsg && (
            <div className="mx-4 mt-3 px-4 py-2 bg-green-50 border border-green-200 rounded-xl text-sm text-green-700 font-medium text-center">
              {syncMsg}
            </div>
          )}

          <div className="p-4 space-y-4">
            {SECTIONS.map(section => (
              <div key={section.title}>
                <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-2 px-1">{section.title}</p>
                <div className="grid grid-cols-2 gap-2">
                  {section.items.map(item => {
                    const Icon = item.icon;
                    const handleClick = () => {
                      if (item.page) {
                        window.location.href = createPageUrl(item.page);
                      } else if (item.action) {
                        handleAction(item.action);
                      }
                    };
                    return (
                      <button
                        key={item.label}
                        onClick={handleClick}
                        className="flex items-center gap-3 px-4 py-3 bg-gray-50 hover:bg-violet-50 hover:text-violet-700 rounded-xl text-sm font-semibold text-gray-700 transition text-left"
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showDrawer && <DrawerOpsModal onClose={() => { setShowDrawer(false); onClose(); }} />}
    </>
  );
}