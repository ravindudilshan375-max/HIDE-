import React from "react";
import { Plus } from "lucide-react";

export default function POSProductGrid({ items, onItemClick, onAddCustom }) {
  return (
    <div className="flex-1 overflow-y-auto p-4">
      {items.length === 0 ? (
        <div className="text-center text-gray-400 text-sm py-16">No items found</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-3">
          {items.map(item => {
            const stock = item.stock_quantity ?? null;
            const isTracked = stock !== null;
            const isLowStock = isTracked && stock > 0 && stock <= 10;
            const isOutOfStock = stock === 0;

            return (
              <button
                key={item.id}
                onClick={() => onItemClick(item)}
                disabled={isOutOfStock}
                className={`group bg-white border rounded-2xl p-3 text-left transition-all duration-150 active:scale-95 shadow-sm hover:shadow-md touch-manipulation ${
                  isOutOfStock
                    ? "opacity-50 cursor-not-allowed border-gray-200"
                    : isLowStock
                    ? "border-orange-400 hover:border-orange-500"
                    : "border-gray-200 hover:border-violet-400"
                }`}
              >
                {item.image_url ? (
                  <img src={item.image_url} alt={item.name} className="w-full h-24 object-cover rounded-xl mb-2" />
                ) : (
                  <div className="w-full h-24 rounded-xl bg-gradient-to-br from-violet-100 to-violet-50 flex items-center justify-center text-3xl mb-2">🍽</div>
                )}
                <p className="text-xs font-semibold text-gray-800 leading-tight">{item.name}</p>
                <p className={`text-sm font-bold mt-1 ${isOutOfStock ? "text-red-600" : isLowStock ? "text-orange-600" : "text-violet-600"}`}>
                  AED {item.base_price?.toFixed(2)}{item.variants?.length > 0 ? "+" : ""}
                </p>
                {isTracked && (
                  <p className={`text-[10px] font-medium mt-0.5 ${isOutOfStock ? "text-red-500" : isLowStock ? "text-orange-500" : "text-gray-400"}`}>
                    {isOutOfStock ? "Out of Stock" : isLowStock ? `${stock} left` : `${stock} in stock`}
                  </p>
                )}
                {item.modifiers?.length > 0 && !isOutOfStock && (
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mx-auto mt-1" />
                )}
              </button>
            );
          })}

          {/* Custom Item Button */}
          <button
            onClick={onAddCustom}
            className="bg-white border-2 border-dashed border-gray-300 rounded-2xl p-3 flex flex-col items-center justify-center text-center hover:border-violet-400 hover:bg-violet-50 transition-all active:scale-95 touch-manipulation"
          >
            <Plus className="w-8 h-8 text-gray-400 mb-1" />
            <p className="text-xs font-semibold text-gray-600">Custom Item</p>
          </button>
        </div>
      )}
    </div>
  );
}