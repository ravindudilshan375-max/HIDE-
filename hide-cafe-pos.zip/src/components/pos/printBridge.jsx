// Print Bridge — supports SUNMI JS Bridge (primary) and LAN/TCP fallback
import { base44 } from "@/api/base44Client";

/** Check if running on a SUNMI device with JS bridge available */
export function isSunmiAvailable() {
  return typeof window !== "undefined" && !!window.sunmi;
}

/** Format order lines for SUNMI text printing */
function formatSunmiReceipt(order) {
  const SEP = "--------------------------------\n";
  const pad = (left, right, width = 32) => {
    const gap = width - left.length - right.length;
    return left + " ".repeat(Math.max(1, gap)) + right + "\n";
  };

  let text = "";
  if (order.restaurant_name) text += `${order.restaurant_name}\n`;
  if (order.branch_name) text += `${order.branch_name}\n`;
  text += SEP;
  if (order.order_number) text += `Order: #${order.order_number}\n`;
  if (order.table_number) text += `Table: ${order.table_number}\n`;
  if (order.cashier_name) text += `Cashier: ${order.cashier_name}\n`;
  text += SEP;

  (order.items || []).forEach(item => {
    if (item.is_voided) return;
    const qty = item.quantity || 1;
    const price = ((item.price || 0) * qty).toFixed(2);
    text += pad(`${qty}x ${item.name}`, price);
    if (item.notes) text += `   * ${item.notes}\n`;
  });

  text += SEP;
  text += pad("Subtotal", `${(order.subtotal || 0).toFixed(2)}`);
  if (order.discount > 0) text += pad("Discount", `-${(order.discount || 0).toFixed(2)}`);
  if (order.tax > 0) text += pad(`Tax`, `${(order.tax || 0).toFixed(2)}`);
  text += pad("TOTAL", `${(order.total || 0).toFixed(2)}`);
  if (order.payment_method) text += pad("Payment", order.payment_method);
  text += SEP;
  text += "      Thank You!\n\n\n";
  return text;
}

/** Print via SUNMI JS Bridge */
function printViaSunmi(text) {
  window.sunmi.printText(text);
  return { success: true, via: "sunmi" };
}

/**
 * Print a customer receipt — tries SUNMI bridge first, then LAN.
 */
export async function printReceipt(order, printer) {
  if (isSunmiAvailable()) {
    return printViaSunmi(formatSunmiReceipt(order));
  }
  const res = await base44.functions.invoke("printBill", {
    order,
    printerIp: printer?.ip,
    printerPort: printer?.port || "9100",
    connectionType: "ethernet",
  });
  if (!res.data?.success) throw new Error(res.data?.error || "Print failed");
  return { success: true, via: "lan" };
}

/**
 * Print a kitchen ticket — tries SUNMI bridge first, then LAN.
 */
export async function printKitchenTicket(payload, printer) {
  if (isSunmiAvailable()) {
    const order = payload.order || payload;
    const SEP = "--------------------------------\n";
    let text = `*** KITCHEN TICKET ***\n${SEP}`;
    if (order.order_number) text += `Order: #${order.order_number}\n`;
    if (order.table_number) text += `Table: ${order.table_number}\n`;
    if (order.type) text += `Type: ${order.type}\n`;
    text += SEP;
    (order.items || []).forEach(item => {
      if (!item.is_voided) text += `${item.quantity || 1}x ${item.name}\n`;
      if (item.notes) text += `   * ${item.notes}\n`;
    });
    text += `${SEP}\n\n`;
    return printViaSunmi(text);
  }
  const res = await base44.functions.invoke("sendToKitchen", {
    ...payload,
    printerIp: printer?.ip,
    printerPort: printer?.port || "9100",
    stationName: printer?.stationName || printer?.name,
  });
  if (!res.data?.success) throw new Error(res.data?.error || "Kitchen print failed");
  return { success: true, via: "lan" };
}

/**
 * Send a test print job.
 */
export async function testPrinter(printer) {
  if (isSunmiAvailable()) {
    return printViaSunmi("*** DENDAX POS TEST ***\nPrinter OK!\n\n\n");
  }
  const res = await base44.functions.invoke("printBill", {
    order: {
      order_number: "TEST-001",
      customer_name: "Test Print",
      items: [{ name: "Test Item", quantity: 1, price: 10, subtotal: 10 }],
      subtotal: 10,
      tax: 0.5,
      total: 10.5,
      restaurant_name: "DENDAX POS",
    },
    printerIp: printer?.ip,
    printerPort: printer?.port || "9100",
    connectionType: "ethernet",
  });
  if (!res.data?.success) throw new Error(res.data?.error || "Test print failed");
  return { success: true, via: "lan" };
}

// Legacy exports
export function checkBridgeAvailable() { return Promise.resolve(isSunmiAvailable()); }
export function getBridgeCached() { return isSunmiAvailable(); }