import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, Search, Printer } from "lucide-react";

export default function ReprintModal({ onClose }) {
  const [orders, setOrders] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Order.list("-created_date", 100).then(data => {
      setOrders(data);
      setLoading(false);
    });
  }, []);

  const printOrder = (order) => {
    const win = window.open("", "_blank");
    const rows = (order.items || []).map(i => `
      <tr>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;">${i.name}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:center;">${i.quantity}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right;">AED ${(i.price || 0).toFixed(2)}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right;">AED ${(i.subtotal || i.price * i.quantity || 0).toFixed(2)}</td>
      </tr>`).join("");

    win.document.write(`
      <!DOCTYPE html><html><head><title>Bill - ${order.order_number || order.id.slice(-6)}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 30px; color: #333; max-width: 500px; margin: 0 auto; }
        h2 { margin: 0 0 4px; font-size: 20px; }
        .sub { color: #888; font-size: 12px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        thead tr { background: #f5f5fa; }
        thead th { padding: 8px; text-align: left; font-size: 11px; color: #888; text-transform: uppercase; }
        thead th:nth-child(2),thead th:nth-child(3),thead th:nth-child(4) { text-align: center; }
        thead th:last-child { text-align: right; }
        .total-row td { padding: 10px 8px; font-weight: 700; border-top: 2px solid #333; }
        .total-row td:last-child { text-align: right; }
        .info { display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 6px; }
        .badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; background: #ede9fe; color: #5B2CC0; }
        @media print { button { display: none; } }
      </style></head><body>
      <h2>Order Receipt</h2>
      <p class="sub">REPRINT</p>
      <div class="info"><span><b>Order #</b> ${order.order_number || order.id.slice(-6)}</span><span class="badge">${order.status}</span></div>
      <div class="info"><span><b>Date:</b> ${new Date(order.created_date).toLocaleString()}</span></div>
      <div class="info"><span><b>Type:</b> ${order.type}</span>${order.table_number ? `<span><b>Table:</b> ${order.table_number}</span>` : ""}</div>
      ${order.customer_name ? `<div class="info"><span><b>Customer:</b> ${order.customer_name}</span></div>` : ""}
      <br/>
      <table>
        <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
        <tbody>${rows || `<tr><td colspan="4" style="padding:12px;text-align:center;color:#aaa;">No items</td></tr>`}</tbody>
        <tfoot>
          ${order.discount > 0 ? `<tr><td colspan="3" style="padding:6px 8px;text-align:right;color:#16a34a;">Discount</td><td style="padding:6px 8px;text-align:right;color:#16a34a;">−AED ${(order.discount || 0).toFixed(2)}</td></tr>` : ""}
          <tr><td colspan="3" style="padding:6px 8px;text-align:right;color:#888;">Tax</td><td style="padding:6px 8px;text-align:right;color:#888;">AED ${(order.tax || 0).toFixed(2)}</td></tr>
          <tr class="total-row"><td colspan="3">TOTAL</td><td>AED ${(order.total || 0).toFixed(2)}</td></tr>
        </tfoot>
      </table>
      <br/>
      <button onclick="window.print()" style="padding:10px 24px;background:#5B2CC0;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;">🖨 Print</button>
      </body></html>`);
    win.document.close();
  };

  const filtered = orders.filter(o => {
    const q = search.toLowerCase();
    return (
      (o.order_number || "").toLowerCase().includes(q) ||
      (o.customer_name || "").toLowerCase().includes(q) ||
      (o.table_number || "").toString().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h3 className="font-bold text-gray-900 text-lg">Reprint Bill</h3>
          <button onClick={onClose} className="text-gray-300 hover:text-gray-600 transition"><X className="w-5 h-5" /></button>
        </div>

        {/* Search */}
        <div className="px-4 py-3 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              autoFocus
              placeholder="Search by order #, customer, table..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full border border-gray-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-violet-400"
            />
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
          {loading ? (
            <div className="py-16 text-center text-gray-300 text-sm">Loading orders...</div>
          ) : filtered.length === 0 ? (
            <div className="py-16 text-center text-gray-300 text-sm">No orders found</div>
          ) : (
            filtered.map(order => (
              <div key={order.id} className="flex items-center justify-between px-5 py-3 hover:bg-gray-50 transition">
                <div>
                  <p className="text-sm font-semibold text-gray-800">#{order.order_number || order.id.slice(-6)}</p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {new Date(order.created_date).toLocaleString()} · {order.type}
                    {order.customer_name ? ` · ${order.customer_name}` : ""}
                    {order.table_number ? ` · Table ${order.table_number}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-gray-700">AED {(order.total || 0).toFixed(2)}</span>
                  <button
                    onClick={() => printOrder(order)}
                    className="flex items-center gap-1.5 bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition"
                  >
                    <Printer className="w-3.5 h-3.5" /> Print
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}