import React, { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { RotateCcw, Check, PenLine } from "lucide-react";

export default function SignatureModal({ order, triggerReason, onComplete, onSkip }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);
  const [signedByName, setSignedByName] = useState("");
  const lastPos = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#1a1a2e";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
  }, []);

  const getPos = (e, canvas) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if (e.touches) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const startDraw = (e) => {
    e.preventDefault();
    setIsDrawing(true);
    const canvas = canvasRef.current;
    lastPos.current = getPos(e, canvas);
  };

  const draw = (e) => {
    e.preventDefault();
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const pos = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    lastPos.current = pos;
    setHasSignature(true);
  };

  const stopDraw = (e) => {
    e.preventDefault();
    setIsDrawing(false);
    lastPos.current = null;
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  const confirm = () => {
    const canvas = canvasRef.current;
    const dataUrl = canvas.toDataURL("image/png");
    onComplete({ signatureImage: dataUrl, signedByName: signedByName || "Customer" });
  };

  const REASON_LABELS = {
    foc: "Free of Charge Order",
    high_discount: "High Discount Applied",
    refund: "Refund / Return",
    manual: "Manual Signature Request",
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[60] p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-violet-600 to-purple-700 px-6 py-4 text-white">
          <div className="flex items-center gap-2 mb-1">
            <PenLine className="w-5 h-5" />
            <h2 className="text-lg font-bold">Digital Invoice Signature</h2>
          </div>
          <p className="text-violet-200 text-sm">{REASON_LABELS[triggerReason] || "Signature Required"}</p>
        </div>

        {/* Order Summary */}
        <div className="px-6 pt-4 pb-2">
          <div className="bg-gray-50 rounded-2xl px-4 py-3 text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-gray-500">Order</span>
              <span className="font-semibold text-gray-800">{order.order_number}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Cashier</span>
              <span className="font-medium text-gray-700">{order.cashier_name}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-red-600">
                <span>Discount</span>
                <span className="font-medium">−AED {order.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-gray-200 pt-1.5 mt-1.5">
              <span className="font-bold text-gray-800">Total</span>
              <span className="font-bold text-violet-700 text-base">AED {order.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Signer name */}
        <div className="px-6 py-2">
          <input
            type="text"
            placeholder="Signer name (optional)"
            value={signedByName}
            onChange={e => setSignedByName(e.target.value)}
            className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-400"
          />
        </div>

        {/* Signature Pad */}
        <div className="px-6 py-2">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Sign Below</p>
            <button onClick={clearCanvas} className="flex items-center gap-1 text-xs text-gray-400 hover:text-red-500 transition">
              <RotateCcw className="w-3 h-3" /> Clear
            </button>
          </div>
          <div className="border-2 border-dashed border-gray-300 rounded-2xl overflow-hidden bg-white touch-none">
            <canvas
              ref={canvasRef}
              width={600}
              height={180}
              className="w-full h-44 cursor-crosshair"
              onMouseDown={startDraw}
              onMouseMove={draw}
              onMouseUp={stopDraw}
              onMouseLeave={stopDraw}
              onTouchStart={startDraw}
              onTouchMove={draw}
              onTouchEnd={stopDraw}
            />
          </div>
          {!hasSignature && (
            <p className="text-center text-xs text-gray-400 mt-1.5">✍️ Draw signature using finger or stylus</p>
          )}
        </div>

        {/* Actions */}
        <div className="px-6 py-4 flex gap-3">
          {onSkip && (
            <Button variant="outline" onClick={onSkip} className="flex-1 rounded-xl h-11 text-gray-500">
              Skip
            </Button>
          )}
          <Button
            onClick={confirm}
            disabled={!hasSignature}
            className="flex-[2] bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl h-11 gap-2"
          >
            <Check className="w-4 h-4" /> Confirm Signature
          </Button>
        </div>
      </div>
    </div>
  );
}