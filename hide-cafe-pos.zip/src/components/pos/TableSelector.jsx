import React from "react";

export default function TableSelector({ tables, selectedTable, onSelect }) {
  return (
    <div className="px-4 pb-2">
      <div className="flex items-center gap-2 overflow-x-auto py-2 scrollbar-none">
        <span className="shrink-0 text-xs text-white/30 font-medium">Tables:</span>
        {tables.length === 0 && (
          <span className="text-xs text-white/20 italic">No tables set up yet — go to Tables page</span>
        )}
        {tables.map(table => (
          <button
            key={table.id}
            onClick={() => onSelect(table.status === "available" || selectedTable?.id === table.id ? table : null)}
            className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium border transition-all ${
              selectedTable?.id === table.id
                ? "bg-amber-400 border-amber-400 text-black"
                : table.status === "occupied"
                ? "bg-red-500/10 border-red-500/30 text-red-400 cursor-not-allowed"
                : table.status === "reserved"
                ? "bg-purple-500/10 border-purple-500/30 text-purple-400"
                : "bg-white/5 border-white/10 text-white/60 hover:bg-white/10"
            }`}
          >
            T{table.number}
            <span className="ml-1 opacity-60">
              {table.status === "occupied" ? "●" : table.status === "reserved" ? "◆" : "○"}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}