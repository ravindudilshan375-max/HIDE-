import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, Search, Printer, Ticket, Plus } from "lucide-react";

export default function OpenTicketsModal({ onClose, onLoadTicket, branchId }) {
  const [tickets, setTickets] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const load = () => {
    base44.entities.Ticket.filter({ status: "open" }).then(data => {
      setTickets(data.sort((a, b) => new Date(b.created_date) - new Date(a.created_date)));
      setLoading(false);
    });
  };

  useEffect(() => { load(); }, []);

  const closeTicket = async (ticket, e) => {
    e.stopPropagation();
    await base44.entities.Ticket.update(ticket.id, { status: "closed" });
    setTickets(prev => prev.filter(t => t.id !== ticket.id));
  };

  const printTicket = (ticket, e) => {
    e.stopPropagation();
    const win = window.open("", "_blank");
    const rows = (ticket.items || []).map(i => `
      <tr>
        <td style="padding:6px 0;border-bottom:1px solid #eee;">${i.name}</td>
        <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:center;">${i.quantity}</td>
        <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;">AED ${(i.subtotal || i.price * i.quantity || 0).toFixed(2)}</td>
      </tr>`).join("");
    win.document.write(`
      <!DOCTYPE html><html><head><title>Ticket - ${ticket.customer_name || "Guest"}</title>
      <style>body{font-family:Arial,sans-serif;padding:30px;max-width:400px;margin:0 auto}h2{margin:0 0 4px}hr{border:none;border-top:1px solid #ccc}table{width:100%;border-collapse:collapse;font-size:13px}.total{font-weight:700;font-size:15px;text-align:right;margin-top:10px}@media print{button{display:none}}</style>
      </head><body>
      <h2>Open Ticket</h2>
      <p style="color:#888;font-size:12px;">Customer: ${ticket.customer_name || "Guest"}</p>
      <hr/><br/>
      <table><thead><tr><th style="text-align:left;font-size:11px;color:#888;">ITEM</th><th style="text-align:center;font-size:11px;color:#888;">QTY</th><th style="text-align:right;font-size:11px;color:#888;">TOTAL</th></tr></thead>
      <tbody>${rows}</tbody></table><br/><hr/>
      <div class="total">Total: AED ${(ticket.total || 0).toFixed(2)}</div><br/>
      <button onclick="window.print()" style="padding:10px 24px;background:#5B2CC0;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;">🖨 Print Bill</button>
      </body></html>`);
    win.document.close();
  };

  const filtered = tickets.filter(t =>
    !search || (t.customer_name || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl flex flex-col max-h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <Ticket className="w-5 h-5 text-violet-600" />
            <h3 className="font-bold text-gray-900 text-lg">Open Tickets</h3>
            {tickets.length > 0 && (
              <span className="bg-violet-100 text-violet-700 text-xs font-bold px-2 py-0.5 rounded-full">{tickets.length}</span>
            )}
          </div>
          <button onClick={onClose} className="text-gray-300 hover:text-gray-600 transition"><X className="w-5 h-5" /></button>
        </div>

        {/* Search */}
        <div className="px-4 py-3 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              autoFocus
              placeholder="Search tickets by customer name..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full border border-gray-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-violet-400"
            />
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
          {loading ? (
            <div className="py-16 text-center text-gray-300 text-sm">Loading tickets...</div>
          ) : filtered.length === 0 ? (
            <div className="py-16 text-center text-gray-300 text-sm">
              <Ticket className="w-10 h-10 mx-auto mb-3 text-gray-200" />
              <p>No open tickets</p>
              <p className="text-xs mt-1">Save a cart as a ticket from the POS</p>
            </div>
          ) : (
            filtered.map(ticket => (
              <div
                key={ticket.id}
                onClick={() => { onLoadTicket(ticket); onClose(); }}
                className="flex items-center justify-between px-5 py-3.5 hover:bg-violet-50/40 transition cursor-pointer group"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-800 group-hover:text-violet-700 transition">
                    {ticket.customer_name || "Guest"}
                  </p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {(ticket.items || []).length} item(s) · {ticket.order_type}
                    {ticket.table_number ? ` · Table ${ticket.table_number}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2 ml-3">
                  <span className="text-sm font-bold text-gray-700">AED {(ticket.total || 0).toFixed(2)}</span>
                  <button
                    onClick={(e) => printTicket(ticket, e)}
                    title="Print bill"
                    className="p-1.5 rounded-lg hover:bg-violet-100 text-gray-400 hover:text-violet-600 transition"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => closeTicket(ticket, e)}
                    title="Close ticket"
                    className="p-1.5 rounded-lg hover:bg-red-100 text-gray-300 hover:text-red-500 transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer hint */}
        <div className="px-5 py-3 border-t border-gray-100 text-xs text-gray-400 text-center">
          Tap a ticket to load it back into the POS cart
        </div>
      </div>
    </div>
  );
}