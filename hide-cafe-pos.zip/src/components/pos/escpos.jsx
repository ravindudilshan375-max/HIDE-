// ESC/POS content generators (client-side, used by PrintBridge)

const getWidth = (paperSize) => paperSize === "80mm" ? 48 : 32;

const pad = (left, right, width) => {
  const w = width || 48;
  const space = w - left.length - right.length;
  return left + ' '.repeat(Math.max(1, space)) + right;
};

export function generateReceipt(order, printerOptions = {}) {
  const W = getWidth(printerOptions.paperSize);
  const divider = '='.repeat(W);
  const subdiv = '-'.repeat(W);
  const autoCut = printerOptions.autoCut !== false;
  const lines = [];
  const now = new Date();

  lines.push('\x1B\x40'); // Reset
  lines.push('\x1B\x61\x01'); // Center
  lines.push('\x1B\x45\x01\x1B\x21\x10');
  lines.push((order.restaurant_name || 'RESTAURANT').toUpperCase() + '\n');
  lines.push('\x1B\x21\x00\x1B\x45\x00');
  if (order.branch_name) lines.push(order.branch_name + '\n');
  lines.push(`${now.toLocaleDateString('en-AE')} ${now.toLocaleTimeString('en-AE', { hour: '2-digit', minute: '2-digit' })}\n`);
  lines.push(divider + '\n');
  lines.push('\x1B\x61\x00');

  if (order.order_number) lines.push(`Order #: ${order.order_number}\n`);
  if (order.table_number) lines.push(`Table:   ${order.table_number}\n`);
  if (order.customer_name) lines.push(`Customer: ${order.customer_name}\n`);
  if (order.cashier_name) lines.push(`Cashier: ${order.cashier_name}\n`);
  lines.push(subdiv + '\n');

  lines.push('\x1B\x45\x01' + pad('Item', 'Total', W) + '\n\x1B\x45\x00');

  (order.items || []).forEach(item => {
    const nameLen = Math.floor(W * 0.55);
    const name = (item.name || '').substring(0, nameLen);
    const qty = `x${item.quantity || 1}`;
    const price = `AED ${((item.subtotal ?? (item.price * item.quantity)) || 0).toFixed(2)}`;
    lines.push(`${name.padEnd(nameLen)} ${qty.padStart(2)} ${price}\n`);
    if (item.modifiers?.length > 0) lines.push(`  + ${item.modifiers.map(m => m.name).join(', ')}\n`);
    if (item.notes) lines.push(`  > ${item.notes}\n`);
  });

  lines.push(divider + '\n');
  const subtotal = (order.subtotal || 0).toFixed(2);
  const tax = (order.tax || 0).toFixed(2);
  const discount = (order.discount || 0).toFixed(2);
  const total = (order.total || 0).toFixed(2);

  lines.push(pad('Subtotal:', `AED ${subtotal}`, W) + '\n');
  if (parseFloat(discount) > 0) lines.push(pad('Discount:', `-AED ${discount}`, W) + '\n');
  lines.push(pad('VAT:', `AED ${tax}`, W) + '\n');
  lines.push(subdiv + '\n');
  lines.push('\x1B\x45\x01' + pad('TOTAL:', `AED ${total}`, W) + '\n\x1B\x45\x00');
  if (order.payment_method) {
    const method = order.payment_method.charAt(0).toUpperCase() + order.payment_method.slice(1);
    lines.push(pad('Payment:', method, W) + '\n');
  }

  lines.push('\n\x1B\x61\x01');
  lines.push('Thank you for your visit!\n');
  lines.push('* '.repeat(Math.floor(W / 2)) + '\n');
  lines.push('\n\n');
  if (autoCut) lines.push('\x1D\x56\x00'); // Auto cut

  return lines.join('');
}

export function generateKitchenTicket({ items, orderType, orderNumber, tableNumber, customerName, stationName }, printerOptions = {}) {
  const W = getWidth(printerOptions.paperSize);
  const divider = '*'.repeat(W);
  const autoCut = printerOptions.autoCut !== false;
  const lines = [];
  const now = new Date();

  lines.push('\x1B\x40');
  lines.push('\x1B\x61\x01');
  lines.push(divider + '\n');
  lines.push('\x1B\x45\x01\x1B\x21\x10');
  lines.push(`${(stationName || 'KITCHEN').toUpperCase()}\n`);
  lines.push('\x1B\x21\x00\x1B\x45\x00');
  lines.push(divider + '\n');
  lines.push(`${now.toLocaleDateString()} ${now.toLocaleTimeString('en-AE', { hour: '2-digit', minute: '2-digit' })}\n`);
  if (orderNumber) lines.push(`Order #: ${orderNumber}\n`);
  if (orderType === 'dine-in' && tableNumber) lines.push(`Table: ${tableNumber}\n`);
  if (customerName) lines.push(`Customer: ${customerName}\n`);
  lines.push('='.repeat(W) + '\n');
  lines.push('\x1B\x61\x00');

  (items || []).forEach(item => {
    lines.push(`\x1B\x45\x01\x1B\x21\x10${item.quantity}x ${item.name}\x1B\x21\x00\x1B\x45\x00\n`);
    if (item.modifiers?.length > 0) lines.push(`   + ${item.modifiers.map(m => m.name).join(', ')}\n`);
    if (item.notes) lines.push(`   > ${item.notes}\n`);
  });

  lines.push('='.repeat(W) + '\n');
  lines.push(`Time: ${now.toLocaleTimeString('en-AE', { hour: '2-digit', minute: '2-digit' })}\n`);
  lines.push(divider + '\n');
  lines.push('\n\n\n');
  if (autoCut) lines.push('\x1D\x56\x00');

  return lines.join('');
}