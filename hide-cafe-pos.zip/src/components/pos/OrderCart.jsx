import React, { useState } from "react";
import { Minus, Plus, Trash2, ShoppingCart, ChefHat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CustomerPicker from "@/components/pos/CustomerPicker";
import { base44 } from "@/api/base44Client";
import AISuggestions from "@/components/pos/AISuggestions";

export default function OrderCart({
  items, orderType, selectedTable, customerName, onCustomerNameChange,
  loyaltyCustomer, onLoyaltyCustomerChange,
  onUpdateItem, subtotal, tax, total, onCheckout, onClear, menuItems = []
}) {
  const [sendingToKitchen, setSendingToKitchen] = useState(false);
  const [kitchenMsg, setKitchenMsg] = useState(null);

  const sendToKitchen = async () => {
    setSendingToKitchen(true);
    setKitchenMsg(null);

    // Always create an Order record so the Kitchen Display picks it up
    const orderNumber = `KDS-${Date.now().toString().slice(-6)}`;
    await base44.entities.Order.create({
      order_number: orderNumber,
      type: orderType,
      table_number: selectedTable?.number || null,
      customer_name: loyaltyCustomer?.name || customerName || null,
      items,
      status: "pending",
      subtotal: items.reduce((s, i) => s + i.subtotal, 0),
    });

    // Also attempt to print if a kitchen printer is configured
    const printers = JSON.parse(localStorage.getItem("pos_printers") || "[]");
    const kitchenPrinter = printers.find(p => p.type === "kitchen");
    if (kitchenPrinter) {
      try {
        await base44.functions.invoke("sendToKitchen", {
          items,
          orderType,
          tableNumber: selectedTable?.number || null,
          customerName: loyaltyCustomer?.name || customerName || null,
          printerIp: kitchenPrinter.ip,
          printerPort: kitchenPrinter.port,
        });
      } catch (_) {
        // printer failure is non-blocking; order is already in KDS
      }
    }

    setKitchenMsg({ type: "success", text: "Order sent to kitchen!" });
    setSendingToKitchen(false);
    setTimeout(() => setKitchenMsg(null), 3000);
  };

  return (
    <div className="w-80 xl:w-96 flex flex-col bg-[#16161d] border-l border-white/10">
      {/* Cart Header */}
      <div className="px-5 py-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-sm">Current Order</span>
          </div>
          {items.length > 0 && (
            <button onClick={onClear} className="text-white/30 hover:text-red-400 transition text-xs">
              Clear
            </button>
          )}
        </div>
        <div className="mt-3 flex gap-2">
          {orderType === "dine-in" && selectedTable && (
            <span className="px-2.5 py-1 bg-amber-400/10 border border-amber-400/30 rounded-lg text-xs text-amber-400 font-medium">
              Table {selectedTable.number}
            </span>
          )}
          {orderType === "takeaway" && (
            <span className="px-2.5 py-1 bg-blue-400/10 border border-blue-400/30 rounded-lg text-xs text-blue-400 font-medium">
              Takeaway
            </span>
          )}
        </div>
        {orderType === "takeaway" && (
          <Input
            placeholder="Customer name (optional)"
            value={customerName}
            onChange={e => onCustomerNameChange(e.target.value)}
            className="mt-2 bg-white/5 border-white/10 text-white text-xs placeholder:text-white/30 h-8 rounded-lg"
          />
        )}
        <div className="mt-2">
          <CustomerPicker selectedCustomer={loyaltyCustomer} onSelect={onLoyaltyCustomerChange} />
        </div>
      </div>

      {/* Items */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
        {items.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-white/20 gap-2 py-16">
            <ShoppingCart className="w-10 h-10" />
            <span className="text-sm">Add items to start an order</span>
          </div>
        )}
        {items.map(item => (
          <div key={item.menu_item_id} className="bg-white/5 rounded-xl p-3">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <span className="text-sm font-medium text-white leading-tight">{item.name}</span>
                {item.isCustom && <span className="ml-1.5 text-xs text-violet-400 bg-violet-400/10 px-1.5 py-0.5 rounded-md">custom</span>}
                {item.modifiers?.length > 0 && (
                  <div className="mt-1 flex flex-wrap gap-1">
                    {item.modifiers.map((m, i) => (
                      <span key={i} className="text-xs bg-amber-400/10 text-amber-300 px-1.5 py-0.5 rounded-md">
                        +{m.name}{m.price > 0 ? ` $${m.price.toFixed(2)}` : ""}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <button
                onClick={() => onUpdateItem(item.menu_item_id, { quantity: 0 })}
                className="text-white/20 hover:text-red-400 transition mt-0.5 shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onUpdateItem(item.menu_item_id, { quantity: item.quantity - 1 })}
                  className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="text-sm w-5 text-center font-medium">{item.quantity}</span>
                <button
                  onClick={() => onUpdateItem(item.menu_item_id, { quantity: item.quantity + 1 })}
                  className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
              <span className="text-amber-400 font-semibold text-sm">${item.subtotal.toFixed(2)}</span>
            </div>
            <input
              placeholder="Note (e.g. no onions)"
              value={item.notes || ""}
              onChange={e => onUpdateItem(item.menu_item_id, { notes: e.target.value, quantity: item.quantity })}
              className="mt-2 w-full bg-transparent border-b border-white/10 text-xs text-white/50 placeholder:text-white/20 py-1 focus:outline-none focus:border-amber-400/50"
            />
          </div>
        ))}
      </div>

      {/* AI Suggestions */}
      <AISuggestions cartItems={items} menuItems={menuItems} onAdd={item => onUpdateItem ? (() => {
        // proxy through parent add - we dispatch a custom event the POS page listens to
        window.dispatchEvent(new CustomEvent("pos:addItem", { detail: item }));
      })() : null} />

      {/* Totals + Checkout */}
      <div className="px-5 py-4 border-t border-white/10 space-y-3">
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between text-white/50">
            <span>Subtotal</span><span>${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-white/50">
            <span>Tax (10%)</span><span>${tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-white font-bold text-base pt-1 border-t border-white/10">
            <span>Total</span><span className="text-amber-400">${total.toFixed(2)}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={sendToKitchen}
            disabled={items.length === 0 || sendingToKitchen}
            variant="outline"
            className="flex-1 border-white/10 bg-white/5 hover:bg-white/10 text-white font-semibold rounded-xl h-12 text-sm gap-2 disabled:opacity-30"
          >
            <ChefHat className="w-4 h-4" />
            {sendingToKitchen ? "Sending..." : "Kitchen"}
          </Button>
          <Button
            onClick={onCheckout}
            disabled={items.length === 0 || (orderType === "dine-in" && !selectedTable)}
            className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-12 text-sm transition-all disabled:opacity-30"
          >
            Checkout
          </Button>
        </div>
        {kitchenMsg && (
          <p className={`text-xs text-center font-medium ${kitchenMsg.type === "success" ? "text-green-400" : "text-red-400"}`}>
            {kitchenMsg.text}
          </p>
        )}
        {orderType === "dine-in" && !selectedTable && items.length > 0 && (
          <p className="text-xs text-center text-red-400/70">Select a table to continue</p>
        )}
      </div>
    </div>
  );
}