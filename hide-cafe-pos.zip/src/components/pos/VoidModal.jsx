import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, ShieldAlert, KeyRound, Trash2, CheckCircle2 } from "lucide-react";

export default function VoidModal({ mode, item, voidReasons, onConfirm, onClose }) {
  const session = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "{}"); } catch { return {}; } })();
  const needsPin = mode === "order" && session.role_type === "cashier";

  const [step, setStep] = useState(needsPin ? "pin" : "reason");
  const [pin, setPin] = useState("");
  const [reason, setReason] = useState("");
  const [pinError, setPinError] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [authorizedStaff, setAuthorizedStaff] = useState(null);

  const handlePinVerify = async () => {
    if (pin.length < 4) return;
    setVerifying(true);
    setPinError("");
    try {
      const branchId = localStorage.getItem("selectedBranchId");
      const res = await base44.functions.invoke("verifyStaffPin", { pin, branchId });
      const staff = res?.data?.staff;
      if (staff && (staff.role_type === "manager" || staff.role_type === "admin")) {
        setAuthorizedStaff(staff);
        setStep("reason");
      } else if (staff) {
        setPinError("Only managers or admins can authorize this void.");
      } else {
        setPinError("Invalid PIN. Please try again.");
      }
    } catch {
      setPinError("Verification failed. Please try again.");
    }
    setVerifying(false);
  };

  const handleConfirm = () => {
    if (!reason) return;
    onConfirm({ reason, authorizedStaff: authorizedStaff || (needsPin ? null : { name: session.name }) });
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-6 max-w-sm w-full space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-500" />
            <h3 className="text-lg font-bold text-gray-900">
              {mode === "item" ? "Void Item" : "Void Order"}
            </h3>
          </div>
          <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
        </div>

        {mode === "item" && item && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3">
            <p className="text-sm font-semibold text-red-700">{item.quantity} × {item.name}</p>
            <p className="text-xs text-red-500 mt-0.5">AED {item.subtotal?.toFixed(2)}</p>
          </div>
        )}

        {step === "pin" && (
          <>
            <div className="text-center">
              <KeyRound className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600 font-medium">Manager PIN required to void order</p>
            </div>
            <div className="flex justify-center gap-3">
              {[0, 1, 2, 3].map(i => (
                <div key={i} className={`w-10 h-10 rounded-full border-2 flex items-center justify-center text-lg font-bold ${pin.length > i ? "border-violet-600 bg-violet-600 text-white" : "border-gray-300"}`}>
                  {pin.length > i ? "●" : ""}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, "", 0, "⌫"].map((k, i) => (
                <button
                  key={i}
                  onClick={() => {
                    if (k === "⌫") setPin(p => p.slice(0, -1));
                    else if (k !== "") setPin(p => p.length < 6 ? p + k : p);
                  }}
                  className={`h-12 rounded-xl font-semibold text-lg transition ${k === "" ? "invisible" : "bg-gray-100 hover:bg-gray-200 text-gray-800 active:scale-95"}`}
                >
                  {k}
                </button>
              ))}
            </div>
            {pinError && <p className="text-xs text-red-600 text-center">{pinError}</p>}
            <button
              onClick={handlePinVerify}
              disabled={pin.length < 4 || verifying}
              className="w-full bg-violet-600 hover:bg-violet-700 disabled:opacity-50 text-white font-bold rounded-xl py-3 transition"
            >
              {verifying ? "Verifying..." : "Verify PIN"}
            </button>
          </>
        )}

        {step === "reason" && (
          <>
            {authorizedStaff && (
              <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-2">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <span className="text-sm text-green-700 font-medium">Authorized: {authorizedStaff.name}</span>
              </div>
            )}
            <div>
              <label className="text-xs font-semibold text-gray-600 block mb-2">Select Reason *</label>
              {voidReasons.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {voidReasons.map(r => (
                    <button
                      key={r.id}
                      onClick={() => setReason(r.name)}
                      className={`w-full text-left px-3 py-2.5 rounded-xl border-2 transition text-sm ${reason === r.name ? "border-red-500 bg-red-50 text-red-700 font-semibold" : "border-gray-200 hover:border-red-300 text-gray-700"}`}
                    >
                      {r.name}
                    </button>
                  ))}
                </div>
              ) : (
                <input
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                  placeholder="Enter reason..."
                  className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-red-400"
                />
              )}
            </div>
            <div className="flex gap-3">
              <button onClick={onClose} className="flex-1 border border-gray-200 rounded-xl py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition">Cancel</button>
              <button
                onClick={handleConfirm}
                disabled={!reason}
                className="flex-1 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold rounded-xl py-2.5 text-sm transition flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" /> Confirm Void
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}