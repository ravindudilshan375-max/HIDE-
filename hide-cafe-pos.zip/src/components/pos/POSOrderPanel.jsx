import React from "react";
import { Plus, Minus, Trash2, UserPlus, UtensilsCrossed, ShoppingBag, ChefHat, Ticket } from "lucide-react";
import CustomerPicker from "./CustomerPicker";

export default function POSOrderPanel({
  cartItems,
  orderType,
  selectedTable,
  tables,
  loyaltyCustomer,
  customerName,
  discountPct,
  subtotal,
  discountAmt,
  tax,
  total,
  taxGroups,
  selectedTaxGroup,
  activeStaff,
  sendingToKitchen,
  kitchenMsg,
  selectedCartItem,
  onOrderTypeChange,
  onTableChange,
  onCustomerClick,
  onCustomerSelect,
  showCustomerPicker,
  onCartItemClick,
  onCartItemUpdate,
  onSaveTicket,
  onSendToKitchen,
  onCheckout,
  onTaxGroupChange,
}) {
  const now = new Date();
  const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString("en-US", { weekday: "short", day: "numeric", month: "short" });

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-100">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-xs text-gray-400">{timeStr} · {dateStr}</div>
            <div className="text-lg font-bold text-violet-700 mt-1">
              {orderType === "dine-in" && selectedTable ? `Table ${selectedTable.number}` : "PICK UP"}
            </div>
            {activeStaff && (
              <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
                {activeStaff}
              </div>
            )}
          </div>
          <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${cartItems.length > 0 ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-400"}`}>
            {cartItems.length > 0 ? "ACTIVE" : "EMPTY"}
          </span>
        </div>

        {/* Customer Picker Button */}
        <button
          onClick={onCustomerClick}
          className="w-full flex items-center gap-1 text-xs text-violet-600 font-semibold hover:underline mt-2"
        >
          <UserPlus className="w-3 h-3" />
          {loyaltyCustomer ? loyaltyCustomer.name : "ADD CUSTOMER"}
        </button>
      </div>

      {/* Customer Picker */}
      {showCustomerPicker && (
        <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
          <CustomerPicker
            selectedCustomer={loyaltyCustomer}
            onSelect={onCustomerSelect}
          />
        </div>
      )}

      {/* Order Type & Table Selection */}
      <div className="px-3 py-2 border-b border-gray-100 space-y-2">
        <div className="flex gap-1">
          <button
            onClick={() => onOrderTypeChange("dine-in")}
            className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-lg text-xs font-semibold transition-all min-h-[40px] ${
              orderType === "dine-in" ? "bg-violet-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"
            }`}
          >
            <UtensilsCrossed className="w-4 h-4" /> Dine-In
          </button>
          <button
            onClick={() => onOrderTypeChange("takeaway")}
            className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-lg text-xs font-semibold transition-all min-h-[40px] ${
              orderType === "takeaway" ? "bg-violet-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"
            }`}
          >
            <ShoppingBag className="w-4 h-4" /> Takeaway
          </button>
        </div>

        {orderType === "dine-in" && (
          <div className="flex flex-wrap gap-1.5 max-h-20 overflow-y-auto">
            {tables.length === 0 && <span className="text-xs text-gray-400">No tables</span>}
            {tables.map(t => (
              <button
                key={t.id}
                onClick={() => onTableChange(selectedTable?.id === t.id ? null : t)}
                disabled={t.status === "occupied" && selectedTable?.id !== t.id}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all min-h-[36px] ${
                  selectedTable?.id === t.id
                    ? "bg-violet-600 text-white border-violet-600"
                    : t.status === "occupied"
                    ? "bg-gray-100 text-gray-400 border-gray-200 opacity-60 cursor-not-allowed"
                    : "bg-white text-gray-700 border-gray-200 hover:border-violet-400"
                }`}
              >
                T{t.number}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Cart Items - Scrollable */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        {cartItems.length === 0 && (
          <div className="text-center text-gray-300 text-sm py-8">No items yet</div>
        )}
        {cartItems.map(item => (
          <div
            key={item.menu_item_id}
            onClick={() => onCartItemClick(item)}
            className={`flex items-start gap-2 py-2 border-b border-gray-100 last:border-0 cursor-pointer rounded-lg px-1 transition ${
              item.is_voided ? "opacity-40" : ""
            } ${selectedCartItem?.menu_item_id === item.menu_item_id ? "bg-red-50 border border-red-200" : "hover:bg-gray-50"}`}
          >
            <div
              className={`w-1 self-stretch rounded-full shrink-0 ${
                selectedCartItem?.menu_item_id === item.menu_item_id ? "bg-red-500" : item.is_voided ? "bg-gray-300" : "bg-violet-500"
              }`}
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-1">
                <span className={`text-sm font-medium leading-tight ${item.is_voided ? "line-through text-gray-400" : "text-gray-800"}`}>
                  {item.quantity}× {item.name}
                  {item.is_voided && <span className="ml-1 text-[10px] bg-red-100 text-red-500 rounded px-1 font-semibold">VOIDED</span>}
                </span>
                <span className="text-sm font-semibold text-gray-700 shrink-0">
                  AED {(item.subtotal ?? item.price * item.quantity ?? 0).toFixed(2)}
                </span>
              </div>
              {item.modifiers?.length > 0 && (
                <div className="mt-0.5">
                  {item.modifiers.map((m, i) => (
                    <div key={i} className="text-xs text-gray-400">
                      + {m.name}{m.price > 0 ? ` (+${m.price.toFixed(2)})` : ""}
                    </div>
                  ))}
                </div>
              )}
              {item.notes && <div className="text-xs text-amber-600 italic mt-0.5">{item.notes}</div>}

              {/* Quantity Controls */}
              <div className="flex items-center gap-1 mt-1.5">
                <button
                  onClick={() => onCartItemUpdate(item.menu_item_id, { quantity: item.quantity - 1 })}
                  className="w-6 h-6 rounded bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition min-h-[32px]"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="text-xs w-5 text-center font-bold">{item.quantity}</span>
                <button
                  onClick={() => onCartItemUpdate(item.menu_item_id, { quantity: item.quantity + 1 })}
                  className="w-6 h-6 rounded bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition min-h-[32px]"
                >
                  <Plus className="w-3 h-3" />
                </button>
                <button
                  onClick={() => onCartItemUpdate(item.menu_item_id, { quantity: 0 })}
                  className="w-6 h-6 rounded bg-gray-100 hover:bg-red-100 text-gray-400 hover:text-red-500 flex items-center justify-center transition ml-auto min-h-[32px]"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Tax Group Selector */}
      {taxGroups.length > 0 && (
        <div className="px-3 py-2 border-t border-gray-100 bg-gray-50">
          <label className="text-xs font-semibold text-gray-600 block mb-1">Tax Group</label>
          <select
            value={selectedTaxGroup?.id || ""}
            onChange={e => onTaxGroupChange(taxGroups.find(t => t.id === e.target.value) || null)}
            className="w-full border border-gray-200 rounded-lg px-2 py-2 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-violet-400 min-h-[36px]"
          >
            <option value="">No Tax Group</option>
            {taxGroups.map(group => (
              <option key={group.id} value={group.id}>{group.name}</option>
            ))}
          </select>
        </div>
      )}

      {/* Totals */}
      <div className="px-4 py-2 border-t border-gray-100 space-y-1 text-sm bg-gray-50">
        {discountPct > 0 && (
          <div className="flex justify-between text-green-600 font-medium">
            <span>Discount ({discountPct}%)</span>
            <span>−AED {discountAmt.toFixed(2)}</span>
          </div>
        )}
        <div className="flex justify-between text-gray-600">
          <span>Tax</span>
          <span>AED {tax.toFixed(2)}</span>
        </div>
        <div className="flex justify-between font-bold text-lg text-gray-900 pt-1 border-t border-gray-200">
          <span>Total</span>
          <span>AED {total.toFixed(2)}</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-3 pb-2 space-y-2">
        <div className="flex gap-2">
          <button
            onClick={onSaveTicket}
            disabled={cartItems.length === 0}
            className="flex-1 flex items-center justify-center gap-1.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl py-3 transition-all text-sm min-h-[44px]"
          >
            <Ticket className="w-4 h-4" />
            Ticket
          </button>
          <button
            onClick={onSendToKitchen}
            disabled={cartItems.length === 0 || sendingToKitchen}
            className="flex-1 flex items-center justify-center gap-1.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl py-3 transition-all text-sm min-h-[44px]"
          >
            <ChefHat className="w-4 h-4" />
            {sendingToKitchen ? "..." : "Kitchen"}
          </button>
        </div>

        {/* Checkout Button */}
        <button
          onClick={onCheckout}
          disabled={cartItems.length === 0 || (orderType === "dine-in" && !selectedTable)}
          className="w-full flex items-center justify-between bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-xl px-4 py-4 transition-all text-base min-h-[48px] shadow-sm"
        >
          <span>CHARGE</span>
          <span>AED {total.toFixed(2)}</span>
        </button>

        {kitchenMsg && <p className="text-xs text-center text-green-600 font-medium">{kitchenMsg}</p>}
      </div>
    </div>
  );
}