import { base44 } from "@/api/base44Client";

/**
 * Log an audit event.
 * @param {object} params
 * @param {string} params.action - Action type (create, update, delete, invite, etc.)
 * @param {string} params.entity_type - Entity type (Role, User, Order, etc.)
 * @param {string} [params.entity_id] - ID of the affected record
 * @param {string} [params.entity_name] - Display name of the affected record
 * @param {string} [params.description] - Human-readable summary
 * @param {object} [params.changes] - Before/after data
 * @param {string} [params.branch_id]
 * @param {string} [params.branch_name]
 * @param {string} [params.severity] - info | warning | critical
 */
export async function logAudit(params) {
  try {
    const user = await base44.auth.me();
    await base44.entities.AuditLog.create({
      actor_email: user?.email || "unknown",
      actor_name: user?.full_name || "",
      action: params.action,
      entity_type: params.entity_type,
      entity_id: params.entity_id || "",
      entity_name: params.entity_name || "",
      description: params.description || "",
      changes: params.changes || null,
      branch_id: params.branch_id || "",
      branch_name: params.branch_name || "",
      severity: params.severity || "info",
    });
  } catch (e) {
    // Non-blocking: audit logging should never break the main flow
    console.warn("Audit log failed:", e?.message);
  }
}