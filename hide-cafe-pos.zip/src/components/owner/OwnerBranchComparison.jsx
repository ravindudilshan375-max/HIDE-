import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const COLORS = ["#7C3AED", "#5B21B6", "#8B5CF6", "#A78BFA", "#C4B5FD"];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg px-4 py-3">
      <p className="text-xs font-semibold text-gray-500 mb-1">{label}</p>
      <p className="text-sm font-bold text-violet-700">AED {(payload[0]?.value || 0).toLocaleString("en", { maximumFractionDigits: 0 })}</p>
    </div>
  );
};

export default function OwnerBranchComparison({ branches, total }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="mb-4">
        <h3 className="text-base font-bold text-gray-900">Branch Performance</h3>
        <p className="text-sm text-gray-400 mt-0.5">Revenue comparison by location</p>
      </div>

      {branches.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-10">No branch data in this period</p>
      ) : (
        <>
          {branches.length > 1 && (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={branches} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                  {branches.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}

          <div className="mt-4 space-y-3">
            {branches.map((b, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold text-gray-800 truncate">{b.name}</span>
                    <span className="text-sm font-bold text-gray-900 ml-2">AED {b.revenue.toLocaleString("en", { maximumFractionDigits: 0 })}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${total > 0 ? (b.revenue / total) * 100 : 0}%`, background: COLORS[i % COLORS.length] }}
                      />
                    </div>
                    <span className="text-xs text-gray-400 shrink-0">
                      {total > 0 ? ((b.revenue / total) * 100).toFixed(1) : 0}% · {b.orders} orders
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}