import React from "react";

export default function OwnerStaffCost({ staff, totalCost, laborPct }) {
  const isGood = laborPct <= 25;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-gray-900">Staff Cost Analysis</h3>
          <p className="text-sm text-gray-400 mt-0.5">Based on timecard hours × hourly rate</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-gray-900">AED {Math.round(totalCost).toLocaleString()}</p>
          <p className={`text-xs font-bold px-2 py-0.5 rounded-full ${isGood ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>
            {laborPct.toFixed(1)}% of revenue
          </p>
        </div>
      </div>

      {staff.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-sm text-gray-400">No timecard data in this period.</p>
          <p className="text-xs text-gray-300 mt-1">Clock in staff via the Timecards page.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {staff.map((s, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-violet-100 flex items-center justify-center text-sm font-bold text-violet-600 shrink-0">
                {s.name?.[0]?.toUpperCase() || "?"}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-gray-800 truncate">{s.name}</span>
                  <span className="text-sm font-bold text-gray-900 ml-2">
                    AED {s.cost.toLocaleString("en", { maximumFractionDigits: 0 })}
                  </span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full mb-1">
                  <div
                    className="h-full bg-violet-400 rounded-full"
                    style={{ width: `${totalCost > 0 ? (s.cost / totalCost) * 100 : 0}%` }}
                  />
                </div>
                <p className="text-xs text-gray-400">
                  {s.hours.toFixed(1)} hrs
                  {s.rate > 0 ? ` · AED ${s.rate}/hr` : " · No rate set"}
                  {totalCost > 0 ? ` · ${((s.cost / totalCost) * 100).toFixed(1)}% of total` : ""}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}