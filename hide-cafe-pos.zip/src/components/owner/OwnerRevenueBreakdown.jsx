import React, { useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

const COLORS = ["#7C3AED", "#3B82F6", "#10B981", "#F59E0B", "#EF4444", "#EC4899"];

const PAYMENT_LABELS = { cash: "Cash", card: "Card", mobile: "Mobile Pay", split: "Split", other: "Other" };
const PLATFORM_LABELS = { pos: "In-Store POS", talabat: "Talabat", careem: "Careem", website: "Website", other: "Other" };

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg px-3 py-2">
      <p className="text-sm font-bold text-gray-800">{payload[0].name}</p>
      <p className="text-sm text-violet-700">AED {(payload[0].value || 0).toLocaleString("en", { maximumFractionDigits: 0 })}</p>
    </div>
  );
};

export default function OwnerRevenueBreakdown({ byPayment, byPlatform, total }) {
  const [view, setView] = useState("payment");

  const data = (view === "payment" ? byPayment : byPlatform)
    .map(d => ({
      ...d,
      name: view === "payment" ? (PAYMENT_LABELS[d.name] || d.name) : (PLATFORM_LABELS[d.name] || d.name),
    }))
    .filter(d => d.value > 0);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-gray-900">Revenue Breakdown</h3>
          <p className="text-sm text-gray-400 mt-0.5">Where your money comes from</p>
        </div>
        <div className="flex bg-gray-100 rounded-xl p-1 gap-0.5">
          <button
            onClick={() => setView("payment")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${view === "payment" ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-700"}`}
          >
            Payment
          </button>
          <button
            onClick={() => setView("platform")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${view === "platform" ? "bg-white shadow-sm text-gray-900" : "text-gray-500 hover:text-gray-700"}`}
          >
            Platform
          </button>
        </div>
      </div>

      {data.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-10">No data for this period</p>
      ) : (
        <div className="flex items-center gap-4">
          <div className="shrink-0">
            <ResponsiveContainer width={150} height={150}>
              <PieChart>
                <Pie data={data} cx="50%" cy="50%" innerRadius={42} outerRadius={68} paddingAngle={3} dataKey="value">
                  {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex-1 space-y-2.5 min-w-0">
            {data.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-sm text-gray-700 truncate">{d.name}</span>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-gray-900">AED {d.value.toLocaleString("en", { maximumFractionDigits: 0 })}</p>
                  <p className="text-xs text-gray-400">{total > 0 ? ((d.value / total) * 100).toFixed(1) : 0}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}