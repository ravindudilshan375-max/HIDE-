import React from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Bar, ComposedChart } from "recharts";
import { format, parseISO } from "date-fns";

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg px-4 py-3">
      <p className="text-xs font-semibold text-gray-500 mb-1">{label}</p>
      <p className="text-sm font-bold text-violet-700">AED {(payload[0]?.value || 0).toLocaleString("en", { maximumFractionDigits: 0 })}</p>
      {payload[1] && <p className="text-xs text-gray-500">{payload[1]?.value} orders</p>}
    </div>
  );
};

export default function OwnerSalesChart({ data, dateRange }) {
  const formatted = data.map(d => ({
    ...d,
    label: (() => {
      try {
        return format(parseISO(d.date), dateRange === "year" ? "MMM" : dateRange === "quarter" ? "MMM d" : "MMM d");
      } catch { return d.date; }
    })(),
  }));

  const total = data.reduce((s, d) => s + d.revenue, 0);
  const totalOrders = data.reduce((s, d) => s + d.orders, 0);
  const avg = totalOrders > 0 ? total / totalOrders : 0;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
        <div>
          <h3 className="text-base font-bold text-gray-900">Sales Performance</h3>
          <p className="text-sm text-gray-400 mt-0.5">Revenue trend over selected period</p>
        </div>
        <div className="flex gap-4">
          <div className="text-right">
            <p className="text-xs text-gray-400">Total</p>
            <p className="text-sm font-bold text-gray-900">AED {Math.round(total).toLocaleString()}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">Orders</p>
            <p className="text-sm font-bold text-gray-900">{totalOrders.toLocaleString()}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-400">Avg Order</p>
            <p className="text-sm font-bold text-gray-900">AED {Math.round(avg).toLocaleString()}</p>
          </div>
        </div>
      </div>
      {formatted.length === 0 ? (
        <div className="h-[220px] flex items-center justify-center text-gray-400 text-sm">No sales data in this period</div>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <ComposedChart data={formatted} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.15} />
                <stop offset="95%" stopColor="#7C3AED" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="revenue" stroke="#7C3AED" strokeWidth={2.5} fill="url(#revGrad)" />
          </ComposedChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}