import React from "react";
import { DollarSign, Package, Users, TrendingUp, TrendingDown, Percent, ShoppingCart } from "lucide-react";

function KPICard({ label, value, sub, iconBg, icon: IconComponent, dark, highlight }) {
  const Icon = IconComponent;
  return (
    <div className={`rounded-2xl p-4 border ${
      highlight
        ? "bg-white border-violet-200 shadow-lg"
        : dark
        ? "bg-white/10 border-white/15"
        : "bg-white/10 border-white/15"
    }`}>
      <div className="flex items-start justify-between mb-3">
        <p className={`text-xs font-semibold uppercase tracking-wide ${highlight ? "text-gray-500" : "text-gray-400"}`}>{label}</p>
        <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${iconBg}`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <p className={`text-2xl font-black ${highlight ? "text-gray-900" : "text-white"}`}>{value}</p>
      {sub && <p className={`text-xs mt-1.5 font-medium ${highlight ? "text-gray-400" : "text-gray-400"}`}>{sub}</p>}
    </div>
  );
}

export default function OwnerKPICards({ financials }) {
  const { revenue, cogs, staffCost, netProfit, profitMargin, primeCostPct, foodCostPct, laborCostPct, orderCount, avgOrderValue } = financials;
  const isGoodMargin = profitMargin >= 15;
  const isGoodPrimeCost = primeCostPct <= 60;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      <KPICard
        label="Total Revenue"
        value={`AED ${Math.round(revenue).toLocaleString()}`}
        sub={`${orderCount.toLocaleString()} orders`}
        iconBg="bg-violet-600"
        icon={DollarSign}
      />
      <KPICard
        label="Cost of Goods"
        value={`AED ${Math.round(cogs).toLocaleString()}`}
        sub={`${foodCostPct.toFixed(1)}% of revenue`}
        iconBg="bg-orange-500"
        icon={Package}
      />
      <KPICard
        label="Staff Cost"
        value={`AED ${Math.round(staffCost).toLocaleString()}`}
        sub={`${laborCostPct.toFixed(1)}% of revenue`}
        iconBg="bg-blue-500"
        icon={Users}
      />
      <KPICard
        label="Net Profit"
        value={`AED ${Math.round(netProfit).toLocaleString()}`}
        sub={`${profitMargin.toFixed(1)}% margin`}
        iconBg={isGoodMargin ? "bg-green-500" : "bg-red-500"}
        icon={isGoodMargin ? TrendingUp : TrendingDown}
        highlight
      />
      <KPICard
        label="Profit Margin"
        value={`${profitMargin.toFixed(1)}%`}
        sub={profitMargin >= 15 ? "✓ Healthy" : "⚠ Below target"}
        iconBg={isGoodMargin ? "bg-green-500" : "bg-amber-500"}
        icon={Percent}
      />
      <KPICard
        label="Prime Cost"
        value={`${primeCostPct.toFixed(1)}%`}
        sub={isGoodPrimeCost ? "✓ Within 60% target" : "⚠ Exceeds target"}
        iconBg={isGoodPrimeCost ? "bg-teal-500" : "bg-red-500"}
        icon={ShoppingCart}
      />
    </div>
  );
}