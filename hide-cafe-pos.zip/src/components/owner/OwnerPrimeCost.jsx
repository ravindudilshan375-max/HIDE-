import React from "react";

function CostBar({ label, pct, target, color }) {
  const isAbove = pct > target;
  const barWidth = Math.min(Math.max(pct, 0), 100);
  return (
    <div className="mb-5">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold text-gray-700">{label}</span>
        <div className="flex items-center gap-2">
          <span className={`text-base font-black ${isAbove ? "text-red-600" : "text-green-700"}`}>
            {pct.toFixed(1)}%
          </span>
          <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
            target &lt;{target}%
          </span>
        </div>
      </div>
      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${isAbove ? "bg-red-500" : color}`}
          style={{ width: `${barWidth}%` }}
        />
      </div>
      <p className={`text-xs mt-1 font-medium ${isAbove ? "text-red-500" : "text-green-600"}`}>
        {isAbove ? `+${(pct - target).toFixed(1)}% above target` : `${(target - pct).toFixed(1)}% below target ✓`}
      </p>
    </div>
  );
}

export default function OwnerPrimeCost({ financials }) {
  const { primeCostPct, foodCostPct, laborCostPct } = financials;
  const isGood = primeCostPct <= 60;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex flex-col">
      <div className="flex items-start justify-between mb-5">
        <div>
          <h3 className="text-base font-bold text-gray-900">Prime Cost</h3>
          <p className="text-xs text-gray-400 mt-0.5">COGS + Labor</p>
        </div>
        <div className={`text-3xl font-black ${isGood ? "text-green-600" : "text-red-600"}`}>
          {primeCostPct.toFixed(1)}%
        </div>
      </div>

      <CostBar label="Food Cost (COGS)" pct={foodCostPct} target={35} color="bg-orange-400" />
      <CostBar label="Labor Cost" pct={laborCostPct} target={25} color="bg-blue-400" />
      <CostBar label="Prime Cost Total" pct={primeCostPct} target={60} color="bg-violet-500" />

      <div className={`mt-auto rounded-xl px-4 py-3 text-sm font-semibold text-center ${
        isGood ? "bg-green-50 text-green-700 border border-green-100" : "bg-red-50 text-red-700 border border-red-100"
      }`}>
        {isGood ? "✓ Prime cost is healthy (< 60%)" : "⚠ Prime cost exceeds 60% target"}
      </div>
    </div>
  );
}