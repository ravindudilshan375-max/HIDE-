import React from "react";

function MarginBadge({ margin, hasCost }) {
  if (!hasCost) return <span className="text-xs text-gray-300">No cost data</span>;
  const color = margin >= 65 ? "bg-green-100 text-green-700" : margin >= 45 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700";
  return <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${color}`}>{margin.toFixed(0)}% margin</span>;
}

export default function OwnerTopProducts({ products }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-gray-900">Top Performing Products</h3>
          <p className="text-sm text-gray-400 mt-0.5">By revenue · with cost & margin</p>
        </div>
      </div>

      {products.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-10">No product data available</p>
      ) : (
        <div className="space-y-3">
          {products.slice(0, 8).map((p, i) => (
            <div key={i} className="flex items-center gap-3 group">
              <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-xs font-black text-gray-500 shrink-0">
                {i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-semibold text-gray-800 truncate">{p.name}</span>
                  <span className="text-sm font-bold text-violet-700 ml-2 shrink-0">
                    AED {p.revenue.toLocaleString("en", { maximumFractionDigits: 0 })}
                  </span>
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  <span className="text-xs text-gray-400">{p.sold.toLocaleString()} sold</span>
                  {p.cost > 0 && (
                    <>
                      <span className="text-xs text-gray-400">Price: AED {p.price.toFixed(1)}</span>
                      <span className="text-xs text-gray-400">Cost: AED {p.cost.toFixed(1)}</span>
                      <MarginBadge margin={p.margin} hasCost={p.cost > 0} />
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}