import React, { useState } from "react";
import { AlertTriangle, CheckCircle, Lightbulb, Loader2, XCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function OwnerAlerts({ financials, topProducts }) {
  const [insights, setInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  const alerts = [];

  if (financials.foodCostPct > 35) {
    alerts.push({ type: "warning", msg: `Food cost is ${financials.foodCostPct.toFixed(1)}% — above the 35% target` });
  }
  if (financials.laborCostPct > 25) {
    alerts.push({ type: "warning", msg: `Labor cost is ${financials.laborCostPct.toFixed(1)}% — above the 25% target` });
  }
  if (financials.primeCostPct > 60) {
    alerts.push({ type: "danger", msg: `Prime cost is ${financials.primeCostPct.toFixed(1)}% — exceeds 60% threshold` });
  }
  if (financials.profitMargin < 5 && financials.revenue > 0) {
    alerts.push({ type: "danger", msg: `Net profit margin is critically low at ${financials.profitMargin.toFixed(1)}%` });
  } else if (financials.profitMargin < 15 && financials.revenue > 0) {
    alerts.push({ type: "warning", msg: `Profit margin is ${financials.profitMargin.toFixed(1)}% — target is 15%+` });
  }

  const lowMarginProducts = topProducts.filter(p => p.cost > 0 && p.margin < 40 && p.sold > 5);
  if (lowMarginProducts.length > 0) {
    alerts.push({ type: "warning", msg: `Low margin items: ${lowMarginProducts.slice(0, 3).map(p => `${p.name} (${p.margin.toFixed(0)}%)`).join(", ")}` });
  }

  if (alerts.length === 0) {
    alerts.push({ type: "success", msg: "All key financial metrics are within healthy targets 🎉" });
  }

  const generateInsights = async () => {
    setLoadingInsights(true);
    setInsights(null);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a restaurant financial analyst. Based on these metrics, give exactly 3 short actionable insights (max 20 words each). Start each with an emoji. Plain text, no markdown, no numbering:

Revenue: AED ${Math.round(financials.revenue).toLocaleString()}
Net Profit Margin: ${financials.profitMargin.toFixed(1)}%
Prime Cost: ${financials.primeCostPct.toFixed(1)}% (target <60%)
Food Cost: ${financials.foodCostPct.toFixed(1)}% (target <35%)
Labor Cost: ${financials.laborCostPct.toFixed(1)}% (target <25%)
Total Orders: ${financials.orderCount}
Avg Order Value: AED ${Math.round(financials.avgOrderValue)}
Top Products: ${topProducts.slice(0, 5).map(p => `${p.name}: ${p.sold} sold, ${p.margin.toFixed(0)}% margin`).join(" | ")}

Output format: One insight per line, nothing else.`,
      });
      const text = typeof result === "string" ? result : (result?.content || "");
      const lines = text.split("\n").map(l => l.trim()).filter(l => l.length > 5).slice(0, 3);
      setInsights(lines.length > 0 ? lines : ["No insights generated. Try again."]);
    } catch (e) {
      setInsights(["Unable to generate insights. Please try again."]);
    }
    setLoadingInsights(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Alerts */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <h3 className="text-base font-bold text-gray-900 mb-4">Financial Alerts</h3>
        <div className="space-y-3">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-start gap-3 rounded-xl px-4 py-3 border ${
              a.type === "danger" ? "bg-red-50 border-red-100" :
              a.type === "warning" ? "bg-amber-50 border-amber-100" :
              "bg-green-50 border-green-100"
            }`}>
              {a.type === "success"
                ? <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 shrink-0" />
                : a.type === "danger"
                ? <XCircle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
                : <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
              }
              <p className={`text-sm font-medium ${
                a.type === "danger" ? "text-red-800" :
                a.type === "warning" ? "text-amber-800" :
                "text-green-800"
              }`}>{a.msg}</p>
            </div>
          ))}
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-gray-900">AI Quick Insights</h3>
            <p className="text-xs text-gray-400 mt-0.5">Powered by AI analysis</p>
          </div>
          <button
            onClick={generateInsights}
            disabled={loadingInsights}
            className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 disabled:opacity-50 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition"
          >
            {loadingInsights
              ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
              : <Lightbulb className="w-3.5 h-3.5" />
            }
            {loadingInsights ? "Analyzing…" : "Generate Insights"}
          </button>
        </div>

        {!insights && !loadingInsights && (
          <div className="text-center py-8">
            <Lightbulb className="w-12 h-12 text-gray-200 mx-auto mb-3" />
            <p className="text-sm text-gray-500 font-medium">Get AI-powered insights</p>
            <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">Click Generate for personalized recommendations based on your current financial data.</p>
          </div>
        )}

        {loadingInsights && (
          <div className="text-center py-8">
            <Loader2 className="w-8 h-8 text-violet-400 animate-spin mx-auto mb-3" />
            <p className="text-sm text-gray-500">Analyzing financial performance…</p>
          </div>
        )}

        {insights && !loadingInsights && (
          <div className="space-y-3">
            {insights.map((insight, i) => (
              <div key={i} className="flex items-start gap-3 bg-gradient-to-r from-violet-50 to-purple-50 border border-violet-100 rounded-xl px-4 py-3">
                <div className="w-5 h-5 rounded-full bg-violet-200 flex items-center justify-center text-xs font-bold text-violet-700 shrink-0 mt-0.5">
                  {i + 1}
                </div>
                <p className="text-sm text-violet-900 leading-relaxed">{insight}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}