import React from "react";
import { CheckCircle2, Circle } from "lucide-react";

const STEPS = [
  { key: "placed",    label: "Order Placed",   statuses: ["pending","preparing","ready","served","paid"] },
  { key: "kitchen",   label: "Sent to Kitchen", statuses: ["preparing","ready","served","paid"] },
  { key: "preparing", label: "Preparing",       statuses: ["preparing","ready","served","paid"] },
  { key: "ready",     label: "Ready",           statuses: ["ready","served","paid"] },
  { key: "served",    label: "Served",          statuses: ["served","paid"] },
  { key: "paid",      label: "Paid",            statuses: ["paid"] },
];

export default function OrderTimeline({ status }) {
  return (
    <div className="px-4 py-3 bg-white rounded-2xl border border-gray-100 shadow-sm mx-4 mt-3">
      <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Order Progress</p>
      <div className="space-y-2">
        {STEPS.map((step, i) => {
          const done = step.statuses.includes(status);
          const current = STEPS[i].statuses.includes(status) && (i === STEPS.length - 1 || !STEPS[i + 1].statuses.includes(status));
          return (
            <div key={step.key} className="flex items-center gap-3">
              {done ? (
                <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
              ) : (
                <Circle className="w-4 h-4 text-gray-200 shrink-0" />
              )}
              <span className={`text-sm ${done ? "text-gray-800 font-medium" : "text-gray-300"} ${current ? "font-bold text-blue-600" : ""}`}>
                {step.label}
              </span>
              {current && (
                <span className="ml-auto text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">Current</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}