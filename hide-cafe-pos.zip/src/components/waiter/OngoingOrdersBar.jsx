import React from "react";
import { ChevronRight } from "lucide-react";

const STATUS_CONFIG = {
  pending:   { label: "Open",       dot: "bg-gray-800",   text: "text-gray-700" },
  preparing: { label: "Preparing",  dot: "bg-orange-400", text: "text-orange-700" },
  ready:     { label: "Ready",      dot: "bg-green-500",  text: "text-green-700" },
  served:    { label: "Pay",        dot: "bg-purple-500", text: "text-purple-700" },
};

export default function OngoingOrdersBar({ orders, onOpenOrder }) {
  const active = orders.filter(o => ["pending","preparing","ready","served"].includes(o.status));
  if (active.length === 0) return null;

  return (
    <div className="bg-white border-t border-gray-100">
      <div className="flex items-center justify-between px-4 pt-2.5 pb-1">
        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Ongoing Orders</span>
        <span className="text-[10px] text-gray-400">{active.length} active</span>
      </div>
      <div className="flex gap-2 px-4 pb-2.5 overflow-x-auto scrollbar-hide">
        {active.map(order => {
          const cfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.pending;
          const label = order.table_number
            ? `Table ${order.table_number}`
            : order.customer_name
            ? `Pickup — ${order.customer_name}`
            : `#${order.order_number}`;
          return (
            <button
              key={order.id}
              onClick={() => onOpenOrder(order)}
              className="shrink-0 flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 hover:bg-gray-100 active:scale-95 transition-all"
            >
              <span className={`w-2 h-2 rounded-full shrink-0 ${cfg.dot}`} />
              <div className="text-left">
                <p className="text-xs font-semibold text-gray-900 whitespace-nowrap">{label}</p>
                <p className={`text-[10px] font-medium ${cfg.text}`}>{cfg.label}</p>
              </div>
              <ChevronRight className="w-3 h-3 text-gray-400 ml-1" />
            </button>
          );
        })}
      </div>
    </div>
  );
}