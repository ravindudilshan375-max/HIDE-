import React, { useState } from "react";
import { X, Plus, Minus } from "lucide-react";

export default function ModifierModal({ item, onAdd, onClose }) {
  const [selectedModifiers, setSelectedModifiers] = useState([]);
  const [notes, setNotes] = useState("");
  const [qty, setQty] = useState(1);

  const modifiers = item.modifiers || [];

  const toggleModifier = (mod) => {
    setSelectedModifiers(prev => {
      const exists = prev.find(m => m.name === mod.name);
      if (exists) return prev.filter(m => m.name !== mod.name);
      return [...prev, mod];
    });
  };

  const modTotal = selectedModifiers.reduce((s, m) => s + (m.price || 0), 0);
  const unitPrice = (item.base_price || 0) + modTotal;
  const totalPrice = unitPrice * qty;

  const handleAdd = () => {
    onAdd({
      menu_item_id: item.id,
      name: item.name,
      price: unitPrice,
      quantity: qty,
      subtotal: totalPrice,
      modifiers: selectedModifiers,
      notes
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50">
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b">
          <div>
            <h2 className="font-bold text-gray-900 text-lg">{item.name}</h2>
            <p className="text-sm text-gray-400">Base: AED {(item.base_price || 0).toFixed(2)}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[60vh] px-5 py-4 space-y-5">
          {/* Modifiers */}
          {modifiers.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Modifiers</p>
              <div className="space-y-2">
                {modifiers.map((mod, i) => {
                  const selected = selectedModifiers.find(m => m.name === mod.name);
                  return (
                    <button
                      key={i}
                      onClick={() => toggleModifier(mod)}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 transition-all ${
                        selected
                          ? "border-violet-500 bg-violet-50"
                          : "border-gray-100 bg-gray-50 hover:border-gray-200"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                          selected ? "bg-violet-500 border-violet-500" : "border-gray-300"
                        }`}>
                          {selected && <span className="text-white text-xs font-bold">✓</span>}
                        </div>
                        <span className="text-sm font-medium text-gray-800">{mod.name}</span>
                      </div>
                      {mod.price > 0 && (
                        <span className="text-sm font-semibold text-violet-600">+AED {mod.price.toFixed(2)}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Notes */}
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Special Instructions</p>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. No onion, extra sauce..."
              rows={2}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:border-violet-400"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 pb-5 pt-3 border-t bg-gray-50 space-y-3">
          {/* Qty */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-gray-600">Quantity</span>
            <div className="flex items-center gap-3">
              <button onClick={() => setQty(q => Math.max(1, q - 1))}
                className="w-8 h-8 rounded-xl bg-gray-200 flex items-center justify-center hover:bg-gray-300">
                <Minus className="w-4 h-4" />
              </button>
              <span className="font-bold text-lg w-6 text-center">{qty}</span>
              <button onClick={() => setQty(q => q + 1)}
                className="w-8 h-8 rounded-xl bg-violet-100 text-violet-600 flex items-center justify-center hover:bg-violet-200">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <button
            onClick={handleAdd}
            className="w-full bg-violet-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-violet-700 transition"
          >
            Add to Order · AED {totalPrice.toFixed(2)}
          </button>
        </div>
      </div>
    </div>
  );
}