import React, { useState } from "react";
import { X, ShoppingBag, Truck, Users } from "lucide-react";

export default function OrderTypeSelector({ onSelect, onClose }) {
  const [step, setStep] = useState("type"); // type | pickup_info
  const [pickupData, setPickupData] = useState({
    customer_name: "",
    customer_phone: "",
  });

  const ORDER_TYPES = [
    { value: "dine-in", label: "Dine In", icon: Users, color: "bg-blue-50 border-blue-200 text-blue-700" },
    { value: "takeaway", label: "Pickup", icon: ShoppingBag, color: "bg-green-50 border-green-200 text-green-700" },
    { value: "delivery", label: "Delivery", icon: Truck, color: "bg-orange-50 border-orange-200 text-orange-700" },
  ];

  const handleTypeSelect = (type) => {
    if (type === "dine-in") {
      onSelect(type, null);
    } else {
      setStep("pickup_info");
    }
  };

  const handlePickupSubmit = () => {
    onSelect("takeaway", pickupData);
  };

  const isPickupValid = pickupData.customer_name.trim();

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60">
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b">
          <h2 className="font-bold text-gray-900 text-lg">
            {step === "type" ? "Create Order" : "Pickup Details"}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-6 space-y-4">

          {step === "type" ? (
            <>
              <p className="text-sm text-gray-600 mb-4">Select order type</p>
              <div className="grid grid-cols-1 gap-3">
                {ORDER_TYPES.map(type => {
                  const Icon = type.icon;
                  return (
                    <button
                      key={type.value}
                      onClick={() => handleTypeSelect(type.value)}
                      className={`flex items-center gap-4 p-4 rounded-2xl border-2 transition-all hover:shadow-md ${type.color}`}
                    >
                      <Icon className="w-6 h-6 shrink-0" />
                      <span className="font-bold text-base">{type.label}</span>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <>
              <p className="text-sm text-gray-600 mb-4">Enter customer details</p>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    Customer Name
                  </label>
                  <input
                    type="text"
                    value={pickupData.customer_name}
                    onChange={(e) => setPickupData({ ...pickupData, customer_name: e.target.value })}
                    placeholder="John"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                    Phone (Optional)
                  </label>
                  <input
                    type="tel"
                    value={pickupData.customer_phone}
                    onChange={(e) => setPickupData({ ...pickupData, customer_phone: e.target.value })}
                    placeholder="0501234567"
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-400"
                  />
                </div>

              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t space-y-2 bg-gray-50">
          {step === "pickup_info" && (
            <button
              onClick={() => setStep("type")}
              className="w-full text-gray-600 py-2.5 rounded-xl font-semibold text-sm hover:bg-gray-100"
            >
              Back
            </button>
          )}
          {step === "pickup_info" && (
            <button
              onClick={handlePickupSubmit}
              disabled={!isPickupValid}
              className="w-full bg-green-600 text-white py-3 rounded-xl font-bold text-sm hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Continue to Menu
            </button>
          )}
        </div>
      </div>
    </div>
  );
}