import React, { useState } from "react";
import { ChevronRight, UtensilsCrossed } from "lucide-react";

const FILTERS = [
  { key: "all",      label: "All" },
  { key: "dine-in",  label: "Dine In" },
  { key: "takeaway", label: "Pickup" },
  { key: "ready",    label: "Ready" },
  { key: "served",   label: "Pay" },
];

const STATUS_STYLES = {
  pending:   { label: "Open",      bg: "bg-gray-100",    text: "text-gray-700" },
  preparing: { label: "Preparing", bg: "bg-orange-100",  text: "text-orange-700" },
  ready:     { label: "Ready",     bg: "bg-green-100",   text: "text-green-700" },
  served:    { label: "Pay",       bg: "bg-purple-100",  text: "text-purple-700" },
};

export default function OrdersListView({ orders, onOpenOrder }) {
  const [filter, setFilter] = useState("all");

  const filtered = orders.filter(o => {
    if (!["pending","preparing","ready","served"].includes(o.status)) return false;
    if (filter === "all") return true;
    if (filter === "ready") return o.status === "ready";
    if (filter === "served") return o.status === "served";
    return o.type === filter;
  });

  return (
    <div className="flex flex-col h-full">
      {/* Filters */}
      <div className="flex gap-2 px-4 py-3 overflow-x-auto scrollbar-hide">
        {FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`shrink-0 px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              filter === f.key
                ? "bg-gray-900 text-white"
                : "bg-white text-gray-600 border border-gray-200 hover:bg-gray-50"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-gray-300">
            <UtensilsCrossed className="w-10 h-10 mx-auto mb-2" />
            <p className="text-sm">No active orders</p>
          </div>
        ) : (
          filtered.map(order => {
            const cfg = STATUS_STYLES[order.status] || STATUS_STYLES.pending;
            const label = order.table_number
              ? `Table ${order.table_number}`
              : order.customer_name
              ? `Pickup — ${order.customer_name}`
              : `Order #${order.order_number}`;
            const itemCount = (order.items || []).filter(i => !i.is_voided).length;
            const total = order.total || 0;
            return (
              <button
                key={order.id}
                onClick={() => onOpenOrder(order)}
                className="w-full flex items-center gap-3 bg-white rounded-2xl border border-gray-100 px-4 py-3.5 text-left hover:shadow-sm active:scale-[0.99] transition-all"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 text-sm">{label}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{itemCount} items · AED {total.toFixed(2)}</p>
                </div>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.bg} ${cfg.text}`}>
                  {cfg.label}
                </span>
                <ChevronRight className="w-4 h-4 text-gray-300 shrink-0" />
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}