import React, { useState } from "react";
import { UtensilsCrossed, Delete } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const DIGITS = ["1","2","3","4","5","6","7","8","9","","0","⌫"];

export default function WaiterLogin({ onLogin }) {
  const [staffId, setStaffId] = useState("");
  const [pin, setPin] = useState("");
  const [step, setStep] = useState("id"); // id | pin
  const [staffMember, setStaffMember] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleIdSubmit = async () => {
    if (!staffId.trim()) return;
    setLoading(true);
    const results = await base44.entities.StaffMember.filter({ staff_id: staffId.trim() });
    setLoading(false);
    if (!results[0]) { toast.error("Staff ID not found"); return; }
    setStaffMember(results[0]);
    setStep("pin");
  };

  const handlePinDigit = async (d) => {
    if (d === "⌫") { setPin(p => p.slice(0, -1)); return; }
    if (d === "") return;
    const newPin = pin + d;
    setPin(newPin);
    if (newPin.length === 4) {
      setLoading(true);
      const res = await base44.functions.invoke("verifyStaffPin", { branch_id: staffMember.branch_id, pin: newPin });
      setLoading(false);
      if (res.data?.success) {
        const session = {
          id: staffMember.id,
          name: staffMember.name,
          role_type: staffMember.role_type,
          branch_id: staffMember.branch_id,
          branch_name: staffMember.branch_name,
          logged_in_at: new Date().toISOString()
        };
        localStorage.setItem("pos_staff_session", JSON.stringify(session));
        onLogin(session);
      } else {
        toast.error("Wrong PIN");
        setPin("");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-950 to-violet-800 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <UtensilsCrossed className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Waiter POS</h1>
          <p className="text-violet-300 text-sm mt-1">Sign in to continue</p>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-2xl">
          {step === "id" ? (
            <div className="space-y-4">
              <label className="block text-sm font-semibold text-gray-600">Staff ID</label>
              <input
                value={staffId}
                onChange={e => setStaffId(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleIdSubmit()}
                placeholder="Enter your staff ID"
                className="w-full border rounded-xl px-4 py-3 text-gray-900 text-lg font-mono text-center focus:outline-none focus:border-violet-500 border-gray-200"
                autoComplete="off"
                autoFocus
              />
              <button
                onClick={handleIdSubmit}
                disabled={!staffId.trim() || loading}
                className="w-full bg-violet-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-violet-700 disabled:opacity-50 transition"
              >
                {loading ? "Checking..." : "Continue"}
              </button>
            </div>
          ) : (
            <div>
              <p className="text-center text-gray-500 text-sm mb-1">Welcome,</p>
              <p className="text-center font-bold text-gray-900 text-lg mb-4">{staffMember?.name}</p>
              
              {/* PIN dots */}
              <div className="flex justify-center gap-3 mb-6">
                {[0,1,2,3].map(i => (
                  <div key={i} className={`w-4 h-4 rounded-full border-2 transition-all ${
                    pin.length > i ? "bg-violet-600 border-violet-600" : "bg-white border-gray-300"
                  }`} />
                ))}
              </div>

              {/* Numpad */}
              <div className="grid grid-cols-3 gap-3">
                {DIGITS.map((d, i) => (
                  <button
                    key={i}
                    onClick={() => handlePinDigit(d)}
                    disabled={loading || d === ""}
                    className={`h-14 rounded-2xl text-lg font-bold transition-all active:scale-95 ${
                      d === "" ? "invisible" :
                      d === "⌫" ? "bg-gray-100 text-gray-500 hover:bg-gray-200" :
                      "bg-gray-50 text-gray-900 hover:bg-violet-50 hover:text-violet-600 border border-gray-100"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>

              <button onClick={() => { setStep("id"); setPin(""); setStaffMember(null); }}
                className="w-full mt-4 text-xs text-gray-400 hover:text-gray-600">
                ← Use different ID
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}