import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { X, CheckCircle2, QrCode, Share2, Copy, Mail, CreditCard, Banknote, Smartphone, Send } from "lucide-react";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

const PAYMENT_METHODS = [
  { value: "cash",   label: "Cash",      icon: Banknote,    color: "bg-green-50 border-green-200 text-green-700" },
  { value: "card",   label: "Card",      icon: CreditCard,  color: "bg-blue-50 border-blue-200 text-blue-700" },
  { value: "mobile", label: "Apple Pay", icon: Smartphone,  color: "bg-gray-50 border-gray-200 text-gray-700" },
];

export default function CheckoutModal({ order, table, waiterName, onClose, onPaid }) {
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [loading, setLoading] = useState(false);
  const [paid, setPaid] = useState(false);
  const [receiptUrl, setReceiptUrl] = useState(null);
  const [emailInput, setEmailInput] = useState("");
  const [emailSending, setEmailSending] = useState(false);

  const subtotal = order.subtotal || 0;
  const tax = order.tax || 0;
  const total = order.total || 0;

  const handleConfirmPayment = async () => {
    setLoading(true);
    await base44.entities.Order.update(order.id, {
      status: "paid",
      payment_method: paymentMethod,
      amount_paid: total,
      branch_id: order.branch_id,
    });
    // Free up table
    if (table) {
      const branchId = table.branch_id || order.branch_id;
      if (branchId) {
        await base44.entities.Table.update(table.id, { status: "available", current_order_id: "", branch_id: branchId });
      }
    }
    const baseUrl = createPageUrl("DigitalReceipt");
    const separator = baseUrl.includes('?') ? '&' : '?';
    const url = `${window.location.origin}${baseUrl}${separator}id=${order.order_number}`;
    setReceiptUrl(url);
    setPaid(true);
    setLoading(false);
    toast.success("✅ Payment confirmed!");
  };

  const qrSrc = receiptUrl
    ? `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(receiptUrl)}&size=200x200&margin=10`
    : null;

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Digital Receipt",
          text: "Here is your digital receipt from our restaurant",
          url: receiptUrl,
        });
      } catch (err) {
        console.log("Share cancelled or failed");
      }
    } else {
      toast.error("Sharing not supported on this device");
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(receiptUrl);
    toast.success("Receipt link copied!");
  };

  const shareEmail = () => {
    const subject = encodeURIComponent("Your Digital Receipt");
    const body = encodeURIComponent(`Thank you for your visit!\n\nView your receipt here:\n${receiptUrl}`);
    window.open(`mailto:?subject=${subject}&body=${body}`, "_blank");
  };

  const shareMessages = () => {
    const msg = encodeURIComponent(`Here is your digital receipt:\n${receiptUrl}`);
    window.open(`sms:?body=${msg}`, "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60">
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b">
          <div>
            <h2 className="font-bold text-gray-900 text-lg">
              {paid ? "✅ Payment Complete" : `💳 Checkout — ${table ? `Table ${table.number}` : "Pickup"}`}
            </h2>
            {!paid && <p className="text-xs text-gray-400 mt-0.5">Waiter: {waiterName}</p>}
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 py-4 space-y-4 overflow-y-auto max-h-[70vh]">

          {!paid ? (
            <>
              {/* Bill Summary */}
              <div className="bg-gray-50 rounded-2xl p-4 space-y-2">
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Subtotal</span>
                  <span>AED {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-500">
                  <span>VAT 5%</span>
                  <span>AED {tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-gray-900 text-xl border-t pt-2 mt-1">
                  <span>Total</span>
                  <span>AED {total.toFixed(2)}</span>
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Payment Method</p>
                <div className="grid grid-cols-3 gap-2">
                  {PAYMENT_METHODS.map(m => {
                    const Icon = m.icon;
                    return (
                      <button
                        key={m.value}
                        onClick={() => setPaymentMethod(m.value)}
                        className={`flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all ${
                          paymentMethod === m.value
                            ? m.color + " border-current shadow-sm scale-105"
                            : "bg-white border-gray-100 text-gray-500 hover:border-gray-200"
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-xs font-semibold">{m.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Confirm */}
              <button
                onClick={handleConfirmPayment}
                disabled={loading}
                className="w-full bg-green-600 text-white py-3.5 rounded-2xl font-bold text-base hover:bg-green-700 disabled:opacity-50 transition flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                {loading ? "Processing..." : `Confirm Payment · AED ${total.toFixed(2)}`}
              </button>
            </>
          ) : (
            <>
              {/* Success */}
              <div className="text-center py-2">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-8 h-8 text-green-600" />
                </div>
                <p className="font-bold text-gray-900 text-lg">AED {total.toFixed(2)}</p>
                <p className="text-sm text-gray-500 mt-1">Paid via {paymentMethod} · Order #{order.order_number}</p>
              </div>

              {/* QR Code */}
              {qrSrc && (
                <div className="bg-gray-50 rounded-2xl p-4 text-center">
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 flex items-center justify-center gap-1">
                    <QrCode className="w-3 h-3" /> Scan for Digital Receipt
                  </p>
                  <img src={qrSrc} alt="QR Code" className="w-40 h-40 mx-auto rounded-xl" />
                  <p className="text-xs text-gray-400 mt-2">Customer scans to view receipt</p>
                </div>
              )}

              {/* Email Receipt */}
              <div className="bg-gray-50 rounded-2xl p-4 space-y-2">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
                  <Mail className="w-3 h-3" /> Email Receipt
                </p>
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={emailInput}
                    onChange={e => setEmailInput(e.target.value)}
                    placeholder="customer@email.com"
                    className="flex-1 px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
                  />
                  <button
                    onClick={async () => {
                      if (!emailInput.includes("@")) { toast.error("Enter a valid email"); return; }
                      setEmailSending(true);
                      const res = await base44.functions.invoke("sendReceiptEmail", {
                        email: emailInput,
                        order_number: order.order_number,
                        order,
                        receipt_url: receiptUrl,
                      });
                      setEmailSending(false);
                      if (res.data?.success) { toast.success("Receipt sent!"); setEmailInput(""); }
                      else toast.error("Failed to send email");
                    }}
                    disabled={emailSending || !emailInput}
                    className="px-4 py-2 bg-violet-600 text-white rounded-xl text-sm font-semibold hover:bg-violet-700 disabled:opacity-50 flex items-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                    {emailSending ? "..." : "Send"}
                  </button>
                </div>
              </div>

              {/* Share Options */}
              <div>
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Share Receipt</p>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  <button
                    onClick={handleNativeShare}
                    className="flex flex-col items-center justify-center gap-2 bg-blue-50 border border-blue-200 text-blue-700 py-3 rounded-xl text-xs font-semibold hover:bg-blue-100 transition"
                  >
                    <Share2 className="w-4 h-4" /> Share
                  </button>
                  <button
                    onClick={copyLink}
                    className="flex flex-col items-center justify-center gap-2 bg-purple-50 border border-purple-200 text-purple-700 py-3 rounded-xl text-xs font-semibold hover:bg-purple-100 transition"
                  >
                    <Copy className="w-4 h-4" /> Copy Link
                  </button>
                  <button
                    onClick={shareMessages}
                    className="flex flex-col items-center justify-center gap-2 bg-green-50 border border-green-200 text-green-700 py-3 rounded-xl text-xs font-semibold hover:bg-green-100 transition"
                  >
                    <Mail className="w-4 h-4" /> Messages
                  </button>
                </div>
                <button
                  onClick={shareEmail}
                  className="w-full flex items-center justify-center gap-2 bg-orange-50 border border-orange-200 text-orange-700 py-2.5 rounded-xl text-sm font-semibold hover:bg-orange-100 transition"
                >
                  <Mail className="w-4 h-4" /> Email
                </button>
              </div>

              <button
                onClick={onPaid}
                className="w-full bg-violet-600 text-white py-3 rounded-2xl font-bold text-sm hover:bg-violet-700 transition"
              >
                Done — Close Table
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}