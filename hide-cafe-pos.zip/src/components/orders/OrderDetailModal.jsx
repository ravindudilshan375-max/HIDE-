import React from "react";
import { X } from "lucide-react";
import { format } from "date-fns";

export default function OrderDetailModal({ order, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-[#16161d] border border-white/10 rounded-3xl w-full max-w-md text-white overflow-hidden">
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
          <div>
            <h2 className="font-bold">Order #{order.order_number || order.id?.slice(-6)}</h2>
            <p className="text-xs text-white/40 mt-0.5 capitalize">{order.type} · {order.status}</p>
          </div>
          <button onClick={onClose} className="text-white/30 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-3 text-sm">
            {order.type === "dine-in" && <Info label="Table" value={`Table ${order.table_number}`} />}
            {order.customer_name && <Info label="Customer" value={order.customer_name} />}
            <Info label="Cashier" value={order.cashier_name} />
            <Info label="Payment" value={order.payment_method} />
            {order.created_date && <Info label="Time" value={format(new Date(order.created_date), "HH:mm, MMM d")} />}
          </div>

          <div className="border-t border-white/10 pt-4">
            <p className="text-xs text-white/40 mb-3">Items</p>
            <div className="space-y-2">
              {order.items?.map((item, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <span className="text-white/70">{item.name} × {item.quantity}</span>
                  <span className="text-white">${item.subtotal?.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-white/10 pt-4 space-y-1.5 text-sm">
            <div className="flex justify-between text-white/50">
              <span>Subtotal</span><span>${order.subtotal?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-white/50">
              <span>Tax</span><span>${order.tax?.toFixed(2)}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-green-400">
                <span>Discount</span><span>-${order.discount?.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-base">
              <span>Total</span><span className="text-amber-400">${order.total?.toFixed(2)}</span>
            </div>
            {order.payment_method === "cash" && order.change_due > 0 && (
              <div className="flex justify-between text-green-400">
                <span>Change Given</span><span>${order.change_due?.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Info({ label, value }) {
  return (
    <div className="bg-white/5 rounded-xl px-3 py-2">
      <p className="text-xs text-white/30 capitalize">{label}</p>
      <p className="text-sm font-medium mt-0.5 capitalize">{value || "—"}</p>
    </div>
  );
}