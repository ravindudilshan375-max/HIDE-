import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, PenLine, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export default function SignatureViewModal({ orderId, orderNumber, onClose }) {
  const [sig, setSig] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.InvoiceSignature.filter({ order_id: orderId })
      .then(results => setSig(results[0] || null))
      .finally(() => setLoading(false));
  }, [orderId]);

  const downloadSignature = () => {
    if (!sig?.signature_image) return;
    const a = document.createElement("a");
    a.href = sig.signature_image;
    a.download = `signature-${orderNumber}.png`;
    a.click();
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <PenLine className="w-4 h-4 text-violet-600" />
            <h2 className="font-bold text-gray-900">Digital Signature</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5">
          {loading && <p className="text-center text-gray-400 py-8 text-sm">Loading...</p>}

          {!loading && !sig && (
            <p className="text-center text-gray-400 py-8 text-sm">No signature found for this order.</p>
          )}

          {!loading && sig && (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-xl px-4 py-3 text-sm space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-gray-500">Order</span>
                  <span className="font-semibold text-gray-800">{sig.order_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Signed by</span>
                  <span className="font-medium text-gray-700">{sig.signed_by_name || "—"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Signed at</span>
                  <span className="font-medium text-gray-700">
                    {sig.signed_at ? format(new Date(sig.signed_at), "dd MMM yyyy HH:mm") : "—"}
                  </span>
                </div>
                {sig.trigger_reason && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Reason</span>
                    <span className="font-medium text-violet-600 capitalize">{sig.trigger_reason.replace("_", " ")}</span>
                  </div>
                )}
                {sig.discount_amount > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Discount</span>
                    <span className="font-medium">−AED {sig.discount_amount.toFixed(2)}</span>
                  </div>
                )}
              </div>

              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Signature</p>
                <div className="border-2 border-gray-200 rounded-xl overflow-hidden bg-white">
                  <img src={sig.signature_image} alt="Customer Signature" className="w-full" />
                </div>
              </div>

              <Button onClick={downloadSignature} variant="outline" className="w-full gap-2 rounded-xl h-10">
                <Download className="w-4 h-4" /> Download Signature
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}