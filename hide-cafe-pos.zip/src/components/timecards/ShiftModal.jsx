import React, { useState, useEffect } from "react";
import { X, Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function ShiftModal({ staff, date, branchId, onClose, onSaved }) {
  const [shiftStart, setShiftStart] = useState("09:00");
  const [shiftEnd, setShiftEnd] = useState("18:00");
  const [gracePeriod, setGracePeriod] = useState(5);
  const [lateRate, setLateRate] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadShift();
  }, []);

  const loadShift = async () => {
    try {
      const shifts = await base44.entities.StaffShift.filter({
        staff_email: staff.staff_email,
        date
      });
      
      if (shifts.length > 0) {
        const shift = shifts[0];
        setShiftStart(shift.shift_start || "09:00");
        setShiftEnd(shift.shift_end || "18:00");
        setGracePeriod(shift.grace_minutes ?? 5);
        setLateRate(shift.late_deduction_rate ?? 1);
      }
    } catch (error) {
      console.log("No existing shift");
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!shiftStart || !shiftEnd) {
      toast.error("Please set both start and end times");
      return;
    }

    setSaving(true);
    try {
      const existing = await base44.entities.StaffShift.filter({
        staff_email: staff.staff_email,
        date
      });

      const shiftData = {
        staff_id: staff.id,
        staff_email: staff.staff_email,
        staff_name: staff.staff_name,
        shift_start: shiftStart,
        shift_end: shiftEnd,
        grace_minutes: gracePeriod,
        late_deduction_rate: lateRate,
        branch_id: branchId
      };

      if (existing.length > 0) {
        await base44.entities.StaffShift.update(existing[0].id, shiftData);
      } else {
        await base44.entities.StaffShift.create({
          ...shiftData,
          date
        });
      }

      toast.success("Shift saved!");
      onSaved?.();
      onClose();
    } catch (error) {
      console.error("Error saving shift:", error);
      toast.error("Failed to save shift");
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-6 w-full max-w-md">
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 text-violet-500 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="font-bold text-gray-900">Set Staff Shift</h2>
            <p className="text-xs text-gray-400 mt-0.5">{staff.staff_name}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Shift Times */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-600 uppercase mb-2">Start Time</label>
              <input
                type="time"
                value={shiftStart}
                onChange={(e) => setShiftStart(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-900 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-600 uppercase mb-2">End Time</label>
              <input
                type="time"
                value={shiftEnd}
                onChange={(e) => setShiftEnd(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-900 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none"
              />
            </div>
          </div>

          {/* Grace Period */}
          <div>
            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">
              Grace Period (minutes)
            </label>
            <input
              type="number"
              min="0"
              max="60"
              value={gracePeriod}
              onChange={(e) => setGracePeriod(Number(e.target.value))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-900 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none"
            />
            <p className="text-xs text-gray-400 mt-1">Time allowed before marking as late</p>
          </div>

          {/* Late Deduction Rate */}
          <div>
            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">
              Late Deduction Rate (AED/minute)
            </label>
            <input
              type="number"
              min="0"
              step="0.5"
              value={lateRate}
              onChange={(e) => setLateRate(Number(e.target.value))}
              className="w-full px-3 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-900 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none"
            />
          </div>

          {/* Preview */}
          <div className="bg-violet-50 border border-violet-100 rounded-xl p-4 text-center">
            <p className="text-xs text-violet-600 uppercase font-semibold mb-2">Shift Preview</p>
            <p className="text-lg font-bold text-violet-700">{shiftStart} - {shiftEnd}</p>
            <p className="text-xs text-violet-500 mt-1">Grace: {gracePeriod}m | Rate: {lateRate} AED/min</p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t border-gray-100">
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1 rounded-lg"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 bg-violet-600 hover:bg-violet-700 text-white rounded-lg gap-2"
          >
            <Save className="w-4 h-4" /> {saving ? "Saving..." : "Save Shift"}
          </Button>
        </div>
      </div>
    </div>
  );
}