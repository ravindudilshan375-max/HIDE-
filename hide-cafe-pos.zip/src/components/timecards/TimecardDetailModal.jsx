import React, { useState } from "react";
import { X, Edit2, Save, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format, parseISO } from "date-fns";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

function formatMinutesToHours(minutes) {
  if (!minutes) return "0h 0m";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h ${m}m`;
}

export default function TimecardDetailModal({ attendance, onClose, onAdjustmentSaved }) {
  const [isEditing, setIsEditing] = useState(false);
  const [adjustmentAmount, setAdjustmentAmount] = useState(attendance?.adjustment_amount || 0);
  const [reason, setReason] = useState(attendance?.adjustment_reason || "");
  const [saving, setSaving] = useState(false);

  const handleSaveAdjustment = async () => {
    setSaving(true);
    const res = await base44.functions.invoke("applyAdjustment", {
      attendance_id: attendance.id,
      adjustment_amount: parseFloat(adjustmentAmount),
      reason
    });

    if (res.data?.success) {
      toast.success("Adjustment saved!");
      setIsEditing(false);
      onAdjustmentSaved?.();
    } else {
      toast.error(res.data?.error || "Failed to save adjustment");
    }
    setSaving(false);
  };

  const workedDisplay = formatMinutesToHours(attendance?.worked_minutes || 0);
  const lateDisplay = formatMinutesToHours(attendance?.late_minutes || 0);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-gray-900">{attendance?.staff_name}</h2>
            <p className="text-xs text-gray-400">{format(parseISO(attendance?.date + "T00:00:00"), "d MMM yyyy")}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-5 space-y-5">

          {/* Clock Times */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-gray-400 uppercase">Clock Times</h3>
            <div className="bg-gray-50 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Clock In</span>
                <span className="font-semibold text-gray-900">
                  {attendance?.clock_in_time ? format(parseISO(attendance.clock_in_time), "HH:mm") : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Clock Out</span>
                <span className="font-semibold text-gray-900">
                  {attendance?.clock_out_time ? format(parseISO(attendance.clock_out_time), "HH:mm") : "—"}
                </span>
              </div>
              <div className="h-px bg-gray-200" />
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-gray-700">Worked Time</span>
                <span className="font-bold text-violet-600 text-base">{workedDisplay}</span>
              </div>
            </div>
          </div>

          {/* Late & Deductions */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-gray-400 uppercase">Late & Deductions</h3>
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-amber-700">Late Minutes</span>
                <span className={`font-semibold ${attendance?.late_minutes > 0 ? "text-red-600" : "text-green-600"}`}>
                  {lateDisplay}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-amber-700">Late Deduction</span>
                <span className="font-bold text-amber-700">{(attendance?.deduction_amount || 0).toFixed(2)} AED</span>
              </div>
            </div>
          </div>

          {/* Adjustment */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-gray-400 uppercase">Adjustment</h3>
              {!isEditing && (
                <button onClick={() => setIsEditing(true)} className="text-violet-600 hover:text-violet-700 p-1">
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {isEditing ? (
              <div className="space-y-3 bg-blue-50 border border-blue-100 rounded-xl p-4">
                <div>
                  <label className="text-xs font-semibold text-blue-700 block mb-1">Amount (AED)</label>
                  <input
                    type="number"
                    value={adjustmentAmount}
                    onChange={(e) => setAdjustmentAmount(e.target.value)}
                    step="0.5"
                    className="w-full px-3 py-2 border border-blue-200 rounded-lg text-sm"
                    placeholder="e.g., -5 (negative to reduce)"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-blue-700 block mb-1">Reason</label>
                  <textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows="2"
                    className="w-full px-3 py-2 border border-blue-200 rounded-lg text-sm resize-none"
                    placeholder="e.g., Traffic delay approved"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => { setIsEditing(false); setAdjustmentAmount(attendance?.adjustment_amount || 0); setReason(attendance?.adjustment_reason || ""); }}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSaveAdjustment}
                    disabled={saving}
                    size="sm"
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white gap-1"
                  >
                    <Save className="w-3.5 h-3.5" /> {saving ? "Saving..." : "Save"}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Adjustment</span>
                  <span className={`font-semibold ${adjustmentAmount < 0 ? "text-green-600" : adjustmentAmount > 0 ? "text-red-600" : "text-gray-600"}`}>
                    {adjustmentAmount >= 0 ? "+" : ""}{adjustmentAmount.toFixed(2)} AED
                  </span>
                </div>
                {reason && <p className="text-xs text-gray-500 italic">Reason: {reason}</p>}
              </div>
            )}
          </div>

          {/* Final Deduction */}
          <div className="bg-violet-50 border border-violet-100 rounded-xl p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-semibold text-violet-900">Final Deduction</span>
              <span className="text-2xl font-bold text-violet-700">{(attendance?.final_deduction || 0).toFixed(2)} AED</span>
            </div>
            <p className="text-xs text-violet-600">({(attendance?.deduction_amount || 0).toFixed(2)} + {adjustmentAmount >= 0 ? "+" : ""}{adjustmentAmount.toFixed(2)})</p>
          </div>

          {/* GPS Location */}
          {attendance?.gps_verified && (
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-gray-400 uppercase">GPS Location</h3>
              <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4 text-green-600" />
                  <span>{attendance?.latitude?.toFixed(4)}, {attendance?.longitude?.toFixed(4)}</span>
                </div>
                <p className="text-xs text-gray-500">{attendance?.gps_distance_meters}m from branch</p>
              </div>
            </div>
          )}

          {/* Status Badge */}
          <div className="flex items-center justify-center pt-3 border-t border-gray-100">
            <span className={`text-xs font-bold px-3 py-1.5 rounded-full ${
              attendance?.status === "on_time" ? "bg-green-100 text-green-700" :
              attendance?.status === "late" ? "bg-amber-100 text-amber-700" :
              "bg-red-100 text-red-700"
            }`}>
              {attendance?.status === "on_time" ? "✓ On Time" : 
               attendance?.status === "late" ? "⏱ Late" : 
               "✕ Absent"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}