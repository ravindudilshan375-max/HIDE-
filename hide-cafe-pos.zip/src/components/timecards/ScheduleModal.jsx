import React, { useState, useEffect } from "react";
import { X, Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function ScheduleModal({ staff, date, branch_id, onClose, onSaved }) {
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("18:00");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSchedule();
  }, []);

  const loadSchedule = async () => {
    try {
      const schedules = await base44.entities.StaffSchedule.filter({
        staff_email: staff.staff_email,
        date
      });
      
      if (schedules.length > 0) {
        setStartTime(schedules[0].shift_start || "09:00");
        setEndTime(schedules[0].shift_end || "18:00");
      }
    } catch (error) {
      console.log("No existing schedule");
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!startTime || !endTime) {
      toast.error("Please set both start and end times");
      return;
    }

    setSaving(true);
    try {
      // Check if schedule exists
      const existing = await base44.entities.StaffSchedule.filter({
        staff_email: staff.staff_email,
        date
      });

      if (existing.length > 0) {
        // Update
        await base44.entities.StaffSchedule.update(existing[0].id, {
          shift_start: startTime,
          shift_end: endTime
        });
      } else {
        // Create
        await base44.entities.StaffSchedule.create({
          staff_email: staff.staff_email,
          staff_name: staff.staff_name,
          date,
          shift_start: startTime,
          shift_end: endTime,
          branch_id
        });
      }

      toast.success("Shift saved!");
      onSaved?.();
      onClose();
    } catch (error) {
      console.error("Error saving schedule:", error);
      toast.error("Failed to save shift");
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 text-violet-500 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="font-bold text-gray-900">Set Shift Time</h2>
            <p className="text-xs text-gray-400 mt-0.5">{staff.staff_name}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          <div>
            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">Start Time</label>
            <input
              type="time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg font-semibold text-gray-900 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">End Time</label>
            <input
              type="time"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg font-semibold text-gray-900 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none"
            />
          </div>

          {/* Preview */}
          <div className="bg-violet-50 border border-violet-100 rounded-xl p-4 text-center">
            <p className="text-xs text-violet-600 uppercase font-semibold mb-1">Shift Preview</p>
            <p className="text-xl font-bold text-violet-700">{startTime} - {endTime}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t border-gray-100">
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1 rounded-lg"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 bg-violet-600 hover:bg-violet-700 text-white rounded-lg gap-2"
          >
            <Save className="w-4 h-4" /> {saving ? "Saving..." : "Save Shift"}
          </Button>
        </div>
      </div>
    </div>
  );
}