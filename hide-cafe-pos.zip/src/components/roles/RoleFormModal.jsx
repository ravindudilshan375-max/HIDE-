import React, { useState } from "react";
import { Copy, Eye, Pencil, Ban } from "lucide-react";

export const PERMISSION_GROUPS = [
  {
    name: "POS & Sales",
    permissions: [
      { key: "pos", label: "POS System" },
      { key: "discounts", label: "Discounts" },
    ]
  },
  {
    name: "Inventory",
    permissions: [
      { key: "inventory", label: "Inventory" },
      { key: "purchase_orders", label: "Purchase Orders" },
      { key: "suppliers", label: "Suppliers" },
    ]
  },
  {
    name: "Orders & Kitchen",
    permissions: [
      { key: "orders", label: "Orders" },
      { key: "kitchen", label: "Kitchen Display" },
    ]
  },
  {
    name: "Menu",
    permissions: [
      { key: "menu", label: "Menu & Products" },
    ]
  },
  {
    name: "Branch Transfers",
    permissions: [
      { key: "branch_transfers_view", label: "View Transfers" },
      { key: "branch_transfers_create", label: "Create Transfer Requests" },
      { key: "branch_transfers_approve", label: "Approve / Reject Transfers" },
      { key: "branch_transfers_complete", label: "Complete Transfers" },
      { key: "branch_transfers_stock", label: "View Stock Overview" },
    ]
  },
  {
    name: "Management",
    permissions: [
      { key: "staff", label: "Staff & Schedules" },
      { key: "reports", label: "Reports & Analytics" },
      { key: "customers", label: "Customers" },
      { key: "settings", label: "Settings" },
    ]
  },
];

// Possible levels per permission
const LEVELS = [
  { value: "none", label: "No Access", icon: Ban, color: "text-gray-400", bg: "bg-gray-100", activeBg: "bg-gray-200 text-gray-700" },
  { value: "view", label: "View Only", icon: Eye, color: "text-blue-500", bg: "bg-blue-50", activeBg: "bg-blue-100 text-blue-700" },
  { value: "manage", label: "Full Access", icon: Pencil, color: "text-violet-500", bg: "bg-violet-50", activeBg: "bg-violet-100 text-violet-700" },
];

export const DEFAULT_PERMISSIONS = Object.fromEntries(
  PERMISSION_GROUPS.flatMap(g => g.permissions.map(p => [p.key, "none"]))
);

function PermissionRow({ label, permKey, value, onChange }) {
  return (
    <div className="flex items-center justify-between py-2.5 border-b border-gray-50 last:border-0">
      <span className="text-sm text-gray-700">{label}</span>
      <div className="flex gap-1">
        {LEVELS.map(level => {
          const Icon = level.icon;
          const active = value === level.value;
          return (
            <button
              key={level.value}
              type="button"
              onClick={() => onChange(permKey, level.value)}
              title={level.label}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                active
                  ? `${level.activeBg} border-current shadow-sm`
                  : "bg-white border-gray-200 text-gray-400 hover:border-gray-300"
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{level.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function RoleFormModal({ editingId, formData, setFormData, branches, roles, onSave, onClose }) {
  const setPermission = (key, level) => {
    setFormData(prev => ({
      ...prev,
      permissions: { ...prev.permissions, [key]: level }
    }));
  };

  const toggleBranch = (branchId) => {
    setFormData(prev => ({
      ...prev,
      applicable_branches: (prev.applicable_branches || []).includes(branchId)
        ? prev.applicable_branches.filter(id => id !== branchId)
        : [...(prev.applicable_branches || []), branchId]
    }));
  };

  const copyFromRole = (roleId) => {
    if (!roleId) return;
    const source = roles.find(r => r.id === roleId);
    if (!source?.permissions) return;
    setFormData(prev => ({ ...prev, permissions: { ...DEFAULT_PERMISSIONS, ...source.permissions } }));
  };

  const otherRoles = roles.filter(r => r.id !== editingId);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="border-b border-gray-200 p-6 flex items-center justify-between shrink-0">
          <h2 className="text-xl font-bold text-gray-900">
            {editingId ? "Edit Role" : "Create Role"}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">✕</button>
        </div>

        <div className="overflow-y-auto flex-1 p-6 space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Role Name *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Cashier"
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
              <textarea
                value={formData.description || ""}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe what this role does..."
                rows={2}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400 resize-none"
              />
            </div>
          </div>

          {/* Copy from role */}
          {otherRoles.length > 0 && (
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 flex items-center gap-3">
              <Copy className="w-4 h-4 text-blue-500 shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-blue-800">Copy permissions from existing role</p>
                <p className="text-xs text-blue-600">This will overwrite the current permission selections below.</p>
              </div>
              <select
                defaultValue=""
                onChange={(e) => copyFromRole(e.target.value)}
                className="border border-blue-200 bg-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-400 text-gray-700"
              >
                <option value="">Select role...</option>
                {otherRoles.map(r => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>
          )}

          {/* Permissions */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-sm font-semibold text-gray-700">Module Permissions</label>
              <div className="flex gap-3 text-xs text-gray-400">
                <span className="flex items-center gap-1"><Ban className="w-3 h-3" /> No Access</span>
                <span className="flex items-center gap-1"><Eye className="w-3 h-3 text-blue-400" /> View Only</span>
                <span className="flex items-center gap-1"><Pencil className="w-3 h-3 text-violet-400" /> Full Access</span>
              </div>
            </div>
            <div className="space-y-4">
              {PERMISSION_GROUPS.map(group => (
                <div key={group.name} className="bg-gray-50 rounded-xl p-4">
                  <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">{group.name}</h4>
                  <div>
                    {group.permissions.map(perm => (
                      <PermissionRow
                        key={perm.key}
                        label={perm.label}
                        permKey={perm.key}
                        value={formData.permissions?.[perm.key] || "none"}
                        onChange={setPermission}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Branches */}
          {branches.length > 0 && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Applicable Branches</label>
              <p className="text-xs text-gray-400 mb-3">Leave empty to apply to all branches</p>
              <div className="flex flex-wrap gap-2">
                {branches.map(branch => {
                  const selected = (formData.applicable_branches || []).includes(branch.id);
                  return (
                    <button
                      key={branch.id}
                      type="button"
                      onClick={() => toggleBranch(branch.id)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition border ${
                        selected
                          ? "bg-violet-600 text-white border-violet-600"
                          : "bg-white text-gray-600 border-gray-200 hover:border-violet-400"
                      }`}
                    >
                      {branch.name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 p-6 flex gap-3 shrink-0">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
          >
            Cancel
          </button>
          <button
            onClick={onSave}
            disabled={!formData.name.trim()}
            className="flex-1 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition"
          >
            {editingId ? "Update Role" : "Create Role"}
          </button>
        </div>
      </div>
    </div>
  );
}