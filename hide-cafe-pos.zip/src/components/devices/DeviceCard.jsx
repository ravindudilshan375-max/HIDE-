import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  Printer, Monitor, LayoutGrid, Bell, CreditCard, Users, Fingerprint,
  Scale, Tablet, Wifi, MoreHorizontal, Pencil, Trash2, RefreshCw
} from "lucide-react";

const TYPE_META = {
  printer:            { label: "Printer",             icon: Printer,       color: "bg-blue-100 text-blue-700" },
  kds:                { label: "KDS",                 icon: Monitor,       color: "bg-orange-100 text-orange-700" },
  load_balancer:      { label: "Load Balancer",       icon: LayoutGrid,    color: "bg-purple-100 text-purple-700" },
  display:            { label: "Display",             icon: Monitor,       color: "bg-cyan-100 text-cyan-700" },
  notifier:           { label: "Notifier",            icon: Bell,          color: "bg-yellow-100 text-yellow-700" },
  payment_terminal:   { label: "Payment Terminal",    icon: CreditCard,    color: "bg-green-100 text-green-700" },
  sub_cashier:        { label: "Sub Cashier",         icon: Users,         color: "bg-indigo-100 text-indigo-700" },
  fingerprint_scanner:{ label: "Fingerprint Scanner", icon: Fingerprint,   color: "bg-red-100 text-red-700" },
  scale:              { label: "Scale",               icon: Scale,         color: "bg-teal-100 text-teal-700" },
  waiter_device:      { label: "Waiter Device",       icon: Tablet,        color: "bg-pink-100 text-pink-700" },
};

export default function DeviceCard({ device, branches, pinging, onPing, onEdit, onDelete }) {
  const meta = TYPE_META[device.device_type] || { label: device.device_type, icon: Wifi, color: "bg-gray-100 text-gray-700" };
  const Icon = meta.icon;
  const online = device.status === "online";
  const branchName = branches.find(b => b.id === device.branch_id)?.name;

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-5 hover:shadow-md transition-shadow">
      {/* Top row */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${meta.color}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <p className="font-semibold text-gray-900 leading-tight">{device.name}</p>
            <p className="text-xs text-gray-400 mt-0.5">{meta.label}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${online ? "bg-green-500" : "bg-gray-300"}`} />
          <span className={`text-xs font-medium ${online ? "text-green-600" : "text-gray-400"}`}>
            {online ? "Online" : "Offline"}
          </span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7 ml-1">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}><Pencil className="w-4 h-4 mr-2" /> Edit</DropdownMenuItem>
              <DropdownMenuItem onClick={onDelete} className="text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Details */}
      <div className="space-y-1.5 text-sm text-gray-600 mb-4">
        {device.ip_address && (
          <div className="flex items-center gap-2">
            <Wifi className="w-3.5 h-3.5 text-gray-400" />
            <span className="font-mono text-xs">{device.ip_address}:{device.port || 9100}</span>
          </div>
        )}
        {device.model && (
          <div className="text-xs text-gray-400">{device.model}</div>
        )}
        {branchName && (
          <Badge variant="outline" className="text-xs">{branchName}</Badge>
        )}
        {device.last_pinged && (
          <div className="text-xs text-gray-400">
            Last pinged: {new Date(device.last_pinged).toLocaleString()}
          </div>
        )}
      </div>

      {/* Ping button */}
      {device.ip_address && (
        <Button
          variant="outline"
          size="sm"
          onClick={onPing}
          disabled={pinging}
          className="w-full gap-2 text-xs"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${pinging ? "animate-spin" : ""}`} />
          {pinging ? "Pinging..." : "Ping Device"}
        </Button>
      )}
    </div>
  );
}