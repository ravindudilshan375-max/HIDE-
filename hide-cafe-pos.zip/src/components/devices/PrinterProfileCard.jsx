import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Printer, MoreHorizontal, Pencil, Trash2, CheckCircle2, Circle } from "lucide-react";

const TYPE_COLORS = {
  receipt: "bg-blue-100 text-blue-700",
  kitchen: "bg-orange-100 text-orange-700",
  drinks:  "bg-cyan-100 text-cyan-700",
  dessert: "bg-pink-100 text-pink-700",
  bar:     "bg-purple-100 text-purple-700",
  kot:     "bg-yellow-100 text-yellow-700",
};

const JOB_LABELS = {
  print_receipts:           "Receipts",
  print_in_person_tickets:  "In-person tickets",
  print_online_tickets:     "Online tickets",
  print_ticket_stubs:       "Ticket stubs",
  print_void_tickets:       "Void tickets",
  print_kot:                "KOT",
};

export default function PrinterProfileCard({ profile, devices, onEdit, onDelete }) {
  const linkedDevice = devices.find(d => d.id === profile.device_id);
  const activeJobs = Object.entries(JOB_LABELS).filter(([k]) => profile[k]);

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${TYPE_COLORS[profile.printer_type] || "bg-gray-100 text-gray-600"}`}>
            <Printer className="w-4 h-4" />
          </div>
          <div>
            <p className="font-semibold text-gray-900">{profile.name}</p>
            <p className="text-xs text-gray-400 capitalize">{profile.printer_type?.replace(/_/g, " ")} · {profile.paper_size}</p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-7 w-7">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onEdit}><Pencil className="w-4 h-4 mr-2" /> Edit</DropdownMenuItem>
            <DropdownMenuItem onClick={onDelete} className="text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Delete</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {linkedDevice && (
        <div className="flex items-center gap-2 mb-3 p-2 bg-gray-50 rounded-lg">
          <span className={`w-2 h-2 rounded-full ${linkedDevice.status === "online" ? "bg-green-500" : "bg-gray-300"}`} />
          <span className="text-xs text-gray-600">{linkedDevice.name}</span>
          {linkedDevice.ip_address && <span className="text-xs text-gray-400 font-mono">{linkedDevice.ip_address}</span>}
        </div>
      )}

      <div className="space-y-1.5">
        {Object.entries(JOB_LABELS).map(([k, label]) => (
          <div key={k} className="flex items-center gap-2 text-xs">
            {profile[k]
              ? <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0" />
              : <Circle className="w-3.5 h-3.5 text-gray-300 shrink-0" />}
            <span className={profile[k] ? "text-gray-700" : "text-gray-300"}>{label}</span>
          </div>
        ))}
      </div>

      {profile.is_backup && (
        <Badge className="mt-3 bg-amber-100 text-amber-700 border-0 text-xs">Backup printer</Badge>
      )}
    </div>
  );
}