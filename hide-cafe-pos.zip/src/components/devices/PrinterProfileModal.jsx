import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Receipt, ChefHat, Coffee, IceCream, Wine, FileText } from "lucide-react";

const PRINTER_TYPES = [
  { value: "receipt",  label: "Receipt Printer",  icon: Receipt },
  { value: "kitchen",  label: "Kitchen Printer",  icon: ChefHat },
  { value: "drinks",   label: "Drinks / Bar",     icon: Coffee },
  { value: "dessert",  label: "Dessert Station",  icon: IceCream },
  { value: "bar",      label: "Bar Printer",      icon: Wine },
  { value: "kot",      label: "KOT Printer",      icon: FileText },
];

const JOB_TYPES = [
  { key: "print_receipts",            label: "Receipts",              desc: "When on, this printer will also print bills, reports and open cash drawers." },
  { key: "print_in_person_tickets",   label: "In-person order tickets", desc: "Use order tickets to send orders to prep stations. Order tickets will print automatically after checkout." },
  { key: "print_online_tickets",      label: "Online order tickets",  desc: "Use online order tickets to send online orders to prep stations." },
  { key: "print_ticket_stubs",        label: "Order ticket stubs",    desc: "Give customers a stub for their order. Order ticket stubs only print after an in-person order ticket is printed." },
  { key: "print_void_tickets",        label: "Void tickets",          desc: "Print a ticket when an item is voided from an order." },
  { key: "print_kot",                 label: "KOT (Kitchen Order Ticket)", desc: "Print kitchen order tickets for food preparation." },
];

function Toggle({ value, onChange }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors shrink-0 ${value ? "bg-gray-900" : "bg-gray-200"}`}
    >
      <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${value ? "translate-x-6" : "translate-x-1"}`} />
    </button>
  );
}

const EMPTY = {
  name: "", printer_type: "receipt", device_id: "", branch_id: "", paper_size: "80mm", is_backup: false,
  print_receipts: false, print_in_person_tickets: false, print_online_tickets: false,
  print_ticket_stubs: false, print_void_tickets: false, print_kot: false,
};

export default function PrinterProfileModal({ profile, devices, branches, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) setForm({ ...EMPTY, ...profile });
    else setForm(EMPTY);
  }, [profile]);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSave = async () => {
    if (!form.name) return;
    setSaving(true);
    if (profile) {
      await base44.entities.PrinterProfile.update(profile.id, form);
    } else {
      await base44.entities.PrinterProfile.create(form);
    }
    setSaving(false);
    onSaved();
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{profile ? "Edit Profile" : "Create profile"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Profile name */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Profile name *</label>
            <Input
              value={form.name}
              onChange={e => set("name", e.target.value)}
              placeholder="e.g. Kitchen Printer, Bar Printer"
              className="text-base"
            />
          </div>

          {/* Printer type */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Printer type</label>
            <div className="grid grid-cols-3 gap-2">
              {PRINTER_TYPES.map(t => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.value}
                    onClick={() => set("printer_type", t.value)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-sm transition-all ${form.printer_type === t.value ? "bg-gray-900 border-gray-900 text-white font-semibold" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    {t.label.split(" ")[0]}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Linked device */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Linked printer device</label>
            <Select value={form.device_id} onValueChange={v => set("device_id", v)}>
              <SelectTrigger><SelectValue placeholder="Select a printer device" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>None</SelectItem>
                {devices.map(d => <SelectItem key={d.id} value={d.id}>{d.name} {d.ip_address ? `(${d.ip_address})` : ""}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {/* Paper size */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-2 block">Paper size</label>
            <div className="flex gap-3">
              {["58mm", "80mm"].map(size => (
                <button
                  key={size}
                  onClick={() => set("paper_size", size)}
                  className={`flex-1 py-2.5 rounded-xl border text-sm font-medium transition-all ${form.paper_size === size ? "bg-gray-900 border-gray-900 text-white" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Branch */}
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Location (Branch)</label>
            <Select value={form.branch_id} onValueChange={v => set("branch_id", v)}>
              <SelectTrigger><SelectValue placeholder="All branches" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>All branches</SelectItem>
                {branches.map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {/* Printer job types */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-1">Printer job types</h3>
            <p className="text-xs text-gray-500 mb-3">Select the items you want to print with this profile.</p>
            <div className="border border-gray-200 rounded-xl divide-y divide-gray-100">
              {JOB_TYPES.map(job => (
                <div key={job.key} className="flex items-start gap-4 p-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{job.label}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{job.desc}</p>
                  </div>
                  <Toggle value={form[job.key]} onChange={v => set(job.key, v)} />
                </div>
              ))}
            </div>
          </div>

          {/* Backup toggle */}
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="text-sm font-medium text-gray-900">Backup printer</p>
              <p className="text-xs text-gray-400">Used as fallback if primary printer is offline</p>
            </div>
            <Toggle value={form.is_backup} onChange={v => set("is_backup", v)} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={!form.name || saving} className="bg-gray-900 text-white">
            {saving ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}