import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Printer, Monitor, LayoutGrid, Bell, CreditCard, Users, Fingerprint, Scale, Tablet, Wifi
} from "lucide-react";

const DEVICE_TYPES = [
  { value: "printer",             label: "Printer",             icon: Printer },
  { value: "kds",                 label: "KDS (Kitchen Display)",icon: Monitor },
  { value: "load_balancer",       label: "Load Balancer",        icon: LayoutGrid },
  { value: "display",             label: "Display",              icon: Monitor },
  { value: "notifier",            label: "Notifier",             icon: Bell },
  { value: "payment_terminal",    label: "Payment Terminal",     icon: CreditCard },
  { value: "sub_cashier",         label: "Sub Cashier",          icon: Users },
  { value: "fingerprint_scanner", label: "Fingerprint Scanner",  icon: Fingerprint },
  { value: "scale",               label: "Scale",                icon: Scale },
  { value: "waiter_device",       label: "Waiter Device",        icon: Tablet },
];

const EMPTY = { name: "", device_type: "printer", model: "", ip_address: "", port: "9100", branch_id: "", notes: "" };

export default function AddDeviceModal({ device, branches, onClose, onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (device) {
      setForm({
        name: device.name || "",
        device_type: device.device_type || "printer",
        model: device.model || "",
        ip_address: device.ip_address || "",
        port: String(device.port || 9100),
        branch_id: device.branch_id || "",
        notes: device.notes || "",
      });
    } else {
      setForm(EMPTY);
    }
  }, [device]);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSave = async () => {
    if (!form.name) return;
    setSaving(true);
    const payload = {
      ...form,
      port: form.port ? parseInt(form.port) : 9100,
      status: "offline",
    };
    if (device) {
      await base44.entities.Device.update(device.id, payload);
    } else {
      await base44.entities.Device.create(payload);
    }
    setSaving(false);
    onSaved();
    onClose();
  };

  const selectedType = DEVICE_TYPES.find(t => t.value === form.device_type);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{device ? "Edit Device" : "Add Device"}</DialogTitle>
        </DialogHeader>

        {/* Device type selector */}
        <div className="grid grid-cols-5 gap-2 my-2">
          {DEVICE_TYPES.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.value}
                onClick={() => set("device_type", t.value)}
                className={`flex flex-col items-center gap-1.5 py-2 px-1 rounded-xl border text-xs transition-all ${form.device_type === t.value ? "bg-gray-900 border-gray-900 text-white" : "border-gray-200 text-gray-500 hover:bg-gray-50"}`}
              >
                <Icon className="w-4 h-4" />
                <span className="leading-tight text-center">{t.label.split(" ")[0]}</span>
              </button>
            );
          })}
        </div>

        <div className="space-y-3 pt-2">
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Device Name *</label>
            <Input value={form.name} onChange={e => set("name", e.target.value)} placeholder={`e.g. ${selectedType?.label || "Device"} 1`} />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Model</label>
            <Input value={form.model} onChange={e => set("model", e.target.value)} placeholder="e.g. Epson TM-T20III" />
          </div>
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="text-sm font-medium text-gray-700 mb-1 block">IP Address</label>
              <Input value={form.ip_address} onChange={e => set("ip_address", e.target.value)} placeholder="10.39.1.201" />
            </div>
            <div className="w-24">
              <label className="text-sm font-medium text-gray-700 mb-1 block">Port</label>
              <Input value={form.port} onChange={e => set("port", e.target.value)} placeholder="9100" type="number" />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Branch / Location</label>
            <Select value={form.branch_id} onValueChange={v => set("branch_id", v)}>
              <SelectTrigger><SelectValue placeholder="Select branch" /></SelectTrigger>
              <SelectContent>
                {branches.map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Notes</label>
            <Input value={form.notes} onChange={e => set("notes", e.target.value)} placeholder="Optional notes" />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={!form.name || saving} className="bg-gray-900 text-white">
            {saving ? "Saving..." : device ? "Save Changes" : "Add Device"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}