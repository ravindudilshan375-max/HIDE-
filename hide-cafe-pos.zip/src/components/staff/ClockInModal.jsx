import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, KeyRound, CheckCircle2, XCircle, Loader2 } from "lucide-react";

function getDistanceMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default function ClockInModal({ staffList, branches, onClose, onClocked }) {
  const [step, setStep] = useState(1);
  const [selectedStaff, setSelectedStaff] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("");
  const [gpsStatus, setGpsStatus] = useState(null); // null | checking | ok | failed
  const [gpsDistance, setGpsDistance] = useState(null);
  const [pin, setPin] = useState("");
  const [pinStatus, setPinStatus] = useState(null); // null | checking | ok | failed
  const [saving, setSaving] = useState(false);
  const [gpsVerified, setGpsVerified] = useState(false);

  const staff = staffList.find(s => s.id === selectedStaff);
  const branch = branches.find(b => b.id === selectedBranch);
  const branchHasGPS = branch?.latitude && branch?.longitude;

  const handleNext = () => {
    if (branchHasGPS) setStep(2);
    else setStep(3);
  };

  const checkGPS = () => {
    setGpsStatus("checking");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const dist = Math.round(getDistanceMeters(
          pos.coords.latitude, pos.coords.longitude,
          parseFloat(branch.latitude), parseFloat(branch.longitude)
        ));
        setGpsDistance(dist);
        const radius = branch.clock_in_radius_meters || 100;
        if (dist <= radius) {
          setGpsStatus("ok");
          setGpsVerified(true);
        } else {
          setGpsStatus("failed");
          setGpsVerified(false);
        }
      },
      () => setGpsStatus("failed")
    );
  };

  const verifyPIN = async () => {
    if (pin.length < 4) return;
    setPinStatus("checking");
    const res = await base44.functions.invoke("verifyStaffPin", { staff_id: staff?.id, pin, branch_id: selectedBranch });
    if (res.data?.success) {
      setPinStatus("ok");
    } else {
      setPinStatus("failed");
      setPin("");
    }
  };

  const handleClockIn = async () => {
    setSaving(true);
    const method = gpsVerified ? "pin_gps" : "pin";
    await base44.entities.StaffTimecard.create({
      staff_email: staff?.staff_id || staff?.name || selectedStaff,
      staff_name: staff?.name || "",
      branch_id: selectedBranch,
      branch_name: branch?.name || "",
      clock_in: new Date().toISOString(),
      status: "active",
      clock_in_method: method,
      gps_verified: gpsVerified,
      gps_distance_meters: gpsDistance,
    });
    setSaving(false);
    onClocked();
    onClose();
  };

  const handlePinKey = (key) => {
    if (key === "⌫") { setPin(p => p.slice(0, -1)); setPinStatus(null); }
    else if (pin.length < 4) setPin(p => p + key);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full p-6">

        {/* Step 1: Select Staff + Branch */}
        {step === 1 && (
          <>
            <h2 className="text-xl font-bold text-gray-900 mb-1">Clock In Staff</h2>
            <p className="text-sm text-gray-400 mb-5">Select staff member and branch</p>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Staff Member *</label>
                <select value={selectedStaff} onChange={e => setSelectedStaff(e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400">
                  <option value="">Select staff…</option>
                  {staffList.map(s => <option key={s.id} value={s.id}>{s.name} — {s.role_type}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Branch *</label>
                <select value={selectedBranch} onChange={e => setSelectedBranch(e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400">
                  <option value="">Select branch…</option>
                  {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              {branch && (
                <div className="bg-gray-50 rounded-xl px-4 py-3 space-y-1.5">
                  <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Security Required</p>
                  <div className="flex gap-2 flex-wrap">
                    {branchHasGPS && (
                      <span className="px-2.5 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">📍 GPS Check</span>
                    )}
                    <span className="px-2.5 py-1 bg-violet-100 text-violet-700 rounded-full text-xs font-semibold">🔐 PIN</span>
                  </div>
                </div>
              )}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
              <button onClick={handleNext} disabled={!selectedStaff || !selectedBranch}
                className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
                Next →
              </button>
            </div>
          </>
        )}

        {/* Step 2: GPS */}
        {step === 2 && (
          <>
            <h2 className="text-xl font-bold text-gray-900 mb-1">GPS Verification</h2>
            <p className="text-sm text-gray-400 mb-5">Confirm you are at {branch?.name}</p>
            <div className="flex flex-col items-center gap-4 py-4 min-h-[140px] justify-center">
              {gpsStatus === null && (
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-3">
                    <MapPin className="w-8 h-8 text-blue-600" />
                  </div>
                  <p className="text-sm text-gray-500 mb-4">Tap to verify your location</p>
                  <button onClick={checkGPS}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition">
                    Check Location
                  </button>
                </div>
              )}
              {gpsStatus === "checking" && (
                <div className="text-center">
                  <Loader2 className="w-10 h-10 text-blue-500 animate-spin mx-auto mb-3" />
                  <p className="text-sm text-gray-500">Getting your location…</p>
                </div>
              )}
              {gpsStatus === "ok" && (
                <div className="text-center">
                  <CheckCircle2 className="w-14 h-14 text-green-500 mx-auto mb-2" />
                  <p className="text-sm font-bold text-green-700">Location Verified ✓</p>
                  <p className="text-xs text-gray-400 mt-1">{gpsDistance}m from {branch?.name}</p>
                </div>
              )}
              {gpsStatus === "failed" && (
                <div className="text-center">
                  <XCircle className="w-14 h-14 text-red-500 mx-auto mb-2" />
                  <p className="text-sm font-bold text-red-700">Outside allowed range</p>
                  {gpsDistance != null && (
                    <p className="text-xs text-gray-400 mt-1">
                      {gpsDistance}m away — max {branch?.clock_in_radius_meters || 100}m
                    </p>
                  )}
                  <button onClick={checkGPS} className="mt-3 text-xs text-blue-600 underline">Try Again</button>
                </div>
              )}
            </div>
            <div className="flex gap-3 mt-2">
              <button onClick={() => setStep(1)} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Back</button>
              <button
                onClick={() => setStep(3)}
                disabled={!gpsStatus || gpsStatus === "checking"}
                className={`flex-1 py-2.5 rounded-xl text-sm font-semibold text-white transition disabled:opacity-40 ${
                  gpsStatus === "ok" ? "bg-green-600 hover:bg-green-700" : "bg-orange-500 hover:bg-orange-600"
                }`}
              >
                {gpsStatus === "ok" ? "Continue →" : "Skip GPS →"}
              </button>
            </div>
          </>
        )}

        {/* Step 3: PIN */}
        {step === 3 && (
          <>
            <h2 className="text-xl font-bold text-gray-900 mb-1">Enter PIN</h2>
            <p className="text-sm text-gray-400 mb-5">{staff?.name}</p>
            <div className="flex flex-col items-center gap-4">
              {/* PIN dots */}
              <div className="flex gap-3">
                {[0, 1, 2, 3].map(i => (
                  <div key={i} className={`w-4 h-4 rounded-full transition-all ${pin.length > i ? "bg-violet-600 scale-110" : "bg-gray-200"}`} />
                ))}
              </div>
              {/* Numpad */}
              <div className="grid grid-cols-3 gap-2 w-full max-w-[200px]">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, "", 0, "⌫"].map((key, i) => (
                  <button key={i}
                    disabled={pinStatus === "checking" || pinStatus === "ok" || key === ""}
                    onClick={() => handlePinKey(String(key))}
                    className={`h-12 rounded-xl font-semibold text-lg transition ${
                      key === "" ? "pointer-events-none invisible" :
                      key === "⌫" ? "bg-gray-100 hover:bg-gray-200 text-gray-600" :
                      "bg-gray-100 hover:bg-violet-100 active:bg-violet-200 text-gray-900"
                    }`}
                  >
                    {key}
                  </button>
                ))}
              </div>
              {pinStatus === "ok" && (
                <div className="flex items-center gap-2 text-green-600 text-sm font-semibold">
                  <CheckCircle2 className="w-4 h-4" /> PIN Verified ✓
                </div>
              )}
              {pinStatus === "failed" && (
                <p className="text-red-500 text-sm font-semibold">Incorrect PIN. Try again.</p>
              )}
              {pinStatus === "checking" && (
                <div className="flex items-center gap-2 text-gray-500 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin" /> Verifying…
                </div>
              )}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => { setStep(branchHasGPS ? 2 : 1); setPin(""); setPinStatus(null); }}
                className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Back</button>
              {pinStatus !== "ok" ? (
                <button onClick={verifyPIN} disabled={pin.length < 4 || pinStatus === "checking"}
                  className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
                  Verify PIN
                </button>
              ) : (
                <button onClick={handleClockIn} disabled={saving}
                  className="flex-1 py-2.5 bg-green-600 hover:bg-green-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
                  {saving ? "Clocking in…" : "✓ Clock In"}
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}