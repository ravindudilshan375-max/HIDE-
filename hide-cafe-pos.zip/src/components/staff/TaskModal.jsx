import React, { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function TaskModal({ users, onSave, onClose, task }) {
  const [form, setForm] = useState(task || { title: "", description: "", assigned_to_email: "", assigned_to_name: "", priority: "medium", due_date: "", status: "pending" });

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = () => {
    if (!form.title.trim()) return;
    onSave(form);
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-[#16161d] border border-white/10 rounded-2xl w-full max-w-md text-white">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <h2 className="font-bold">{task ? "Edit Task" : "New Task"}</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-white/40 hover:text-white" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="text-xs text-white/40 block mb-1">Title *</label>
            <Input value={form.title} onChange={e => set("title", e.target.value)} placeholder="Task title" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl" />
          </div>
          <div>
            <label className="text-xs text-white/40 block mb-1">Description</label>
            <Input value={form.description} onChange={e => set("description", e.target.value)} placeholder="Details..." className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl" />
          </div>
          <div>
            <label className="text-xs text-white/40 block mb-1">Assign To</label>
            <select value={form.assigned_to_email} onChange={e => {
              const u = users.find(u => u.email === e.target.value);
              set("assigned_to_email", e.target.value);
              set("assigned_to_name", u?.full_name || e.target.value);
            }} className="w-full bg-white/5 border border-white/10 text-white text-sm rounded-xl px-3 py-2 focus:outline-none">
              <option value="" className="bg-[#16161d]">Unassigned</option>
              {users.map(u => <option key={u.id} value={u.email} className="bg-[#16161d]">{u.full_name || u.email}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-white/40 block mb-1">Priority</label>
              <select value={form.priority} onChange={e => set("priority", e.target.value)} className="w-full bg-white/5 border border-white/10 text-white text-sm rounded-xl px-3 py-2 focus:outline-none">
                <option value="low" className="bg-[#16161d]">Low</option>
                <option value="medium" className="bg-[#16161d]">Medium</option>
                <option value="high" className="bg-[#16161d]">High</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-white/40 block mb-1">Due Date</label>
              <Input type="date" value={form.due_date} onChange={e => set("due_date", e.target.value)} className="bg-white/5 border-white/10 text-white rounded-xl" />
            </div>
          </div>
        </div>
        <div className="px-6 pb-6 flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1 border-white/10 text-white/60 hover:text-white bg-transparent">Cancel</Button>
          <Button onClick={handleSave} className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-semibold">Save Task</Button>
        </div>
      </div>
    </div>
  );
}