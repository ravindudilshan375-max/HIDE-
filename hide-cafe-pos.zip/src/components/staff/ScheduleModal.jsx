import React, { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ScheduleModal({ users, onSave, onClose, shift }) {
  const [form, setForm] = useState(shift || { staff_email: "", staff_name: "", date: "", shift_start: "09:00", shift_end: "17:00", role: "", notes: "" });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-[#16161d] border border-white/10 rounded-2xl w-full max-w-md text-white">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <h2 className="font-bold">{shift ? "Edit Shift" : "Add Shift"}</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-white/40 hover:text-white" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="text-xs text-white/40 block mb-1">Staff Member *</label>
            <select value={form.staff_email} onChange={e => {
              const u = users.find(u => u.email === e.target.value);
              set("staff_email", e.target.value);
              set("staff_name", u?.full_name || e.target.value);
              set("role", u?.role || "");
            }} className="w-full bg-white/5 border border-white/10 text-white text-sm rounded-xl px-3 py-2 focus:outline-none">
              <option value="" className="bg-[#16161d]">Select staff...</option>
              {users.map(u => <option key={u.id} value={u.email} className="bg-[#16161d]">{u.full_name || u.email}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-white/40 block mb-1">Date *</label>
            <Input type="date" value={form.date} onChange={e => set("date", e.target.value)} className="bg-white/5 border-white/10 text-white rounded-xl" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-white/40 block mb-1">Shift Start</label>
              <Input type="time" value={form.shift_start} onChange={e => set("shift_start", e.target.value)} className="bg-white/5 border-white/10 text-white rounded-xl" />
            </div>
            <div>
              <label className="text-xs text-white/40 block mb-1">Shift End</label>
              <Input type="time" value={form.shift_end} onChange={e => set("shift_end", e.target.value)} className="bg-white/5 border-white/10 text-white rounded-xl" />
            </div>
          </div>
          <div>
            <label className="text-xs text-white/40 block mb-1">Notes</label>
            <Input value={form.notes} onChange={e => set("notes", e.target.value)} placeholder="Optional notes" className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl" />
          </div>
        </div>
        <div className="px-6 pb-6 flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1 border-white/10 text-white/60 hover:text-white bg-transparent">Cancel</Button>
          <Button onClick={() => { if (form.staff_email && form.date) onSave(form); }} className="flex-1 bg-amber-400 hover:bg-amber-300 text-black font-semibold">Save Shift</Button>
        </div>
      </div>
    </div>
  );
}