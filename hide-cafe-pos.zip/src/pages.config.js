/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import ActivityLog from './pages/ActivityLog';
import Analytics from './pages/Analytics';
import AuditLog from './pages/AuditLog';
import BranchLogin from './pages/BranchLogin';
import BranchTransferDashboard from './pages/BranchTransferDashboard';
import Branches from './pages/Branches';
import BusinessDaysReport from './pages/BusinessDaysReport';
import BusinessReports from './pages/BusinessReports';
import CostAdjustment from './pages/CostAdjustment';
import CustomerFeedback from './pages/CustomerFeedback';
import Customers from './pages/Customers';
import Dashboard from './pages/Dashboard';
import DeliveryIntegrations from './pages/DeliveryIntegrations';
import Devices from './pages/Devices';
import DigitalReceipt from './pages/DigitalReceipt';
import DiscountAnalytics from './pages/DiscountAnalytics';
import Discounts from './pages/Discounts';
import DrawerOpsReport from './pages/DrawerOpsReport';
import EndOfDay from './pages/EndOfDay';
import ExpenseCategories from './pages/ExpenseCategories';
import ExpenseDashboard from './pages/ExpenseDashboard';
import Expenses from './pages/Expenses';
import GiftCardsReport from './pages/GiftCardsReport';
import HRDashboard from './pages/HRDashboard';
import HRDepartments from './pages/HRDepartments';
import HRLaborReports from './pages/HRLaborReports';
import HRPayroll from './pages/HRPayroll';
import Integrations from './pages/Integrations';
import Inventory from './pages/Inventory';
import InventoryCategories from './pages/InventoryCategories';
import InventoryCount from './pages/InventoryCount';
import InventoryHub from './pages/InventoryHub';
import InventoryItems from './pages/InventoryItems';
import InventoryManagement from './pages/InventoryManagement';
import InventorySpotCheck from './pages/InventorySpotCheck';
import Kitchen from './pages/Kitchen';
import LoyaltyDashboard from './pages/LoyaltyDashboard';
import LoyaltySignup from './pages/LoyaltySignup';
import Manage from './pages/Manage';
import ManagementAccess from './pages/ManagementAccess';
import ManagementLogin from './pages/ManagementLogin';
import Menu from './pages/Menu';
import MenuCategories from './pages/MenuCategories';
import MenuCombos from './pages/MenuCombos';
import MenuEngineering from './pages/MenuEngineering';
import MenuGroups from './pages/MenuGroups';
import MenuModifiers from './pages/MenuModifiers';
import OrderTransaction from './pages/OrderTransaction';
import Orders from './pages/Orders';
import OwnerDashboard from './pages/OwnerDashboard';
import POS from './pages/POS';
import POSLogin from './pages/POSLogin';
import POSv2 from './pages/POSv2';
import PaymentMethods from './pages/PaymentMethods';
import ProductCost from './pages/ProductCost';
import PurchaseOrders from './pages/PurchaseOrders';
import QuantityAdjustment from './pages/QuantityAdjustment';
import Reasons from './pages/Reasons';
import RecipeImporter from './pages/RecipeImporter';
import ReplenishmentReport from './pages/ReplenishmentReport';
import Reports from './pages/Reports';
import Roles from './pages/Roles';
import Settings from './pages/Settings';
import ShiftsReport from './pages/ShiftsReport';
import Staff from './pages/Staff';
import StaffClockQR from './pages/StaffClockQR';
import StaffManagement from './pages/StaffManagement';
import StaffTimeClock from './pages/StaffTimeClock';
import StaffTimecards from './pages/StaffTimecards';
import Suppliers from './pages/Suppliers';
import Tables from './pages/Tables';
import Tags from './pages/Tags';
import TaxesAndGroups from './pages/TaxesAndGroups';
import TaxesReport from './pages/TaxesReport';
import TillsReport from './pages/TillsReport';
import TipsReport from './pages/TipsReport';
import VoidsReturnsReport from './pages/VoidsReturnsReport';
import WaiterAccess from './pages/WaiterAccess';
import WaiterPOS from './pages/WaiterPOS';
import Warehouses from './pages/Warehouses';
import WasteLog from './pages/WasteLog';
import __Layout from './Layout.jsx';


export const PAGES = {
    "ActivityLog": ActivityLog,
    "Analytics": Analytics,
    "AuditLog": AuditLog,
    "BranchLogin": BranchLogin,
    "BranchTransferDashboard": BranchTransferDashboard,
    "Branches": Branches,
    "BusinessDaysReport": BusinessDaysReport,
    "BusinessReports": BusinessReports,
    "CostAdjustment": CostAdjustment,
    "CustomerFeedback": CustomerFeedback,
    "Customers": Customers,
    "Dashboard": Dashboard,
    "DeliveryIntegrations": DeliveryIntegrations,
    "Devices": Devices,
    "DigitalReceipt": DigitalReceipt,
    "DiscountAnalytics": DiscountAnalytics,
    "Discounts": Discounts,
    "DrawerOpsReport": DrawerOpsReport,
    "EndOfDay": EndOfDay,
    "ExpenseCategories": ExpenseCategories,
    "ExpenseDashboard": ExpenseDashboard,
    "Expenses": Expenses,
    "GiftCardsReport": GiftCardsReport,
    "HRDashboard": HRDashboard,
    "HRDepartments": HRDepartments,
    "HRLaborReports": HRLaborReports,
    "HRPayroll": HRPayroll,
    "Integrations": Integrations,
    "Inventory": Inventory,
    "InventoryCategories": InventoryCategories,
    "InventoryCount": InventoryCount,
    "InventoryHub": InventoryHub,
    "InventoryItems": InventoryItems,
    "InventoryManagement": InventoryManagement,
    "InventorySpotCheck": InventorySpotCheck,
    "Kitchen": Kitchen,
    "LoyaltyDashboard": LoyaltyDashboard,
    "LoyaltySignup": LoyaltySignup,
    "Manage": Manage,
    "ManagementAccess": ManagementAccess,
    "ManagementLogin": ManagementLogin,
    "Menu": Menu,
    "MenuCategories": MenuCategories,
    "MenuCombos": MenuCombos,
    "MenuEngineering": MenuEngineering,
    "MenuGroups": MenuGroups,
    "MenuModifiers": MenuModifiers,
    "OrderTransaction": OrderTransaction,
    "Orders": Orders,
    "OwnerDashboard": OwnerDashboard,
    "POS": POS,
    "POSLogin": POSLogin,
    "POSv2": POSv2,
    "PaymentMethods": PaymentMethods,
    "ProductCost": ProductCost,
    "PurchaseOrders": PurchaseOrders,
    "QuantityAdjustment": QuantityAdjustment,
    "Reasons": Reasons,
    "RecipeImporter": RecipeImporter,
    "ReplenishmentReport": ReplenishmentReport,
    "Reports": Reports,
    "Roles": Roles,
    "Settings": Settings,
    "ShiftsReport": ShiftsReport,
    "Staff": Staff,
    "StaffClockQR": StaffClockQR,
    "StaffManagement": StaffManagement,
    "StaffTimeClock": StaffTimeClock,
    "StaffTimecards": StaffTimecards,
    "Suppliers": Suppliers,
    "Tables": Tables,
    "Tags": Tags,
    "TaxesAndGroups": TaxesAndGroups,
    "TaxesReport": TaxesReport,
    "TillsReport": TillsReport,
    "TipsReport": TipsReport,
    "VoidsReturnsReport": VoidsReturnsReport,
    "WaiterAccess": WaiterAccess,
    "WaiterPOS": WaiterPOS,
    "Warehouses": Warehouses,
    "WasteLog": WasteLog,
}

export const pagesConfig = {
    mainPage: "DigitalReceipt",
    Pages: PAGES,
    Layout: __Layout,
};