import React, { useState } from "react";
import { createPageUrl } from "@/utils";
import { Copy, Check, QrCode, Link2, LayoutDashboard, Shield, Info, KeyRound, ChefHat } from "lucide-react";
import { toast } from "sonner";

const ROLES = [
  { role: "Admin",      description: "Full access to all features, settings, and reports" },
  { role: "Manager",    description: "Access to orders, staff, branches, and reports" },
  { role: "CEO",        description: "Full business overview including analytics and profit" },
  { role: "Accountant", description: "Financial reports, VAT, and payment summaries" },
];

export default function ManagementAccess() {
  const [copied, setCopied] = useState(false);
  const [copiedPin, setCopiedPin] = useState(false);

  const dashboardUrl = `${window.location.origin}${createPageUrl("Dashboard")}`;
  const pinLoginUrl = `${window.location.origin}${createPageUrl("ManagementLogin")}`;
  const kitchenUrl = `${window.location.origin}${createPageUrl("Kitchen")}`;
  const [copiedKitchen, setCopiedKitchen] = useState(false);

  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(dashboardUrl)}&size=280x280&margin=12`;
  const pinQrSrc = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(pinLoginUrl)}&size=200x200&margin=10`;
  const kitchenQrSrc = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(kitchenUrl)}&size=200x200&margin=10`;

  const copyKitchenLink = () => {
    navigator.clipboard.writeText(kitchenUrl);
    setCopiedKitchen(true);
    toast.success("Kitchen link copied!");
    setTimeout(() => setCopiedKitchen(false), 2000);
  };

  const copyPinLink = () => {
    navigator.clipboard.writeText(pinLoginUrl);
    setCopiedPin(true);
    toast.success("PIN login link copied!");
    setTimeout(() => setCopiedPin(false), 2000);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(dashboardUrl);
    setCopied(true);
    toast.success("Dashboard link copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-2xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Management Dashboard Access</h1>
          <p className="text-sm text-gray-500 mt-1">Share this link or QR code with managers, CEO, and authorized staff to access the business dashboard.</p>
        </div>

        {/* QR + Link Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 flex flex-col items-center text-center">
          <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center mb-4">
            <LayoutDashboard className="w-6 h-6 text-violet-600" />
          </div>
          <h2 className="font-bold text-gray-900 text-lg mb-1">Scan to Open Dashboard</h2>
          <p className="text-sm text-gray-400 mb-6">Management scans this QR code to access the business dashboard on any device</p>

          <div className="bg-gray-50 rounded-2xl p-4 mb-6 border border-gray-100">
            <img src={qrSrc} alt="Dashboard QR Code" className="w-56 h-56 rounded-xl" />
          </div>

          {/* URL display */}
          <div className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3">
            <Link2 className="w-4 h-4 text-gray-400 shrink-0" />
            <span className="flex-1 text-sm text-gray-600 truncate text-left">{dashboardUrl}</span>
            <button
              onClick={copyLink}
              className="shrink-0 flex items-center gap-1.5 bg-violet-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-violet-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>

        {/* How it works */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <QrCode className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">How Management Accesses the Dashboard</h3>
              <p className="text-xs text-gray-400">Secure login via the Base44 platform</p>
            </div>
          </div>

          <ol className="space-y-3">
            {[
              { step: "1", text: "Share the QR code or link with authorized staff" },
              { step: "2", text: "Staff open the link — if not logged in, they'll be prompted to sign in" },
              { step: "3", text: "After login, they land on the full business dashboard" },
              { step: "4", text: "Access is controlled by their account role (Admin / Manager)" },
            ].map(({ step, text }) => (
              <li key={step} className="flex items-center gap-3">
                <span className="w-7 h-7 rounded-full bg-violet-100 text-violet-700 text-xs font-bold flex items-center justify-center shrink-0">{step}</span>
                <span className="text-sm text-gray-600">{text}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Role access */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-4 h-4 text-violet-600" />
            <h3 className="font-bold text-gray-900">Who Can Access</h3>
          </div>
          <div className="space-y-3">
            {ROLES.map(({ role, description }) => (
              <div key={role} className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
                <span className="bg-violet-100 text-violet-700 text-xs font-bold px-2 py-1 rounded-lg shrink-0">{role}</span>
                <p className="text-sm text-gray-600 mt-0.5">{description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* PIN Login Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 bg-violet-100 rounded-xl flex items-center justify-center">
              <KeyRound className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">PIN Code Login</h3>
              <p className="text-xs text-gray-400">Staff log in with Staff ID + PIN — no email required</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100 shrink-0">
              <img src={pinQrSrc} alt="PIN Login QR" className="w-40 h-40 rounded-lg" />
            </div>
            <div className="flex-1 w-full">
              <p className="text-sm text-gray-500 mb-3">Share this link with managers and admins to log in via PIN code:</p>
              <div className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3 mb-3">
                <Link2 className="w-4 h-4 text-gray-400 shrink-0" />
                <span className="flex-1 text-sm text-gray-600 truncate text-left">{pinLoginUrl}</span>
                <button
                  onClick={copyPinLink}
                  className="shrink-0 flex items-center gap-1.5 bg-violet-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-violet-700 transition"
                >
                  {copiedPin ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedPin ? "Copied!" : "Copy"}
                </button>
              </div>
              <ol className="space-y-1.5">
                {["Staff opens the link on their device", "Enters their Staff ID", "Enters their PIN code", "Redirected to the dashboard"].map((step, i) => (
                  <li key={i} className="flex items-center gap-2 text-xs text-gray-500">
                    <span className="w-5 h-5 rounded-full bg-violet-100 text-violet-700 font-bold flex items-center justify-center shrink-0 text-[10px]">{i + 1}</span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        {/* Kitchen Display Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center">
              <ChefHat className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Kitchen Display Screen (KDS)</h3>
              <p className="text-xs text-gray-400">Kitchen staff scan to open the order display</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="bg-orange-50 rounded-2xl p-3 border border-orange-100 shrink-0 text-center">
              <img src={kitchenQrSrc} alt="Kitchen QR" className="w-40 h-40 rounded-lg" />
              <p className="text-[10px] text-orange-500 font-semibold mt-2 uppercase tracking-wider">Kitchen Display</p>
            </div>
            <div className="flex-1 w-full">
              <p className="text-sm text-gray-500 mb-3">Post this QR code in the kitchen. Staff scan it to open the order display screen:</p>
              <div className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3 mb-3">
                <Link2 className="w-4 h-4 text-gray-400 shrink-0" />
                <span className="flex-1 text-sm text-gray-600 truncate text-left">{kitchenUrl}</span>
                <button
                  onClick={copyKitchenLink}
                  className="shrink-0 flex items-center gap-1.5 bg-orange-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-orange-600 transition"
                >
                  {copiedKitchen ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKitchen ? "Copied!" : "Copy"}
                </button>
              </div>
              <ol className="space-y-1.5">
                {["Scan the QR code with phone camera", "Kitchen Display page opens", "Orders from POS appear in real-time", "Tap 'Mark Ready' when item is prepared"].map((step, i) => (
                  <li key={i} className="flex items-center gap-2 text-xs text-gray-500">
                    <span className="w-5 h-5 rounded-full bg-orange-100 text-orange-600 font-bold flex items-center justify-center shrink-0 text-[10px]">{i + 1}</span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        {/* Note */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-blue-800">Invite users to grant access</p>
            <p className="text-xs text-blue-700 mt-0.5">
              To give someone dashboard access, go to <strong>Settings → Users</strong> and invite them. They'll receive a login email and can access the dashboard immediately.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}