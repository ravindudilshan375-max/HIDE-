import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { AlertTriangle, Edit2, Save, X, RefreshCw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Inventory() {
  const [items, setItems] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [editValues, setEditValues] = useState({});
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("all");

  useEffect(() => {
    Promise.all([
      base44.entities.MenuItem.list(),
      base44.entities.Branch.list(),
    ]).then(([menuItems, branchList]) => {
      setItems(menuItems);
      setBranches(branchList);
      setLoading(false);
    });
  }, []);

  const reload = () => {
    setLoading(true);
    base44.entities.MenuItem.list().then(data => { setItems(data); setLoading(false); });
  };

  const startEdit = (item) => {
    setEditingId(item.id);
    setEditValues({
      stock_quantity: item.stock_quantity ?? "",
      cost_price: item.cost_price ?? "",
      low_stock_threshold: item.low_stock_threshold ?? 10,
    });
  };

  const saveEdit = async (id) => {
    const updates = {
      stock_quantity: editValues.stock_quantity !== "" ? Number(editValues.stock_quantity) : null,
      cost_price: editValues.cost_price !== "" ? Number(editValues.cost_price) : 0,
      low_stock_threshold: Number(editValues.low_stock_threshold) || 10,
    };
    await base44.entities.MenuItem.update(id, updates);
    setEditingId(null);
    reload();
  };

  const filtered = useMemo(() => {
    let f = items;
    if (selectedBranch !== "all") f = f.filter(i => i.branch_id === selectedBranch);
    if (search) f = f.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));
    const threshold = (item) => item.low_stock_threshold ?? 10;
    if (filter === "low") f = f.filter(i => i.stock_quantity !== null && i.stock_quantity > 0 && i.stock_quantity <= threshold(i));
    if (filter === "out") f = f.filter(i => i.stock_quantity === 0);
    return f;
  }, [items, filter, search, selectedBranch]);

  const stats = useMemo(() => {
    const threshold = (item) => item.low_stock_threshold ?? 10;
    const tracked = items.filter(i => i.stock_quantity !== null && i.stock_quantity !== undefined);
    return {
      total: items.length,
      tracked: tracked.length,
      low: tracked.filter(i => i.stock_quantity > 0 && i.stock_quantity <= threshold(i)).length,
      out: tracked.filter(i => i.stock_quantity === 0).length,
    };
  }, [items]);

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-6">

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
              <Link to={createPageUrl("InventoryHub")} className="hover:text-violet-600 transition">Inventory</Link>
              <span>/</span><span className="text-gray-600">Stock Levels</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Stock Levels</h1>
            <p className="text-gray-400 text-sm mt-0.5">Track and manage stock by branch. POS auto-deducts on each sale.</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {branches.length > 1 && (
              <select value={selectedBranch} onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <button onClick={reload} className="flex items-center gap-1.5 text-sm bg-white border border-gray-200 hover:border-violet-400 text-gray-600 px-3 py-2 rounded-xl transition">
              <RefreshCw className="w-4 h-4" /> Refresh
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total Items", value: stats.total, cls: "text-gray-900" },
            { label: "Being Tracked", value: stats.tracked, cls: "text-gray-900" },
            { label: "Low Stock", value: stats.low, cls: "text-orange-600", bg: "bg-orange-50 border-orange-200" },
            { label: "Out of Stock", value: stats.out, cls: "text-red-600", bg: "bg-red-50 border-red-200" },
          ].map(({ label, value, cls, bg }) => (
            <div key={label} className={`${bg || "bg-white border-gray-100"} border rounded-2xl p-4 shadow-sm`}>
              <p className="text-xs text-gray-400">{label}</p>
              <p className={`text-2xl font-bold mt-1 ${cls}`}>{value}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          <Input placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} className="w-48 bg-white border-gray-200 rounded-xl text-sm" />
          {["all", "low", "out"].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all capitalize ${
                filter === f ? "bg-violet-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:border-violet-300"
              }`}>
              {f === "all" ? `All (${items.length})` : f === "low" ? `Low Stock (${stats.low})` : `Out of Stock (${stats.out})`}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
          <div className="grid grid-cols-12 px-5 py-3 border-b border-gray-100 bg-gray-50 text-xs font-semibold text-gray-400 uppercase tracking-wide">
            <span className="col-span-4">Item</span>
            <span className="col-span-1">Category</span>
            <span className="col-span-1 text-right">Price</span>
            <span className="col-span-1 text-right">Cost</span>
            <span className="col-span-2 text-right">Stock</span>
            <span className="col-span-1 text-right">Threshold</span>
            <span className="col-span-1 text-center">Status</span>
            <span className="col-span-1"></span>
          </div>

          {loading ? (
            <p className="py-16 text-center text-gray-300">Loading...</p>
          ) : filtered.length === 0 ? (
            <p className="py-16 text-center text-gray-300">No items found</p>
          ) : (
            filtered.map(item => {
              const stock = item.stock_quantity ?? null;
              const isTracked = stock !== null;
              const threshold = item.low_stock_threshold ?? 10;
              const isLow = isTracked && stock > 0 && stock <= threshold;
              const isOut = stock === 0;
              const isEditing = editingId === item.id;

              return (
                <div key={item.id}
                  className={`grid grid-cols-12 px-5 py-3.5 border-b border-gray-50 hover:bg-gray-50 transition items-center text-sm ${isOut ? "bg-red-50/40" : isLow ? "bg-amber-50/40" : ""}`}>

                  <div className="col-span-4 flex items-center gap-2">
                    {item.image_url && <img src={item.image_url} alt={item.name} className="w-8 h-8 rounded-lg object-cover" />}
                    <p className="font-medium text-gray-800">{item.name}</p>
                  </div>
                  <div className="col-span-1 text-gray-400 text-xs">{item.category || "—"}</div>
                  <div className="col-span-1 text-right text-gray-700 font-semibold">${item.base_price?.toFixed(2)}</div>

                  {/* Cost */}
                  <div className="col-span-1 text-right">
                    {isEditing ? (
                      <Input type="number" min="0" step="0.01" value={editValues.cost_price}
                        onChange={e => setEditValues(v => ({ ...v, cost_price: e.target.value }))}
                        className="w-20 text-right border-gray-200 rounded-lg text-xs h-7 ml-auto" />
                    ) : (
                      <span className="text-gray-500 text-xs">${(item.cost_price || 0).toFixed(2)}</span>
                    )}
                  </div>

                  {/* Stock */}
                  <div className="col-span-2 text-right">
                    {isEditing ? (
                      <Input type="number" min="0" value={editValues.stock_quantity}
                        onChange={e => setEditValues(v => ({ ...v, stock_quantity: e.target.value }))}
                        className="w-20 text-right border-gray-200 rounded-lg text-xs h-7 ml-auto" />
                    ) : (
                      <span className={`font-bold ${isOut ? "text-red-600" : isLow ? "text-orange-600" : "text-gray-800"}`}>
                        {isTracked ? stock : <span className="text-gray-300 font-normal text-xs">untracked</span>}
                      </span>
                    )}
                  </div>

                  {/* Threshold */}
                  <div className="col-span-1 text-right">
                    {isEditing ? (
                      <Input type="number" min="1" value={editValues.low_stock_threshold}
                        onChange={e => setEditValues(v => ({ ...v, low_stock_threshold: e.target.value }))}
                        className="w-16 text-right border-gray-200 rounded-lg text-xs h-7 ml-auto" />
                    ) : (
                      <span className="text-gray-300 text-xs">{threshold}</span>
                    )}
                  </div>

                  {/* Status badge */}
                  <div className="col-span-1 text-center">
                    {!isTracked ? (
                      <span className="text-xs text-gray-300">—</span>
                    ) : isOut ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-medium">
                        <AlertTriangle className="w-3 h-3" /> Out
                      </span>
                    ) : isLow ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-medium">
                        <AlertTriangle className="w-3 h-3" /> Low
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-medium">OK</span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="col-span-1 flex items-center justify-end gap-1">
                    {isEditing ? (
                      <>
                        <button onClick={() => saveEdit(item.id)} className="p-1.5 rounded-lg hover:bg-green-100 text-gray-400 hover:text-green-600 transition">
                          <Save className="w-4 h-4" />
                        </button>
                        <button onClick={() => setEditingId(null)} className="p-1.5 rounded-lg hover:bg-gray-200 text-gray-400 hover:text-gray-600 transition">
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <button onClick={() => startEdit(item)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-300 hover:text-gray-600 transition">
                        <Edit2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}