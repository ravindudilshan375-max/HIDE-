import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Upload, Download, Filter, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import ProductDetail from "@/components/menu/ProductDetail.jsx";
import ProductForm from "@/components/menu/ProductForm.jsx";
import MenuImportExport from "@/components/menu/MenuImportExport.jsx";

export default function Menu() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("all");
  const [selected, setSelected] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [branches, setBranches] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [modifierGroups, setModifierGroups] = useState([]);
  const [showImportExport, setShowImportExport] = useState(false);
  const [importExportType, setImportExportType] = useState("products"); // products | recipes | modifiers
  const [importDropOpen, setImportDropOpen] = useState(false);
  const [exportDropOpen, setExportDropOpen] = useState(false);
  const importRef = useRef(null);
  const exportRef = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (importRef.current && !importRef.current.contains(e.target)) setImportDropOpen(false);
      if (exportRef.current && !exportRef.current.contains(e.target)) setExportDropOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const [itemsData, branchData, invData, modData] = await Promise.all([
      base44.entities.MenuItem.list("category"),
      base44.entities.Branch.list(),
      base44.entities.InventoryItem.list("name"),
      base44.entities.ModifierGroup.list("name"),
    ]);
    setItems(itemsData);
    setBranches(branchData);
    setInventoryItems(invData);
    setModifierGroups(modData);
    setLoading(false);
  };

  const filteredItems = items.filter(item => {
    if (tab === "active") return item.is_available !== false;
    if (tab === "inactive") return item.is_available === false;
    return true;
  });

  const toggleSelect = (id) => setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const toggleAll = () => selected.length === filteredItems.length ? setSelected([]) : setSelected(filteredItems.map(i => i.id));



  const handleSaved = () => {
    setShowCreate(false);
    setSelectedItem(null);
    load();
  };

  if (showCreate) {
    return (
      <ProductForm
        branches={branches}
        inventoryItems={inventoryItems}
        onSaved={handleSaved}
        onCancel={() => setShowCreate(false)}
      />
    );
  }

  if (selectedItem) {
    return (
      <ProductDetail
        item={selectedItem}
        branches={branches}
        inventoryItems={inventoryItems}
        modifierGroups={modifierGroups}
        onBack={() => setSelectedItem(null)}
        onSaved={() => { load(); setSelectedItem(null); }}
      />
    );
  }

  return (
    <>
    {showImportExport && (
      <MenuImportExport
        type={importExportType}
        branches={branches}
        inventoryItems={inventoryItems}
        modifierGroups={modifierGroups}
        onClose={() => setShowImportExport(false)}
        onImportComplete={() => { load(); setShowImportExport(false); }}
      />
    )}
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-5">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              Products
              <span className="w-5 h-5 rounded-full bg-gray-200 text-gray-500 text-xs flex items-center justify-center font-bold cursor-help" title="Manage your menu items">?</span>
            </h1>
            <p className="text-sm text-gray-400 mt-0.5">Manage your menu items</p>
          </div>
          <div className="flex items-center gap-2">
            {/* Import dropdown */}
            <div className="relative" ref={importRef}>
              <Button
                variant="outline"
                className="border-gray-200 rounded-xl gap-2 text-sm font-medium"
                onClick={() => { setImportDropOpen(v => !v); setExportDropOpen(false); }}
              >
                <Upload className="w-4 h-4" /> Import <ChevronDown className="w-3.5 h-3.5" />
              </Button>
              {importDropOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white border border-gray-100 rounded-xl shadow-lg z-20 w-52 overflow-hidden">
                  {[
                    { label: "Import Products", type: "products" },
                    { label: "Import Recipes", type: "recipes" },
                    { label: "Import Modifier Groups", type: "modifiers" },
                  ].map(({ label, type }) => (
                    <button
                      key={type}
                      className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-violet-50 hover:text-violet-700 transition"
                      onClick={() => { setImportExportType(type); setShowImportExport(true); setImportDropOpen(false); }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Export dropdown */}
            <div className="relative" ref={exportRef}>
              <Button
                variant="outline"
                className="border-gray-200 rounded-xl gap-2 text-sm font-medium"
                onClick={() => { setExportDropOpen(v => !v); setImportDropOpen(false); }}
              >
                <Download className="w-4 h-4" /> Export <ChevronDown className="w-3.5 h-3.5" />
              </Button>
              {exportDropOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white border border-gray-100 rounded-xl shadow-lg z-20 w-52 overflow-hidden">
                  {[
                    { label: "Export Products", type: "products" },
                    { label: "Export Recipes", type: "recipes" },
                    { label: "Export Modifier Groups", type: "modifiers" },
                  ].map(({ label, type }) => (
                    <button
                      key={type}
                      className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700 transition"
                      onClick={() => { setImportExportType(type); setShowImportExport(true); setExportDropOpen(false); }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <Button
              onClick={() => setShowCreate(true)}
              className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Product
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {/* Tabs + Filter */}
          <div className="flex items-center justify-between px-5 pt-4 pb-0 border-b border-gray-100">
            <div className="flex gap-1">
              {["all", "active", "inactive", "deleted"].map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`px-4 py-2 text-sm font-medium rounded-t-lg capitalize transition border-b-2 ${
                    tab === t
                      ? "border-violet-600 text-violet-700"
                      : "border-transparent text-gray-400 hover:text-gray-700"
                  }`}
                >
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>
            <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm mb-2">
              <Filter className="w-4 h-4" />
              Filter
            </Button>
          </div>

          {loading ? (
            <div className="text-center py-16 text-gray-300 text-sm">Loading...</div>
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-16 text-gray-300 text-sm">No products found</div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="pl-5 py-3 w-8">
                    <input
                      type="checkbox"
                      className="rounded border-gray-300 text-violet-600"
                      checked={selected.length === filteredItems.length && filteredItems.length > 0}
                      onChange={toggleAll}
                    />
                  </th>
                  <th className="w-10 py-3" />
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Name</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">SKU</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Category</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Price</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Tax Group</th>
                  <th className="py-3 pr-5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Active</th>
                </tr>
              </thead>
              <tbody>
                {filteredItems.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition cursor-pointer"
                    onClick={() => setSelectedItem(item)}
                  >
                    <td className="pl-5 py-3.5" onClick={e => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-violet-600"
                        checked={selected.includes(item.id)}
                        onChange={() => toggleSelect(item.id)}
                      />
                    </td>
                    <td className="py-3.5" onClick={e => e.stopPropagation()}>
                      {item.image_url ? (
                        <img src={item.image_url} alt={item.name} className="w-9 h-9 object-cover rounded-lg border border-gray-100" />
                      ) : (
                        <div className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center text-gray-300 text-xs font-bold">
                          {item.name?.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm font-semibold text-gray-800">{item.name}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-gray-500 font-mono">{item.sku || "—"}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-gray-600">{item.category || "—"}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-gray-800">฿ {item.base_price ?? "—"}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-gray-500">VAT</span>
                    </td>
                    <td className="py-3.5 pr-5">
                      <span className={`text-sm font-medium ${item.is_available !== false ? "text-green-600" : "text-gray-400"}`}>
                        {item.is_available !== false ? "Active" : "Inactive"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
    </>
  );
}