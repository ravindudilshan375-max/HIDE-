import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import CheckoutModal from "@/components/pos/CheckoutModal";
import ItemCustomizerModal from "@/components/pos/ItemCustomizerModal";
import CustomItemModal from "@/components/pos/CustomItemModal";
import CustomerPicker from "@/components/pos/CustomerPicker";
import VariantSelector from "@/components/pos/VariantSelector";
import ReprintModal from "@/components/pos/ReprintModal";
import OpenTicketsModal from "@/components/pos/OpenTicketsModal";
import POSMoreMenu from "@/components/pos/POSMoreMenu";
import VoidModal from "@/components/pos/VoidModal";
import LoyaltyScanModal from "@/components/pos/LoyaltyScanModal";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import {
  Printer, ChefHat, Ban, Percent, MoreHorizontal,
  Search, Home, ClipboardList, LayoutGrid, Plus, Minus, Trash2,
  ShoppingBag, UtensilsCrossed, UserPlus, CheckCircle2, XCircle, Ticket, X, Tag, Zap, AlertCircle, QrCode, Star
} from "lucide-react";

const ACTION_BTNS = [
  { icon: Printer, label: "Print" },
  { icon: Ban, label: "Void" },
  { icon: Percent, label: "Discount" },
  { icon: Ticket, label: "Tickets" },
  { icon: MoreHorizontal, label: "More" },
];

export default function POS() {
  const [menuItems, setMenuItems] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [orderType, setOrderType] = useState("takeaway");
  const [selectedTable, setSelectedTable] = useState(null);
  const [tables, setTables] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [loyaltyCustomer, setLoyaltyCustomer] = useState(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [user, setUser] = useState(null);
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [customizerItem, setCustomizerItem] = useState(null);
  const [showCustomItem, setShowCustomItem] = useState(false);
  const [paymentBanner, setPaymentBanner] = useState(null);
  const [sendingToKitchen, setSendingToKitchen] = useState(false);
  const [kitchenMsg, setKitchenMsg] = useState(null);
  const [showCustomerPicker, setShowCustomerPicker] = useState(false);
  const [discountPct, setDiscountPct] = useState(0);
  const [showDiscountInput, setShowDiscountInput] = useState(false);
  const [variantItem, setVariantItem] = useState(null);
  const [showVoidConfirm, setShowVoidConfirm] = useState(false);
  const [selectedCartItem, setSelectedCartItem] = useState(null);
  const [voidMode, setVoidMode] = useState(null); // "item" | "order"
  const [showReprint, setShowReprint] = useState(false);
  const [showTickets, setShowTickets] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showPromoMenu, setShowPromoMenu] = useState(false);
  const [activePromos, setActivePromos] = useState([]);
  const [branch, setBranch] = useState(null);
  const [printers, setPrinters] = useState([]);
  const [voidReasons, setVoidReasons] = useState([]);
  const [selectedVoidReason, setSelectedVoidReason] = useState("");
  const [taxGroups, setTaxGroups] = useState([]);
  const [selectedTaxGroup, setSelectedTaxGroup] = useState(null);
  const [showLoyaltyScan, setShowLoyaltyScan] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    base44.entities.MenuItem.filter({ is_available: true }).then(setMenuItems);
    base44.entities.Table.list().then(setTables);
    base44.entities.Branch.list().then(branches => {
      if (branches.length > 0) setBranch(branches[0]);
    });

    // Load void reasons
    base44.entities.Reason.filter({ category: "void_and_return", is_deleted: false })
      .then(setVoidReasons)
      .catch(() => {});

    // Load tax groups and auto-select first active one
    base44.entities.TaxGroup?.list()
      .then(groups => {
        const active = groups.filter(g => g.is_active !== false);
        setTaxGroups(active);
        if (active.length > 0) setSelectedTaxGroup(active[0]);
      })
      .catch(() => {});

    // Load active promos
    const loadPromos = async () => {
      const allDiscounts = await base44.entities.Discount.list();
      const today = new Date().toISOString().split("T")[0];
      const active = allDiscounts.filter(d => {
        if (!d.is_active) return false;
        if (d.start_date && d.start_date > today) return false;
        if (d.end_date && d.end_date < today) return false;
        if (d.usage_limit > 0 && d.times_used >= d.usage_limit) return false;
        return true;
      });
      setActivePromos(active);
    };
    loadPromos();

    // Load printers
    try {
      const stored = JSON.parse(localStorage.getItem("pos_printers") || "[]");
      setPrinters(stored);
    } catch { }

    // Subscribe to discount changes
    const unsubscribeDiscounts = base44.entities.Discount.subscribe((event) => {
      loadPromos();
    });

    const handleAIAdd = (e) => addToCart(e.detail);
    window.addEventListener("pos:addItem", handleAIAdd);

    const handlePromoApply = (e) => {
      const promo = e.detail;
      if (!promo) return;
      
      const currentSubtotal = cartItems.reduce((s, i) => s + i.subtotal, 0);
      let discountAmount = 0;
      
      if (promo.type === "percentage") {
        discountAmount = (currentSubtotal * promo.value) / 100;
        if (promo.max_discount_amount) {
          discountAmount = Math.min(discountAmount, promo.max_discount_amount);
        }
      } else if (promo.type === "fixed_amount") {
        discountAmount = promo.value;
      }
      
      const discountPct = currentSubtotal > 0 ? (discountAmount / currentSubtotal) * 100 : 0;
      setDiscountPct(discountPct);
    };
    window.addEventListener("pos:applyPromo", handlePromoApply);

    const params = new URLSearchParams(window.location.search);
    const payment = params.get("payment");
    if (payment === "success") {
      setPaymentBanner("success");
      window.history.replaceState({}, "", window.location.pathname);
      setTimeout(() => setPaymentBanner(null), 5000);
    } else if (payment === "cancelled") {
      setPaymentBanner("cancelled");
      window.history.replaceState({}, "", window.location.pathname);
      setTimeout(() => setPaymentBanner(null), 4000);
    }
    return () => {
      window.removeEventListener("pos:addItem", handleAIAdd);
      window.removeEventListener("pos:applyPromo", handlePromoApply);
      unsubscribeDiscounts();
    };
  }, []);

  const addToCart = (item) => {
    if (item.menu_item_id) {
      setCartItems(prev => {
        const canStack = !item.isCustom && (!item.modifiers || item.modifiers.length === 0);
        const existing = canStack && prev.find(c => c.menu_item_id === item.menu_item_id);
        if (existing) {
          return prev.map(c => c.menu_item_id === item.menu_item_id
            ? { ...c, quantity: c.quantity + item.quantity, subtotal: (c.quantity + item.quantity) * c.price }
            : c
          );
        }
        return [...prev, item.isCustom ? { ...item, menu_item_id: `custom_${Date.now()}` } : item];
      });
      return;
    }
    setCartItems(prev => {
      const existing = prev.find(c => c.menu_item_id === item.id);
      if (existing) {
        return prev.map(c => c.menu_item_id === item.id
          ? { ...c, quantity: c.quantity + 1, subtotal: (c.quantity + 1) * c.price }
          : c
        );
      }
      return [...prev, { menu_item_id: item.id, name: item.name, price: item.base_price, quantity: 1, notes: "", modifiers: [], subtotal: item.base_price }];
    });
  };

  const updateCartItem = (menuItemId, updates) => {
    setCartItems(prev => prev.map(c => c.menu_item_id === menuItemId
      ? { ...c, ...updates, subtotal: (updates.quantity ?? c.quantity) * c.price }
      : c
    ).filter(c => c.quantity > 0));
  };

  const clearCart = () => {
    setCartItems([]);
    setSelectedTable(null);
    setCustomerName("");
    setLoyaltyCustomer(null);
    setDiscountPct(0);
  };

  const handleItemClick = (item) => {
    if (item.variants?.length > 0) {
      setVariantItem(item);
    } else if (item.modifiers?.length > 0) {
      setCustomizerItem(item);
    } else {
      addToCart({ menu_item_id: item.id, name: item.name, price: item.base_price, quantity: 1, notes: "", modifiers: [], subtotal: item.base_price });
    }
  };

  const saveTicket = async () => {
    if (cartItems.length === 0) return;
    const sub = cartItems.reduce((s, i) => s + i.subtotal, 0);
    const disc = sub * (discountPct / 100);
    const tx = (sub - disc) * 0.1;
    await base44.entities.Ticket.create({
      customer_name: loyaltyCustomer?.name || customerName || "Guest",
      items: cartItems,
      order_type: orderType,
      table_number: selectedTable?.number || null,
      discount_pct: discountPct,
      subtotal: sub,
      total: sub - disc + tx,
      status: "open",
      branch_id: branch?.id || null,
    });
    clearCart();
    alert("Ticket saved!");
  };

  const loadTicket = (ticket) => {
    setCartItems(ticket.items || []);
    setOrderType(ticket.order_type || "takeaway");
    setDiscountPct(ticket.discount_pct || 0);
    if (ticket.customer_name && ticket.customer_name !== "Guest") {
      setCustomerName(ticket.customer_name);
    }
    // close the saved ticket
    base44.entities.Ticket.update(ticket.id, { status: "closed" });
  };

  const sendToKitchen = async () => {
    if (cartItems.length === 0) return;
    setSendingToKitchen(true);
    const orderNumber = `KDS-${Date.now().toString().slice(-6)}`;
    await base44.entities.Order.create({
      order_number: orderNumber,
      type: orderType,
      table_number: selectedTable?.number || null,
      customer_name: loyaltyCustomer?.name || customerName || null,
      items: cartItems,
      status: "pending",
      subtotal: cartItems.reduce((s, i) => s + i.subtotal, 0),
      branch_id: branch?.id,
    });
    const printers = JSON.parse(localStorage.getItem("pos_printers") || "[]");
    const kitchenPrinter = printers.find(p => p.type === "kitchen");
    if (kitchenPrinter) {
      try {
        await base44.functions.invoke("sendToKitchen", {
          items: cartItems, orderType,
          tableNumber: selectedTable?.number || null,
          customerName: loyaltyCustomer?.name || customerName || null,
          printerIp: kitchenPrinter.ip, printerPort: kitchenPrinter.port,
        });
      } catch (_) {}
    }
    setKitchenMsg("Order sent to kitchen!");
    setSendingToKitchen(false);
    setTimeout(() => setKitchenMsg(null), 3000);
  };

  const handleActionBtn = (label) => {
    if (label === "Discount") setShowPromoMenu(v => !v);
    else if (label === "Void") {
      if (selectedCartItem) { setVoidMode("item"); setShowVoidConfirm(true); }
      else if (cartItems.length > 0) { setVoidMode("order"); setShowVoidConfirm(true); }
      else clearCart();
    }
    else if (label === "Print") setShowReprint(true);
    else if (label === "Tickets") setShowTickets(true);
    else if (label === "More") setShowMoreMenu(true);
  };

  const applyPromo = (promo) => {
    const currentSubtotal = cartItems.reduce((s, i) => s + i.subtotal, 0);
    let discountAmount = 0;
    
    if (promo.type === "percentage") {
      discountAmount = (currentSubtotal * promo.value) / 100;
      if (promo.max_discount_amount) {
        discountAmount = Math.min(discountAmount, promo.max_discount_amount);
      }
    } else if (promo.type === "fixed_amount") {
      discountAmount = promo.value;
    }
    
    const discountPct = currentSubtotal > 0 ? (discountAmount / currentSubtotal) * 100 : 0;
    setDiscountPct(discountPct);
    setShowPromoMenu(false);
  };

  const subtotal = cartItems.reduce((sum, i) => sum + i.subtotal, 0);
  const discountAmt = subtotal * (discountPct / 100);
  const tax = (subtotal - discountAmt) * 0.1;
  const total = subtotal - discountAmt + tax;

  const categories = ["All", ...Array.from(new Set(menuItems.map(i => i.category).filter(Boolean)))];

  const filtered = menuItems.filter(item => {
    const matchCat = activeCategory === "All" || item.category === activeCategory;
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const now = new Date();
  const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString("en-US", { weekday: "short", day: "numeric", month: "short" });

  const staffSession = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "{}"); } catch { return {}; } })();
  const activeStaff = staffSession.name || user?.full_name || null;

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden text-gray-900 select-none">
      {variantItem && <VariantSelector item={variantItem} onSelect={addToCart} onClose={() => setVariantItem(null)} />}
      {customizerItem && <ItemCustomizerModal item={customizerItem} onAdd={addToCart} onClose={() => setCustomizerItem(null)} />}
      {showCustomItem && <CustomItemModal onAdd={addToCart} onClose={() => setShowCustomItem(false)} />}

      {paymentBanner === "success" && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-green-100 border border-green-300 text-green-700 px-5 py-3 rounded-2xl text-sm font-medium shadow">
          <CheckCircle2 className="w-4 h-4" /> Payment successful!
        </div>
      )}
      {paymentBanner === "cancelled" && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-red-100 border border-red-300 text-red-700 px-5 py-3 rounded-2xl text-sm font-medium shadow">
          <XCircle className="w-4 h-4" /> Payment cancelled.
        </div>
      )}

      {/* ── LEFT PANEL: Order ── */}
      <div className="w-72 xl:w-80 flex flex-col bg-white border-r border-gray-200">
        {/* Order header */}
        <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
          <div>
            <div className="text-xs text-gray-400">{timeStr} · {dateStr}</div>
            <div className="text-base font-bold text-violet-700 mt-0.5">
              {orderType === "dine-in" && selectedTable ? `Table ${selectedTable.number}` : "PICK UP"}
            </div>
            {activeStaff && (
              <div className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
                {activeStaff}
              </div>
            )}
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${cartItems.length > 0 ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-400"}`}>
              {cartItems.length > 0 ? "ACTIVE" : "EMPTY"}
            </span>
            <button
              onClick={() => setShowCustomerPicker(v => !v)}
              className="flex items-center gap-1 text-xs text-violet-600 font-semibold hover:underline"
            >
              <UserPlus className="w-3 h-3" />
              {loyaltyCustomer ? loyaltyCustomer.name : "ADD CUSTOMER"}
            </button>
          </div>
        </div>

        {showCustomerPicker && (
          <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
            <CustomerPicker
              selectedCustomer={loyaltyCustomer}
              onSelect={(c) => { setLoyaltyCustomer(c); setShowCustomerPicker(false); }}
            />
          </div>
        )}

        {/* Order type toggle */}
        <div className="px-3 py-2 border-b border-gray-100 flex gap-1">
          <button
            onClick={() => setOrderType("dine-in")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${orderType === "dine-in" ? "bg-violet-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}
          >
            <UtensilsCrossed className="w-3 h-3" /> Dine-In
          </button>
          <button
            onClick={() => setOrderType("takeaway")}
            className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${orderType === "takeaway" ? "bg-violet-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"}`}
          >
            <ShoppingBag className="w-3 h-3" /> Takeaway
          </button>
        </div>

        {orderType === "dine-in" && (
          <div className="px-3 py-2 border-b border-gray-100 flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
            {tables.length === 0 && <span className="text-xs text-gray-400">No tables configured</span>}
            {tables.map(t => (
              <button
                key={t.id}
                onClick={() => setSelectedTable(selectedTable?.id === t.id ? null : t)}
                disabled={t.status === "occupied" && selectedTable?.id !== t.id}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                  selectedTable?.id === t.id
                    ? "bg-violet-600 text-white border-violet-600"
                    : t.status === "occupied"
                    ? "bg-gray-100 text-gray-400 border-gray-200 opacity-60 cursor-not-allowed"
                    : "bg-white text-gray-700 border-gray-200 hover:border-violet-400"
                }`}
              >
                T{t.number}
              </button>
            ))}
          </div>
        )}

        {/* Cart items */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1.5">
          {cartItems.length === 0 && (
            <div className="text-center text-gray-300 text-sm py-12">No items yet</div>
          )}
          {cartItems.map(item => (
            <div
              key={item.menu_item_id}
              onClick={() => setSelectedCartItem(prev => prev?.menu_item_id === item.menu_item_id ? null : item)}
              className={`flex items-start gap-2 py-2 border-b border-gray-100 last:border-0 cursor-pointer rounded-lg px-1 transition ${item.is_voided ? "opacity-40" : ""} ${selectedCartItem?.menu_item_id === item.menu_item_id ? "bg-red-50 border border-red-200" : "hover:bg-gray-50"}`}
            >
              <div className={`w-1 self-stretch rounded-full shrink-0 ${selectedCartItem?.menu_item_id === item.menu_item_id ? "bg-red-500" : item.is_voided ? "bg-gray-300" : "bg-violet-500"}`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-1">
                  <div className="flex-1">
                    <span className={`text-sm font-medium leading-tight ${item.is_voided ? "line-through text-gray-400" : "text-gray-800"}`}>
                      {item.quantity} × {item.name}
                      {item.is_voided && <span className="ml-1 text-[10px] bg-red-100 text-red-500 rounded px-1 not-italic font-semibold">VOIDED</span>}
                    </span>
                    {item.modifiers?.length > 0 && (
                      <div className="mt-0.5">
                        {item.modifiers.map((m, i) => (
                          <div key={i} className="text-xs text-gray-400">
                            + {m.name}{m.price > 0 ? ` (+AED ${m.price.toFixed(2)})` : ""}
                          </div>
                        ))}
                      </div>
                    )}
                    {item.notes && <div className="text-xs text-amber-600 italic mt-0.5">{item.notes}</div>}
                  </div>
                  <span className="text-sm font-semibold text-gray-700 shrink-0">AED {(item.subtotal ?? item.price * item.quantity ?? 0).toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1.5">
                  <button onClick={() => updateCartItem(item.menu_item_id, { quantity: item.quantity - 1 })} className="w-5 h-5 rounded bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition">
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="text-xs w-4 text-center font-bold">{item.quantity}</span>
                  <button onClick={() => updateCartItem(item.menu_item_id, { quantity: item.quantity + 1 })} className="w-5 h-5 rounded bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition">
                    <Plus className="w-3 h-3" />
                  </button>
                  <button onClick={() => updateCartItem(item.menu_item_id, { quantity: 0 })} className="w-5 h-5 rounded bg-gray-100 hover:bg-red-100 text-gray-400 hover:text-red-500 flex items-center justify-center transition ml-auto">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tax Group Selector */}
        {taxGroups.length > 0 && (
          <div className="px-3 py-2 border-t border-gray-100 bg-gray-50">
            <label className="text-xs font-semibold text-gray-600 block mb-1.5">Tax Group</label>
            <select
              value={selectedTaxGroup?.id || ""}
              onChange={e => setSelectedTaxGroup(taxGroups.find(t => t.id === e.target.value) || null)}
              className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-violet-400"
            >
              <option value="">No Tax Group</option>
              {taxGroups.map(group => (
                <option key={group.id} value={group.id}>{group.name}</option>
              ))}
            </select>
          </div>
        )}

        {/* Totals */}
        <div className="px-4 py-2 border-t border-gray-100 space-y-1 text-sm">
          {discountPct > 0 && (
            <div className="flex justify-between text-green-600">
              <span>Discount ({discountPct}%)</span><span>−AED {discountAmt.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between text-gray-400">
            <span>Taxes</span><span>AED {tax.toFixed(2)}</span>
          </div>
          {selectedTaxGroup && (
            <div className="flex justify-between text-violet-600 text-xs pt-1 border-t border-gray-100">
              <span>{selectedTaxGroup.name}</span><span>Applied</span>
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="px-3 pb-1 flex gap-1.5">
          <button
            onClick={saveTicket}
            disabled={cartItems.length === 0}
            className="flex-1 flex flex-col items-center justify-center gap-0.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl py-2.5 transition-all text-xs"
          >
            <Ticket className="w-4 h-4" />
            Save Ticket
          </button>
          <button
            onClick={sendToKitchen}
            disabled={cartItems.length === 0 || sendingToKitchen}
            className="flex-1 flex flex-col items-center justify-center gap-0.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl py-2.5 transition-all text-xs"
          >
            <ChefHat className="w-4 h-4" />
            {sendingToKitchen ? "Sending..." : "Kitchen"}
          </button>
        </div>

        {/* Loyalty Scan button */}
        <button
          onClick={() => setShowLoyaltyScan(true)}
          className={`mx-3 mb-2 flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all border ${
            loyaltyCustomer
              ? "bg-amber-50 border-amber-400 text-amber-700"
              : "bg-white border-gray-200 text-gray-600 hover:border-amber-400 hover:text-amber-600"
          }`}
        >
          {loyaltyCustomer ? (
            <>
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              {loyaltyCustomer.name} · {(loyaltyCustomer.points || 0).toLocaleString()} pts
            </>
          ) : (
            <>
              <QrCode className="w-4 h-4" /> Scan Loyalty Card
            </>
          )}
        </button>

        {/* Checkout button */}
        <button
          onClick={() => cartItems.length > 0 && setShowCheckout(true)}
          disabled={cartItems.length === 0 || (orderType === "dine-in" && !selectedTable)}
          className="mx-3 mb-3 flex items-center justify-between bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-xl px-5 py-3 transition-all"
          >
          <span className="text-sm tracking-wide">CHARGE</span>
          <span className="text-sm font-bold">AED {total.toFixed(2)}</span>
          </button>
          {/* Tax Group Info */}
          {selectedTaxGroup && (
          <div className="mx-3 mb-2 px-3 py-2 bg-violet-50 border border-violet-200 rounded-lg text-xs text-center">
            <span className="font-semibold text-violet-700">Tax Group:</span> <span className="text-violet-600">{selectedTaxGroup.name}</span>
          </div>
          )}
        {kitchenMsg && <p className="text-xs text-center text-green-600 font-medium pb-1">{kitchenMsg}</p>}
      </div>

      {/* ── RIGHT PANEL: Products ── */}
      <div className="flex-1 flex flex-col bg-gray-50 overflow-hidden">
        {/* Top action bar */}
        <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-2 overflow-x-auto">
          {ACTION_BTNS.map(({ icon: Icon, label }) => (
            <button
              key={label}
              onClick={() => handleActionBtn(label)}
              className={`flex flex-col items-center justify-center gap-1 min-w-[52px] px-3 py-2 rounded-xl transition-all relative
                ${label === "Discount" && showPromoMenu ? "bg-violet-800 text-white" : "bg-violet-600 text-white hover:bg-violet-700"}`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-semibold whitespace-nowrap">{label}</span>
            </button>
          ))}

          {/* Promos Menu */}
          {showPromoMenu && activePromos.length > 0 && (
            <div className="absolute top-full right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-2xl z-40 min-w-96 p-3 max-h-64 overflow-y-auto">
              <div className="flex items-center justify-between mb-3 sticky top-0 bg-white pb-2 border-b border-gray-100">
                <span className="text-sm font-bold text-gray-900 flex items-center gap-1">
                  <Zap className="w-4 h-4 text-amber-500" /> Active Promos
                </span>
                <button onClick={() => setShowPromoMenu(false)} className="text-gray-400 hover:text-gray-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-2">
                {activePromos.map(promo => {
                  const promoValue = promo.type === "percentage" ? `${promo.value}%` : `AED ${promo.value.toFixed(2)}`;
                  return (
                    <button
                      key={promo.id}
                      onClick={() => applyPromo(promo)}
                      className="w-full text-left px-4 py-3 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 hover:from-amber-100 hover:to-orange-100 border-2 border-transparent hover:border-amber-400 transition group"
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex-1">
                          <div className="font-bold text-gray-900 group-hover:text-amber-700 text-sm">{promo.name}</div>
                          {promo.description && <div className="text-xs text-gray-600 mt-0.5">{promo.description}</div>}
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-bold text-lg text-orange-600">{promoValue}</div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Manual discount input */}
          {showPromoMenu && activePromos.length === 0 && (
            <div className="flex items-center gap-2 ml-2">
              <input
                type="number"
                min="0"
                max="100"
                value={discountPct}
                onChange={e => setDiscountPct(Math.min(100, Math.max(0, Number(e.target.value))))}
                className="w-16 border border-gray-200 rounded-lg px-2 py-1.5 text-sm text-center focus:outline-none focus:border-violet-400"
                placeholder="%"
              />
              <span className="text-xs text-gray-500">% off</span>
            </div>
          )}


        </div>

        {/* Search */}
        <div className="px-4 pt-3 pb-2 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              placeholder="Search products"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none focus:border-violet-400 transition"
            />
          </div>
          <button
            onClick={() => setShowCustomItem(true)}
            className="flex items-center gap-1.5 bg-white border border-gray-200 hover:border-violet-400 rounded-xl px-3 py-2 text-xs text-gray-600 hover:text-violet-600 transition font-medium"
          >
            <Plus className="w-3.5 h-3.5" /> Custom
          </button>
        </div>

        {/* Category tabs */}
        <div className="px-4 pb-2 flex gap-2 overflow-x-auto scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-semibold transition-all border ${
                activeCategory === cat
                  ? "bg-violet-600 text-white border-violet-600"
                  : "bg-white text-gray-500 border-gray-200 hover:border-violet-400 hover:text-violet-600"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product grid */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="grid grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {filtered.length === 0 && (
              <div className="col-span-full text-center text-gray-400 text-sm py-16">No items found</div>
            )}
            {filtered.map(item => {
              const stock = item.stock_quantity ?? null;
              const isTracked = stock !== null;
              const isLowStock = isTracked && stock > 0 && stock <= 10;
              const isOutOfStock = stock === 0;

              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  disabled={isOutOfStock}
                  className={`group bg-white border rounded-2xl p-3 text-left transition-all duration-150 active:scale-95 shadow-sm hover:shadow-md ${
                    isOutOfStock
                      ? "opacity-50 cursor-not-allowed border-gray-200"
                      : isLowStock
                      ? "border-orange-400 hover:border-orange-500"
                      : "border-gray-200 hover:border-violet-400"
                  }`}
                >
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} className="w-full h-20 object-cover rounded-xl mb-2" />
                  ) : (
                    <div className="w-full h-16 rounded-xl bg-gradient-to-br from-violet-100 to-violet-50 flex items-center justify-center text-2xl mb-2">🍽</div>
                  )}
                  <p className="text-xs font-semibold text-gray-800 leading-tight text-center">{item.name}</p>
                  <p className={`text-xs font-bold text-center mt-1 ${isOutOfStock ? "text-red-600" : isLowStock ? "text-orange-600" : "text-violet-600"}`}>
                    AED {item.base_price?.toFixed(2)}{item.variants?.length > 0 ? "+" : ""}
                  </p>
                  {isTracked && (
                    <p className={`text-[10px] font-medium text-center mt-0.5 ${isOutOfStock ? "text-red-500" : isLowStock ? "text-orange-500" : "text-gray-400"}`}>
                      {isOutOfStock ? "Out of Stock" : isLowStock ? `${stock} left (low)` : `${stock} in stock`}
                    </p>
                  )}
                  {item.modifiers?.length > 0 && !isOutOfStock && (
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mx-auto mt-1" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom nav */}
        <div className="bg-white border-t border-gray-200 flex items-center">
          <Link to={createPageUrl("Dashboard")} className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold relative group">
            <Home className="w-5 h-5" /> HOME
            {printers.length > 0 && (
              <div className="absolute bottom-0 flex gap-1">
                {printers.map((printer, i) => {
                  const isConnected = printer.status === "connected";
                  return (
                    <div
                      key={i}
                      className="w-1.5 h-1.5 rounded-full transition"
                      style={{ backgroundColor: isConnected ? "#10b981" : "#d1d5db" }}
                      title={`${printer.name}: ${isConnected ? "Connected" : "Offline"}`}
                    />
                  );
                })}
              </div>
            )}
          </Link>
          <Link to={createPageUrl("Orders")} className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold">
            <ClipboardList className="w-5 h-5" /> ORDERS
          </Link>
          <Link to={createPageUrl("Tables")} className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold">
            <LayoutGrid className="w-5 h-5" /> TABLES
          </Link>
          <button
            onClick={() => setShowCustomItem(true)}
            className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold"
          >
            <Plus className="w-5 h-5" /> NEW
          </button>
        </div>
      </div>

      {showLoyaltyScan && (
        <LoyaltyScanModal
          onSelect={(c) => { setLoyaltyCustomer(c); setShowLoyaltyScan(false); }}
          onClose={() => setShowLoyaltyScan(false)}
        />
      )}
      {showReprint && <ReprintModal onClose={() => setShowReprint(false)} />}
      {showTickets && <OpenTicketsModal onClose={() => setShowTickets(false)} onLoadTicket={loadTicket} branchId={branch?.id} />}
      {showMoreMenu && <POSMoreMenu onClose={() => setShowMoreMenu(false)} onUserLogin={(u) => setUser(u)} />}

      {showVoidConfirm && (
        <VoidModal
          mode={voidMode}
          item={voidMode === "item" ? selectedCartItem : null}
          voidReasons={voidReasons}
          onClose={() => { setShowVoidConfirm(false); setVoidMode(null); }}
          onConfirm={async ({ reason, authorizedStaff }) => {
            const session = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "{}"); } catch { return {}; } })();
            if (voidMode === "item" && selectedCartItem) {
              // Void single item — mark as voided in cart
              setCartItems(prev => prev.map(c =>
                c.menu_item_id === selectedCartItem.menu_item_id
                  ? { ...c, is_voided: true, voided_by: authorizedStaff?.name || session.name, void_reason: reason, void_time: new Date().toISOString() }
                  : c
              ));
              await base44.entities.AuditLog.create({
                actor_email: user?.email || "pos",
                actor_name: authorizedStaff?.name || session.name || "POS",
                action: "void",
                entity_type: "Order",
                entity_name: selectedCartItem.name,
                description: `Void item: ${selectedCartItem.name} — ${reason}`,
                severity: "warning",
              });
              setSelectedCartItem(null);
            } else {
              // Void entire order
              clearCart();
              await base44.entities.AuditLog.create({
                actor_email: user?.email || "pos",
                actor_name: authorizedStaff?.name || session.name || "POS",
                action: "void",
                entity_type: "Order",
                entity_name: "Cart Order",
                description: `Void entire order — ${reason}`,
                severity: "warning",
              });
            }
            setShowVoidConfirm(false);
            setVoidMode(null);
          }}
        />
      )}

      {showCheckout && (
        <CheckoutModal
           cartItems={cartItems}
           orderType={orderType}
           selectedTable={selectedTable}
           customerName={loyaltyCustomer?.name || customerName}
           subtotal={subtotal || 0}
           tax={tax || 0}
           total={total || 0}
           cashierName={user?.full_name || "Cashier"}
           tables={tables}
           loyaltyCustomer={loyaltyCustomer}
           branchId={branch?.id}
           selectedTaxGroup={selectedTaxGroup}
           onClose={() => setShowCheckout(false)}
           onSuccess={() => {
             clearCart();
             setShowCheckout(false);
             setSelectedTaxGroup(null);
             base44.entities.Table.list().then(setTables);
           }}
         />
      )}
    </div>
  );
}