import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { subDays, startOfDay, startOfQuarter, startOfYear } from "date-fns";
import { RefreshCw } from "lucide-react";
import OwnerKPICards from "@/components/owner/OwnerKPICards";
import OwnerSalesChart from "@/components/owner/OwnerSalesChart";
import OwnerPrimeCost from "@/components/owner/OwnerPrimeCost";
import OwnerRevenueBreakdown from "@/components/owner/OwnerRevenueBreakdown";
import OwnerTopProducts from "@/components/owner/OwnerTopProducts";
import OwnerBranchComparison from "@/components/owner/OwnerBranchComparison";
import OwnerStaffCost from "@/components/owner/OwnerStaffCost";
import OwnerAlerts from "@/components/owner/OwnerAlerts";

const DATE_RANGES = [
  { label: "Today", value: "today" },
  { label: "7 Days", value: "7days" },
  { label: "30 Days", value: "30days" },
  { label: "Quarter", value: "quarter" },
  { label: "Year", value: "year" },
];

function getStartDate(range) {
  const now = new Date();
  switch (range) {
    case "today": return startOfDay(now);
    case "7days": return subDays(now, 7);
    case "30days": return subDays(now, 30);
    case "quarter": return startOfQuarter(now);
    case "year": return startOfYear(now);
    default: return subDays(now, 30);
  }
}

export default function OwnerDashboard() {
  const [dateRange, setDateRange] = useState("30days");
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [staffList, setStaffList] = useState([]);
  const [timecards, setTimecards] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const [inventoryItems, setInventoryItems] = useState([]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [ordersData, menuData, staffData, timecardsData, branchData, invData] = await Promise.all([
        base44.entities.Order.list("-created_date", 3000).catch(() => []),
        base44.entities.MenuItem.list().catch(() => []),
        base44.entities.StaffMember.list().catch(() => []),
        base44.entities.StaffTimecard.list("-clock_in", 1000).catch(() => []),
        base44.entities.Branch.list().catch(() => []),
        base44.entities.InventoryItem.list().catch(() => []),
      ]);
      setOrders(ordersData || []);
      setMenuItems(menuData || []);
      setStaffList(staffData || []);
      setTimecards(timecardsData || []);
      setBranches((branchData || []).filter(b => b.is_active !== false));
      setInventoryItems(invData || []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const startDate = useMemo(() => getStartDate(dateRange), [dateRange]);

  const filteredOrders = useMemo(() =>
    orders.filter(o => o.status === "paid" && o.created_date && new Date(o.created_date) >= startDate),
    [orders, startDate]
  );

  const filteredTimecards = useMemo(() =>
    timecards.filter(t => t.status === "completed" && t.clock_in && new Date(t.clock_in) >= startDate),
    [timecards, startDate]
  );

  // Build lookup maps for COGS calculation
  const menuItemMap = useMemo(() => {
    const byId = new Map();
    const byName = new Map();
    menuItems.forEach(m => { byId.set(m.id, m); byName.set(m.name?.toLowerCase().trim(), m); });
    return { byId, byName };
  }, [menuItems]);

  const invItemMap = useMemo(() => {
    const byId = new Map();
    const byName = new Map();
    inventoryItems.forEach(i => {
      byId.set(i.id, i);
      byName.set(i.name?.toLowerCase().replace(/^"|"$/g, "").trim(), i);
    });
    return { byId, byName };
  }, [inventoryItems]);

  const getInv = (r) => invItemMap.byId.get(r.inventory_item_id) || invItemMap.byName.get(r.inventory_item_name?.toLowerCase().replace(/^"|"$/g, "").trim());

  const calcOrderCOGS = (order) => {
    return (order.items || []).filter(i => !i.is_voided).reduce((sum, orderItem) => {
      const menuItem = menuItemMap.byId.get(orderItem.menu_item_id) || menuItemMap.byName.get(orderItem.name?.toLowerCase().trim());
      if (!menuItem) return sum;
      const qty = orderItem.quantity || 1;
      // Always try recipe first if recipe exists
      if (menuItem.recipe?.length > 0) {
        const recipeCost = menuItem.recipe.reduce((rsum, r) => {
          const inv = getInv(r);
          if (!inv) return rsum;
          const costPerUnit = (inv.unit_cost || 0) / (inv.factor || 1);
          return rsum + r.quantity * costPerUnit;
        }, 0);
        // If recipe cost > 0, use it; otherwise fall back to cost_price
        if (recipeCost > 0) return sum + recipeCost * qty;
      }
      // Fall back to fixed cost_price
      return sum + (menuItem.cost_price || 0) * qty;
    }, 0);
  };

  const financials = useMemo(() => {
    const revenue = filteredOrders.reduce((s, o) => s + (o.total || 0), 0);

    const cogs = filteredOrders.reduce((sum, o) => sum + calcOrderCOGS(o), 0);

    const staffCost = filteredTimecards.reduce((sum, t) => {
      const staff = staffList.find(s => s.email === t.staff_email || s.name === t.staff_name);
      const hours = (t.duration_minutes || 0) / 60;
      return sum + (hours * (staff?.hourly_rate || 0));
    }, 0);

    const primeCost = cogs + staffCost;
    const netProfit = revenue - primeCost;
    const profitMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;
    const primeCostPct = revenue > 0 ? (primeCost / revenue) * 100 : 0;
    const foodCostPct = revenue > 0 ? (cogs / revenue) * 100 : 0;
    const laborCostPct = revenue > 0 ? (staffCost / revenue) * 100 : 0;
    const orderCount = filteredOrders.length;
    const avgOrderValue = orderCount > 0 ? revenue / orderCount : 0;

    return { revenue, cogs, staffCost, primeCost, netProfit, profitMargin, primeCostPct, foodCostPct, laborCostPct, orderCount, avgOrderValue };
  }, [filteredOrders, filteredTimecards, staffList, menuItemMap, invItemMap]);

  const salesByDay = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      const day = o.created_date?.slice(0, 10);
      if (!day) return;
      if (!map[day]) map[day] = { date: day, revenue: 0, orders: 0 };
      map[day].revenue += o.total || 0;
      map[day].orders += 1;
    });
    return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
  }, [filteredOrders]);

  const revenueByPayment = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      const method = o.payment_method || "other";
      map[method] = (map[method] || 0) + (o.total || 0);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [filteredOrders]);

  const revenueByPlatform = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      const platform = o.platform || "pos";
      map[platform] = (map[platform] || 0) + (o.total || 0);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [filteredOrders]);

  const topProducts = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      (o.items || []).filter(i => !i.is_voided).forEach(item => {
        const id = item.menu_item_id || item.name;
        if (!map[id]) {
          const menuItem = menuItems.find(m => m.id === item.menu_item_id);
          map[id] = { name: item.name, sold: 0, revenue: 0, cost: menuItem?.cost_price || 0, price: item.price || 0 };
        }
        map[id].sold += item.quantity || 1;
        map[id].revenue += (item.price || 0) * (item.quantity || 1);
      });
    });
    return Object.values(map)
      .map(p => ({ ...p, profit: p.price - p.cost, margin: p.price > 0 ? ((p.price - p.cost) / p.price) * 100 : 0 }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);
  }, [filteredOrders, menuItems]);

  const branchComparison = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      const branch = branches.find(b => b.id === o.branch_id);
      const name = branch?.name || o.branch_id || "Unknown";
      if (!map[name]) map[name] = { name, revenue: 0, orders: 0 };
      map[name].revenue += o.total || 0;
      map[name].orders += 1;
    });
    return Object.values(map).sort((a, b) => b.revenue - a.revenue);
  }, [filteredOrders, branches]);

  const staffCostBreakdown = useMemo(() => {
    const map = {};
    filteredTimecards.forEach(t => {
      const staff = staffList.find(s => s.email === t.staff_email || s.name === t.staff_name);
      const name = t.staff_name || "Unknown";
      const hours = (t.duration_minutes || 0) / 60;
      const cost = hours * (staff?.hourly_rate || 0);
      if (!map[name]) map[name] = { name, hours: 0, cost: 0, rate: staff?.hourly_rate || 0 };
      map[name].hours += hours;
      map[name].cost += cost;
    });
    return Object.values(map).sort((a, b) => b.cost - a.cost).slice(0, 10);
  }, [filteredTimecards, staffList]);

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-violet-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-gray-500 text-sm">Loading financial data…</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 px-6 pt-6 pb-10">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">Owner Dashboard</h1>
            <p className="text-gray-400 text-sm mt-0.5">Profitability, cash flow & operational costs</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex bg-white/10 rounded-xl p-1 gap-1">
              {DATE_RANGES.map(r => (
                <button
                  key={r.value}
                  onClick={() => setDateRange(r.value)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
                    dateRange === r.value ? "bg-white text-gray-900" : "text-gray-300 hover:text-white"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
            <button onClick={loadData} className="text-gray-400 hover:text-white transition p-2 hover:bg-white/10 rounded-lg">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
        <OwnerKPICards financials={financials} />
      </div>

      <div className="p-6 space-y-6 -mt-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <OwnerSalesChart data={salesByDay} dateRange={dateRange} />
          </div>
          <OwnerPrimeCost financials={financials} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <OwnerRevenueBreakdown byPayment={revenueByPayment} byPlatform={revenueByPlatform} total={financials.revenue} />
          <OwnerTopProducts products={topProducts} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <OwnerBranchComparison branches={branchComparison} total={financials.revenue} />
          <OwnerStaffCost staff={staffCostBreakdown} totalCost={financials.staffCost} laborPct={financials.laborCostPct} />
        </div>

        <OwnerAlerts financials={financials} topProducts={topProducts} />
      </div>
    </div>
  );
}