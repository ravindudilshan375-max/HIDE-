import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { DollarSign, TrendingUp, TrendingDown, Package, RefreshCw, Search, ChevronDown, ChevronUp } from "lucide-react";
import { Input } from "@/components/ui/input";

function pct(cost, price) {
  if (!price || price === 0) return 0;
  return (cost / price) * 100;
}

function CostBar({ costPct }) {
  const clamp = Math.min(costPct, 100);
  const color = clamp <= 30 ? "bg-green-400" : clamp <= 50 ? "bg-amber-400" : "bg-red-400";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${clamp}%` }} />
      </div>
      <span className={`text-xs font-semibold w-10 text-right ${clamp <= 30 ? "text-green-600" : clamp <= 50 ? "text-amber-600" : "text-red-600"}`}>
        {costPct.toFixed(1)}%
      </span>
    </div>
  );
}

export default function ProductCost() {
  const [menuItems, setMenuItems] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [sortDir, setSortDir] = useState("asc");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [expandedItem, setExpandedItem] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.MenuItem.list("name"),
      base44.entities.InventoryItem.list("name"),
      base44.entities.Branch.list(),
    ]).then(([menus, invs, brs]) => {
      setMenuItems(menus);
      setInventoryItems(invs);
      setBranches(brs);
      setLoading(false);
    });
  }, []);

  const invMap = useMemo(() => {
    const byId = {};
    const byName = {};
    inventoryItems.forEach(i => {
      byId[i.id] = i;
      byName[i.name?.toLowerCase().replace(/^"|"$/g, "").trim()] = i;
    });
    return { byId, byName };
  }, [inventoryItems]);

  const getInv = (ing) =>
    invMap.byId[ing.inventory_item_id] ||
    invMap.byName[ing.inventory_item_name?.toLowerCase().replace(/^"|"$/g, "").trim()];

  // Calculate recipe cost for a menu item
  const calcRecipeCost = (item) => {
    if (!item.recipe || item.recipe.length === 0) return item.cost_price || 0;
    let total = 0;
    for (const ing of item.recipe) {
      const inv = getInv(ing);
      const unitCost = (inv?.unit_cost || 0) / (inv?.factor || 1);
      total += unitCost * (ing.quantity || 0);
    }
    return total;
  };

  const enriched = useMemo(() => {
    return menuItems
      .filter(i => selectedBranch === "all" || i.branch_id === selectedBranch)
      .map(item => {
        const recipeCost = calcRecipeCost(item);
        const sellingPrice = item.base_price || 0;
        const grossProfit = sellingPrice - recipeCost;
        const costPct = pct(recipeCost, sellingPrice);
        return { ...item, recipeCost, grossProfit, costPct };
      });
  }, [menuItems, invMap, selectedBranch]);

  const categories = useMemo(() => ["all", ...new Set(menuItems.map(i => i.category).filter(Boolean))], [menuItems]);

  const filtered = useMemo(() => {
    let list = enriched;
    if (categoryFilter !== "all") list = list.filter(i => i.category === categoryFilter);
    if (search) list = list.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));
    list = [...list].sort((a, b) => {
      let va = a[sortBy], vb = b[sortBy];
      if (typeof va === "string") va = va.toLowerCase();
      if (typeof vb === "string") vb = vb.toLowerCase();
      if (va < vb) return sortDir === "asc" ? -1 : 1;
      if (va > vb) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return list;
  }, [enriched, search, categoryFilter, sortBy, sortDir]);

  const totals = useMemo(() => ({
    avgCostPct: filtered.length ? filtered.reduce((s, i) => s + i.costPct, 0) / filtered.length : 0,
    totalRevenuePotential: filtered.reduce((s, i) => s + i.base_price, 0),
    totalCost: filtered.reduce((s, i) => s + i.recipeCost, 0),
    withRecipe: filtered.filter(i => i.recipe?.length > 0).length,
  }), [filtered]);

  const handleSort = (col) => {
    if (sortBy === col) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortBy(col); setSortDir("asc"); }
  };

  const SortIcon = ({ col }) => sortBy === col
    ? (sortDir === "asc" ? <ChevronUp className="w-3 h-3 inline ml-0.5" /> : <ChevronDown className="w-3 h-3 inline ml-0.5" />)
    : null;

  if (loading) return <div className="flex items-center justify-center h-screen text-gray-400 text-sm">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Product Cost Report</h1>
            <p className="text-sm text-gray-400 mt-0.5">Recipe-based cost analysis per menu item</p>
          </div>
          <div className="flex items-center gap-3">
            {branches.length > 1 && (
              <select
                value={selectedBranch}
                onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400"
              >
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <button
              onClick={() => { setLoading(true); Promise.all([base44.entities.MenuItem.list("name"), base44.entities.InventoryItem.list("name")]).then(([m, i]) => { setMenuItems(m); setInventoryItems(i); setLoading(false); }); }}
              className="flex items-center gap-2 text-sm font-medium bg-white border border-gray-200 hover:border-violet-400 text-gray-600 px-3 py-2 rounded-xl transition"
            >
              <RefreshCw className="w-4 h-4" /> Refresh
            </button>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="w-9 h-9 bg-violet-50 rounded-xl flex items-center justify-center mb-3">
              <Package className="w-4 h-4 text-violet-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">{filtered.length}</p>
            <p className="text-xs text-gray-400 mt-1">Total Products</p>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="w-9 h-9 bg-green-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-4 h-4 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-700">{totals.avgCostPct.toFixed(1)}%</p>
            <p className="text-xs text-gray-400 mt-1">Avg Cost %</p>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="w-9 h-9 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingUp className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">{totals.withRecipe}</p>
            <p className="text-xs text-gray-400 mt-1">Items with Recipe</p>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="w-9 h-9 bg-amber-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingDown className="w-4 h-4 text-amber-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">{filtered.filter(i => i.costPct > 50).length}</p>
            <p className="text-xs text-gray-400 mt-1">High Cost (&gt;50%)</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search products..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 border-gray-200 rounded-xl bg-white"
            />
          </div>
          <div className="flex gap-1 bg-white border border-gray-200 rounded-xl p-1 overflow-x-auto">
            {categories.map(cat => (
              <button key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap ${categoryFilter === cat ? "bg-violet-600 text-white" : "text-gray-400 hover:text-gray-700"}`}
              >
                {cat === "all" ? "All" : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="grid grid-cols-12 px-5 py-3 border-b border-gray-100 bg-gray-50 text-xs font-semibold text-gray-400 uppercase tracking-wide">
            <button className="col-span-3 text-left hover:text-gray-600 transition" onClick={() => handleSort("name")}>
              Product <SortIcon col="name" />
            </button>
            <span className="col-span-1 text-center">Category</span>
            <button className="col-span-2 text-right hover:text-gray-600 transition" onClick={() => handleSort("base_price")}>
              Sell Price <SortIcon col="base_price" />
            </button>
            <button className="col-span-2 text-right hover:text-gray-600 transition" onClick={() => handleSort("recipeCost")}>
              Recipe Cost <SortIcon col="recipeCost" />
            </button>
            <button className="col-span-2 text-right hover:text-gray-600 transition" onClick={() => handleSort("grossProfit")}>
              Gross Profit <SortIcon col="grossProfit" />
            </button>
            <button className="col-span-2 text-right hover:text-gray-600 transition" onClick={() => handleSort("costPct")}>
              Cost % <SortIcon col="costPct" />
            </button>
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16 text-gray-300 text-sm">No products found</div>
          )}

          {filtered.map(item => (
            <React.Fragment key={item.id}>
              <div
                onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)}
                className="grid grid-cols-12 px-5 py-3.5 border-b border-gray-50 hover:bg-gray-50 transition cursor-pointer items-center"
              >
                {/* Name */}
                <div className="col-span-3 flex items-center gap-3">
                  {item.image_url
                    ? <img src={item.image_url} alt={item.name} className="w-8 h-8 rounded-lg object-cover shrink-0" />
                    : <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm shrink-0">🍽</div>
                  }
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{item.name}</p>
                    {item.recipe?.length > 0
                      ? <p className="text-[10px] text-green-600">{item.recipe.length} ingredients</p>
                      : <p className="text-[10px] text-gray-300">No recipe</p>
                    }
                  </div>
                </div>

                {/* Category */}
                <div className="col-span-1 text-center">
                  <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">{item.category || "—"}</span>
                </div>

                {/* Sell Price */}
                <div className="col-span-2 text-right">
                  <span className="text-sm font-semibold text-gray-800">{item.base_price?.toFixed(3)}</span>
                  <span className="text-xs text-gray-400 ml-1">AED</span>
                </div>

                {/* Recipe Cost */}
                <div className="col-span-2 text-right">
                  <span className={`text-sm font-semibold ${item.recipeCost > 0 ? "text-orange-600" : "text-gray-300"}`}>
                    {item.recipeCost.toFixed(3)}
                  </span>
                  <span className="text-xs text-gray-400 ml-1">AED</span>
                </div>

                {/* Gross Profit */}
                <div className="col-span-2 text-right">
                  <span className={`text-sm font-semibold ${item.grossProfit >= 0 ? "text-green-600" : "text-red-500"}`}>
                    {item.grossProfit.toFixed(3)}
                  </span>
                  <span className="text-xs text-gray-400 ml-1">AED</span>
                </div>

                {/* Cost % */}
                <div className="col-span-2 pl-4">
                  {item.recipe?.length > 0
                    ? <CostBar costPct={item.costPct} />
                    : <span className="text-xs text-gray-300">—</span>
                  }
                </div>
              </div>

              {/* Expanded ingredient breakdown */}
              {expandedItem === item.id && item.recipe?.length > 0 && (
                <div className="col-span-12 bg-violet-50/40 border-b border-violet-100 px-8 py-3">
                  <p className="text-xs font-semibold text-violet-700 mb-2 uppercase tracking-wide">Ingredient Breakdown</p>
                  <div className="grid grid-cols-4 gap-2">
                    {item.recipe.map((ing, idx) => {
                      const inv = getInv(ing);
                      const unitCost = (inv?.unit_cost || 0) / (inv?.factor || 1);
                      const lineCost = unitCost * ing.quantity;
                      return (
                        <div key={idx} className="bg-white rounded-xl px-3 py-2 border border-violet-100 text-xs">
                          <p className="font-semibold text-gray-700">{ing.inventory_item_name}</p>
                          <p className="text-gray-400 mt-0.5">{ing.quantity} {ing.unit} × {unitCost.toFixed(3)} AED</p>
                          <p className="text-violet-600 font-bold mt-1">{lineCost.toFixed(3)} AED</p>
                        </div>
                      );
                    })}
                  </div>
                  {/* cost % of item total */}
                  {item.recipe.length > 0 && (
                    <div className="mt-3 flex items-center gap-6 text-xs text-gray-500 border-t border-violet-100 pt-2">
                      <span>Total Recipe Cost: <strong className="text-orange-600">{item.recipeCost.toFixed(3)} AED</strong></span>
                      <span>Sell Price: <strong className="text-gray-700">{item.base_price?.toFixed(3)} AED</strong></span>
                      <span>Gross Profit: <strong className="text-green-600">{item.grossProfit.toFixed(3)} AED</strong></span>
                      <span>Cost%: <strong className={item.costPct > 50 ? "text-red-600" : item.costPct > 30 ? "text-amber-600" : "text-green-600"}>{item.costPct.toFixed(1)}%</strong></span>
                    </div>
                  )}
                </div>
              )}
            </React.Fragment>
          ))}

          {/* Footer totals */}
          {filtered.length > 0 && (
            <div className="grid grid-cols-12 px-5 py-3.5 bg-gray-50 border-t border-gray-200 text-xs font-bold text-gray-600">
              <span className="col-span-3">Total ({filtered.length} items)</span>
              <span className="col-span-1" />
              <span className="col-span-2 text-right text-violet-700">{totals.totalRevenuePotential.toFixed(3)} AED</span>
              <span className="col-span-2 text-right text-orange-600">{totals.totalCost.toFixed(3)} AED</span>
              <span className="col-span-2 text-right text-green-600">{(totals.totalRevenuePotential - totals.totalCost).toFixed(3)} AED</span>
              <span className="col-span-2 text-right text-gray-500 pr-4">{totals.avgCostPct.toFixed(1)}% avg</span>
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-6 text-xs text-gray-400 pb-4">
          <div className="flex items-center gap-1.5"><div className="w-3 h-1.5 rounded-full bg-green-400" /> ≤30% Good</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-1.5 rounded-full bg-amber-400" /> 30–50% Watch</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-1.5 rounded-full bg-red-400" /> &gt;50% High Cost</div>
          <span>· Click any row to see ingredient breakdown</span>
        </div>
      </div>
    </div>
  );
}