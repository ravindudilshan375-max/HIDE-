import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { Delete, AlertCircle, Copy, CheckCircle2, ExternalLink, MapPin } from "lucide-react";

const PUBLISHED_URL = "https://nonchalant-swift-serve-pos.base44.app";

function getBranchLoginUrl(branchId) {
  return `${PUBLISHED_URL}${createPageUrl("BranchLogin")}?branch=${branchId}`;
}

// ── Branch Selector (no ?branch param) ──
function BranchSelector() {
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    base44.entities.Branch.list().then(data => {
      setBranches(data.filter(b => b.is_active !== false));
      setLoading(false);
    });
  }, []);

  const copyLink = async (branch) => {
    await navigator.clipboard.writeText(getBranchLoginUrl(branch.id));
    setCopiedId(branch.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const openLink = (branch) => {
    window.open(getBranchLoginUrl(branch.id), "_blank");
  };

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-6"
      style={{ background: "linear-gradient(160deg, #f3f0ff 0%, #f8f9fa 60%)", fontFamily: "'Inter', sans-serif" }}
    >
      <div className="w-full max-w-lg">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg" style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <span className="text-white font-bold text-2xl">D</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">DENDAX</h1>
          <p className="text-gray-400 text-sm mt-1">Branch Login Links</p>
        </div>

        {loading ? (
          <p className="text-center text-gray-400 text-sm">Loading branches…</p>
        ) : branches.length === 0 ? (
          <p className="text-center text-gray-400 text-sm">No active branches found.</p>
        ) : (
          <div className="space-y-3">
            {branches.map(branch => (
              <div key={branch.id} className="bg-white rounded-2xl border border-gray-200 shadow-sm p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-violet-500 shrink-0" />
                      <p className="font-semibold text-gray-900">{branch.name}</p>
                    </div>
                    {branch.location && (
                      <p className="text-xs text-gray-400 mt-0.5 ml-6">{branch.location}</p>
                    )}
                    <div className="mt-2 ml-6 bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 font-mono text-xs text-gray-400 truncate">
                      {getBranchLoginUrl(branch.id)}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 shrink-0">
                    <button
                      onClick={() => copyLink(branch)}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-all border bg-violet-50 text-violet-600 hover:bg-violet-100 border-violet-200"
                    >
                      {copiedId === branch.id ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedId === branch.id ? "Copied!" : "Copy"}
                    </button>
                    <button
                      onClick={() => openLink(branch)}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-all border bg-gray-50 text-gray-600 hover:bg-gray-100 border-gray-200"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Open
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <p className="text-center text-xs text-gray-400 mt-8">
          Share each branch link with the staff at that location
        </p>
      </div>
    </div>
  );
}

// ── PIN Login ──
export default function BranchLogin() {
  const navigate = useNavigate();
  const [branch, setBranch] = useState(null);
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [loadingBranch, setLoadingBranch] = useState(true);
  const [showSelector, setShowSelector] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("branch");

    if (!slug) {
      setShowSelector(true);
      setLoadingBranch(false);
      return;
    }

    base44.entities.Branch.list().then(branches => {
      const match = branches.find(b =>
        b.id === slug ||
        (b.name || "").toLowerCase().replace(/\s+/g, "-") === slug.toLowerCase()
      );

      if (!match || match.is_active === false) {
        setShowSelector(true);
      } else {
        setBranch(match);
      }
      setLoadingBranch(false);
    });
  }, []);

  const pressKey = (digit) => {
    if (pin.length >= 6 || loading) return;
    setError("");
    setPin(prev => prev + digit);
  };

  const clearAll = () => { setPin(""); setError(""); };
  const backspace = () => { setPin(prev => prev.slice(0, -1)); setError(""); };

  const handleLogin = async () => {
    if (!branch || pin.length < 4) return;
    setLoading(true);
    setError("");

    try {
      const res = await base44.functions.invoke("verifyStaffPin", {
        pin,
        branch_id: branch.id
      });

      const data = res.data;

      if (data.locked) {
        setError(`Account locked. Try again in ${data.locked_minutes} minute(s).`);
        setPin("");
        setLoading(false);
        return;
      }

      if (!data.success) {
        setError("Incorrect PIN. Please try again.");
        setPin("");
        setLoading(false);
        // Track failed login
        base44.analytics.track({
          eventName: "cashier_login_failed",
          properties: {
            branch_name: branch.name || "",
            branch_id: branch.id || "",
          }
        });
        return;
      }

      const loginTime = new Date().toISOString();
      localStorage.setItem("pos_staff_session", JSON.stringify({
        ...data.staff,
        logged_in_at: loginTime
      }));
      localStorage.setItem("selectedBranchId", branch.id);

      // Track login event
      base44.analytics.track({
        eventName: "cashier_login",
        properties: {
          staff_name: data.staff.name || "",
          role_type: data.staff.role_type || "",
          branch_name: branch.name || "",
          branch_id: branch.id || "",
        }
      });

      const role = data.staff.role_type;
      if (role === "kitchen") {
        navigate(createPageUrl("Kitchen"));
      } else if (role === "cashier") {
        navigate(createPageUrl("POS"));
      } else {
        navigate(createPageUrl("Dashboard"));
      }
    } catch {
      setError("Login failed. Please try again.");
      setPin("");
    }

    setLoading(false);
  };

  useEffect(() => {
    if (pin.length === 6 && branch && !loading) handleLogin();
  }, [pin]);

  if (loadingBranch) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <p className="text-gray-400 text-sm">Loading…</p>
      </div>
    );
  }

  if (showSelector) {
    return <BranchSelector />;
  }

  // ── PIN Login Screen ──
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-4"
      style={{ fontFamily: "'Inter', sans-serif", background: "linear-gradient(160deg, #f3f0ff 0%, #f8f9fa 60%)" }}
    >
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-lg" style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <span className="text-white font-bold text-2xl">D</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">DENDAX</h1>
          <div className="mt-3 inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-semibold text-white shadow"
            style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            📍 {branch.name}
          </div>
          {branch.location && (
            <p className="text-xs text-gray-400 mt-1">{branch.location}</p>
          )}
        </div>

        <div className="flex justify-center gap-3 mb-5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className={`w-4 h-4 rounded-full border-2 transition-all duration-150 ${
              i < pin.length ? "bg-violet-600 border-violet-600 scale-110" : "bg-white border-gray-300"
            }`} />
          ))}
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-100 rounded-xl py-2.5 px-4">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="bg-white rounded-3xl shadow border border-gray-200 p-5">
          <div className="grid grid-cols-3 gap-3">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => (
              <button
                key={n}
                onClick={() => pressKey(String(n))}
                disabled={loading}
                className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-2xl font-medium text-gray-800 hover:bg-violet-50 hover:border-violet-300 hover:text-violet-700 active:scale-95 transition-all disabled:opacity-50"
              >
                {n}
              </button>
            ))}
            <button onClick={clearAll} disabled={loading} className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-sm font-semibold text-gray-400 hover:bg-red-50 hover:border-red-200 hover:text-red-500 active:scale-95 transition-all disabled:opacity-50">
              C
            </button>
            <button onClick={() => pressKey("0")} disabled={loading} className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-2xl font-medium text-gray-800 hover:bg-violet-50 hover:border-violet-300 hover:text-violet-700 active:scale-95 transition-all disabled:opacity-50">
              0
            </button>
            <button onClick={backspace} disabled={loading} className="h-16 rounded-2xl bg-gray-50 border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-orange-50 hover:border-orange-200 hover:text-orange-500 active:scale-95 transition-all disabled:opacity-50">
              <Delete className="w-5 h-5" />
            </button>
          </div>

          <button
            onClick={handleLogin}
            disabled={pin.length < 4 || loading}
            className="mt-4 w-full h-14 rounded-2xl font-semibold text-white text-base transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}
          >
            {loading ? "Verifying…" : "Login"}
          </button>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          5 wrong attempts will lock your account for 15 minutes
        </p>
      </div>
    </div>
  );
}