import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import { RefreshCw, Clock } from "lucide-react";

export default function DrawerOpsReport() {
  const [loading, setLoading] = useState(false);

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Drawer Operations</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6">
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-8 text-center">
          <RefreshCw className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-600 text-lg font-semibold">Drawer Operations</p>
          <p className="text-gray-400 text-sm mt-2">Drawer opening and closing operations tracking to be implemented</p>
          <p className="text-xs text-gray-300 mt-4">Track till openings, closings, cash audits, and discrepancies</p>
        </div>
      </div>
    </div>
  );
}