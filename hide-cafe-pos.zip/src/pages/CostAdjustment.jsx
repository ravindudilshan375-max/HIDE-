import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";


const ADJUSTMENT_REASONS = ["supplier_price_change", "bulk_discount", "promotion", "correction", "other"];

export default function CostAdjustment() {
  const [adjustments, setAdjustments] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [newCost, setNewCost] = useState("");
  const [reason, setReason] = useState("supplier_price_change");
  const [notes, setNotes] = useState("");
  const [updatedBy, setUpdatedBy] = useState("");
  const [user, setUser] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [adjs, items, currentUser] = await Promise.all([
      base44.entities.InventoryCostAdjustment.list("-created_date", 50),
      base44.entities.MenuItem.list(),
      base44.auth.me().catch(() => null)
    ]);
    setAdjustments(adjs);
    setMenuItems(items);
    setUser(currentUser);
    setUpdatedBy(currentUser?.full_name || "");
    setLoading(false);
  };

  const saveAdjustment = async () => {
    if (!selectedItem || newCost === "" || !reason) {
      toast.error("Fill in all required fields");
      return;
    }

    const cost = Number(newCost);
    const previousCost = selectedItem.cost || 0;
    const costChange = cost - previousCost;

    await base44.entities.InventoryCostAdjustment.create({
      date: new Date().toISOString().split('T')[0],
      menu_item_id: selectedItem.id,
      item_name: selectedItem.name,
      previous_cost: previousCost,
      new_cost: cost,
      cost_change: costChange,
      reason: reason,
      notes: notes,
      updated_by: updatedBy
    });

    toast.success(`Cost updated to $${cost.toFixed(2)}`);
    setShowForm(false);
    setSelectedItem(null);
    setNewCost("");
    setNotes("");
    loadData();
  };

  const deleteAdjustment = async (id) => {
    await base44.entities.InventoryCostAdjustment.delete(id);
    toast.success("Adjustment deleted");
    loadData();
  };

  const filteredItems = menuItems.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Cost Adjustment</h1>
            <p className="text-gray-400 text-sm mt-0.5">Update supplier costs and unit prices</p>
          </div>
          <Button
            onClick={() => {
              setShowForm(true);
              setSelectedItem(null);
              setSearch("");
            }}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Adjustment
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">Adjust Cost</h2>

            {!selectedItem ? (
              <>
                <Input
                  placeholder="Search items..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />
                <div className="max-h-60 overflow-y-auto space-y-1.5">
                  {filteredItems.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-4">No items found</p>
                  ) : (
                    filteredItems.map(item => (
                      <button
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className="w-full text-left px-4 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg transition"
                      >
                        <p className="text-sm font-medium text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-400">Current: ${(item.cost || 0).toFixed(2)}</p>
                      </button>
                    ))
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-sm font-medium text-gray-900">{selectedItem.name}</p>
                  <p className="text-xs text-gray-400 mt-1">Current cost: ${(selectedItem.cost || 0).toFixed(2)}</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block font-medium">New Cost</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={newCost}
                      onChange={e => setNewCost(e.target.value)}
                      className="border-gray-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block font-medium">Reason</label>
                    <select
                      value={reason}
                      onChange={e => setReason(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
                    >
                      {ADJUSTMENT_REASONS.map(r => (
                        <option key={r} value={r}>{r.replace(/_/g, " ")}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <Input
                  placeholder="Updated by"
                  value={updatedBy}
                  onChange={e => setUpdatedBy(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />

                <textarea
                  placeholder="Notes (optional)"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-violet-400"
                  rows="2"
                />

                <div className="flex gap-2">
                  <Button
                    onClick={() => setSelectedItem(null)}
                    variant="outline"
                    className="border-gray-200 rounded-xl flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={saveAdjustment}
                    className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
                  >
                    Save Adjustment
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        <div className="space-y-2">
          {adjustments.length === 0 ? (
            <p className="text-center text-gray-400 py-12">No adjustments yet</p>
          ) : (
            adjustments.map(adj => (
              <div key={adj.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-start justify-between">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{adj.item_name}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{adj.date} · {adj.updated_by}</p>
                  <div className="flex gap-4 mt-2 text-xs">
                    <span className="text-gray-600">${adj.previous_cost.toFixed(2)} → ${adj.new_cost.toFixed(2)}</span>
                    <span className={adj.cost_change > 0 ? "text-red-600" : "text-green-600"}>
                      {adj.cost_change > 0 ? "+" : ""}{adj.cost_change.toFixed(2)}
                    </span>
                    <span className="text-gray-500 capitalize">{adj.reason.replace(/_/g, " ")}</span>
                  </div>
                  {adj.notes && <p className="text-xs text-gray-500 mt-1 italic">{adj.notes}</p>}
                </div>
                <button
                  onClick={() => deleteAdjustment(adj.id)}
                  className="text-gray-300 hover:text-red-500 transition p-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}