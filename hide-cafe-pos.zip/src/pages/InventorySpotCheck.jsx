import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, AlertTriangle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function InventorySpotCheck() {
  const [checks, setChecks] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [actualQty, setActualQty] = useState("");
  const [checkedBy, setCheckedBy] = useState("");
  const [notes, setNotes] = useState("");
  const [user, setUser] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [checks, items, currentUser] = await Promise.all([
      base44.entities.InventorySpotCheck.list("-created_date", 50),
      base44.entities.MenuItem.list(),
      base44.auth.me().catch(() => null)
    ]);
    setChecks(checks);
    setMenuItems(items);
    setUser(currentUser);
    setLoading(false);
  };

  const startCheck = (item) => {
    setSelectedItem(item);
    setActualQty("");
    setCheckedBy(user?.full_name || "");
    setNotes("");
    setShowForm(true);
  };

  const saveCheck = async () => {
    if (actualQty === "" || !selectedItem || !checkedBy.trim()) {
      toast.error("Fill in all fields");
      return;
    }

    const systemQty = selectedItem.stock_quantity || 0;
    const actual = Number(actualQty);
    const variance = actual - systemQty;
    const status = variance === 0 ? "ok" : Math.abs(variance) > 5 ? "critical" : "variance";

    await base44.entities.InventorySpotCheck.create({
      date: new Date().toISOString().split('T')[0],
      menu_item_id: selectedItem.id,
      item_name: selectedItem.name,
      system_quantity: systemQty,
      actual_quantity: actual,
      variance: variance,
      status: status,
      checked_by: checkedBy,
      notes: notes
    });

    if (status !== "ok") {
      toast.warning(`Variance found: ${variance > 0 ? "+" : ""}${variance}`);
    } else {
      toast.success("Spot check saved");
    }

    setShowForm(false);
    loadData();
  };

  const deleteCheck = async (id) => {
    await base44.entities.InventorySpotCheck.delete(id);
    toast.success("Check deleted");
    loadData();
  };

  const filteredItems = menuItems.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  const recentChecks = checks.slice(0, 20);

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Spot Checks</h1>
            <p className="text-gray-400 text-sm mt-0.5">Random item verification</p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Spot Check
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">Spot Check Item</h2>

            {!selectedItem ? (
              <>
                <Input
                  placeholder="Search items..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />
                <div className="max-h-60 overflow-y-auto space-y-1.5">
                  {filteredItems.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-4">No items found</p>
                  ) : (
                    filteredItems.map(item => (
                      <button
                        key={item.id}
                        onClick={() => startCheck(item)}
                        className="w-full text-left px-4 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg transition"
                      >
                        <p className="text-sm font-medium text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-400">System: {item.stock_quantity || 0} units</p>
                      </button>
                    ))
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-sm font-medium text-gray-900">{selectedItem.name}</p>
                  <p className="text-xs text-gray-400 mt-1">System stock: {selectedItem.stock_quantity || 0}</p>
                </div>

                <Input
                  type="number"
                  min="0"
                  placeholder="Actual quantity found"
                  value={actualQty}
                  onChange={e => setActualQty(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />

                <Input
                  placeholder="Checked by"
                  value={checkedBy}
                  onChange={e => setCheckedBy(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />

                <textarea
                  placeholder="Notes (optional)"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-violet-400"
                  rows="2"
                />

                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      setSelectedItem(null);
                      setSearch("");
                    }}
                    variant="outline"
                    className="border-gray-200 rounded-xl flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={saveCheck}
                    className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
                  >
                    Save Check
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        <div className="space-y-2">
          {recentChecks.length === 0 ? (
            <p className="text-center text-gray-400 py-12">No spot checks yet</p>
          ) : (
            recentChecks.map(check => (
              <div key={check.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900">{check.item_name}</p>
                    {check.status === "ok" ? (
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-orange-600" />
                    )}
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">{check.date} · {check.checked_by}</p>
                  <div className="flex gap-4 mt-2 text-xs">
                    <span className="text-gray-600">System: <span className="font-medium">{check.system_quantity}</span></span>
                    <span className="text-gray-600">Actual: <span className="font-medium">{check.actual_quantity}</span></span>
                    <span className={check.variance === 0 ? "text-green-600" : "text-orange-600"}>
                      Variance: <span className="font-medium">{check.variance > 0 ? "+" : ""}{check.variance}</span>
                    </span>
                  </div>
                  {check.notes && <p className="text-xs text-gray-500 mt-1 italic">{check.notes}</p>}
                </div>
                <button
                  onClick={() => deleteCheck(check.id)}
                  className="text-gray-300 hover:text-red-500 transition p-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}