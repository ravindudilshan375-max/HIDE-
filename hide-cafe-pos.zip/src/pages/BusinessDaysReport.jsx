import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, startOfDay, isAfter, eachDayOfInterval, subDays } from "date-fns";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { DollarSign, ShoppingBag, TrendingUp } from "lucide-react";

export default function BusinessDaysReport() {
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 1000),
    ]).then(([u, b, o]) => {
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setOrders(o);
      setLoading(false);
    });
  }, []);

  const periodStart = useMemo(() => startOfMonth(new Date()), []);

  const dailyMetrics = useMemo(() => {
    const days = eachDayOfInterval({ start: periodStart, end: new Date() });
    return days.map(day => {
      const dayOrders = orders.filter(o => 
        o.status === "paid" && 
        format(new Date(o.created_date), "yyyy-MM-dd") === format(day, "yyyy-MM-dd") &&
        (!selectedBranchId || o.branch_id === selectedBranchId)
      );
      return {
        date: format(day, "MMM dd"),
        dateStr: format(day, "yyyy-MM-dd"),
        revenue: dayOrders.reduce((s, o) => s + (o.total || 0), 0),
        orders: dayOrders.length,
        avgOrder: dayOrders.length ? dayOrders.reduce((s, o) => s + (o.total || 0), 0) / dayOrders.length : 0,
      };
    });
  }, [orders, periodStart, selectedBranchId]);

  const stats = useMemo(() => {
    const revenue = dailyMetrics.reduce((s, d) => s + d.revenue, 0);
    const totalOrders = dailyMetrics.reduce((s, d) => s + d.orders, 0);
    const bestDay = dailyMetrics.reduce((max, d) => d.revenue > (max?.revenue || 0) ? d : max, null);
    return {
      totalRevenue: revenue,
      totalOrders,
      avgDaily: dailyMetrics.length ? revenue / dailyMetrics.length : 0,
      bestDay,
    };
  }, [dailyMetrics]);

  if (loading) return <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Business Days Report</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-3">
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
        </div>

        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-violet-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-violet-600" />
            </div>
            <p className="text-2xl font-bold text-violet-600">AED {stats.totalRevenue.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Monthly Revenue</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
              <ShoppingBag className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">{stats.totalOrders}</p>
            <p className="text-xs text-gray-400 mt-1">Total Orders</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">AED {stats.avgDaily.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Avg Daily Revenue</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingUp className="w-5 h-5 text-amber-600" />
            </div>
            <p className="text-2xl font-bold text-amber-600">{stats.bestDay ? format(new Date(stats.bestDay.dateStr), "MMM d") : "—"}</p>
            <p className="text-xs text-gray-400 mt-1">Best Day</p>
          </div>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
          <h3 className="font-semibold text-sm mb-4 text-gray-500">Daily Revenue</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dailyMetrics}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} tickFormatter={v => `AED ${v}`} />
              <Tooltip formatter={(v) => `AED ${v.toFixed(2)}`} />
              <Bar dataKey="revenue" fill="#7c3aed" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
          <h3 className="font-semibold text-sm mb-4 text-gray-500">Order Volume by Day</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={dailyMetrics}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="orders" stroke="#7c3aed" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}