import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";

async function generateSku(prefix, entityName) {
  const all = await base44.entities[entityName].list();
  const nums = all.map(i => parseInt((i.sku || "").replace(`${prefix}-`, ""))).filter(n => !isNaN(n));
  const next = (nums.length > 0 ? Math.max(...nums) : 0) + 1;
  return `${prefix}-${String(next).padStart(4, "0")}`;
}

function GenerateSkuButton({ prefix, entity, onGenerated }) {
  const [loading, setLoading] = useState(false);
  return (
    <button type="button"
      disabled={loading}
      onClick={async () => { setLoading(true); const sku = await generateSku(prefix, entity); onGenerated(sku); setLoading(false); }}
      className="px-3 py-2 text-xs font-medium border border-gray-200 rounded-xl text-gray-600 hover:text-violet-600 hover:border-violet-300 transition whitespace-nowrap disabled:opacity-50"
    >
      {loading ? "..." : "Generate"}
    </button>
  );
}
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Edit2, Trash2, RefreshCw, ArrowLeft, AlertTriangle, ChevronRight, X, Zap, Check, Search, Barcode, Upload, Download } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const UNITS = ["kg", "g", "litre", "ml", "piece", "box", "pack", "bottle", "can", "bag", "CTN", "carton", "pallet", "other"];
const COSTING_METHODS = ["fixed", "weighted_average", "fifo"];

const EMPTY_FORM = {
  name: "", sku: "", barcode: "", category: "",
  storage_unit: "", unit: "kg", factor: "1",
  current_quantity: "", minimum_level: "", par_level: "", maximum_level: "",
  low_stock_threshold: "5", costing_method: "fixed",
  unit_cost: "", supplier_name: "", notes: "", branch_id: ""
};

function DetailField({ label, value }) {
  return (
    <div className="py-3 border-b border-gray-100 last:border-0">
      <p className="text-xs text-gray-400 mb-0.5">{label}</p>
      <p className="text-sm text-gray-800 font-medium">{value ?? "—"}</p>
    </div>
  );
}

function ItemDetail({ item, onEdit, onDelete, onBack }) {
  const costPerUnit = (item.unit_cost || 0) / (item.factor || 1);
  const totalCost = (item.current_quantity || 0) * costPerUnit;
  const threshold = item.low_stock_threshold ?? 5;
  const qty = item.current_quantity ?? 0;
  const isOut = qty <= 0;
  const isLow = !isOut && qty <= threshold;

  return (
    <div className="flex-1 overflow-auto">
      {/* Header */}
      <div className="flex items-center justify-between px-8 py-5 border-b border-gray-100 bg-white sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 transition">
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <span className="text-gray-200">/</span>
          <h2 className="text-xl font-bold text-gray-900">{item.name}</h2>
          {isOut && <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-semibold">Out of Stock</span>}
          {isLow && !isOut && <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">Low Stock</span>}
        </div>
        <div className="flex gap-2">
          <Button onClick={onEdit} variant="outline" className="border-violet-300 text-violet-600 hover:bg-violet-50 rounded-xl gap-2 font-semibold">
            <Edit2 className="w-4 h-4" /> Edit Item
          </Button>
          <button onClick={onDelete} className="p-2 rounded-xl border border-red-200 hover:bg-red-50 text-red-400 hover:text-red-600 transition">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-8 max-w-4xl">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-12">
            <DetailField label="Name" value={item.name} />
            <DetailField label="Name Localized" value={null} />
            <DetailField label="SKU" value={item.sku} />
            <DetailField label="Barcode" value={item.barcode} />
            <DetailField label="Minimum Level" value={item.minimum_level} />
            <DetailField label="Par Level" value={item.par_level} />
            <DetailField label="Maximum Level" value={item.maximum_level} />
            <DetailField label="Storage Unit" value={item.storage_unit} />
            <DetailField label="Ingredient Unit" value={item.unit} />
            <DetailField
              label="Factor"
              value={item.storage_unit && item.unit && item.factor
                ? `1 ${item.storage_unit} = ${Number(item.factor).toLocaleString()} ${item.unit}`
                : item.factor}
            />
            <DetailField
              label="Costing Method"
              value={item.costing_method === "weighted_average" ? "Weighted Average" : item.costing_method ? item.costing_method.charAt(0).toUpperCase() + item.costing_method.slice(1) : null}
            />
            <DetailField label={`Cost per ${item.storage_unit || "Unit"}`} value={item.unit_cost != null ? `AED ${Number(item.unit_cost).toFixed(3)}` : null} />
            <DetailField
              label={`Cost per ${item.unit || "Ingredient Unit"}`}
              value={item.unit_cost != null && item.factor ? `AED ${(Number(item.unit_cost) / Number(item.factor)).toFixed(5)}` : null}
            />
            <DetailField label="Category" value={item.category} />
            <DetailField label="Total Cost of Production" value={`AED ${totalCost.toFixed(3)}`} />
            <DetailField label="Supplier" value={item.supplier_name} />
            <DetailField label="Current Quantity" value={item.current_quantity != null ? `${item.current_quantity} ${item.unit || ""}` : null} />
            {item.notes && <div className="sm:col-span-2"><DetailField label="Notes" value={item.notes} /></div>}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function InventoryItems() {
  const [items, setItems] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingSku, setEditingSku] = useState(null); // { id, value }
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [replenishmentItems, setReplenishmentItems] = useState([]);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [supplierFilter, setSupplierFilter] = useState("all");
  const [showImportModal, setShowImportModal] = useState(false);
  const [importFile, setImportFile] = useState(null);
  const [importError, setImportError] = useState("");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [bulkDeleting, setBulkDeleting] = useState(false);

  useEffect(() => {
    Promise.all([
      base44.entities.InventoryItem.list("name"),
      base44.entities.Branch.list(),
    ]).then(async ([itemData, branchData]) => {
      setItems(itemData);
      setBranches(branchData);
      if (branchData.length > 0) setForm(f => ({ ...f, branch_id: branchData[0].id }));
      
      // Load replenishment suggestions
      try {
        const response = await base44.functions.invoke('getReplenishmentSuggestions', { days: 7, branchId: null });
        setReplenishmentItems(response.data.suggestions || []);
      } catch (_) {}
      
      setLoading(false);
    });
  }, []);

  const reload = () => {
    setLoading(true);
    setSelectedIds(new Set());
    base44.entities.InventoryItem.list("name").then(data => { setItems(data); setLoading(false); });
  };

  const save = async () => {
    if (!form.name || !form.unit || !form.branch_id) {
      toast.error("Name, unit and branch are required");
      return;
    }
    const data = {
      ...form,
      current_quantity: parseFloat(form.current_quantity) || 0,
      low_stock_threshold: parseFloat(form.low_stock_threshold) || 5,
      unit_cost: parseFloat(form.unit_cost) || 0,
      factor: parseFloat(form.factor) || 1,
      minimum_level: form.minimum_level !== "" ? parseFloat(form.minimum_level) : null,
      par_level: form.par_level !== "" ? parseFloat(form.par_level) : null,
      maximum_level: form.maximum_level !== "" ? parseFloat(form.maximum_level) : null,
    };
    let saved;
    if (editingItem) {
      saved = await base44.entities.InventoryItem.update(editingItem.id, data);
      toast.success("Item updated");
    } else {
      saved = await base44.entities.InventoryItem.create(data);
      toast.success("Item created");
    }
    setShowForm(false);
    setEditingItem(null);
    setForm(f => ({ ...EMPTY_FORM, branch_id: f.branch_id }));
    reload();
    if (editingItem) {
      // refresh selected item
      setSelectedItem({ ...editingItem, ...data });
    }
  };

  const saveSku = async (id, sku) => {
    await base44.entities.InventoryItem.update(id, { sku });
    setItems(prev => prev.map(i => i.id === id ? { ...i, sku } : i));
    setEditingSku(null);
    toast.success("SKU updated");
  };

  const deleteItem = async (id) => {
    await base44.entities.InventoryItem.delete(id);
    toast.success("Deleted");
    setItems(prev => prev.filter(i => i.id !== id));
    setSelectedItem(null);
  };

  const autoGenerateSkuBarcode = async () => {
    if (selectedBranch === "all") {
      toast.error("Please select a branch first");
      return;
    }
    
    try {
      setLoading(true);
      const response = await base44.functions.invoke('autoGenerateSkuBarcode', { branch_id: selectedBranch });
      toast.success(response.data.message);
      reload();
    } catch (err) {
      toast.error("Failed to generate SKU/Barcode");
    }
  };

  const downloadTemplate = () => {
    const headers = ["name", "sku", "barcode", "category", "storage_unit", "unit", "cost", "minimum_level", "par_level", "maximum_level", "supplier_name"];
    const csvContent = [
      headers.join(","),
      "Coffee Beans,INV001,200000001,Beverages,kg,piece,45.00,2,5,10,Supplier A",
      "Milk,INV002,200000002,Dairy,liter,ml,8.50,5,10,20,Supplier B",
      "Sugar,INV003,200000003,Sweeteners,kg,gram,3.00,1,3,10,Supplier A"
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "inventory_template.csv";
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleImportChange = (e) => {
    setImportFile(e.target.files?.[0] || null);
    setImportError("");
  };

  const handleImport = async () => {
    if (!importFile) {
      setImportError("Please select a CSV file");
      return;
    }

    if (selectedBranch === "all") {
      setImportError("Please select a branch first");
      return;
    }

    try {
      setLoading(true);
      const text = await importFile.text();
      const lines = text.trim().split("\n");
      const headers = lines[0].split(",").map(h => h.trim().toLowerCase());

      // Validate headers
      const requiredFields = ["name", "cost"];
      const hasRequired = requiredFields.every(f => headers.includes(f));
      if (!hasRequired) {
        setImportError(`CSV must contain columns: ${requiredFields.join(", ")}`);
        setLoading(false);
        return;
      }

      const items = [];
      for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const values = lines[i].split(",").map(v => v.trim());
        const row = {};
        headers.forEach((h, idx) => {
          row[h] = values[idx] || "";
        });

        items.push({
          name: row.name,
          sku: row.sku || "",
          barcode: row.barcode || "",
          category: row.category || "",
          storage_unit: row.storage_unit || "",
          unit: row.unit || "piece",
          cost: parseFloat(row.cost) || 0,
          unit_cost: parseFloat(row.cost) || 0,
          minimum_level: row.minimum_level ? parseFloat(row.minimum_level) : null,
          par_level: row.par_level ? parseFloat(row.par_level) : null,
          maximum_level: row.maximum_level ? parseFloat(row.maximum_level) : null,
          supplier_name: row.supplier_name || "",
          branch_id: selectedBranch,
        });
      }

      // Bulk create items
      if (items.length > 0) {
        await base44.entities.InventoryItem.bulkCreate(items);
        toast.success(`Imported ${items.length} items`);
        setShowImportModal(false);
        setImportFile(null);
        reload();
      } else {
        setImportError("No valid items found in CSV");
      }
    } catch (err) {
      setImportError(`Import failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    const itemsToExport = selectedBranch === "all" ? items : items.filter(i => i.branch_id === selectedBranch);
    
    if (itemsToExport.length === 0) {
      toast.error("No items to export");
      return;
    }

    const headers = ["name", "sku", "barcode", "category", "storage_unit", "unit", "cost", "minimum_level", "par_level", "maximum_level", "supplier_name"];
    const rows = itemsToExport.map(item => [
      item.name,
      item.sku || "",
      item.barcode || "",
      item.category || "",
      item.storage_unit || "",
      item.unit || "",
      (item.unit_cost || 0).toFixed(2),
      item.minimum_level || "",
      item.par_level || "",
      item.maximum_level || "",
      item.supplier_name || ""
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.map(v => `"${v}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `inventory_items_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success("Exported successfully");
  };

  const toggleSelect = (id) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filtered.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map(i => i.id)));
    }
  };

  const bulkDelete = async () => {
    setBulkDeleting(true);
    for (const id of selectedIds) {
      await base44.entities.InventoryItem.delete(id);
    }
    toast.success(`Deleted ${selectedIds.size} items`);
    setSelectedIds(new Set());
    setShowBulkDeleteConfirm(false);
    setBulkDeleting(false);
    reload();
  };

  const openEdit = (item) => {
    setEditingItem(item);
    setForm({
      name: item.name, sku: item.sku || "", barcode: item.barcode || "",
      category: item.category || "", storage_unit: item.storage_unit || "",
      unit: item.unit, factor: item.factor ?? 1,
      current_quantity: item.current_quantity ?? "",
      minimum_level: item.minimum_level ?? "", par_level: item.par_level ?? "",
      maximum_level: item.maximum_level ?? "",
      low_stock_threshold: item.low_stock_threshold ?? 5,
      costing_method: item.costing_method || "fixed",
      unit_cost: item.unit_cost ?? "", supplier_name: item.supplier_name || "",
      notes: item.notes || "", branch_id: item.branch_id || "",
    });
    setShowForm(true);
  };

  const categories = useMemo(() => [...new Set(items.map(i => i.category).filter(Boolean))].sort(), [items]);
  const suppliers = useMemo(() => [...new Set(items.map(i => i.supplier_name).filter(Boolean))].sort(), [items]);

  const filtered = useMemo(() => {
    let f = items;
    if (selectedBranch !== "all") f = f.filter(i => i.branch_id === selectedBranch);
    if (search) f = f.filter(i => i.name.toLowerCase().includes(search.toLowerCase()) || i.sku?.toLowerCase().includes(search.toLowerCase()));
    if (filter === "low") f = f.filter(i => i.current_quantity > 0 && i.current_quantity <= (i.low_stock_threshold ?? 5));
    if (filter === "out") f = f.filter(i => i.current_quantity <= 0);
    if (categoryFilter !== "all") f = f.filter(i => i.category === categoryFilter);
    if (supplierFilter !== "all") f = f.filter(i => i.supplier_name === supplierFilter);
    return f;
  }, [items, filter, search, selectedBranch, categoryFilter, supplierFilter]);

  const stats = useMemo(() => ({
    total: items.length,
    low: items.filter(i => i.current_quantity > 0 && i.current_quantity <= (i.low_stock_threshold ?? 5)).length,
    out: items.filter(i => i.current_quantity <= 0).length,
    value: items.reduce((s, i) => s + (i.current_quantity || 0) * ((i.unit_cost || 0) / (i.factor || 1)), 0),
  }), [items]);

  // If viewing an item detail
  if (selectedItem && !showForm) {
    return (
      <div className="min-h-screen bg-[#f5f5fa] flex flex-col">
        <ItemDetail
          item={selectedItem}
          onBack={() => setSelectedItem(null)}
          onEdit={() => openEdit(selectedItem)}
          onDelete={() => deleteItem(selectedItem.id)}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
              <Link to={createPageUrl("InventoryHub")} className="hover:text-violet-600 transition">Inventory</Link>
              <span>/</span><span className="text-gray-700 font-medium">Inventory Items</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Inventory Items</h1>
            <p className="text-gray-400 text-sm mt-0.5">Raw ingredients & supplies</p>
          </div>
          {replenishmentItems.length > 0 && (
            <Link to={createPageUrl("ReplenishmentReport")} className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition transform hover:scale-105 flex items-center gap-2 text-sm whitespace-nowrap">
              <Zap className="w-4 h-4 animate-pulse" />
              Replenish ({replenishmentItems.length})
            </Link>
          )}
          <div className="flex gap-2 flex-wrap items-center">
            {branches.length > 1 && (
              <select value={selectedBranch} onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <button onClick={reload} className="flex items-center gap-1.5 text-sm bg-white border border-gray-200 hover:border-violet-400 text-gray-600 px-3 py-2 rounded-xl transition">
              <RefreshCw className="w-4 h-4" />
            </button>
            <Button onClick={autoGenerateSkuBarcode} disabled={selectedBranch === "all"} variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm text-gray-600 hover:text-violet-600 hover:border-violet-400">
              <Barcode className="w-4 h-4" /> Generate SKU/Barcode
            </Button>
            <Button onClick={() => setShowImportModal(true)} variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm text-gray-600 hover:text-violet-600 hover:border-violet-400">
              <Upload className="w-4 h-4" /> Import CSV
            </Button>
            <Button onClick={handleExport} variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm text-gray-600 hover:text-violet-600 hover:border-violet-400">
              <Download className="w-4 h-4" /> Export CSV
            </Button>
            <Button onClick={() => { setEditingItem(null); setForm(f => ({ ...EMPTY_FORM, branch_id: f.branch_id })); setShowForm(true); }}
              className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
              <Plus className="w-4 h-4" /> Add Item
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-gray-400">Total Items</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-amber-700">Low Stock</p>
            <p className="text-2xl font-bold text-amber-600 mt-1">{stats.low}</p>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-red-700">Out of Stock</p>
            <p className="text-2xl font-bold text-red-600 mt-1">{stats.out}</p>
          </div>
          <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
            <p className="text-xs text-gray-400">Total Value</p>
            <p className="text-2xl font-bold text-violet-600 mt-1">AED {stats.value.toFixed(2)}</p>
          </div>
        </div>

        {/* Add/Edit Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                <h3 className="font-bold text-gray-900 text-lg">{editingItem ? "Edit Item" : "New Inventory Item"}</h3>
                <button onClick={() => { setShowForm(false); setEditingItem(null); }} className="text-gray-300 hover:text-gray-600 transition">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormFields form={form} setForm={setForm} branches={branches} UNITS={UNITS} COSTING_METHODS={COSTING_METHODS} />
                </div>
              </div>
              <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100">
                {editingItem && (
                  <button onClick={() => { deleteItem(editingItem.id); setShowForm(false); }} className="text-red-500 hover:text-red-700 text-sm font-medium transition">
                    Delete Item
                  </button>
                )}
                <div className="flex gap-2 ml-auto">
                  <Button onClick={() => { setShowForm(false); setEditingItem(null); }} variant="outline" className="border-gray-200 rounded-xl">Close</Button>
                  <Button onClick={save} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
                    {editingItem ? "Save" : "Create"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Import CSV Modal */}
        {showImportModal && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md flex flex-col">
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                <h3 className="font-bold text-gray-900 text-lg">Import Inventory CSV</h3>
                <button onClick={() => { setShowImportModal(false); setImportFile(null); setImportError(""); }} className="text-gray-300 hover:text-gray-600 transition">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                {/* Branch validation */}
                {selectedBranch === "all" && (
                  <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                    <p className="text-sm text-amber-700">Please select a branch before importing</p>
                  </div>
                )}

                {/* Download template button */}
                <button onClick={downloadTemplate} className="w-full text-center px-4 py-2 text-sm text-violet-600 hover:text-violet-700 font-medium border border-violet-200 rounded-xl hover:bg-violet-50 transition">
                  Download Template
                </button>

                {/* File input */}
                <label className="block">
                  <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-violet-400 transition cursor-pointer">
                    <Upload className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                    <p className="text-sm text-gray-600">
                      {importFile ? (
                        <span className="text-violet-600 font-medium">{importFile.name}</span>
                      ) : (
                        <>Drag & drop CSV file<br /><span className="text-xs text-gray-400">or click to browse</span></>
                      )}
                    </p>
                  </div>
                  <input type="file" accept=".csv" onChange={handleImportChange} className="hidden" />
                </label>

                {/* Error message */}
                {importError && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                    <p className="text-sm text-red-700">{importError}</p>
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex gap-2">
                  <Button onClick={() => { setShowImportModal(false); setImportFile(null); setImportError(""); }} variant="outline" className="flex-1 border-gray-200 rounded-xl">
                    Cancel
                  </Button>
                  <Button onClick={handleImport} disabled={!importFile || selectedBranch === "all" || loading} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl disabled:opacity-50">
                    {loading ? "Importing…" : "Import"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input placeholder="Search items or SKU…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9 w-52 bg-white border-gray-200 rounded-xl text-sm" />
          </div>

          {categories.length > 0 && (
            <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}
              className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
              <option value="all">All Categories</option>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          )}

          {suppliers.length > 0 && (
            <select value={supplierFilter} onChange={e => setSupplierFilter(e.target.value)}
              className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
              <option value="all">All Suppliers</option>
              {suppliers.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          )}

          <select value={filter} onChange={e => setFilter(e.target.value)}
            className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
            <option value="all">All Status ({items.length})</option>
            <option value="low">Low Stock ({stats.low})</option>
            <option value="out">Out of Stock ({stats.out})</option>
          </select>
        </div>

        {/* Results count */}
        {(categoryFilter !== "all" || supplierFilter !== "all" || filter !== "all" || search) && (
          <p className="text-xs text-gray-400">Showing {filtered.length} of {items.length} items</p>
        )}

        {/* Bulk Action Toolbar */}
        {selectedIds.size > 0 && (
          <div className="flex items-center gap-3 px-4 py-3 bg-violet-600 text-white rounded-2xl shadow-md">
            <span className="font-semibold text-sm">{selectedIds.size} item{selectedIds.size !== 1 ? "s" : ""} selected</span>
            <div className="flex-1" />
            <button
              onClick={() => setShowBulkDeleteConfirm(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500 hover:bg-red-600 text-white text-sm font-semibold rounded-lg transition"
            >
              <Trash2 className="w-4 h-4" /> Delete
            </button>
            <button onClick={() => setSelectedIds(new Set())} className="flex items-center gap-1 text-sm text-violet-200 hover:text-white transition">
              <X className="w-4 h-4" /> Cancel
            </button>
          </div>
        )}

        {/* List */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {loading ? (
            <p className="text-center py-12 text-gray-300 text-sm">Loading…</p>
          ) : filtered.length === 0 ? (
            <p className="text-center py-12 text-gray-300 text-sm">No inventory items found</p>
          ) : (
            <>
            {/* Select All header */}
            <div className="flex items-center px-5 py-3 border-b border-gray-100 bg-gray-50">
              <input
                type="checkbox"
                checked={filtered.length > 0 && selectedIds.size === filtered.length}
                onChange={toggleSelectAll}
                className="w-4 h-4 rounded accent-violet-600 cursor-pointer mr-3"
              />
              <span className="text-xs text-gray-400 font-medium">Select All ({filtered.length})</span>
            </div>
            {filtered.map((item, idx) => {
              const threshold = item.low_stock_threshold ?? 5;
              const qty = item.current_quantity ?? 0;
              const isOut = qty <= 0;
              const isLow = !isOut && qty <= threshold;

              return (
                <div key={item.id}
                  className={`flex items-center px-5 py-4 border-b border-gray-50 hover:bg-violet-50/40 transition group ${idx === filtered.length - 1 ? "border-b-0" : ""} ${isOut ? "bg-red-50/20" : isLow ? "bg-amber-50/20" : ""} ${selectedIds.has(item.id) ? "bg-violet-50" : ""}`}>

                  <input
                    type="checkbox"
                    checked={selectedIds.has(item.id)}
                    onChange={() => toggleSelect(item.id)}
                    onClick={e => e.stopPropagation()}
                    className="w-4 h-4 rounded accent-violet-600 cursor-pointer mr-3 shrink-0"
                  />
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setSelectedItem(item)}>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-gray-800 text-sm group-hover:text-violet-700 transition">{item.name}</p>
                      {isOut && <span className="px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 text-[10px] font-semibold flex items-center gap-0.5"><AlertTriangle className="w-2.5 h-2.5" />Out</span>}
                      {isLow && !isOut && <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-semibold flex items-center gap-0.5"><AlertTriangle className="w-2.5 h-2.5" />Low</span>}
                    </div>
                    <div className="flex items-center gap-3 mt-0.5" onClick={e => e.stopPropagation()}>
                      {editingSku?.id === item.id ? (
                        <div className="flex items-center gap-1">
                          <Input
                            autoFocus
                            value={editingSku.value}
                            onChange={e => setEditingSku(s => ({ ...s, value: e.target.value }))}
                            onKeyDown={e => { if (e.key === "Enter") saveSku(item.id, editingSku.value); if (e.key === "Escape") setEditingSku(null); }}
                            className="h-6 text-xs border-violet-300 rounded-lg w-32 px-2"
                          />
                          <button onClick={() => saveSku(item.id, editingSku.value)} className="text-violet-600 hover:text-violet-800">
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => setEditingSku(null)} className="text-gray-400 hover:text-gray-600">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setEditingSku({ id: item.id, value: item.sku || "" })}
                          className="text-xs text-gray-400 hover:text-violet-600 transition flex items-center gap-1 group/sku"
                        >
                          <span>{item.sku || <span className="italic text-gray-300">Add SKU</span>}</span>
                          <Edit2 className="w-2.5 h-2.5 opacity-0 group-hover/sku:opacity-100 transition" />
                        </button>
                      )}
                      {item.category && <p className="text-xs text-gray-300">{item.category}</p>}
                      {item.supplier_name && <p className="text-xs text-gray-300">{item.supplier_name}</p>}
                    </div>
                  </div>

                  <div className="flex items-center gap-6 text-sm text-right mr-4 cursor-pointer" onClick={() => setSelectedItem(item)}>
                    <div>
                      <p className="text-xs text-gray-400">Qty {item.storage_unit && `(${item.storage_unit})`}</p>
                      <p className={`font-bold ${isOut ? "text-red-600" : isLow ? "text-amber-600" : "text-gray-700"}`}>
                        {qty} <span className="text-xs font-normal text-gray-400">{item.storage_unit || item.unit}</span>
                      </p>
                      {item.storage_unit && item.factor && item.unit && (
                        <p className="text-xs text-violet-600 mt-0.5">= {(qty * item.factor).toLocaleString()} {item.unit}</p>
                      )}
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Cost/{item.storage_unit || item.unit}</p>
                      <p className="font-semibold text-gray-700">AED {(item.unit_cost || 0).toFixed(3)}</p>
                    </div>
                    <div className="hidden md:block">
                      <p className="text-xs text-gray-400">Cost/{item.unit}</p>
                      <p className="font-semibold text-gray-700">AED {item.factor ? ((item.unit_cost || 0) / item.factor).toFixed(5) : (item.unit_cost || 0).toFixed(5)}</p>
                    </div>
                    <div className="hidden md:block">
                      <p className="text-xs text-gray-400">Value</p>
                      <p className="font-semibold text-violet-600">AED {(qty * ((item.unit_cost || 0) / (item.factor || 1))).toFixed(2)}</p>
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-violet-400 transition shrink-0" />
                </div>
              );
            })}
            </>
          )}
        </div>
      </div>

      {/* Bulk Delete Confirmation */}
      {showBulkDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
            <h3 className="font-bold text-gray-900 text-lg mb-2">Delete {selectedIds.size} items?</h3>
            <p className="text-sm text-gray-500 mb-6">This action cannot be undone. All selected inventory items will be permanently deleted.</p>
            <div className="flex gap-3">
              <Button onClick={() => setShowBulkDeleteConfirm(false)} variant="outline" className="flex-1 border-gray-200 rounded-xl">Cancel</Button>
              <Button onClick={bulkDelete} disabled={bulkDeleting} className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl">
                {bulkDeleting ? "Deleting…" : "Delete"}
              </Button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

// Inline form fields component to avoid duplication
function FormFields({ form, setForm, branches, UNITS, COSTING_METHODS }) {
  return (
    <>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Name *</label>
        <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Tomatoes" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">SKU</label>
        <div className="flex gap-2">
          <Input value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} placeholder="e.g. ING-0001" className="border-gray-200 rounded-xl flex-1" />
          <GenerateSkuButton prefix="ING" onGenerated={(sku) => setForm(f => ({ ...f, sku }))} entity="InventoryItem" />
        </div>
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Barcode</label>
        <Input value={form.barcode} onChange={e => setForm(f => ({ ...f, barcode: e.target.value }))} placeholder="Barcode" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Category</label>
        <Input value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} placeholder="e.g. PKAGN, Produce" className="border-gray-200 rounded-xl" />
      </div>
      {branches.length > 1 && (
        <div>
          <label className="text-xs text-gray-400 mb-1 block font-medium">Branch *</label>
          <select value={form.branch_id} onChange={e => setForm(f => ({ ...f, branch_id: e.target.value }))}
            className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
            {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
      )}
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Storage Unit</label>
        <Input value={form.storage_unit} onChange={e => setForm(f => ({ ...f, storage_unit: e.target.value }))} placeholder="e.g. CTN, Box" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Ingredient Unit *</label>
        <select value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))}
          className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
          {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
        </select>
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">
          Factor {form.storage_unit && form.unit ? <span className="text-violet-500">(1 {form.storage_unit} = ? {form.unit})</span> : ""}
        </label>
        <Input type="number" min="0" step="0.001" value={form.factor} onChange={e => setForm(f => ({ ...f, factor: e.target.value }))} placeholder="1" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">
          Current Quantity {form.storage_unit && form.unit ? <span className="text-violet-500">by {form.storage_unit}</span> : ""}
        </label>
        <div className="space-y-2">
          <Input type="number" min="0" value={form.current_quantity} onChange={e => setForm(f => ({ ...f, current_quantity: e.target.value }))} placeholder="0" className="border-gray-200 rounded-xl" />
          {form.current_quantity && form.factor && form.storage_unit && form.unit && (
            <p className="text-xs text-violet-600 font-medium">= {(parseFloat(form.current_quantity) * parseFloat(form.factor)).toLocaleString()} {form.unit}</p>
          )}
        </div>
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Minimum Level</label>
        <Input type="number" min="0" value={form.minimum_level} onChange={e => setForm(f => ({ ...f, minimum_level: e.target.value }))} placeholder="—" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Par Level</label>
        <Input type="number" min="0" value={form.par_level} onChange={e => setForm(f => ({ ...f, par_level: e.target.value }))} placeholder="—" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Maximum Level</label>
        <Input type="number" min="0" value={form.maximum_level} onChange={e => setForm(f => ({ ...f, maximum_level: e.target.value }))} placeholder="—" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Low Stock Alert</label>
        <Input type="number" min="0" value={form.low_stock_threshold} onChange={e => setForm(f => ({ ...f, low_stock_threshold: e.target.value }))} placeholder="5" className="border-gray-200 rounded-xl" />
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Costing Method</label>
        <select value={form.costing_method} onChange={e => setForm(f => ({ ...f, costing_method: e.target.value }))}
          className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
          {COSTING_METHODS.map(m => <option key={m} value={m}>{m === "weighted_average" ? "Weighted Average" : m.charAt(0).toUpperCase() + m.slice(1)}</option>)}
        </select>
      </div>
      <div className="sm:col-span-2">
        <label className="text-xs text-gray-400 mb-1 block font-medium">Cost per {form.storage_unit || "unit"}</label>
        <Input type="number" min="0" step="0.001" value={form.unit_cost} onChange={e => setForm(f => ({ ...f, unit_cost: e.target.value }))} placeholder="0.000" className="border-gray-200 rounded-xl" />
        {form.unit_cost && parseFloat(form.unit_cost) > 0 && (
          <div className="mt-2 p-3 bg-violet-50 border border-violet-200 rounded-xl space-y-1">
            <p className="text-xs font-semibold text-violet-700">💡 Cost Calculation Preview</p>
            <div className="flex justify-between text-xs text-violet-600">
              <span>Cost per {form.storage_unit || "storage unit"}:</span>
              <span className="font-semibold">AED {parseFloat(form.unit_cost || 0).toFixed(4)}</span>
            </div>
            <div className="flex justify-between text-xs text-violet-700">
              <span>÷ Factor ({form.factor || 1}) = Cost per {form.unit || "ingredient unit"}:</span>
              <span className="font-bold text-violet-800">AED {(parseFloat(form.unit_cost || 0) / (parseFloat(form.factor) || 1)).toFixed(5)}</span>
            </div>
            {parseFloat(form.factor) <= 1 && form.storage_unit && form.unit && form.storage_unit.toLowerCase() !== form.unit.toLowerCase() && (
              <div className="mt-1 p-2 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-xs text-red-700 font-semibold">⚠️ Factor = 1 but units differ!</p>
                <p className="text-xs text-red-600">If 1 {form.storage_unit} = 1000 {form.unit}, set Factor = 1000</p>
              </div>
            )}
          </div>
        )}
      </div>
      <div>
        <label className="text-xs text-gray-400 mb-1 block font-medium">Supplier</label>
        <Input value={form.supplier_name} onChange={e => setForm(f => ({ ...f, supplier_name: e.target.value }))} placeholder="Supplier name" className="border-gray-200 rounded-xl" />
      </div>
      <div className="sm:col-span-2">
        <label className="text-xs text-gray-400 mb-1 block font-medium">Notes</label>
        <Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Storage conditions, notes..." className="border-gray-200 rounded-xl" />
      </div>
    </>
  );
}