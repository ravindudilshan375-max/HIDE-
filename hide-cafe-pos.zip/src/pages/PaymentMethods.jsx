import React, { useState, useEffect } from "react";
import { ChevronLeft, Info, Plus, Edit2, Trash2, MoreVertical } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

const PAYMENT_TYPES = ["Cash", "Card", "Mobile Wallet", "Gift Card", "House Account", "Check"];
const PROVIDER_TYPES = ["Cash", "Card", "3rd Party", "Other"];

export default function PaymentMethods() {
  const [methods, setMethods] = useState([]);
  const [activeTab, setActiveTab] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    type: "Card",
    provider: "Card",
    is_active: true
  });

  useEffect(() => {
    loadMethods();
  }, []);

  const loadMethods = () => {
    const saved = JSON.parse(localStorage.getItem("paymentMethods") || "[]");
    setMethods(saved);
  };

  const saveMethod = () => {
    if (!formData.name.trim()) {
      toast.error("Payment method name is required");
      return;
    }

    let updated;
    if (editingId) {
      updated = methods.map(m => m.id === editingId ? { ...formData, id: editingId, deleted: false } : m);
      toast.success("Payment method updated");
    } else {
      updated = [...methods, { ...formData, id: Date.now().toString(), deleted: false }];
      toast.success("Payment method created");
    }
    setMethods(updated);
    localStorage.setItem("paymentMethods", JSON.stringify(updated));
    resetForm();
  };

  const deleteMethod = (id) => {
    const updated = methods.map(m => m.id === id ? { ...m, deleted: true } : m);
    setMethods(updated);
    localStorage.setItem("paymentMethods", JSON.stringify(updated));
    toast.success("Payment method deleted");
  };

  const toggleActive = (id) => {
    const updated = methods.map(m => m.id === id ? { ...m, is_active: !m.is_active } : m);
    setMethods(updated);
    localStorage.setItem("paymentMethods", JSON.stringify(updated));
  };

  const editMethod = (method) => {
    setEditingId(method.id);
    setFormData({
      name: method.name,
      type: method.type,
      provider: method.provider,
      is_active: method.is_active
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setEditingId(null);
    setFormData({ name: "", type: "Card", provider: "Card", is_active: true });
    setShowForm(false);
  };

  const getFilteredMethods = () => {
    let filtered = methods.filter(m => {
      if (activeTab === "active") return !m.deleted && m.is_active;
      if (activeTab === "inactive") return !m.deleted && !m.is_active;
      if (activeTab === "deleted") return m.deleted;
      return !m.deleted;
    });

    // Sort
    if (sortBy === "name") {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "type") {
      filtered.sort((a, b) => a.type.localeCompare(b.type));
    } else if (sortBy === "status") {
      filtered.sort((a, b) => (b.is_active ? 1 : 0) - (a.is_active ? 1 : 0));
    }

    return filtered;
  };

  const filtered = getFilteredMethods();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <Link to={createPageUrl("Manage")} className="text-gray-600 hover:text-gray-900 transition">
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Payment Methods</h1>
          <Info className="w-5 h-5 text-gray-400" />
        </div>

        <div className="flex items-center justify-between gap-4">
          {/* Tabs */}
          <div className="flex gap-6 border-b border-gray-200">
            {["all", "active", "inactive", "deleted"].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-3 font-medium text-sm capitalize border-b-2 transition-colors ${
                  activeTab === tab
                    ? "border-violet-600 text-gray-900"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="flex gap-3 shrink-0">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500 bg-white"
            >
              <option value="name">Sort Payment Methods</option>
              <option value="type">Sort by Type</option>
              <option value="status">Sort by Status</option>
            </select>
            {activeTab !== "deleted" && (
              <button
                onClick={() => setShowForm(true)}
                className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg font-semibold text-sm transition flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Add Payment Method
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-7xl mx-auto">
        {filtered.length === 0 ? (
          <p className="text-center text-gray-400 py-12">No payment methods</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {filtered.map(method => (
              <div key={method.id} className="bg-white border border-gray-200 rounded-xl p-4 hover:shadow-md transition">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-gray-900">{method.name}</h3>
                  {activeTab !== "deleted" && (
                    <button
                      onClick={() => editMethod(method)}
                      className="text-gray-400 hover:text-violet-600 transition p-1"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <p className="text-xs text-gray-500 mb-3">{method.provider}</p>

                <div className="flex items-center justify-between">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                    method.is_active
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}>
                    {method.is_active ? "Active" : "Inactive"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              {editingId ? "Edit Payment Method" : "Add Payment Method"}
            </h3>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500"
                  placeholder="e.g., Talabat Prepaid"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500"
                >
                  {PAYMENT_TYPES.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Provider</label>
                <select
                  value={formData.provider}
                  onChange={(e) => setFormData({ ...formData, provider: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500"
                >
                  {PROVIDER_TYPES.map(provider => (
                    <option key={provider} value={provider}>{provider}</option>
                  ))}
                </select>
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                  className="w-4 h-4 rounded border-gray-300 text-violet-600 focus:ring-violet-500"
                />
                <span className="text-sm text-gray-700">Active</span>
              </label>
            </div>

            <div className="flex gap-3">
              <button
                onClick={resetForm}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              {editingId && (
                <button
                  onClick={() => {
                    deleteMethod(editingId);
                    resetForm();
                  }}
                  className="flex-1 px-4 py-2 border border-red-300 rounded-lg font-medium text-red-600 hover:bg-red-50 transition"
                >
                  Delete
                </button>
              )}
              <button
                onClick={saveMethod}
                className="flex-1 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg font-medium transition"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}