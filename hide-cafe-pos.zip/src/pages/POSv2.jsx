import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import CheckoutModal from "@/components/pos/CheckoutModal";
import ItemCustomizerModal from "@/components/pos/ItemCustomizerModal";
import CustomItemModal from "@/components/pos/CustomItemModal";
import CustomerPicker from "@/components/pos/CustomerPicker";
import VariantSelector from "@/components/pos/VariantSelector";
import ReprintModal from "@/components/pos/ReprintModal";
import OpenTicketsModal from "@/components/pos/OpenTicketsModal";
import POSMoreMenu from "@/components/pos/POSMoreMenu";
import VoidModal from "@/components/pos/VoidModal";
import POSCategoryTiles from "@/components/pos/POSCategoryTiles.jsx";
import POSProductGrid from "@/components/pos/POSProductGrid.jsx";
import POSOrderPanel from "@/components/pos/POSOrderPanel.jsx";
import POSActionBar from "@/components/pos/POSActionBar.jsx";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { CheckCircle2, XCircle, Home, ClipboardList, LayoutGrid, Plus } from "lucide-react";

export default function POSv2() {
  const [menuItems, setMenuItems] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [orderType, setOrderType] = useState("takeaway");
  const [selectedTable, setSelectedTable] = useState(null);
  const [tables, setTables] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [loyaltyCustomer, setLoyaltyCustomer] = useState(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [user, setUser] = useState(null);
  const [activeCategory, setActiveCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [customizerItem, setCustomizerItem] = useState(null);
  const [showCustomItem, setShowCustomItem] = useState(false);
  const [paymentBanner, setPaymentBanner] = useState(null);
  const [sendingToKitchen, setSendingToKitchen] = useState(false);
  const [kitchenMsg, setKitchenMsg] = useState(null);
  const [showCustomerPicker, setShowCustomerPicker] = useState(false);
  const [discountPct, setDiscountPct] = useState(0);
  const [variantItem, setVariantItem] = useState(null);
  const [showVoidConfirm, setShowVoidConfirm] = useState(false);
  const [selectedCartItem, setSelectedCartItem] = useState(null);
  const [voidMode, setVoidMode] = useState(null);
  const [showReprint, setShowReprint] = useState(false);
  const [showTickets, setShowTickets] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showPromoMenu, setShowPromoMenu] = useState(false);
  const [activePromos, setActivePromos] = useState([]);
  const [branch, setBranch] = useState(null);
  const [printers, setPrinters] = useState([]);
  const [voidReasons, setVoidReasons] = useState([]);
  const [selectedTaxGroup, setSelectedTaxGroup] = useState(null);
  const [taxGroups, setTaxGroups] = useState([]);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    base44.entities.MenuItem.filter({ is_available: true }).then(setMenuItems);
    base44.entities.Table.list().then(setTables);
    base44.entities.Branch.list().then(branches => {
      if (branches.length > 0) setBranch(branches[0]);
    });

    base44.entities.Reason.filter({ category: "void_and_return", is_deleted: false })
      .then(setVoidReasons)
      .catch(() => {});

    base44.entities.TaxGroup?.list()
      .then(groups => {
        const active = groups.filter(g => g.is_active !== false);
        setTaxGroups(active);
        if (active.length > 0) setSelectedTaxGroup(active[0]);
      })
      .catch(() => {});

    const loadPromos = async () => {
      const allDiscounts = await base44.entities.Discount.list();
      const today = new Date().toISOString().split("T")[0];
      const active = allDiscounts.filter(d => {
        if (!d.is_active) return false;
        if (d.start_date && d.start_date > today) return false;
        if (d.end_date && d.end_date < today) return false;
        if (d.usage_limit > 0 && d.times_used >= d.usage_limit) return false;
        return true;
      });
      setActivePromos(active);
    };
    loadPromos();

    try {
      const stored = JSON.parse(localStorage.getItem("pos_printers") || "[]");
      setPrinters(stored);
    } catch { }

    const unsubscribeDiscounts = base44.entities.Discount.subscribe(() => {
      loadPromos();
    });

    const handleAIAdd = (e) => addToCart(e.detail);
    window.addEventListener("pos:addItem", handleAIAdd);

    const params = new URLSearchParams(window.location.search);
    const payment = params.get("payment");
    if (payment === "success") {
      setPaymentBanner("success");
      window.history.replaceState({}, "", window.location.pathname);
      setTimeout(() => setPaymentBanner(null), 5000);
    } else if (payment === "cancelled") {
      setPaymentBanner("cancelled");
      window.history.replaceState({}, "", window.location.pathname);
      setTimeout(() => setPaymentBanner(null), 4000);
    }

    return () => {
      window.removeEventListener("pos:addItem", handleAIAdd);
      unsubscribeDiscounts();
    };
  }, []);

  const addToCart = (item) => {
    if (item.menu_item_id) {
      setCartItems(prev => {
        const canStack = !item.isCustom && (!item.modifiers || item.modifiers.length === 0);
        const existing = canStack && prev.find(c => c.menu_item_id === item.menu_item_id);
        if (existing) {
          return prev.map(c => c.menu_item_id === item.menu_item_id
            ? { ...c, quantity: c.quantity + item.quantity, subtotal: (c.quantity + item.quantity) * c.price }
            : c
          );
        }
        return [...prev, item.isCustom ? { ...item, menu_item_id: `custom_${Date.now()}` } : item];
      });
      return;
    }
    setCartItems(prev => {
      const existing = prev.find(c => c.menu_item_id === item.id);
      if (existing) {
        return prev.map(c => c.menu_item_id === item.id
          ? { ...c, quantity: c.quantity + 1, subtotal: (c.quantity + 1) * c.price }
          : c
        );
      }
      return [...prev, { menu_item_id: item.id, name: item.name, price: item.base_price, quantity: 1, notes: "", modifiers: [], subtotal: item.base_price }];
    });
  };

  const updateCartItem = (menuItemId, updates) => {
    setCartItems(prev => prev.map(c => c.menu_item_id === menuItemId
      ? { ...c, ...updates, subtotal: (updates.quantity ?? c.quantity) * c.price }
      : c
    ).filter(c => c.quantity > 0));
  };

  const clearCart = () => {
    setCartItems([]);
    setSelectedTable(null);
    setCustomerName("");
    setLoyaltyCustomer(null);
    setDiscountPct(0);
  };

  const handleItemClick = (item) => {
    if (item.variants?.length > 0) {
      setVariantItem(item);
    } else if (item.modifiers?.length > 0) {
      setCustomizerItem(item);
    } else {
      addToCart({ menu_item_id: item.id, name: item.name, price: item.base_price, quantity: 1, notes: "", modifiers: [], subtotal: item.base_price });
    }
  };

  const saveTicket = async () => {
    if (cartItems.length === 0) return;
    const sub = cartItems.reduce((s, i) => s + i.subtotal, 0);
    const disc = sub * (discountPct / 100);
    const tx = (sub - disc) * 0.1;
    await base44.entities.Ticket.create({
      customer_name: loyaltyCustomer?.name || customerName || "Guest",
      items: cartItems,
      order_type: orderType,
      table_number: selectedTable?.number || null,
      discount_pct: discountPct,
      subtotal: sub,
      total: sub - disc + tx,
      status: "open",
      branch_id: branch?.id || null,
    });
    clearCart();
    alert("Ticket saved!");
  };

  const loadTicket = (ticket) => {
    setCartItems(ticket.items || []);
    setOrderType(ticket.order_type || "takeaway");
    setDiscountPct(ticket.discount_pct || 0);
    if (ticket.customer_name && ticket.customer_name !== "Guest") {
      setCustomerName(ticket.customer_name);
    }
    base44.entities.Ticket.update(ticket.id, { status: "closed" });
  };

  const sendToKitchen = async () => {
    if (cartItems.length === 0) return;
    setSendingToKitchen(true);
    const orderNumber = `KDS-${Date.now().toString().slice(-6)}`;
    await base44.entities.Order.create({
      order_number: orderNumber,
      type: orderType,
      table_number: selectedTable?.number || null,
      customer_name: loyaltyCustomer?.name || customerName || null,
      items: cartItems,
      status: "pending",
      subtotal: cartItems.reduce((s, i) => s + i.subtotal, 0),
      branch_id: branch?.id,
    });
    const printers = JSON.parse(localStorage.getItem("pos_printers") || "[]");
    const kitchenPrinter = printers.find(p => p.type === "kitchen");
    if (kitchenPrinter) {
      try {
        await base44.functions.invoke("sendToKitchen", {
          items: cartItems, orderType,
          tableNumber: selectedTable?.number || null,
          customerName: loyaltyCustomer?.name || customerName || null,
          printerIp: kitchenPrinter.ip, printerPort: kitchenPrinter.port,
        });
      } catch (_) {}
    }
    setKitchenMsg("Order sent to kitchen!");
    setSendingToKitchen(false);
    setTimeout(() => setKitchenMsg(null), 3000);
  };

  const subtotal = cartItems.reduce((sum, i) => sum + i.subtotal, 0);
  const discountAmt = subtotal * (discountPct / 100);
  const tax = (subtotal - discountAmt) * 0.1;
  const total = subtotal - discountAmt + tax;

  const categories = ["All", ...Array.from(new Set(menuItems.map(i => i.category).filter(Boolean)))];

  const filtered = menuItems.filter(item => {
    const matchCat = activeCategory === "All" || item.category === activeCategory;
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const staffSession = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "{}"); } catch { return {}; } })();
  const activeStaff = staffSession.name || user?.full_name || null;

  return (
    <div className="fixed inset-0 flex flex-col bg-gray-100 text-gray-900 select-none">
      {/* Modals */}
      {variantItem && <VariantSelector item={variantItem} onSelect={addToCart} onClose={() => setVariantItem(null)} />}
      {customizerItem && <ItemCustomizerModal item={customizerItem} onAdd={addToCart} onClose={() => setCustomizerItem(null)} />}
      {showCustomItem && <CustomItemModal onAdd={addToCart} onClose={() => setShowCustomItem(false)} />}

      {paymentBanner === "success" && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9998] flex items-center gap-2 bg-green-100 border border-green-300 text-green-700 px-5 py-3 rounded-2xl text-sm font-medium shadow">
          <CheckCircle2 className="w-4 h-4" /> Payment successful!
        </div>
      )}
      {paymentBanner === "cancelled" && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9998] flex items-center gap-2 bg-red-100 border border-red-300 text-red-700 px-5 py-3 rounded-2xl text-sm font-medium shadow">
          <XCircle className="w-4 h-4" /> Payment cancelled.
        </div>
      )}

      {/* Top Bar - Action Bar */}
      <div className="h-14 flex items-center bg-white border-b border-gray-200 px-4 gap-3 shrink-0 overflow-x-auto">
        <button
          onClick={() => setShowReprint(true)}
          className="flex items-center gap-1.5 px-3 py-2 bg-violet-600 text-white font-semibold text-sm rounded-xl hover:bg-violet-700 transition whitespace-nowrap min-h-[40px]"
        >
          Print
        </button>
        <button
          onClick={() => {
            if (selectedCartItem) { setVoidMode("item"); setShowVoidConfirm(true); }
            else if (cartItems.length > 0) { setVoidMode("order"); setShowVoidConfirm(true); }
            else clearCart();
          }}
          className="flex items-center gap-1.5 px-3 py-2 bg-red-600 text-white font-semibold text-sm rounded-xl hover:bg-red-700 transition whitespace-nowrap min-h-[40px]"
        >
          Void
        </button>
        <button
          onClick={() => setShowTickets(true)}
          className="flex items-center gap-1.5 px-3 py-2 bg-amber-500 text-white font-semibold text-sm rounded-xl hover:bg-amber-600 transition whitespace-nowrap min-h-[40px]"
        >
          Tickets
        </button>
        <button
          onClick={() => setShowMoreMenu(true)}
          className="flex items-center gap-1.5 px-3 py-2 bg-gray-500 text-white font-semibold text-sm rounded-xl hover:bg-gray-600 transition whitespace-nowrap min-h-[40px]"
        >
          More
        </button>
      </div>

      {/* Main Layout Grid - Responsive */}
      <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-[280px_1fr_340px] gap-0 pos-main-content">
        
        {/* Categories Panel (Left) - Hidden on Mobile */}
        <div className="hidden md:flex flex-col bg-white border-r border-gray-200 overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 bg-gray-50">
            <h2 className="font-bold text-sm text-gray-900">Menu</h2>
          </div>
          <div className="flex-1 overflow-y-auto">
            {categories.map((cat) => {
              const itemCount = menuItems.filter(i => activeCategory === "All" ? true : i.category === cat).length;
              const abbrev = cat.slice(0, 2).toUpperCase();
              const isActive = activeCategory === cat;
              
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`w-full flex items-center gap-3 px-3 py-3 border-b border-gray-100 transition-all text-left ${
                    isActive
                      ? "bg-violet-50 border-l-4 border-l-violet-600 border-b-gray-100"
                      : "hover:bg-gray-50"
                  }`}
                >
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center font-bold shrink-0 ${
                    isActive ? "bg-violet-600 text-white" : "bg-gray-200 text-gray-700"
                  }`}>
                    {abbrev}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm text-gray-900 truncate">{cat}</div>
                    <div className="text-xs text-gray-500 mt-0.5">{itemCount} items</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Products Panel (Center) */}
        <div className="flex flex-col bg-gray-50 overflow-hidden">
          {/* Mobile Category Tabs */}
          <div className="md:hidden flex px-3 py-2 gap-2 overflow-x-auto bg-white border-b border-gray-200 scrollbar-hide">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all border ${
                  activeCategory === cat
                    ? "bg-violet-600 text-white border-violet-600"
                    : "bg-white text-gray-500 border-gray-200"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="hidden md:block px-3 py-2 bg-white border-b border-gray-100">
            <input
              placeholder="Search items..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:border-violet-400"
            />
          </div>

          {/* Products Grid */}
          <POSProductGrid
            items={filtered}
            onItemClick={handleItemClick}
            onAddCustom={() => setShowCustomItem(true)}
          />
        </div>

        {/* Order Panel (Right) */}
        <div className="flex flex-col bg-white border-l border-gray-200 overflow-hidden md:border-l md:border-gray-200 md:col-span-1">
          <POSOrderPanel
            cartItems={cartItems}
            orderType={orderType}
            selectedTable={selectedTable}
            tables={tables}
            loyaltyCustomer={loyaltyCustomer}
            customerName={customerName}
            discountPct={discountPct}
            subtotal={subtotal}
            discountAmt={discountAmt}
            tax={tax}
            total={total}
            taxGroups={taxGroups}
            selectedTaxGroup={selectedTaxGroup}
            activeStaff={activeStaff}
            sendingToKitchen={sendingToKitchen}
            kitchenMsg={kitchenMsg}
            selectedCartItem={selectedCartItem}
            onOrderTypeChange={setOrderType}
            onTableChange={setSelectedTable}
            onCustomerClick={() => setShowCustomerPicker(!showCustomerPicker)}
            onCustomerSelect={(c) => { setLoyaltyCustomer(c); setShowCustomerPicker(false); }}
            showCustomerPicker={showCustomerPicker}
            onCartItemClick={(item) => setSelectedCartItem(prev => prev?.menu_item_id === item.menu_item_id ? null : item)}
            onCartItemUpdate={updateCartItem}
            onSaveTicket={saveTicket}
            onSendToKitchen={sendToKitchen}
            onCheckout={() => cartItems.length > 0 && setShowCheckout(true)}
            onTaxGroupChange={setSelectedTaxGroup}
          />
        </div>
      </div>

      {/* Bottom Action Bar - Fixed Above Navigation */}
      <div className="fixed bottom-16 left-0 right-0 md:hidden flex items-center gap-3 bg-white border-t border-gray-200 px-3 py-2 z-40">
        <button
          onClick={sendToKitchen}
          disabled={cartItems.length === 0 || sendingToKitchen}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-full font-bold text-sm transition-all min-h-[48px] ${
            cartItems.length === 0
              ? "bg-gray-200 text-gray-400 cursor-not-allowed"
              : "bg-orange-500 hover:bg-orange-600 text-white"
          }`}
        >
          <span>🍳</span> Kitchen {cartItems.length > 0 && `(${cartItems.length})`}
        </button>
        <button
          onClick={() => cartItems.length > 0 && setShowCheckout(true)}
          disabled={cartItems.length === 0}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-full font-bold text-sm transition-all min-h-[48px] ${
            cartItems.length === 0
              ? "bg-gray-400 text-white cursor-not-allowed"
              : "bg-black hover:bg-gray-900 text-white"
          }`}
        >
          <span>💳</span> Charge AED {total.toFixed(2)}
        </button>
      </div>

      {/* Bottom Navigation - Mobile Only */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 flex items-center bg-white border-t border-gray-200 gap-0 z-40">
        <button 
          onClick={() => setShowCustomItem(true)}
          className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-500 hover:text-violet-600 transition text-xs font-semibold"
        >
          <Plus className="w-5 h-5" /> NEW
        </button>
        <Link 
          to={createPageUrl("Orders")} 
          className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-500 hover:text-violet-600 transition text-xs font-semibold"
        >
          <ClipboardList className="w-5 h-5" /> ORDERS
        </Link>
        <Link 
          to={createPageUrl("Tables")} 
          className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-500 hover:text-violet-600 transition text-xs font-semibold"
        >
          <LayoutGrid className="w-5 h-5" /> TABLES
        </Link>
        <button 
          onClick={() => setShowMoreMenu(true)}
          className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2 text-gray-500 hover:text-violet-600 transition text-xs font-semibold"
        >
          <span className="text-lg">⋮</span> MORE
        </button>
      </div>

      {/* Add padding to main layout for mobile bottom bars */}
      <style>{`
        @media (max-width: 768px) {
          .pos-main-content {
            padding-bottom: 112px;
          }
        }
      `}</style>

      {/* Modals */}
      {showReprint && <ReprintModal onClose={() => setShowReprint(false)} />}
      {showTickets && <OpenTicketsModal onClose={() => setShowTickets(false)} onLoadTicket={loadTicket} branchId={branch?.id} />}
      {showMoreMenu && <POSMoreMenu onClose={() => setShowMoreMenu(false)} onUserLogin={(u) => setUser(u)} />}

      {showVoidConfirm && (
        <VoidModal
          mode={voidMode}
          item={voidMode === "item" ? selectedCartItem : null}
          voidReasons={voidReasons}
          onClose={() => { setShowVoidConfirm(false); setVoidMode(null); }}
          onConfirm={async ({ reason, authorizedStaff }) => {
            const session = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "{}"); } catch { return {}; } })();
            if (voidMode === "item" && selectedCartItem) {
              setCartItems(prev => prev.map(c =>
                c.menu_item_id === selectedCartItem.menu_item_id
                  ? { ...c, is_voided: true, voided_by: authorizedStaff?.name || session.name, void_reason: reason, void_time: new Date().toISOString() }
                  : c
              ));
              await base44.entities.AuditLog.create({
                actor_email: user?.email || "pos",
                actor_name: authorizedStaff?.name || session.name || "POS",
                action: "void",
                entity_type: "Order",
                entity_name: selectedCartItem.name,
                description: `Void item: ${selectedCartItem.name} — ${reason}`,
                severity: "warning",
              });
              setSelectedCartItem(null);
            } else {
              clearCart();
              await base44.entities.AuditLog.create({
                actor_email: user?.email || "pos",
                actor_name: authorizedStaff?.name || session.name || "POS",
                action: "void",
                entity_type: "Order",
                entity_name: "Cart Order",
                description: `Void entire order — ${reason}`,
                severity: "warning",
              });
            }
            setShowVoidConfirm(false);
            setVoidMode(null);
          }}
        />
      )}

      {showCheckout && (
        <CheckoutModal
          cartItems={cartItems}
          orderType={orderType}
          selectedTable={selectedTable}
          customerName={loyaltyCustomer?.name || customerName}
          subtotal={subtotal || 0}
          tax={tax || 0}
          total={total || 0}
          cashierName={user?.full_name || "Cashier"}
          tables={tables}
          loyaltyCustomer={loyaltyCustomer}
          branchId={branch?.id}
          selectedTaxGroup={selectedTaxGroup}
          onClose={() => setShowCheckout(false)}
          onSuccess={() => {
            clearCart();
            setShowCheckout(false);
            setSelectedTaxGroup(null);
            base44.entities.Table.list().then(setTables);
          }}
        />
      )}
    </div>
  );
}