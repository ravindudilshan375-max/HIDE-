import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import {
  startOfDay, startOfWeek, startOfMonth, subDays, subWeeks, subMonths,
  isAfter, isBefore, format, eachDayOfInterval, eachWeekOfInterval
} from "date-fns";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from "recharts";
import { TrendingUp, ShoppingBag, DollarSign, Users, Star, Award, Calendar, Package, AlertTriangle, Zap, Clock } from "lucide-react";

const TABS = ["Sales", "Top Items", "Customer Habits", "Loyalty", "Inventory", "Staff"];

const PERIODS = [
  { label: "Today", key: "day" },
  { label: "This Week", key: "week" },
  { label: "This Month", key: "month" },
];

function StatCard({ icon: Icon, label, value, sub, color = "text-violet-600", bg = "bg-violet-50" }) {
  return (
    <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
      <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-xs text-gray-400 mt-1">{label}</p>
      {sub && <p className="text-xs text-gray-300 mt-0.5">{sub}</p>}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 shadow rounded-xl px-4 py-3 text-sm">
      <p className="text-gray-400 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="font-semibold">
          {p.name}: {typeof p.value === "number" && p.name.toLowerCase().includes("$") || p.name === "Revenue"
            ? `AED ${p.value.toFixed(2)}` : p.value}
        </p>
      ))}
    </div>
  );
};

export default function Reports() {
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [branches, setBranches] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("Sales");
  const [period, setPeriod] = useState("week");
  const [reorderThreshold, setReorderThreshold] = useState(10);
  const [selectedBranchId, setSelectedBranchId] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 500),
      base44.entities.Customer.list("-points", 100),
      base44.entities.MenuItem.list(),
      base44.entities.StaffSchedule.list(),
    ]).then(([u, b, o, c, m, s]) => {
      setUser(u);
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setOrders(o);
      setCustomers(c);
      setMenuItems(m);
      setSchedules(s);
      setLoading(false);
    });
  }, []);

  const periodStart = useMemo(() => {
    if (period === "day") return startOfDay(new Date());
    if (period === "week") return startOfWeek(new Date(), { weekStartsOn: 1 });
    return startOfMonth(new Date());
  }, [period]);

  const paidOrders = useMemo(() =>
    orders.filter(o => o.status === "paid" && o.created_date && isAfter(new Date(o.created_date), periodStart) && (!selectedBranchId || o.branch_id === selectedBranchId)),
    [orders, periodStart, selectedBranchId]
  );

  const branchMenuItems = useMemo(() =>
    menuItems.filter(m => !selectedBranchId || m.branch_id === selectedBranchId),
    [menuItems, selectedBranchId]
  );

  const branchSchedules = useMemo(() =>
    schedules.filter(s => !selectedBranchId || s.branch_id === selectedBranchId),
    [schedules, selectedBranchId]
  );

  // --- Sales Tab ---
  const salesStats = useMemo(() => {
    const revenue = paidOrders.reduce((s, o) => s + (o.total || 0), 0);
    const count = paidOrders.length;
    const avg = count ? revenue / count : 0;
    const discounts = paidOrders.reduce((s, o) => s + (o.discount || 0), 0);
    return { revenue, count, avg, discounts };
  }, [paidOrders]);

  const salesChartData = useMemo(() => {
    if (period === "day") {
      const hours = Array.from({ length: 24 }, (_, h) => ({ label: `${h}:00`, Revenue: 0, Orders: 0 }));
      paidOrders.forEach(o => {
        const h = new Date(o.created_date).getHours();
        hours[h].Revenue += o.total || 0;
        hours[h].Orders += 1;
      });
      return hours.filter(h => h.Revenue > 0 || h.Orders > 0);
    }
    if (period === "week") {
      const days = eachDayOfInterval({ start: periodStart, end: new Date() });
      return days.map(d => {
        const label = format(d, "EEE");
        const dayOrders = paidOrders.filter(o => format(new Date(o.created_date), "yyyy-MM-dd") === format(d, "yyyy-MM-dd"));
        return { label, Revenue: dayOrders.reduce((s, o) => s + (o.total || 0), 0), Orders: dayOrders.length };
      });
    }
    // month — group by week
    const weeks = eachWeekOfInterval({ start: periodStart, end: new Date() }, { weekStartsOn: 1 });
    return weeks.map((wStart, i) => {
      const wEnd = subDays(weeks[i + 1] || new Date(), 0);
      const label = `W${i + 1} (${format(wStart, "MMM d")})`;
      const wOrders = paidOrders.filter(o => {
        const d = new Date(o.created_date);
        return isAfter(d, wStart) && (i + 1 >= weeks.length || isBefore(d, weeks[i + 1]));
      });
      return { label, Revenue: wOrders.reduce((s, o) => s + (o.total || 0), 0), Orders: wOrders.length };
    });
  }, [paidOrders, period, periodStart]);

  // --- Top Items Tab ---
  const topItems = useMemo(() => {
    const map = {};
    paidOrders.forEach(o => {
      (o.items || []).forEach(item => {
        if (!map[item.name]) map[item.name] = { name: item.name, qty: 0, revenue: 0 };
        map[item.name].qty += item.quantity || 1;
        map[item.name].revenue += item.subtotal || 0;
      });
    });
    return Object.values(map).sort((a, b) => b.qty - a.qty).slice(0, 10);
  }, [paidOrders]);

  // --- Customer Habits Tab ---
  const customerStats = useMemo(() => {
    const byCustomer = {};
    paidOrders.forEach(o => {
      const key = o.customer_name || "(Walk-in)";
      if (!byCustomer[key]) byCustomer[key] = { name: key, visits: 0, spent: 0, items: 0 };
      byCustomer[key].visits += 1;
      byCustomer[key].spent += o.total || 0;
      byCustomer[key].items += (o.items || []).reduce((s, i) => s + (i.quantity || 1), 0);
    });
    return Object.values(byCustomer).sort((a, b) => b.spent - a.spent).slice(0, 10);
  }, [paidOrders]);

  const orderTypeBreakdown = useMemo(() => {
    const dine = paidOrders.filter(o => o.type === "dine-in").length;
    const take = paidOrders.filter(o => o.type === "takeaway").length;
    return [
      { label: "Dine-In", value: dine, color: "bg-amber-400" },
      { label: "Takeaway", value: take, color: "bg-blue-400" },
    ];
  }, [paidOrders]);

  // --- Loyalty Tab ---
  const loyaltyStats = useMemo(() => {
    const totalPoints = customers.reduce((s, c) => s + (c.points || 0), 0);
    const active = customers.filter(c => (c.visit_count || 0) > 0).length;
    const gold = customers.filter(c => (c.points || 0) >= 5000).length;
    const silver = customers.filter(c => (c.points || 0) >= 1000 && (c.points || 0) < 5000).length;
    const bronze = customers.filter(c => (c.points || 0) < 1000).length;
    const totalDiscount = paidOrders.reduce((s, o) => s + (o.discount || 0), 0);
    return { totalPoints, active, gold, silver, bronze, totalDiscount };
  }, [customers, paidOrders]);

  const topLoyalty = useMemo(() =>
    [...customers].sort((a, b) => (b.points || 0) - (a.points || 0)).slice(0, 8),
    [customers]
  );

  // --- Inventory Tab ---
  // Use all paid orders from the last 30 days for velocity
  const last30DaysOrders = useMemo(() => {
    const cutoff = subDays(new Date(), 30);
    return orders.filter(o => o.status === "paid" && o.created_date && isAfter(new Date(o.created_date), cutoff));
  }, [orders]);

  const inventoryData = useMemo(() => {
    // Build sales velocity map (units sold in last 30 days)
    const salesMap = {};
    last30DaysOrders.forEach(o => {
      (o.items || []).forEach(item => {
        if (!salesMap[item.name]) salesMap[item.name] = 0;
        salesMap[item.name] += item.quantity || 1;
      });
    });

    return menuItems.map(item => {
      const soldLast30 = salesMap[item.name] || 0;
      const velocityPerDay = soldLast30 / 30;
      const stock = item.stock_quantity ?? null; // null = untracked
      const daysUntilEmpty = stock !== null && velocityPerDay > 0 ? Math.floor(stock / velocityPerDay) : null;
      const belowThreshold = stock !== null && stock <= reorderThreshold;
      return { ...item, soldLast30, velocityPerDay, stock, daysUntilEmpty, belowThreshold };
    }).sort((a, b) => {
      // Sort: below threshold first, then by velocity desc
      if (a.belowThreshold && !b.belowThreshold) return -1;
      if (!a.belowThreshold && b.belowThreshold) return 1;
      return b.velocityPerDay - a.velocityPerDay;
    });
  }, [menuItems, last30DaysOrders, reorderThreshold]);

  const belowThresholdCount = useMemo(() => inventoryData.filter(i => i.belowThreshold).length, [inventoryData]);

  // --- Staff Tab ---
  const staffStats = useMemo(() => {
    const staffMap = {};
    branchSchedules.forEach(s => {
      if (!staffMap[s.staff_email]) {
        staffMap[s.staff_email] = { email: s.staff_email, name: s.staff_name, shifts: 0, role: s.role };
      }
      staffMap[s.staff_email].shifts += 1;
    });
    return Object.values(staffMap).sort((a, b) => b.shifts - a.shifts);
  }, [branchSchedules]);

  if (loading) return (
    <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center">
      <p className="text-gray-400 text-sm">Loading reports…</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-100 bg-white flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
        </div>
        <div className="flex gap-3 flex-wrap">
          {/* Branch selector */}
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-gray-100 border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
          {/* Period selector — hidden on Inventory & Staff tabs */}
          {!["Inventory", "Staff"].includes(activeTab) && (
            <div className="flex bg-gray-100 rounded-xl p-1 gap-1">
              {PERIODS.map(p => (
                <button key={p.key} onClick={() => setPeriod(p.key)}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${period === p.key ? "bg-violet-600 text-white" : "text-gray-500 hover:text-gray-800"}`}>
                  {p.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 pt-4 flex gap-1 border-b border-gray-100 bg-white overflow-x-auto">
        {TABS.map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 text-sm font-medium rounded-t-xl transition-all whitespace-nowrap ${activeTab === tab ? "bg-gray-50 text-violet-700 border border-b-0 border-gray-200" : "text-gray-400 hover:text-gray-700"}`}>
            {tab}
          </button>
        ))}
      </div>

      <div className="p-6 space-y-6">

        {/* SALES TAB */}
        {activeTab === "Sales" && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={DollarSign} label="Total Revenue" value={`AED ${salesStats.revenue.toFixed(2)}`} />
              <StatCard icon={ShoppingBag} label="Orders" value={salesStats.count} color="text-blue-600" bg="bg-blue-50" />
              <StatCard icon={TrendingUp} label="Avg Order Value" value={`AED ${salesStats.avg.toFixed(2)}`} color="text-green-600" bg="bg-green-50" />
              <StatCard icon={Calendar} label="Discounts Given" value={`AED ${salesStats.discounts.toFixed(2)}`} color="text-purple-600" bg="bg-purple-50" />
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
              <h3 className="font-semibold text-sm mb-4 text-gray-500">Revenue Over Time</h3>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={salesChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="label" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `AED ${v}`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="Revenue" stroke="#7c3aed" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
              <h3 className="font-semibold text-sm mb-4 text-gray-500">Order Volume</h3>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={salesChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="label" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="Orders" fill="#7c6cf8" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </>
        )}

        {/* TOP ITEMS TAB */}
        {activeTab === "Top Items" && (
          <>
            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
              <h3 className="font-semibold text-sm mb-4 text-gray-500">Items by Quantity Sold</h3>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={topItems} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                  <XAxis type="number" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="name" type="category" tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} width={100} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="qty" name="Qty Sold" fill="#7c6cf8" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-4">
                <span className="col-span-2">Item</span><span className="text-right">Qty Sold</span><span className="text-right">Revenue</span>
              </div>
              {topItems.map((item, i) => (
                <div key={item.name} className="grid grid-cols-4 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm">
                  <div className="col-span-2 flex items-center gap-3">
                    <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                    <span className="font-medium text-gray-800">{item.name}</span>
                  </div>
                  <span className="text-right text-blue-600 font-semibold">{item.qty}</span>
                  <span className="text-right text-violet-700 font-semibold">AED {item.revenue.toFixed(2)}</span>
                </div>
              ))}
              {topItems.length === 0 && <p className="text-center py-10 text-gray-300 text-sm">No data for this period</p>}
            </div>
          </>
        )}

        {/* CUSTOMER HABITS TAB */}
        {activeTab === "Customer Habits" && (
          <>
            <div className="grid grid-cols-2 gap-4">
              {orderTypeBreakdown.map(t => (
                <div key={t.label} className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${t.color}`} />
                    <span className="text-sm text-gray-500">{t.label}</span>
                  </div>
                  <p className="text-3xl font-bold text-gray-900">{t.value}</p>
                  <p className="text-xs text-gray-300 mt-1">orders</p>
                </div>
              ))}
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100">
                <h3 className="font-semibold text-sm text-gray-500">Top Spenders</h3>
              </div>
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-4">
                <span className="col-span-2">Customer</span><span className="text-right">Visits</span><span className="text-right">Total Spent</span>
              </div>
              {customerStats.map((c, i) => (
                <div key={c.name} className="grid grid-cols-4 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm">
                  <div className="col-span-2 flex items-center gap-3">
                    <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                    <span className="font-medium text-gray-800">{c.name}</span>
                  </div>
                  <span className="text-right text-gray-500">{c.visits}</span>
                  <span className="text-right text-violet-700 font-semibold">AED {c.spent.toFixed(2)}</span>
                </div>
              ))}
              {customerStats.length === 0 && <p className="text-center py-10 text-gray-300 text-sm">No data for this period</p>}
            </div>
          </>
        )}

        {/* INVENTORY TAB */}
        {activeTab === "Inventory" && (
          <>
            <div className="grid grid-cols-3 gap-4">
              <StatCard icon={Package} label="Total Menu Items" value={inventoryData.length} color="text-blue-600" bg="bg-blue-50" />
              <StatCard icon={AlertTriangle} label="Below Reorder Threshold" value={belowThresholdCount} color="text-red-600" bg="bg-red-50" />
              <StatCard icon={Zap} label="Top Item Velocity" value={inventoryData[0] ? `${inventoryData[0].velocityPerDay.toFixed(1)}/day` : "—"} color="text-green-600" bg="bg-green-50" />
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-4 flex items-center gap-4">
              <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
              <span className="text-sm text-gray-500">Reorder threshold:</span>
              <input
                type="number"
                min={0}
                value={reorderThreshold}
                onChange={e => setReorderThreshold(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-20 bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-sm text-gray-800 text-center focus:outline-none focus:border-violet-400"
              />
              <span className="text-sm text-gray-400">units — items at or below this quantity will be flagged</span>
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-12">
                <span className="col-span-3">Item</span>
                <span className="col-span-2 text-center">Category</span>
                <span className="col-span-2 text-center">Stock</span>
                <span className="col-span-2 text-center">Sold (30d)</span>
                <span className="col-span-2 text-center">Velocity</span>
                <span className="col-span-1 text-center">Days Left</span>
              </div>
              {inventoryData.map(item => (
                <div key={item.id}
                  className={`grid grid-cols-12 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm items-center ${item.belowThreshold ? "bg-red-50" : ""}`}>
                  <div className="col-span-3 flex items-center gap-2">
                    {item.belowThreshold && <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0" />}
                    <span className={`font-medium ${item.belowThreshold ? "text-red-600" : "text-gray-800"}`}>{item.name}</span>
                  </div>
                  <span className="col-span-2 text-center text-gray-400 text-xs">{item.category || "—"}</span>
                  <div className="col-span-2 text-center">
                    {item.stock !== null ? (
                      <span className={`font-semibold ${item.belowThreshold ? "text-red-600" : "text-gray-800"}`}>{item.stock}</span>
                    ) : (
                      <span className="text-gray-300 text-xs italic">untracked</span>
                    )}
                  </div>
                  <span className="col-span-2 text-center text-blue-600 font-semibold">{item.soldLast30}</span>
                  <div className="col-span-2 text-center">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${item.velocityPerDay > 5 ? "bg-green-100 text-green-700" : item.velocityPerDay > 1 ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-400"}`}>
                      {item.velocityPerDay.toFixed(1)}/day
                    </span>
                  </div>
                  <div className="col-span-1 text-center">
                    {item.daysUntilEmpty !== null ? (
                      <span className={`text-xs font-semibold ${item.daysUntilEmpty <= 3 ? "text-red-600" : item.daysUntilEmpty <= 7 ? "text-amber-600" : "text-green-600"}`}>
                        {item.daysUntilEmpty}d
                      </span>
                    ) : (
                      <span className="text-gray-300 text-xs">—</span>
                    )}
                  </div>
                </div>
              ))}
              {inventoryData.length === 0 && (
                <p className="text-center py-10 text-gray-300 text-sm">No menu items found</p>
              )}
            </div>

            <p className="text-xs text-gray-300 text-center">
              Stock levels require a <span className="text-gray-400">stock_quantity</span> field on menu items. Velocity is based on the last 30 days of paid orders.
            </p>
          </>
        )}

        {/* LOYALTY TAB */}
        {activeTab === "Loyalty" && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              <StatCard icon={Users} label="Active Members" value={loyaltyStats.active} color="text-blue-600" bg="bg-blue-50" />
              <StatCard icon={Star} label="Total Points in Circulation" value={loyaltyStats.totalPoints.toLocaleString()} />
              <StatCard icon={Award} label="Discounts Redeemed" value={`AED ${loyaltyStats.totalDiscount.toFixed(2)}`} color="text-green-600" bg="bg-green-50" />
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
              <h3 className="font-semibold text-sm mb-4 text-gray-500">Tier Breakdown</h3>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "Gold", count: loyaltyStats.gold, color: "text-yellow-600", bg: "bg-yellow-50", border: "border-yellow-100" },
                  { label: "Silver", count: loyaltyStats.silver, color: "text-slate-500", bg: "bg-slate-50", border: "border-slate-200" },
                  { label: "Bronze", count: loyaltyStats.bronze, color: "text-orange-600", bg: "bg-orange-50", border: "border-orange-100" },
                ].map(t => (
                  <div key={t.label} className={`${t.bg} border ${t.border} rounded-xl p-4 text-center`}>
                    <p className={`text-3xl font-bold ${t.color}`}>{t.count}</p>
                    <p className="text-xs text-gray-400 mt-1">{t.label} Members</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100">
                <h3 className="font-semibold text-sm text-gray-500">Top Loyalty Members</h3>
              </div>
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-4">
                <span className="col-span-2">Customer</span><span className="text-right">Visits</span><span className="text-right">Points</span>
              </div>
              {topLoyalty.map((c, i) => {
                const tier = c.points >= 5000 ? { label: "Gold", color: "text-yellow-600" } : c.points >= 1000 ? { label: "Silver", color: "text-slate-500" } : { label: "Bronze", color: "text-orange-600" };
                return (
                  <div key={c.id} className="grid grid-cols-4 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm">
                    <div className="col-span-2 flex items-center gap-3">
                      <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                      <div>
                        <p className="font-medium text-gray-800">{c.name}</p>
                        <p className={`text-xs ${tier.color}`}>{tier.label}</p>
                      </div>
                    </div>
                    <span className="text-right text-gray-500 self-center">{c.visit_count || 0}</span>
                    <span className="text-right text-violet-700 font-semibold self-center">{(c.points || 0).toLocaleString()}</span>
                  </div>
                );
              })}
              {topLoyalty.length === 0 && <p className="text-center py-10 text-gray-300 text-sm">No loyalty members yet</p>}
            </div>
          </>
        )}

        {/* STAFF TAB */}
        {activeTab === "Staff" && (
          <>
            <div className="grid grid-cols-2 gap-4">
              <StatCard icon={Users} label="Staff Members" value={staffStats.length} color="text-blue-600" bg="bg-blue-50" />
              <StatCard icon={Clock} label="Total Shifts (Period)" value={branchSchedules.length} color="text-green-600" bg="bg-green-50" />
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100">
                <h3 className="font-semibold text-sm text-gray-500">Staff Performance</h3>
              </div>
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-4">
                <span className="col-span-2">Staff Member</span><span className="text-center">Role</span><span className="text-right">Shifts</span>
              </div>
              {staffStats.map((staff, i) => (
                <div key={staff.email} className="grid grid-cols-4 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm items-center">
                  <div className="col-span-2 flex items-center gap-3">
                    <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                    <div>
                      <p className="font-medium text-gray-800">{staff.name}</p>
                      <p className="text-xs text-gray-400">{staff.email}</p>
                    </div>
                  </div>
                  <span className="text-center text-gray-500 text-xs">{staff.role || "—"}</span>
                  <span className="text-right text-violet-700 font-semibold">{staff.shifts}</span>
                </div>
              ))}
              {staffStats.length === 0 && <p className="text-center py-10 text-gray-300 text-sm">No staff schedules found</p>}
            </div>
          </>
        )}
        </div>
        </div>
        );
        }