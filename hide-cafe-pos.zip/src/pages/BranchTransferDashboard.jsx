import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import TransferStats from "@/components/transfers/TransferStats";
import TransferList from "@/components/transfers/TransferList";
import BranchStockTable from "@/components/transfers/BranchStockTable";
import CreateTransferModal from "@/components/transfers/CreateTransferModal";
import TransferDetailModal from "@/components/transfers/TransferDetailModal";
import TransferFilters from "@/components/transfers/TransferFilters";
import { Button } from "@/components/ui/button";
import { Plus, RefreshCw, ArrowLeftRight, Package, BarChart2, ClipboardList } from "lucide-react";
import { toast } from "sonner";

const TABS = [
  { id: "dashboard", label: "Dashboard", icon: BarChart2 },
  { id: "transfers", label: "Transfers", icon: ArrowLeftRight },
  { id: "stock", label: "Stock Overview", icon: Package },
  { id: "history", label: "History", icon: ClipboardList },
];

export default function BranchTransferDashboard() {
  const [tab, setTab] = useState("dashboard");
  const [branches, setBranches] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [filters, setFilters] = useState({ status: "all", branch: "all", search: "" });

  // transfer_manager: all actions allowed
  const session = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "null"); } catch { return null; } })();
  const isTransferManager = session?.role_type === "transfer_manager";

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const [branchData, invData, transferData, userData] = await Promise.all([
      base44.entities.Branch.list(),
      base44.entities.InventoryItem.list(),
      base44.entities.BranchTransfer.list("-created_date"),
      base44.auth.me().catch(() => null),
    ]);
    setBranches(branchData);
    setInventoryItems(invData);
    setTransfers(transferData);
    setUser(userData);
    setLoading(false);
  };

  const handleApprove = async (transfer) => {
    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "approved",
      approved_by: user?.email,
      approved_by_name: user?.full_name,
      approval_date: new Date().toISOString(),
    });
    toast.success("Transfer approved");
    loadData();
    if (selectedTransfer?.id === transfer.id) setSelectedTransfer(null);
  };

  const handleReject = async (transfer) => {
    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "cancelled",
      approved_by: user?.email,
      approved_by_name: user?.full_name,
    });
    toast.success("Transfer rejected");
    loadData();
    if (selectedTransfer?.id === transfer.id) setSelectedTransfer(null);
  };

  const handleComplete = async (transfer) => {
    // Adjust inventory
    for (const item of transfer.items || []) {
      const srcItem = inventoryItems.find(i => i.id === item.menu_item_id && i.branch_id === transfer.from_branch_id);
      if (srcItem) {
        await base44.entities.InventoryItem.update(srcItem.id, {
          current_quantity: Math.max(0, (srcItem.current_quantity || 0) - item.quantity),
        });
      }
      const dstItems = inventoryItems.filter(i => i.name === (srcItem?.name || item.item_name) && i.branch_id === transfer.to_branch_id);
      if (dstItems.length > 0) {
        await base44.entities.InventoryItem.update(dstItems[0].id, {
          current_quantity: (dstItems[0].current_quantity || 0) + item.quantity,
        });
      }
    }
    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "completed",
      completion_date: new Date().toISOString(),
    });
    toast.success("Transfer completed — inventory updated");
    loadData();
    if (selectedTransfer?.id === transfer.id) setSelectedTransfer(null);
  };

  const filteredTransfers = transfers.filter(t => {
    if (filters.status !== "all" && t.status !== filters.status) return false;
    if (filters.branch !== "all" && t.from_branch_id !== filters.branch && t.to_branch_id !== filters.branch) return false;
    if (filters.search) {
      const q = filters.search.toLowerCase();
      if (!t.from_branch_name?.toLowerCase().includes(q) &&
          !t.to_branch_name?.toLowerCase().includes(q) &&
          !t.requested_by_name?.toLowerCase().includes(q) &&
          !t.items?.some(i => i.item_name?.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  const pendingTransfers = transfers.filter(t => t.status === "pending");
  const approvedTransfers = transfers.filter(t => t.status === "approved");
  const completedTransfers = transfers.filter(t => t.status === "completed");

  if (loading) return (
    <div className="flex items-center justify-center h-full min-h-screen bg-[#f5f5fa]">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 border-4 border-violet-600 border-t-transparent rounded-full animate-spin" />
        <span className="text-gray-500 text-sm">Loading transfer data...</span>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-600 flex items-center justify-center">
              <ArrowLeftRight className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Branch Transfers</h1>
              <p className="text-xs text-gray-400">Multi-branch inventory management</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={loadData} className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 transition">
              <RefreshCw className="w-4 h-4" />
            </button>
            <Button onClick={() => setShowCreate(true)} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
              <Plus className="w-4 h-4" /> New Transfer
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="max-w-7xl mx-auto mt-4 flex gap-1 overflow-x-auto">
          {TABS.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition whitespace-nowrap ${
                  tab === t.id
                    ? "bg-violet-600 text-white"
                    : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                }`}
              >
                <Icon className="w-4 h-4" />
                {t.label}
                {t.id === "transfers" && pendingTransfers.length > 0 && (
                  <span className="ml-1 min-w-[20px] h-5 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center px-1">
                    {pendingTransfers.length}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">

        {/* Dashboard Tab */}
        {tab === "dashboard" && (
          <>
            <TransferStats
              branches={branches}
              inventoryItems={inventoryItems}
              transfers={transfers}
              pendingCount={pendingTransfers.length}
              approvedCount={approvedTransfers.length}
              completedCount={completedTransfers.length}
            />

            {/* Action required */}
            {(pendingTransfers.length > 0 || approvedTransfers.length > 0) && (
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                  <h2 className="font-bold text-gray-900">Action Required</h2>
                  <span className="text-xs text-orange-600 font-semibold bg-orange-50 px-2.5 py-1 rounded-full">
                    {pendingTransfers.length + approvedTransfers.length} pending
                  </span>
                </div>
                <TransferList
                  transfers={[...pendingTransfers, ...approvedTransfers]}
                  onApprove={handleApprove}
                  onReject={handleReject}
                  onComplete={handleComplete}
                  onView={setSelectedTransfer}
                  user={user}
                  compact
                />
              </div>
            )}

            {/* Recent transfers */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <h2 className="font-bold text-gray-900">Recent Transfers</h2>
                <button onClick={() => setTab("transfers")} className="text-xs text-violet-600 font-semibold hover:underline">View all</button>
              </div>
              <TransferList
                transfers={transfers.slice(0, 5)}
                onApprove={handleApprove}
                onReject={handleReject}
                onComplete={handleComplete}
                onView={setSelectedTransfer}
                user={user}
                compact
              />
            </div>
          </>
        )}

        {/* Transfers Tab */}
        {tab === "transfers" && (
          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100">
              <h2 className="font-bold text-gray-900 mb-3">All Transfers</h2>
              <TransferFilters filters={filters} setFilters={setFilters} branches={branches} />
            </div>
            <TransferList
              transfers={filteredTransfers}
              onApprove={handleApprove}
              onReject={handleReject}
              onComplete={handleComplete}
              onView={setSelectedTransfer}
              user={user}
            />
          </div>
        )}

        {/* Stock Overview Tab */}
        {tab === "stock" && (
          <BranchStockTable branches={branches} inventoryItems={inventoryItems} />
        )}

        {/* History Tab */}
        {tab === "history" && (
          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100">
              <h2 className="font-bold text-gray-900 mb-3">Transfer History Log</h2>
              <TransferFilters filters={filters} setFilters={setFilters} branches={branches} />
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="text-left py-3 px-4 font-semibold text-gray-600">Date</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600">From → To</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600">Items</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600">Requested By</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600">Approved By</th>
                    <th className="text-center py-3 px-4 font-semibold text-gray-600">Status</th>
                    <th className="text-center py-3 px-4 font-semibold text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransfers.length === 0 && (
                    <tr><td colSpan={7} className="text-center text-gray-400 py-10">No transfers found</td></tr>
                  )}
                  {filteredTransfers.map(t => (
                    <tr key={t.id} className="border-b border-gray-100 hover:bg-gray-50 transition">
                      <td className="py-3 px-4 text-gray-500 text-xs">
                        {t.created_date ? new Date(t.created_date).toLocaleDateString("en-AE", { day: "numeric", month: "short", year: "numeric" }) : "—"}
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-medium text-gray-900">{t.from_branch_name}</span>
                        <span className="text-gray-400 mx-1">→</span>
                        <span className="font-medium text-gray-900">{t.to_branch_name}</span>
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-xs">
                        {t.items?.map(i => `${i.item_name} (×${i.quantity})`).join(", ")}
                      </td>
                      <td className="py-3 px-4 text-gray-600 text-xs">{t.requested_by_name || "—"}</td>
                      <td className="py-3 px-4 text-gray-600 text-xs">{t.approved_by_name || "—"}</td>
                      <td className="py-3 px-4 text-center">
                        <StatusBadge status={t.status} />
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button onClick={() => setSelectedTransfer(t)} className="text-xs text-violet-600 hover:underline font-semibold">
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {showCreate && (
        <CreateTransferModal
          branches={branches}
          inventoryItems={inventoryItems}
          user={user}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); loadData(); toast.success("Transfer created"); }}
        />
      )}

      {selectedTransfer && (
        <TransferDetailModal
          transfer={selectedTransfer}
          onClose={() => setSelectedTransfer(null)}
          onApprove={handleApprove}
          onReject={handleReject}
          onComplete={handleComplete}
          user={user}
        />
      )}
    </div>
  );
}

export function StatusBadge({ status }) {
  const map = {
    pending: "bg-amber-100 text-amber-700",
    approved: "bg-blue-100 text-blue-700",
    in_transit: "bg-purple-100 text-purple-700",
    completed: "bg-green-100 text-green-700",
    cancelled: "bg-gray-100 text-gray-600",
  };
  return (
    <span className={`inline-block text-xs px-2.5 py-1 rounded-full font-semibold capitalize ${map[status] || "bg-gray-100 text-gray-600"}`}>
      {status}
    </span>
  );
}