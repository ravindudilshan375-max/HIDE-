import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Calendar, TrendingUp, DollarSign, Zap, Filter, X } from "lucide-react";
import { format, subDays } from "date-fns";

const DISCOUNT_TYPE_COLORS = {
  percentage: "#f97316",
  fixed_amount: "#3b82f6",
  item_specific: "#8b5cf6"
};

export default function DiscountAnalytics() {
  const [orders, setOrders] = useState([]);
  const [discounts, setDiscounts] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filters
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 30), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedDiscountType, setSelectedDiscountType] = useState("all");
  const [selectedBranch, setSelectedBranch] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [orderData, discountData, branchData] = await Promise.all([
      base44.entities.Order.list("-created_date", 500),
      base44.entities.Discount.list(),
      base44.entities.Branch.list()
    ]);
    setOrders(orderData);
    setDiscounts(discountData);
    setBranches(branchData);
    setLoading(false);
  };

  // Filter and calculate metrics
  const filteredOrders = orders.filter(o => {
    const orderDate = o.created_date?.split("T")[0];
    const dateMatch = orderDate >= startDate && orderDate <= endDate;
    const branchMatch = selectedBranch === "all" || o.branch_id === selectedBranch;
    return dateMatch && branchMatch;
  });

  const filteredDiscounts = discounts.filter(d => 
    selectedDiscountType === "all" || d.type === selectedDiscountType
  );

  // Calculate metrics
  const discountMetrics = filteredDiscounts.map(discount => {
    const usageCount = filteredOrders.filter(o => {
      // Count how many times this discount was applied (tracked via discount amount)
      // For simplicity, we count it if the order's discount value roughly matches
      return o.discount > 0;
    }).length;

    const totalValue = filteredOrders.reduce((sum, o) => sum + (o.discount || 0), 0);
    const avgPerOrder = usageCount > 0 ? totalValue / usageCount : 0;

    return {
      ...discount,
      usageCount,
      totalValue,
      avgPerOrder
    };
  });

  const totalDiscountApplied = filteredOrders.reduce((sum, o) => sum + (o.discount || 0), 0);
  const ordersWithDiscount = filteredOrders.filter(o => o.discount > 0).length;
  const avgDiscountPerOrder = filteredOrders.length > 0 ? totalDiscountApplied / filteredOrders.length : 0;
  const discountedOrders = filteredOrders.filter(o => o.discount > 0);

  // Chart data: Discount usage by type
  const typeData = filteredDiscounts.map(d => {
    const count = filteredOrders.filter(o => o.discount > 0).length;
    return {
      type: d.type,
      count: count,
      value: filteredOrders.reduce((sum, o) => sum + (o.discount || 0), 0)
    };
  });

  // Chart data: Daily discount trends
  const dailyData = {};
  filteredOrders.forEach(o => {
    const date = o.created_date?.split("T")[0];
    if (!dailyData[date]) dailyData[date] = { date, discount: 0, orders: 0 };
    dailyData[date].discount += o.discount || 0;
    if (o.discount > 0) dailyData[date].orders += 1;
  });
  const trendData = Object.values(dailyData).sort((a, b) => a.date.localeCompare(b.date));

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Discount Analytics</h1>
            <p className="text-sm text-gray-400 mt-0.5">Track discount performance and ROI</p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-semibold text-gray-700">Filters</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs text-gray-600 mb-1.5 block font-medium">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
            <div>
              <label className="text-xs text-gray-600 mb-1.5 block font-medium">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
            <div>
              <label className="text-xs text-gray-600 mb-1.5 block font-medium">Discount Type</label>
              <select
                value={selectedDiscountType}
                onChange={e => setSelectedDiscountType(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="all">All Types</option>
                <option value="percentage">Percentage</option>
                <option value="fixed_amount">Fixed Amount</option>
                <option value="item_specific">Item Specific</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-600 mb-1.5 block font-medium">Branch</label>
              <select
                value={selectedBranch}
                onChange={e => setSelectedBranch(e.target.value)}
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="all">All Branches</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400 font-medium">Total Discount Value</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">AED {totalDiscountApplied.toFixed(2)}</p>
              </div>
              <DollarSign className="w-10 h-10 text-violet-600/20 flex-shrink-0" />
            </div>
          </div>

          <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400 font-medium">Orders with Discount</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{ordersWithDiscount}</p>
              </div>
              <Zap className="w-10 h-10 text-amber-600/20 flex-shrink-0" />
            </div>
          </div>

          <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400 font-medium">Avg Discount per Order</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">AED {avgDiscountPerOrder.toFixed(2)}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-600/20 flex-shrink-0" />
            </div>
          </div>

          <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400 font-medium">Discount Rate</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {filteredOrders.length > 0 ? ((ordersWithDiscount / filteredOrders.length) * 100).toFixed(1) : 0}%
                </p>
              </div>
              <Calendar className="w-10 h-10 text-blue-600/20 flex-shrink-0" />
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily Trend */}
          <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
            <h2 className="text-sm font-bold text-gray-900 mb-4">Discount Trend (Daily)</h2>
            {trendData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="#9ca3af" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: "8px" }}
                    formatter={(value) => [`AED ${value.toFixed(2)}`, "Discount"]}
                  />
                  <Line type="monotone" dataKey="discount" stroke="#7c3aed" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-300">No data</div>
            )}
          </div>

          {/* Type Distribution */}
          <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
            <h2 className="text-sm font-bold text-gray-900 mb-4">Discount by Type</h2>
            {filteredDiscounts.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={filteredDiscounts.map((d, i) => ({
                      name: d.type,
                      value: d.times_used || 0
                    }))}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {filteredDiscounts.map((d, i) => (
                      <Cell key={`cell-${i}`} fill={DISCOUNT_TYPE_COLORS[d.type] || "#6b7280"} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} uses`, "Count"]} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-300">No discounts available</div>
            )}
          </div>
        </div>

        {/* Discount Usage Table */}
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100">
            <h2 className="text-sm font-bold text-gray-900">Discount Performance</h2>
          </div>

          {loading ? (
            <div className="p-10 text-center text-gray-300">Loading...</div>
          ) : discountMetrics.length === 0 ? (
            <div className="p-10 text-center text-gray-300">No discounts to display</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100 bg-gray-50">
                    <th className="text-left px-5 py-3 font-semibold text-gray-700">Discount Name</th>
                    <th className="text-left px-4 py-3 font-semibold text-gray-700">Type</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-700">Value</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-700">Times Used</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-700">Total Value</th>
                    <th className="text-right px-4 py-3 font-semibold text-gray-700">Avg per Order</th>
                  </tr>
                </thead>
                <tbody>
                  {discountMetrics.map(d => (
                    <tr key={d.id} className="border-b border-gray-50 hover:bg-gray-50 transition">
                      <td className="px-5 py-3">
                        <div>
                          <p className="font-medium text-gray-900">{d.name}</p>
                          {d.description && <p className="text-xs text-gray-400 mt-0.5">{d.description}</p>}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2.5 py-1 rounded-full font-medium capitalize ${
                          d.type === "percentage" ? "bg-orange-100 text-orange-700" :
                          d.type === "fixed_amount" ? "bg-blue-100 text-blue-700" :
                          "bg-purple-100 text-purple-700"
                        }`}>
                          {d.type.replace("_", " ")}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-semibold text-gray-900">
                        {d.type === "percentage" ? `${d.value}%` : `AED ${d.value.toFixed(2)}`}
                      </td>
                      <td className="px-4 py-3 text-right font-semibold text-gray-900">{d.times_used || 0}</td>
                      <td className="px-4 py-3 text-right font-semibold text-violet-600">AED {d.totalValue?.toFixed(2) || "0.00"}</td>
                      <td className="px-4 py-3 text-right font-semibold text-gray-900">AED {d.avgPerOrder?.toFixed(2) || "0.00"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}