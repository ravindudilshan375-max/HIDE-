import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Pencil, Trash2 } from "lucide-react";

const STATUS_STYLES = {
  available: "border-green-200 bg-green-50 text-green-700",
  occupied: "border-red-200 bg-red-50 text-red-700",
  reserved: "border-purple-200 bg-purple-50 text-purple-700",
};

export default function Tables() {
  const [tables, setTables] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingTable, setEditingTable] = useState(null);
  const [form, setForm] = useState({ number: "", capacity: 4 });

  const load = () => base44.entities.Table.list("number").then(setTables);
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.number) return;
    const branchId = localStorage.getItem("selectedBranchId") || "";
    if (editingTable) {
      await base44.entities.Table.update(editingTable.id, { ...form, branch_id: editingTable.branch_id || branchId });
    } else {
      await base44.entities.Table.create({ ...form, status: "available", branch_id: branchId });
    }
    setShowForm(false);
    setEditingTable(null);
    setForm({ number: "", capacity: 4 });
    load();
  };

  const deleteTable = async (id) => {
    await base44.entities.Table.delete(id);
    load();
  };

  const changeStatus = async (table, status) => {
    await base44.entities.Table.update(table.id, { status, branch_id: table.branch_id });
    load();
  };

  const openEdit = (table) => {
    setEditingTable(table);
    setForm({ number: table.number, capacity: table.capacity });
    setShowForm(true);
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Tables</h1>
            <p className="text-sm text-gray-400 mt-0.5">Manage your restaurant floor</p>
          </div>
          <Button
            onClick={() => { setShowForm(true); setEditingTable(null); setForm({ number: "", capacity: 4 }); }}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> Add Table
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5 mb-6 flex gap-4 flex-wrap items-end">
            <div className="flex-1 min-w-[120px]">
              <label className="text-xs text-gray-400 mb-1.5 block">Table Number</label>
              <Input
                placeholder="e.g. 1, 2A..."
                value={form.number}
                onChange={e => setForm(f => ({ ...f, number: e.target.value }))}
                className="border-gray-200 rounded-xl"
              />
            </div>
            <div className="w-32">
              <label className="text-xs text-gray-400 mb-1.5 block">Capacity</label>
              <Input
                type="number" min={1}
                value={form.capacity}
                onChange={e => setForm(f => ({ ...f, capacity: parseInt(e.target.value) }))}
                className="border-gray-200 rounded-xl"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={save} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
                {editingTable ? "Update" : "Create"}
              </Button>
              <Button onClick={() => setShowForm(false)} variant="ghost" className="text-gray-400 border border-gray-200 rounded-xl">
                Cancel
              </Button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {tables.map(table => (
            <div key={table.id} className={`rounded-2xl border p-4 flex flex-col gap-3 shadow-sm bg-white ${STATUS_STYLES[table.status]}`}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-2xl font-bold">T{table.number}</p>
                  <p className="text-xs opacity-60 mt-0.5">{table.capacity} seats</p>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(table)} className="opacity-40 hover:opacity-100 transition p-1">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => deleteTable(table.id)} className="opacity-40 hover:opacity-100 transition p-1">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <select
                value={table.status}
                onChange={e => changeStatus(table, e.target.value)}
                className="bg-white border border-current/30 rounded-lg text-xs px-2 py-1 cursor-pointer focus:outline-none capitalize"
              >
                <option value="available">Available</option>
                <option value="occupied">Occupied</option>
                <option value="reserved">Reserved</option>
              </select>
            </div>
          ))}
          {tables.length === 0 && (
            <div className="col-span-full text-center py-16 text-gray-300 text-sm">No tables yet. Add your first table.</div>
          )}
        </div>
      </div>
    </div>
  );
}