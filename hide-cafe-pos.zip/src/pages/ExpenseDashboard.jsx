import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, DollarSign, Download, ChevronLeft, ChevronRight, Receipt } from "lucide-react";

function fmt(n) { return `AED ${(n || 0).toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; }

export default function ExpenseDashboard() {
  const [expenses, setExpenses] = useState([]);
  const [orders, setOrders] = useState([]);
  const [categories, setCategories] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Expense.list("-date"),
      base44.entities.Order.filter({ status: "paid" }),
      base44.entities.ExpenseCategory.list("name"),
      base44.entities.Branch.list(),
    ]).then(([exp, ord, cats, brs]) => {
      setExpenses(exp);
      setOrders(ord);
      setCategories(cats);
      setBranches(brs);
      setLoading(false);
    });
  }, []);

  const monthStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, "0")}`;

  const monthExpenses = useMemo(() => expenses.filter(e => {
    const match = e.date?.startsWith(monthStr);
    const branchMatch = selectedBranch === "all" || !e.branch_id || e.branch_id === selectedBranch;
    return match && branchMatch;
  }), [expenses, monthStr, selectedBranch]);

  const monthIncome = useMemo(() => orders.filter(o => {
    const match = o.created_date?.startsWith(monthStr);
    return match && (selectedBranch === "all" || o.branch_id === selectedBranch);
  }).reduce((s, o) => s + (o.total || 0), 0), [orders, monthStr, selectedBranch]);

  const totalExpenses = monthExpenses.reduce((s, e) => s + (e.amount || 0), 0);
  const netProfit = monthIncome - totalExpenses;

  // Build 6-month chart data
  const chartData = useMemo(() => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(currentMonth);
      d.setMonth(d.getMonth() - i);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleString("default", { month: "short" });
      const exp = expenses.filter(e => e.date?.startsWith(key) && (selectedBranch === "all" || !e.branch_id || e.branch_id === selectedBranch))
        .reduce((s, e) => s + (e.amount || 0), 0);
      const inc = orders.filter(o => o.created_date?.startsWith(key) && (selectedBranch === "all" || o.branch_id === selectedBranch))
        .reduce((s, o) => s + (o.total || 0), 0);
      months.push({ name: label, Income: inc, Expenses: exp });
    }
    return months;
  }, [expenses, orders, currentMonth, selectedBranch]);

  // Category breakdown
  const categoryBreakdown = useMemo(() => {
    const map = {};
    monthExpenses.forEach(e => {
      const cat = e.category || "Uncategorized";
      map[cat] = (map[cat] || 0) + (e.amount || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [monthExpenses]);

  const prevMonth = () => { const d = new Date(currentMonth); d.setMonth(d.getMonth() - 1); setCurrentMonth(d); };
  const nextMonth = () => { const d = new Date(currentMonth); d.setMonth(d.getMonth() + 1); setCurrentMonth(d); };

  const handleExportCSV = () => {
    const rows = [["Date", "Supplier", "Category", "Payment", "Tax", "Amount", "Notes"]];
    monthExpenses.forEach(e => rows.push([e.date, e.supplier_name || "", e.category || "", e.payment_method || "", e.tax || 0, e.amount, e.notes || ""]));
    const csv = rows.map(r => r.map(v => `"${v}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url;
    a.download = `expenses-${monthStr}.csv`; a.click(); URL.revokeObjectURL(url);
  };

  const monthLabel = currentMonth.toLocaleString("default", { month: "long", year: "numeric" });

  if (loading) return <div className="p-8 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-4 md:p-6">
      <div className="max-w-4xl mx-auto space-y-5">

        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Expenses</h1>
            <p className="text-gray-400 text-sm">Financial overview</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {branches.length > 1 && (
              <select value={selectedBranch} onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none">
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <Link to={createPageUrl("Expenses")}
              className="flex items-center gap-1.5 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white text-sm font-semibold rounded-xl transition">
              <Receipt className="w-4 h-4" /> Transactions
            </Link>
          </div>
        </div>

        {/* Month Navigator */}
        <div className="flex items-center gap-3 bg-white rounded-2xl border border-gray-100 px-4 py-3 shadow-sm">
          <button onClick={prevMonth} className="p-1.5 rounded-lg hover:bg-gray-100 transition"><ChevronLeft className="w-4 h-4 text-gray-500" /></button>
          <span className="flex-1 text-center font-semibold text-gray-800">{monthLabel}</span>
          <button onClick={nextMonth} className="p-1.5 rounded-lg hover:bg-gray-100 transition"><ChevronRight className="w-4 h-4 text-gray-500" /></button>
          <button onClick={handleExportCSV} className="flex items-center gap-1.5 text-xs font-semibold text-violet-600 border border-violet-200 px-3 py-1.5 rounded-xl hover:bg-violet-50 transition">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p className="text-xs text-gray-400 mb-1">Net Profit</p>
            <p className={`text-2xl font-bold ${netProfit >= 0 ? "text-green-600" : "text-red-600"}`}>{fmt(netProfit)}</p>
            <p className="text-xs text-gray-400 mt-1">Income − Expenses</p>
          </div>
          <div className="bg-green-50 rounded-2xl border border-green-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <p className="text-xs text-green-700 font-semibold">Income (POS Sales)</p>
            </div>
            <p className="text-2xl font-bold text-green-700">{fmt(monthIncome)}</p>
          </div>
          <div className="bg-red-50 rounded-2xl border border-red-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-1">
              <TrendingDown className="w-4 h-4 text-red-600" />
              <p className="text-xs text-red-700 font-semibold">Expenses</p>
            </div>
            <p className="text-2xl font-bold text-red-700">{fmt(totalExpenses)}</p>
          </div>
        </div>

        {/* Chart */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <h2 className="font-semibold text-gray-800 mb-4 text-sm">6-Month Overview</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData} barSize={18}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} width={60} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip formatter={(v) => fmt(v)} />
              <Bar dataKey="Income" fill="#22c55e" radius={[4,4,0,0]} />
              <Bar dataKey="Expenses" fill="#ef4444" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Total Spending Circle */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 flex items-center justify-center">
          <div className="w-48 h-48 rounded-full border-8 border-gray-100 flex flex-col items-center justify-center">
            <p className="text-xs text-gray-400">Total Spending</p>
            <p className="text-xl font-bold text-gray-900 mt-1">{fmt(totalExpenses)}</p>
          </div>
        </div>

        {/* Category Breakdown */}
        {categoryBreakdown.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <h2 className="font-semibold text-gray-800 mb-4 text-sm">Spending by Category</h2>
            <div className="space-y-3">
              {categoryBreakdown.map(([cat, amt]) => {
                const pct = totalExpenses > 0 ? (amt / totalExpenses) * 100 : 0;
                return (
                  <div key={cat}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-700 font-medium">{cat}</span>
                      <span className="text-gray-900 font-semibold">{fmt(amt)}</span>
                    </div>
                    <div className="bg-gray-100 rounded-full h-1.5">
                      <div className="bg-violet-500 h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}