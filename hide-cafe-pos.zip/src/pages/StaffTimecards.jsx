import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Download, Eye, Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format, parseISO, subDays, addDays } from "date-fns";
import TimecardDetailModal from "@/components/timecards/TimecardDetailModal";
import ShiftModal from "@/components/timecards/ShiftModal";
import { toast } from "sonner";
import { useAuth } from "@/lib/AuthContext";

function formatMinutesToHours(minutes) {
  if (!minutes) return "0h 0m";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h ${m}m`;
}

export default function StaffTimecards() {
  const { navigateToLogin } = useAuth();
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [filters, setFilters] = useState({ lateOnly: false, absentOnly: false });
  const [loading, setLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [staffForSchedule, setStaffForSchedule] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [schedules, setSchedules] = useState({});

  useEffect(() => {
    loadData();
  }, [date, selectedBranch]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [attendanceData, branchData, shiftData] = await Promise.all([
        base44.entities.Attendance.filter({ date }).catch(() => []),
        base44.entities.Branch.list(),
        base44.entities.StaffShift.filter({ date }).catch(() => [])
      ]);
      
      let filtered = attendanceData;
      if (selectedBranch) {
        filtered = filtered.filter(a => a.branch_id === selectedBranch);
      }

      // Index shifts by staff email
      const shiftMap = {};
      shiftData.forEach(s => {
        shiftMap[s.staff_email] = s;
      });
      setSchedules(shiftMap);

      setAttendance(filtered);
      setBranches(branchData.filter(b => b.is_active !== false));
      if (!selectedBranch && branchData.length > 0) {
        setSelectedBranch(branchData[0].id);
      }
      setLoading(false);
      } catch (error) {
      if (error.message?.includes('Authentication')) {
        navigateToLogin();
      } else {
        toast.error("Failed to load timecards");
        setLoading(false);
      }
      }
      };

      const filtered = useMemo(() => {
    let result = attendance;
    if (filters.lateOnly) result = result.filter(a => a.late_minutes > 0);
    if (filters.absentOnly) result = result.filter(a => a.status === "absent");
    return result;
  }, [attendance, filters]);

  const handleExportPayroll = async () => {
    setExporting(true);
    try {
      const summary = filtered.map(a => ({
        Staff: a.staff_name,
        "Late Minutes": a.late_minutes || 0,
        "Deduction (AED)": (a.final_deduction || 0).toFixed(2)
      }));

      const headers = ["Staff", "Late Minutes", "Deduction (AED)"];
      const csv = [
        headers.join(","),
        ...summary.map(row => `"${row.Staff}",${row["Late Minutes"]},${row["Deduction (AED)"]}`)
      ].join("\n");

      const link = document.createElement("a");
      link.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
      link.download = `payroll_${date}.csv`;
      link.click();
      toast.success("Payroll exported!");
    } catch (error) {
      toast.error("Export failed");
    }
    setExporting(false);
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-5">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Staff Timecards</h1>
            <p className="text-sm text-gray-400 mt-0.5">Attendance & Salary Deductions</p>
          </div>
          <Button
            onClick={handleExportPayroll}
            disabled={exporting}
            className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl gap-2"
          >
            <Download className="w-4 h-4" /> {exporting ? "Exporting..." : "Export Payroll"}
          </Button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Date Navigation */}
            <div className="flex items-center gap-3">
              <button onClick={() => setDate(format(subDays(parseISO(date), 1), 'yyyy-MM-dd'))}
                className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-600">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm font-semibold"
              />
              <button onClick={() => setDate(format(addDays(parseISO(date), 1), 'yyyy-MM-dd'))}
                className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-600">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Branch */}
            <select
              value={selectedBranch || ""}
              onChange={(e) => setSelectedBranch(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm font-medium"
            >
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>

            {/* Quick Filters */}
            <div className="flex gap-2">
              <button
                onClick={() => setFilters(f => ({ ...f, lateOnly: !f.lateOnly }))}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition ${
                  filters.lateOnly ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                Late Only
              </button>
              <button
                onClick={() => setFilters(f => ({ ...f, absentOnly: !f.absentOnly }))}
                className={`px-3 py-2 rounded-lg text-xs font-semibold transition ${
                  filters.absentOnly ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                Absent Only
              </button>
            </div>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Total Staff", value: filtered.length, color: "text-gray-700" },
            { label: "On Time", value: filtered.filter(a => a.status === "on_time").length, color: "text-green-600" },
            { label: "Late", value: filtered.filter(a => a.status === "late").length, color: "text-amber-600" },
            { label: "Absent", value: filtered.filter(a => a.status === "absent").length, color: "text-red-600" },
          ].map((card, i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-center">
              <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
              <p className="text-xs text-gray-400 mt-1">{card.label}</p>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16">
              <p className="text-gray-400">No records found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="px-5 py-3 text-left text-xs font-bold text-gray-500 uppercase">Staff</th>
                    <th className="px-5 py-3 text-left text-xs font-bold text-gray-500 uppercase">Shift</th>
                    <th className="px-5 py-3 text-left text-xs font-bold text-gray-500 uppercase">Clock In</th>
                    <th className="px-5 py-3 text-left text-xs font-bold text-gray-500 uppercase">Clock Out</th>
                    <th className="px-5 py-3 text-center text-xs font-bold text-gray-500 uppercase">Worked</th>
                    <th className="px-5 py-3 text-center text-xs font-bold text-gray-500 uppercase">Late</th>
                    <th className="px-5 py-3 text-center text-xs font-bold text-gray-500 uppercase">Final</th>
                    <th className="px-5 py-3 text-center text-xs font-bold text-gray-500 uppercase">Status</th>
                    <th className="px-5 py-3 text-center text-xs font-bold text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((record, idx) => {
                    const schedule = schedules[record.staff_email];
                    return (
                      <tr key={idx} className="border-t border-gray-50 hover:bg-gray-50/50 transition">
                        <td className="px-5 py-4">
                          <p className="font-semibold text-gray-900">{record.staff_name}</p>
                          <p className="text-xs text-gray-400">{record.staff_email}</p>
                        </td>
                        <td className="px-5 py-4 text-sm">
                          {schedule ? (
                            <button
                              onClick={() => setStaffForSchedule({ ...record, staff_email: record.staff_email, staff_name: record.staff_name })}
                              className="text-violet-600 hover:text-violet-800 font-semibold flex items-center gap-1 hover:underline"
                            >
                              <Clock className="w-3.5 h-3.5" /> {schedule.shift_start} - {schedule.shift_end}
                            </button>
                          ) : (
                            <button
                              onClick={() => setStaffForSchedule({ ...record, staff_email: record.staff_email, staff_name: record.staff_name })}
                              className="text-gray-400 hover:text-violet-600 text-xs font-semibold hover:underline"
                            >
                              Set Shift
                            </button>
                          )}
                        </td>
                        <td className="px-5 py-4 text-sm text-gray-600">
                          {record.clock_in_time ? format(parseISO(record.clock_in_time), "HH:mm") : "—"}
                        </td>
                        <td className="px-5 py-4 text-sm text-gray-600">
                          {record.clock_out_time ? format(parseISO(record.clock_out_time), "HH:mm") : "—"}
                        </td>
                        <td className="px-5 py-4 text-center font-semibold text-gray-900">
                          {formatMinutesToHours(record.worked_minutes)}
                        </td>
                        <td className="px-5 py-4 text-center font-semibold text-amber-600">
                          {formatMinutesToHours(record.late_minutes)}
                        </td>
                        <td className="px-5 py-4 text-center font-bold text-violet-700">
                          {(record.final_deduction || 0).toFixed(2)} AED
                        </td>
                        <td className="px-5 py-4 text-center">
                          <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                            record.status === "on_time" ? "bg-green-100 text-green-700" :
                            record.status === "late" ? "bg-amber-100 text-amber-700" :
                            "bg-red-100 text-red-700"
                          }`}>
                            {record.status === "on_time" ? "✓" :
                             record.status === "late" ? "⏱" : "✕"} {record.status === "on_time" ? "On Time" : record.status === "late" ? "Late" : "Absent"}
                          </span>
                        </td>
                        <td className="px-5 py-4 text-center">
                          <button onClick={() => setSelectedRecord(record)}
                            className="text-violet-600 hover:text-violet-800 p-1 hover:bg-violet-50 rounded-lg transition">
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {selectedRecord && (
        <TimecardDetailModal
          attendance={selectedRecord}
          onClose={() => setSelectedRecord(null)}
          onAdjustmentSaved={loadData}
        />
      )}

      {staffForSchedule && (
        <ShiftModal
          staff={staffForSchedule}
          date={date}
          branchId={selectedBranch}
          onClose={() => setStaffForSchedule(null)}
          onSaved={loadData}
        />
      )}
    </div>
  );
}