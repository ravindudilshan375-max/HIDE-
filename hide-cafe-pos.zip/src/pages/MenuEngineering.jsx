import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Star, HelpCircle, TrendingDown, Trash2, RefreshCw, ChevronDown, ChevronUp, Info } from "lucide-react";

const CATEGORY_CONFIG = {
  star: {
    label: "Stars",
    icon: Star,
    color: "text-yellow-600",
    bg: "bg-yellow-50",
    border: "border-yellow-200",
    badge: "bg-yellow-100 text-yellow-700",
    dot: "bg-yellow-400",
    desc: "High popularity · High profitability",
    tip: "These are your best performers. Highlight them prominently on your menu and train staff to recommend them.",
  },
  puzzle: {
    label: "Puzzles",
    icon: HelpCircle,
    color: "text-violet-600",
    bg: "bg-violet-50",
    border: "border-violet-200",
    badge: "bg-violet-100 text-violet-700",
    dot: "bg-violet-400",
    desc: "Low popularity · High profitability",
    tip: "Great margins but rarely ordered. Improve visibility, rename, add photos, or offer promos to move them into Stars.",
  },
  plowhorse: {
    label: "Plow Horses",
    icon: TrendingDown,
    color: "text-blue-600",
    bg: "bg-blue-50",
    border: "border-blue-200",
    badge: "bg-blue-100 text-blue-700",
    dot: "bg-blue-400",
    desc: "High popularity · Low profitability",
    tip: "Customer favorites with thin margins. Pair with high-margin add-ons or find cost savings without changing quality.",
  },
  dog: {
    label: "Dogs",
    icon: Trash2,
    color: "text-red-600",
    bg: "bg-red-50",
    border: "border-red-200",
    badge: "bg-red-100 text-red-700",
    dot: "bg-red-400",
    desc: "Low popularity · Low profitability",
    tip: "Neither popular nor profitable. Consider removing these from the menu to reduce waste and complexity.",
  },
};

function classifyItem(item, avgPopularity, avgMargin) {
  const popular = item.order_count >= avgPopularity;
  const profitable = item.margin_pct >= avgMargin;
  if (popular && profitable) return "star";
  if (!popular && profitable) return "puzzle";
  if (popular && !profitable) return "plowhorse";
  return "dog";
}

function MatrixChart({ items }) {
  // Normalize coordinates to 0–100
  const maxCount = Math.max(...items.map(i => i.order_count), 1);
  const maxMargin = Math.max(...items.map(i => i.margin_pct), 1);
  const avgCountPct = (items.reduce((s, i) => s + i.order_count, 0) / Math.max(items.length, 1)) / maxCount * 100;
  const avgMarginPct = (items.reduce((s, i) => s + i.margin_pct, 0) / Math.max(items.length, 1)) / maxMargin * 100;

  const COLORS = { star: "#f59e0b", puzzle: "#7c3aed", plowhorse: "#3b82f6", dog: "#ef4444" };

  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
      <h2 className="text-sm font-semibold text-gray-700 mb-4">Matrix View</h2>
      <div className="relative w-full" style={{ paddingBottom: "70%" }}>
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 280">
          {/* Quadrant backgrounds */}
          <rect x="0" y="0" width="200" height="140" fill="#fef9ec" rx="2" />
          <rect x="200" y="0" width="200" height="140" fill="#faf5ff" rx="2" />
          <rect x="0" y="140" width="200" height="140" fill="#eff6ff" rx="2" />
          <rect x="200" y="140" width="200" height="140" fill="#fef2f2" rx="2" />

          {/* Axis lines */}
          <line x1="200" y1="0" x2="200" y2="280" stroke="#e5e7eb" strokeWidth="1.5" strokeDasharray="4 3" />
          <line x1="0" y1="140" x2="400" y2="140" stroke="#e5e7eb" strokeWidth="1.5" strokeDasharray="4 3" />

          {/* Quadrant labels */}
          <text x="100" y="15" textAnchor="middle" fontSize="9" fill="#a16207" fontWeight="600">⭐ STARS</text>
          <text x="300" y="15" textAnchor="middle" fontSize="9" fill="#6d28d9" fontWeight="600">❓ PUZZLES</text>
          <text x="100" y="275" textAnchor="middle" fontSize="9" fill="#1d4ed8" fontWeight="600">🐎 PLOW HORSES</text>
          <text x="300" y="275" textAnchor="middle" fontSize="9" fill="#b91c1c" fontWeight="600">🐕 DOGS</text>

          {/* Axis labels */}
          <text x="200" y="295" textAnchor="middle" fontSize="8" fill="#9ca3af">← Popularity (order count) →</text>
          <text x="-140" y="8" fontSize="8" fill="#9ca3af" transform="rotate(-90)" textAnchor="middle">← Profitability (margin %) →</text>

          {/* Plot items */}
          {items.map((item, idx) => {
            const x = (item.order_count / maxCount) * 380 + 10;
            const y = 270 - (item.margin_pct / maxMargin) * 260;
            const cat = item.category_eng;
            return (
              <g key={item.id}>
                <circle cx={x} cy={y} r="6" fill={COLORS[cat]} opacity="0.85" />
                <text x={x} y={y - 9} textAnchor="middle" fontSize="7" fill="#374151"
                  style={{ overflow: "hidden", textOverflow: "ellipsis" }}>
                  {item.name.length > 12 ? item.name.slice(0, 11) + "…" : item.name}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </div>
  );
}

function CategoryCard({ catKey, items }) {
  const cfg = CATEGORY_CONFIG[catKey];
  const Icon = cfg.icon;
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={`bg-white border ${cfg.border} rounded-2xl shadow-sm overflow-hidden`}>
      <div className={`${cfg.bg} px-5 py-4`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Icon className={`w-5 h-5 ${cfg.color}`} />
            <h3 className={`font-bold text-base ${cfg.color}`}>{cfg.label}</h3>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cfg.badge}`}>{items.length}</span>
          </div>
          <button onClick={() => setExpanded(v => !v)} className={`${cfg.color} opacity-60 hover:opacity-100 transition`}>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-1">{cfg.desc}</p>
      </div>

      {/* Tip */}
      <div className="px-5 py-3 border-b border-gray-100 flex items-start gap-2">
        <Info className="w-3.5 h-3.5 text-gray-400 mt-0.5 shrink-0" />
        <p className="text-xs text-gray-400">{cfg.tip}</p>
      </div>

      {/* Items */}
      {(expanded || items.length <= 3) && items.length > 0 && (
        <div className="divide-y divide-gray-50">
          {items.map(item => (
            <div key={item.id} className="flex items-center justify-between px-5 py-3 hover:bg-gray-50 transition">
              <div>
                <p className="text-sm font-medium text-gray-800">{item.name}</p>
                <p className="text-xs text-gray-400">{item.category || "Uncategorized"}</p>
              </div>
              <div className="text-right text-xs space-y-0.5">
                <p className="text-gray-600 font-semibold">{item.order_count} orders</p>
                <p className="text-gray-400">{item.margin_pct.toFixed(1)}% margin</p>
                <p className="text-gray-300">${(item.base_price || 0).toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {!expanded && items.length > 3 && (
        <button onClick={() => setExpanded(true)}
          className={`w-full text-xs ${cfg.color} py-3 hover:bg-gray-50 transition font-medium`}>
          Show all {items.length} items
        </button>
      )}

      {items.length === 0 && (
        <p className="text-xs text-gray-300 text-center py-5">No items in this category</p>
      )}
    </div>
  );
}

export default function MenuEngineering() {
  const [menuItems, setMenuItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [dateRange, setDateRange] = useState("30");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [items, branchList, orderList] = await Promise.all([
      base44.entities.MenuItem.list(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 500),
    ]);
    setMenuItems(items);
    setBranches(branchList);
    setOrders(orderList);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const enriched = useMemo(() => {
    const days = parseInt(dateRange);
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);

    const filteredOrders = orders.filter(o => {
      if (o.status === "cancelled") return false;
      if (selectedBranch !== "all" && o.branch_id !== selectedBranch) return false;
      if (o.created_date && new Date(o.created_date) < cutoff) return false;
      return true;
    });

    // Count orders per menu item
    const countMap = {};
    filteredOrders.forEach(order => {
      (order.items || []).forEach(item => {
        if (item.menu_item_id) {
          countMap[item.menu_item_id] = (countMap[item.menu_item_id] || 0) + (item.quantity || 1);
        }
      });
    });

    const branchFiltered = selectedBranch === "all"
      ? menuItems
      : menuItems.filter(m => m.branch_id === selectedBranch);

    return branchFiltered.map(item => {
      const price = item.base_price || 0;
      const cost = item.cost_price || 0;
      const gross = price - cost;
      const margin_pct = price > 0 ? (gross / price) * 100 : 0;
      const order_count = countMap[item.id] || 0;
      return { ...item, order_count, gross_profit: gross, margin_pct };
    });
  }, [menuItems, orders, selectedBranch, dateRange]);

  const { classified, avgPopularity, avgMargin } = useMemo(() => {
    if (enriched.length === 0) return { classified: [], avgPopularity: 0, avgMargin: 0 };
    const avgPop = enriched.reduce((s, i) => s + i.order_count, 0) / enriched.length;
    const avgMar = enriched.reduce((s, i) => s + i.margin_pct, 0) / enriched.length;
    const result = enriched.map(item => ({
      ...item,
      category_eng: classifyItem(item, avgPop, avgMar),
    }));
    return { classified: result, avgPopularity: avgPop, avgMargin: avgMar };
  }, [enriched]);

  const byCategory = useMemo(() => ({
    star: classified.filter(i => i.category_eng === "star"),
    puzzle: classified.filter(i => i.category_eng === "puzzle"),
    plowhorse: classified.filter(i => i.category_eng === "plowhorse"),
    dog: classified.filter(i => i.category_eng === "dog"),
  }), [classified]);

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Menu Engineering</h1>
            <p className="text-gray-400 text-sm mt-0.5">Classify items by popularity & profitability to maximize revenue</p>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {branches.length > 1 && (
              <select value={selectedBranch} onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <select value={dateRange} onChange={e => setDateRange(e.target.value)}
              className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
              <option value="7">Last 7 days</option>
              <option value="30">Last 30 days</option>
              <option value="60">Last 60 days</option>
              <option value="90">Last 90 days</option>
            </select>
            <button onClick={load}
              className="flex items-center gap-2 text-sm font-medium bg-white border border-gray-200 hover:border-violet-400 text-gray-600 px-3 py-2 rounded-xl transition">
              <RefreshCw className="w-4 h-4" /> Refresh
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-8 h-8 border-2 border-violet-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            {/* KPI Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {Object.entries(byCategory).map(([key, items]) => {
                const cfg = CATEGORY_CONFIG[key];
                const Icon = cfg.icon;
                return (
                  <div key={key} className={`bg-white border ${cfg.border} rounded-2xl p-4 shadow-sm`}>
                    <div className="flex items-center gap-2 mb-1">
                      <div className={`w-2 h-2 rounded-full ${cfg.dot}`} />
                      <p className={`text-xs font-semibold ${cfg.color}`}>{cfg.label}</p>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{items.length}</p>
                    <p className="text-xs text-gray-400 mt-0.5">items</p>
                  </div>
                );
              })}
            </div>

            {/* Thresholds info */}
            <div className="bg-white border border-gray-100 rounded-2xl px-5 py-3 text-xs text-gray-400 flex flex-wrap gap-6 shadow-sm">
              <span>📊 <strong className="text-gray-600">Avg. orders:</strong> {avgPopularity.toFixed(1)}</span>
              <span>💰 <strong className="text-gray-600">Avg. margin:</strong> {avgMargin.toFixed(1)}%</span>
              <span>📦 <strong className="text-gray-600">Total items analyzed:</strong> {classified.length}</span>
              <span className="text-gray-300 hidden sm:block">Classification based on above-average = High, below-average = Low</span>
            </div>

            {/* Matrix Chart */}
            {classified.length > 0 && <MatrixChart items={classified} />}

            {/* 4 Quadrant Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {["star", "puzzle", "plowhorse", "dog"].map(key => (
                <CategoryCard key={key} catKey={key} items={byCategory[key]} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}