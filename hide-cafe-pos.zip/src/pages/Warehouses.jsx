import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";

export default function Warehouses() {
  const [warehouses, setWarehouses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    location: "",
    capacity: "",
    manager_name: "",
    contact_number: "",
    is_active: true
  });

  useEffect(() => {
    loadWarehouses();
  }, []);

  const loadWarehouses = async () => {
    setLoading(true);
    const data = await base44.entities.Warehouse.list();
    setWarehouses(data);
    setLoading(false);
  };

  const saveWarehouse = async () => {
    if (!formData.name.trim() || !formData.location.trim()) {
      toast.error("Enter warehouse name and location");
      return;
    }

    const data = {
      ...formData,
      capacity: formData.capacity ? Number(formData.capacity) : null
    };

    if (editingId) {
      await base44.entities.Warehouse.update(editingId, data);
      toast.success("Warehouse updated");
    } else {
      await base44.entities.Warehouse.create(data);
      toast.success("Warehouse created");
    }

    setShowForm(false);
    setEditingId(null);
    setFormData({
      name: "",
      location: "",
      capacity: "",
      manager_name: "",
      contact_number: "",
      is_active: true
    });
    loadWarehouses();
  };

  const deleteWarehouse = async (id) => {
    await base44.entities.Warehouse.delete(id);
    toast.success("Warehouse deleted");
    loadWarehouses();
  };

  const startEdit = (wh) => {
    setFormData(wh);
    setEditingId(wh.id);
    setShowForm(true);
  };

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Warehouses</h1>
            <p className="text-gray-400 text-sm mt-0.5">Manage storage locations</p>
          </div>
          <Button
            onClick={() => {
              setShowForm(true);
              setEditingId(null);
              setFormData({
                name: "",
                location: "",
                capacity: "",
                manager_name: "",
                contact_number: "",
                is_active: true
              });
            }}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Warehouse
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">{editingId ? "Edit" : "New"} Warehouse</h2>

            <Input
              placeholder="Warehouse name"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <Input
              placeholder="Location"
              value={formData.location}
              onChange={e => setFormData({ ...formData, location: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <div className="grid grid-cols-2 gap-3">
              <Input
                type="number"
                placeholder="Capacity (units)"
                value={formData.capacity}
                onChange={e => setFormData({ ...formData, capacity: e.target.value })}
                className="border-gray-200 rounded-xl"
              />
              <Input
                placeholder="Manager name"
                value={formData.manager_name || ""}
                onChange={e => setFormData({ ...formData, manager_name: e.target.value })}
                className="border-gray-200 rounded-xl"
              />
            </div>

            <Input
              placeholder="Contact number"
              value={formData.contact_number || ""}
              onChange={e => setFormData({ ...formData, contact_number: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.is_active}
                onChange={e => setFormData({ ...formData, is_active: e.target.checked })}
                className="w-4 h-4 rounded border-gray-200 cursor-pointer"
              />
              <label className="text-sm text-gray-600">Active</label>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                }}
                variant="outline"
                className="border-gray-200 rounded-xl flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={saveWarehouse}
                className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
              >
                Save Warehouse
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {warehouses.length === 0 ? (
            <p className="text-center text-gray-400 py-12">No warehouses yet</p>
          ) : (
            warehouses.map(wh => (
              <div key={wh.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900">{wh.name}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      wh.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"
                    }`}>
                      {wh.is_active ? "Active" : "Inactive"}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">{wh.location}</p>
                  <div className="flex gap-4 mt-2 text-xs text-gray-600">
                    {wh.capacity && <span>Capacity: {wh.capacity} units</span>}
                    {wh.manager_name && <span>Manager: {wh.manager_name}</span>}
                    {wh.contact_number && <span>{wh.contact_number}</span>}
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => startEdit(wh)}
                    className="text-gray-300 hover:text-violet-600 transition p-2"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteWarehouse(wh.id)}
                    className="text-gray-300 hover:text-red-500 transition p-2"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}