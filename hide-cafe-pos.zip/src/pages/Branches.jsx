import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Edit2, Users, Link as LinkIcon, Copy, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

function getBranchLoginUrl(branch) {
  const base = "https://nonchalant-swift-serve-pos.base44.app";
  return `${base}${createPageUrl("BranchLogin")}?branch=${branch.id}`;
}

function CopyLinkButton({ branch }) {
  const [copied, setCopied] = useState(false);
  const url = getBranchLoginUrl(branch);
  const handleCopy = async (e) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Login link copied!");
  };
  return (
    <button
      onClick={handleCopy}
      title="Copy branch login link"
      className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-violet-50 text-violet-600 hover:bg-violet-100 border border-violet-200 transition-all font-medium"
    >
      {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? "Copied!" : "Copy Login URL"}
    </button>
  );
}

export default function Branches() {
  const [branches, setBranches] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [expandedBranch, setExpandedBranch] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    location: "",
    phone: "",
    email: "",
    manager_name: "",
    is_active: true
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [branchData, userData] = await Promise.all([
      base44.entities.Branch.list(),
      base44.entities.User.list().catch(() => [])
    ]);
    setBranches(branchData);
    setUsers(userData);
    setLoading(false);
  };

  const saveBranch = async () => {
    if (!formData.name.trim() || !formData.location.trim()) {
      toast.error("Enter branch name and location");
      return;
    }

    if (editingId) {
      await base44.entities.Branch.update(editingId, formData);
      toast.success("Branch updated");
    } else {
      await base44.entities.Branch.create(formData);
      toast.success("Branch created");
    }

    setShowForm(false);
    setEditingId(null);
    setFormData({
      name: "",
      location: "",
      phone: "",
      email: "",
      manager_name: "",
      is_active: true
    });
    loadData();
  };

  const deleteBranch = async (id) => {
    await base44.entities.Branch.delete(id);
    toast.success("Branch deleted");
    loadData();
  };

  const assignUserToBranch = async (branchId, userId) => {
    try {
      const user = users.find(u => u.id === userId);
      if (!user.branch_ids) user.branch_ids = [];
      if (!user.branch_ids.includes(branchId)) {
        user.branch_ids.push(branchId);
        await base44.entities.User.update(userId, { branch_ids: user.branch_ids });
        toast.success("User assigned to branch");
        loadData();
      }
    } catch (error) {
      toast.error("Failed to assign user");
    }
  };

  const removeUserFromBranch = async (branchId, userId) => {
    try {
      const user = users.find(u => u.id === userId);
      if (user.branch_ids) {
        user.branch_ids = user.branch_ids.filter(id => id !== branchId);
        await base44.entities.User.update(userId, { branch_ids: user.branch_ids });
        toast.success("User removed from branch");
        loadData();
      }
    } catch (error) {
      toast.error("Failed to remove user");
    }
  };

  const startEdit = (branch) => {
    setFormData(branch);
    setEditingId(branch.id);
    setShowForm(true);
  };

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Branches</h1>
            <p className="text-gray-400 text-sm mt-0.5">Manage restaurant locations</p>
          </div>
          <Button
            onClick={() => {
              setShowForm(true);
              setEditingId(null);
              setFormData({
                name: "",
                location: "",
                phone: "",
                email: "",
                manager_name: "",
                is_active: true
              });
            }}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Branch
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">{editingId ? "Edit" : "New"} Branch</h2>

            <Input
              placeholder="Branch name"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <Input
              placeholder="Location / Address"
              value={formData.location}
              onChange={e => setFormData({ ...formData, location: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <div className="grid grid-cols-2 gap-3">
              <Input
                placeholder="Phone"
                value={formData.phone || ""}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="border-gray-200 rounded-xl"
              />
              <Input
                placeholder="Email"
                value={formData.email || ""}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="border-gray-200 rounded-xl"
              />
            </div>

            <Input
              placeholder="Manager name"
              value={formData.manager_name || ""}
              onChange={e => setFormData({ ...formData, manager_name: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.is_active}
                onChange={e => setFormData({ ...formData, is_active: e.target.checked })}
                className="w-4 h-4 rounded border-gray-200 cursor-pointer"
              />
              <label className="text-sm text-gray-600">Active</label>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                }}
                variant="outline"
                className="border-gray-200 rounded-xl flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={saveBranch}
                className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
              >
                Save Branch
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {branches.length === 0 ? (
            <p className="text-center text-gray-400 py-12">No branches yet</p>
          ) : (
            branches.map(branch => {
              const branchUsers = users.filter(u => u.branch_ids?.includes(branch.id));
              const availableUsers = users.filter(u => !u.branch_ids?.includes(branch.id));
              return (
                <div key={branch.id} className="bg-white border border-gray-100 rounded-xl overflow-hidden">
                  <div className="p-4 flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-gray-900">{branch.name}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          branch.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"
                        }`}>
                          {branch.is_active ? "Active" : "Inactive"}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">{branch.location}</p>
                      <div className="flex gap-4 mt-2 text-xs text-gray-600">
                        {branch.phone && <span>{branch.phone}</span>}
                        {branch.email && <span>{branch.email}</span>}
                        {branch.manager_name && <span>Manager: {branch.manager_name}</span>}
                      </div>
                      {/* Branch Login URL */}
                      <div className="mt-3 flex items-center gap-2">
                        <div className="flex-1 min-w-0 bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs text-gray-400 font-mono truncate">
                          {getBranchLoginUrl(branch)}
                        </div>
                        <CopyLinkButton branch={branch} />
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button
                        onClick={() => setExpandedBranch(expandedBranch === branch.id ? null : branch.id)}
                        className="text-gray-300 hover:text-violet-600 transition p-2"
                        title="Manage users"
                      >
                        <Users className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => startEdit(branch)}
                        className="text-gray-300 hover:text-violet-600 transition p-2"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteBranch(branch.id)}
                        className="text-gray-300 hover:text-red-500 transition p-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* User management section */}
                  {expandedBranch === branch.id && (
                    <div className="border-t border-gray-100 bg-gray-50 p-4 space-y-4">
                      <div>
                        <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Users with access</p>
                        {branchUsers.length === 0 ? (
                          <p className="text-xs text-gray-400">No users assigned yet</p>
                        ) : (
                          <div className="space-y-1.5">
                            {branchUsers.map(user => (
                              <div key={user.id} className="flex items-center justify-between bg-white rounded-lg px-3 py-2 border border-gray-200">
                                <div className="text-sm">
                                  <p className="font-medium text-gray-700">{user.full_name || user.email}</p>
                                  <p className="text-xs text-gray-400">{user.email}</p>
                                </div>
                                <button
                                  onClick={() => removeUserFromBranch(branch.id, user.id)}
                                  className="text-red-500 hover:text-red-700 text-xs font-medium transition"
                                >
                                  Remove
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {availableUsers.length > 0 && (
                        <div>
                          <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Add user</p>
                          <select
                            onChange={(e) => {
                              if (e.target.value) assignUserToBranch(branch.id, e.target.value);
                              e.target.value = "";
                            }}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500 bg-white"
                          >
                            <option value="">Select a user to add...</option>
                            {availableUsers.map(user => (
                              <option key={user.id} value={user.id}>
                                {user.full_name || user.email}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}