import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Shield, ShoppingCart, ChefHat, UserPlus, Trash2, Mail, Upload, X, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import PrinterSettings from "@/components/settings/PrinterSettings";
import InventoryImportExport from "@/components/settings/InventoryImportExport";
import SalesReportSettings from "@/components/settings/SalesReportSettings";
import ReceiptBrandingSettings from "@/components/settings/ReceiptBrandingSettings";
import InvoiceEditor from "@/components/settings/InvoiceEditor";
import { toast } from "sonner";

const ROLES = [
  {
    key: "manager",
    label: "Manager",
    icon: Shield,
    color: "text-purple-400 bg-purple-400/10 border-purple-400/30",
    description: "Full access — dashboard, POS, orders, tables, menu, customers, settings",
    permissions: ["Dashboard", "POS", "Orders", "Tables", "Menu", "Customers", "Settings"],
  },
  {
    key: "cashier",
    label: "Cashier",
    icon: ShoppingCart,
    color: "text-amber-400 bg-amber-400/10 border-amber-400/30",
    description: "POS, orders, tables, and customer loyalty",
    permissions: ["POS", "Orders", "Tables", "Customers"],
  },
  {
    key: "kitchen",
    label: "Kitchen Staff",
    icon: ChefHat,
    color: "text-green-400 bg-green-400/10 border-green-400/30",
    description: "View-only access to the orders queue",
    permissions: ["Orders"],
  },
];

const TABS = ["Receipt", "Customer Bill", "Staff", "Sales Reports", "Printers & Devices", "Import / Export", "Invoice Editor"];

const LANGUAGES = [
  { value: "english", label: "English" },
  { value: "arabic", label: "عربي" },
  { value: "main_localized", label: "Main & Localized" },
];

const PRINT_LANGUAGES = [
  { value: "english_only", label: "English Only" },
  { value: "arabic_only", label: "Arabic Only" },
  { value: "main_localized", label: "Main & Localized" },
];

export default function Settings() {
  const [activeTab, setActiveTab] = useState("Receipt");
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("cashier");
  const [inviting, setInviting] = useState(false);
  const [inviteMsg, setInviteMsg] = useState("");
  
  // Receipt settings
  const [receiptLogo, setReceiptLogo] = useState(null);
  const [printLanguage, setPrintLanguage] = useState("main_localized");
  const [mainLanguage, setMainLanguage] = useState("english");
  const [localizedLanguage, setLocalizedLanguage] = useState("arabic");
  const [receiptHeader, setReceiptHeader] = useState("");

  // Customer Bill settings
  const [billLogo, setBillLogo] = useState(null);
  const [billBusinessName, setBillBusinessName] = useState("");
  const [billPhone, setBillPhone] = useState("");
  const [billFacebook, setBillFacebook] = useState("");
  const [billInstagram, setBillInstagram] = useState("");
  const [billTwitter, setBillTwitter] = useState("");
  const [billWebsite, setBillWebsite] = useState("");
  const [billReturnPolicy, setBillReturnPolicy] = useState("");
  const [billCustomText, setBillCustomText] = useState("");
  const [billShowItemDesc, setBillShowItemDesc] = useState(false);
  const [billShowSavingsRow, setBillShowSavingsRow] = useState(false);
  const [billShowCartDiscounts, setBillShowCartDiscounts] = useState(true);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const userData = await base44.entities.User.list();
    setUsers(userData);
    // Load receipt settings from localStorage
    const saved = JSON.parse(localStorage.getItem("receipt_settings") || "{}");
    if (saved.receipt_logo) setReceiptLogo(saved.receipt_logo);
    if (saved.print_language) setPrintLanguage(saved.print_language);
    if (saved.main_language) setMainLanguage(saved.main_language);
    if (saved.localized_language) setLocalizedLanguage(saved.localized_language);
    if (saved.receipt_header) setReceiptHeader(saved.receipt_header);
    // Load customer bill settings
    const bill = JSON.parse(localStorage.getItem("customer_bill_settings") || "{}");
    if (bill.logo) setBillLogo(bill.logo);
    if (bill.business_name) setBillBusinessName(bill.business_name);
    if (bill.phone) setBillPhone(bill.phone);
    if (bill.facebook) setBillFacebook(bill.facebook);
    if (bill.instagram) setBillInstagram(bill.instagram);
    if (bill.twitter) setBillTwitter(bill.twitter);
    if (bill.website) setBillWebsite(bill.website);
    if (bill.return_policy) setBillReturnPolicy(bill.return_policy);
    if (bill.custom_text) setBillCustomText(bill.custom_text);
    if (bill.show_item_desc !== undefined) setBillShowItemDesc(bill.show_item_desc);
    if (bill.show_savings_row !== undefined) setBillShowSavingsRow(bill.show_savings_row);
    if (bill.show_cart_discounts !== undefined) setBillShowCartDiscounts(bill.show_cart_discounts);
    setLoading(false);
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setReceiptLogo(file_url);
      toast.success("Logo uploaded");
    } catch (error) {
      toast.error("Failed to upload logo");
    }
  };

  const handleBillLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setBillLogo(file_url);
      toast.success("Logo uploaded");
    } catch {
      toast.error("Failed to upload logo");
    }
  };

  const saveBillSettings = () => {
    localStorage.setItem("customer_bill_settings", JSON.stringify({
      logo: billLogo,
      business_name: billBusinessName,
      phone: billPhone,
      facebook: billFacebook,
      instagram: billInstagram,
      twitter: billTwitter,
      website: billWebsite,
      return_policy: billReturnPolicy,
      custom_text: billCustomText,
      show_item_desc: billShowItemDesc,
      show_savings_row: billShowSavingsRow,
      show_cart_discounts: billShowCartDiscounts,
    }));
    toast.success("Customer Bill settings saved");
  };

  const saveReceiptSettings = () => {
    localStorage.setItem("receipt_settings", JSON.stringify({
      receipt_logo: receiptLogo,
      print_language: printLanguage,
      main_language: mainLanguage,
      localized_language: localizedLanguage,
      receipt_header: receiptHeader,
    }));
    toast.success("Receipt settings saved");
  };

  const changeRole = async (userId, newRole) => {
    await base44.entities.User.update(userId, { role: newRole });
    load();
  };

  const invite = async () => {
    if (!inviteEmail.trim()) return;
    setInviting(true);
    setInviteMsg("");
    await base44.users.inviteUser(inviteEmail.trim(), "user");
    // Find the newly created user and set role
    setInviteMsg(`Invitation sent to ${inviteEmail}`);
    setInviteEmail("");
    setInviting(false);
    setTimeout(() => setInviteMsg(""), 4000);
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-400 text-sm mt-0.5">Manage staff, printers, and data</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white border border-gray-100 rounded-2xl p-1 w-fit shadow-sm">
          {TABS.map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeTab === tab ? "bg-violet-600 text-white shadow-sm" : "text-gray-500 hover:text-gray-800"
              }`}>
              {tab}
            </button>
          ))}
        </div>

        {activeTab === "Customer Bill" && (
          <div className="space-y-6">
            {/* Preview + Branding */}
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 space-y-4">
              <div>
                <h2 className="text-lg font-bold text-gray-900">Branding</h2>
                <p className="text-sm text-gray-400 mt-0.5">Upload your logo to display on customer bills</p>
              </div>
              <div className="flex items-center gap-4 p-4 border border-gray-200 rounded-xl">
                <div className="w-16 h-16 rounded-lg border border-gray-200 bg-gray-50 flex items-center justify-center overflow-hidden shrink-0">
                  {billLogo ? <img src={billLogo} alt="Bill Logo" className="w-full h-full object-contain" /> : <span className="text-gray-300 text-2xl">🏪</span>}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-800">{billBusinessName || "Business Name"}</p>
                  <p className="text-xs text-gray-400 mt-0.5">Brand</p>
                </div>
                <label className="cursor-pointer p-2 rounded-lg hover:bg-gray-100 transition">
                  <Pencil className="w-4 h-4 text-gray-500" />
                  <input type="file" accept="image/*" onChange={handleBillLogoUpload} className="hidden" />
                </label>
              </div>
            </div>

            {/* Items and total */}
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 space-y-4">
              <h2 className="text-lg font-bold text-gray-900">Items and total</h2>
              {[
                { label: "Show item description", value: billShowItemDesc, setter: setBillShowItemDesc },
                { label: "Show total savings row when more than one discount is applied", value: billShowSavingsRow, setter: setBillShowSavingsRow },
                { label: "Show cart-level discounts on the item level", value: billShowCartDiscounts, setter: setBillShowCartDiscounts },
              ].map(({ label, value, setter }) => (
                <div key={label} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <span className="text-sm text-gray-700">{label}</span>
                  <button
                    onClick={() => setter(!value)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${value ? "bg-violet-600" : "bg-gray-200"}`}
                  >
                    <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${value ? "translate-x-6" : "translate-x-1"}`} />
                  </button>
                </div>
              ))}
            </div>

            {/* Business */}
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 space-y-3">
              <h2 className="text-lg font-bold text-gray-900">Business</h2>
              <div className="flex border border-gray-200 rounded-xl overflow-hidden">
                <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-44 shrink-0">Location Business Name</span>
                <input
                  value={billBusinessName}
                  onChange={e => setBillBusinessName(e.target.value)}
                  placeholder="Your business name"
                  className="flex-1 px-4 py-3 text-sm focus:outline-none"
                />
              </div>
            </div>

            {/* Contact */}
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 space-y-3">
              <h2 className="text-lg font-bold text-gray-900">Contact</h2>
              {[
                { label: "Phone", value: billPhone, setter: setBillPhone, placeholder: "Phone" },
                { label: "Facebook", value: billFacebook, setter: setBillFacebook, placeholder: "facebook.com/example" },
                { label: "Instagram", value: billInstagram, setter: setBillInstagram, placeholder: "Username" },
                { label: "Twitter", value: billTwitter, setter: setBillTwitter, placeholder: "Username" },
                { label: "Website", value: billWebsite, setter: setBillWebsite, placeholder: "example.com" },
              ].map(({ label, value, setter, placeholder }) => (
                <div key={label} className="flex border border-gray-200 rounded-xl overflow-hidden">
                  <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-44 shrink-0">{label}</span>
                  <input
                    value={value}
                    onChange={e => setter(e.target.value)}
                    placeholder={placeholder}
                    className="flex-1 px-4 py-3 text-sm focus:outline-none"
                  />
                </div>
              ))}
            </div>

            {/* Additional text */}
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 space-y-3">
              <h2 className="text-lg font-bold text-gray-900">Additional text</h2>
              <div className="flex border border-gray-200 rounded-xl overflow-hidden">
                <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-44 shrink-0">Return Policy</span>
                <textarea
                  value={billReturnPolicy}
                  onChange={e => setBillReturnPolicy(e.target.value)}
                  placeholder="Add your refund, exchange, or cancellation policy."
                  className="flex-1 px-4 py-3 text-sm focus:outline-none resize-none"
                  rows={3}
                />
              </div>
              <div className="flex border border-gray-200 rounded-xl overflow-hidden">
                <span className="px-4 py-3 bg-gray-50 text-sm text-gray-500 border-r border-gray-200 w-44 shrink-0">Custom Text</span>
                <textarea
                  value={billCustomText}
                  onChange={e => setBillCustomText(e.target.value)}
                  placeholder='E.g. "Now Hiring!"'
                  className="flex-1 px-4 py-3 text-sm focus:outline-none resize-none"
                  rows={3}
                />
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setActiveTab("Receipt")}>Cancel</Button>
              <Button onClick={saveBillSettings} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold px-6">Save</Button>
            </div>
          </div>
        )}

        {activeTab === "Invoice Editor" && <InvoiceEditor />}
        {activeTab === "Sales Reports" && <SalesReportSettings />}
        {activeTab === "Printers & Devices" && <PrinterSettings />}
        {activeTab === "Import / Export" && <InventoryImportExport />}

        {/* Receipt Settings Tab */}
        {activeTab === "Receipt" && <ReceiptBrandingSettings />}

        {/* Staff tab */}
        {activeTab === "Staff" && (
        <div className="space-y-8">

        {/* Role legend */}
        <div>
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Role Definitions</h2>
          <div className="grid gap-3">
            {ROLES.map(({ key, label, icon: Icon, color, description, permissions }) => (
              <div key={key} className="bg-white border border-gray-100 shadow-sm rounded-2xl p-4 flex items-start gap-4">
                <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-gray-900">{label}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full border ${color}`}>{key}</span>
                  </div>
                  <p className="text-gray-400 text-xs mt-0.5">{description}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {permissions.map(p => (
                      <span key={p} className="text-xs bg-gray-50 text-gray-500 px-2 py-0.5 rounded-md border border-gray-200">{p}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Invite staff */}
        <div>
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Invite Staff</h2>
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="flex gap-3">
              <Input
                placeholder="staff@email.com"
                value={inviteEmail}
                onChange={e => setInviteEmail(e.target.value)}
                className="border-gray-200 rounded-xl flex-1"
              />
              <div className="flex gap-2 shrink-0">
                {ROLES.map(r => (
                  <button key={r.key} onClick={() => setInviteRole(r.key)}
                    className={`px-3 py-2 rounded-xl text-xs font-medium border transition-all ${
                      inviteRole === r.key ? `${r.color}` : "bg-gray-50 border-gray-200 text-gray-400 hover:text-gray-700"
                    }`}>
                    {r.label}
                  </button>
                ))}
              </div>
              <Button onClick={invite} disabled={inviting || !inviteEmail.trim()}
                className="bg-violet-600 hover:bg-violet-700 text-white font-semibold gap-2 shrink-0">
                <UserPlus className="w-4 h-4" />
                {inviting ? "Sending..." : "Invite"}
              </Button>
            </div>
            {inviteMsg && <p className="text-green-600 text-sm mt-3">{inviteMsg}</p>}
          </div>
        </div>

        {/* Staff list */}
        <div>
          <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Staff Members</h2>
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
            {loading ? (
              <div className="py-12 text-center text-gray-300 text-sm">Loading...</div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100 text-gray-400 text-xs">
                    <th className="text-left px-5 py-3 font-medium">Staff Member</th>
                    <th className="text-left px-4 py-3 font-medium">Email</th>
                    <th className="text-left px-4 py-3 font-medium">Role</th>
                    <th className="text-left px-4 py-3 font-medium">Joined</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => {
                    const role = ROLES.find(r => r.key === (u.role || "cashier")) || ROLES[1];
                    return (
                      <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50 transition">
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 rounded-full bg-violet-100 flex items-center justify-center text-xs font-bold text-violet-600">
                              {u.full_name?.[0]?.toUpperCase() || u.email?.[0]?.toUpperCase() || "?"}
                            </div>
                            <span className="text-gray-800 font-medium">{u.full_name || "—"}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-gray-500">{u.email}</td>
                        <td className="px-4 py-3">
                          <select
                            value={u.role || "cashier"}
                            onChange={e => changeRole(u.id, e.target.value)}
                            className={`text-xs px-2.5 py-1.5 rounded-lg border bg-white font-medium cursor-pointer focus:outline-none ${role.color}`}
                          >
                            {ROLES.map(r => <option key={r.key} value={r.key}>{r.label}</option>)}
                          </select>
                        </td>
                        <td className="px-4 py-3 text-gray-400 text-xs">
                          {u.created_date ? new Date(u.created_date).toLocaleDateString() : "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
        </div>
        )}
      </div>
    </div>
  );
}