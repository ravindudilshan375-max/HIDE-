import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, isAfter } from "date-fns";
import { DollarSign, Calculator, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function TillsReport() {
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 500),
    ]).then(([u, b, o]) => {
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setOrders(o);
      setLoading(false);
    });
  }, []);

  const periodStart = useMemo(() => startOfMonth(new Date()), []);

  const filteredOrders = useMemo(() => {
    return orders.filter(o => 
      o.status === "paid" && 
      o.created_date && 
      isAfter(new Date(o.created_date), periodStart) &&
      (!selectedBranchId || o.branch_id === selectedBranchId)
    );
  }, [orders, periodStart, selectedBranchId]);

  const tillStats = useMemo(() => {
    const paymentMap = {};
    let totalCash = 0, totalCard = 0, totalMobile = 0;

    filteredOrders.forEach(o => {
      const method = o.payment_method || "unknown";
      if (!paymentMap[method]) paymentMap[method] = { method, count: 0, amount: 0 };
      paymentMap[method].count += 1;
      paymentMap[method].amount += o.total || 0;

      if (method === "cash") totalCash += o.total || 0;
      if (method === "card") totalCard += o.total || 0;
      if (method === "mobile") totalMobile += o.total || 0;
    });

    const total = totalCash + totalCard + totalMobile;
    return {
      paymentMethods: Object.values(paymentMap),
      totalCash,
      totalCard,
      totalMobile,
      total,
      cashPercent: total > 0 ? ((totalCash / total) * 100).toFixed(1) : 0,
    };
  }, [filteredOrders]);

  const chartData = useMemo(() => {
    return [
      { method: "Cash", amount: tillStats.totalCash, fill: "#10b981" },
      { method: "Card", amount: tillStats.totalCard, fill: "#3b82f6" },
      { method: "Mobile", amount: tillStats.totalMobile, fill: "#8b5cf6" },
    ].filter(m => m.amount > 0);
  }, [tillStats]);

  if (loading) return <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Tills Report</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-3">
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
        </div>

        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">AED {tillStats.totalCash.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Cash</p>
            <p className="text-xs text-green-600 font-semibold mt-1">{tillStats.cashPercent}%</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">AED {tillStats.totalCard.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Card</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-purple-600" />
            </div>
            <p className="text-2xl font-bold text-purple-600">AED {tillStats.totalMobile.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Mobile</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-violet-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingUp className="w-5 h-5 text-violet-600" />
            </div>
            <p className="text-2xl font-bold text-violet-600">AED {tillStats.total.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Total</p>
          </div>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
          <h3 className="font-semibold text-sm mb-4 text-gray-500">Payment Method Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="method" tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} tickFormatter={v => `AED ${v}`} />
              <Tooltip formatter={(v) => `AED ${v.toFixed(2)}`} />
              <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, idx) => (
                  <Bar key={idx} dataKey="amount" fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-4">
            <span className="col-span-2">Payment Method</span><span className="text-right">Transactions</span><span className="text-right">Amount</span>
          </div>
          {tillStats.paymentMethods.map((pm, i) => (
            <div key={pm.method} className="grid grid-cols-4 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm items-center">
              <div className="col-span-2 flex items-center gap-2">
                <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                <span className="font-medium text-gray-800 capitalize">{pm.method}</span>
              </div>
              <span className="text-right text-gray-500">{pm.count}</span>
              <span className="text-right text-violet-700 font-semibold">AED {pm.amount.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}