import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Receipt, CreditCard, BadgeAlert, MapPin, Tag, AlertCircle,
  ChefHat, Calendar, Bookmark, ShoppingCart, Bell, Settings,
  ChevronRight
} from "lucide-react";

const MANAGE_ITEMS = [
  { icon: Receipt, label: "Taxes & Groups", page: "TaxesAndGroups" },
  { icon: CreditCard, label: "Payment Methods", page: "PaymentMethods" },
  { icon: BadgeAlert, label: "Charges", page: "Settings" },
  { icon: MapPin, label: "Delivery Zones", page: "Settings" },
  { icon: Tag, label: "Tags", page: "Tags" },
  { icon: AlertCircle, label: "Reasons", page: "Reasons" },
  { icon: ChefHat, label: "Kitchen Flows", page: "Kitchen" },
  { icon: Calendar, label: "Reservations", page: "Settings" },
  { icon: Bookmark, label: "Brands", page: "Settings" },
  { icon: ShoppingCart, label: "Online Ordering", page: "Settings", isNew: true },
  { icon: Bell, label: "Notifications", page: "Settings" },
  { icon: Settings, label: "Settings", page: "Settings" }
];

export default function Manage() {
  const [modifiedItems, setModifiedItems] = useState(new Set());

  useEffect(() => {
    // Load modified items from localStorage
    const saved = localStorage.getItem("manage_modified_items");
    if (saved) {
      setModifiedItems(new Set(JSON.parse(saved)));
    }
  }, []);

  const toggleModified = (label, e) => {
    e.preventDefault();
    e.stopPropagation();
    const updated = new Set(modifiedItems);
    if (updated.has(label)) {
      updated.delete(label);
    } else {
      updated.add(label);
    }
    setModifiedItems(updated);
    localStorage.setItem("manage_modified_items", JSON.stringify(Array.from(updated)));
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Manage</h1>
          <p className="text-sm text-gray-500 mt-1">Configure and manage all system settings</p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {MANAGE_ITEMS.map((item) => {
            const Icon = item.icon;
            const isModified = modifiedItems.has(item.label);
            return (
              <Link
                key={item.label}
                to={createPageUrl(item.page)}
                className="group relative bg-white border border-gray-200 rounded-2xl p-5 hover:border-violet-400 hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="p-2.5 rounded-lg bg-violet-50 group-hover:bg-violet-100 transition-colors">
                    <Icon className="w-5 h-5 text-violet-600" />
                  </div>
                  <button
                    onClick={(e) => toggleModified(item.label, e)}
                    className={`w-5 h-5 rounded-full border-2 transition-all flex items-center justify-center ${
                      isModified
                        ? "bg-amber-500 border-amber-500"
                        : "border-gray-300 hover:border-amber-400"
                    }`}
                    title="Mark as modified"
                  >
                    {isModified && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                  </button>
                </div>

                <h3 className="font-semibold text-gray-900 text-sm mb-4">{item.label}</h3>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500 font-medium">Manage</span>
                  <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-violet-600 transition-colors" />
                </div>

                {/* Badges */}
                <div className="absolute top-3 right-3 flex gap-2">
                  {item.isNew && (
                    <span className="bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      New!
                    </span>
                  )}
                  {isModified && (
                    <span className="bg-amber-100 text-amber-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">
                      Modified
                    </span>
                  )}
                </div>
              </Link>
            );
          })}
        </div>

        {/* Modified items indicator */}
        {modifiedItems.size > 0 && (
          <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-xl">
            <p className="text-sm text-amber-800">
              <span className="font-semibold">{modifiedItems.size}</span> item{modifiedItems.size !== 1 ? 's' : ''} marked as modified
            </p>
          </div>
        )}
      </div>
    </div>
  );
}