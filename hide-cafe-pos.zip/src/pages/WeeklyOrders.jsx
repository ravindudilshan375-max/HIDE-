import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, RefreshCw, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import WeeklyOrderForm from "@/components/weekly/WeeklyOrderForm";
import WeeklyOrderList from "@/components/weekly/WeeklyOrderList";
import WeeklyOrderDetail from "@/components/weekly/WeeklyOrderDetail";
import { useNavigate } from "react-router-dom";

const STATUS_TABS = ["all", "processing", "ready_to_receive", "received"];

export default function WeeklyOrders() {
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("list");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [user, setUser] = useState(null);
  const [staffSession, setStaffSession] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check for staff PIN session
    try {
      const raw = localStorage.getItem("weekly_orders_session");
      if (raw) setStaffSession(JSON.parse(raw));
    } catch {}
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [ordersData, branchData, invData, userData] = await Promise.all([
      base44.entities.WeeklyOrderRequest.list("-created_date"),
      base44.entities.Branch.list(),
      base44.entities.InventoryItem.list("name"),
      base44.auth.me().catch(() => null),
    ]);
    setOrders(ordersData);
    setBranches(branchData.filter(b => b.is_active !== false));
    setInventoryItems(invData);
    setUser(userData);
    setLoading(false);
  };

  // Staff session overrides: if logged in via PIN as staff, isManager=false
  const isManager = staffSession
    ? (staffSession.role === "manager" || staffSession.role === "admin")
    : (user?.role === "admin" || user?.role === "manager");

  const handleStaffLogout = () => {
    localStorage.removeItem("weekly_orders_session");
    navigate("/WeeklyOrdersLogin");
  };

  const filtered = useMemo(() => {
    if (statusFilter === "all") return orders;
    if (statusFilter === "processing") return orders.filter(o => o.status === "draft" || o.status === "pending" || o.status === "approved");
    if (statusFilter === "ready_to_receive") return orders.filter(o => o.status === "ready_to_receive");
    return orders.filter(o => o.status === statusFilter);
  }, [orders, statusFilter]);

  const counts = useMemo(() => ({
    all: orders.length,
    processing: orders.filter(o => o.status === "draft" || o.status === "pending" || o.status === "approved").length,
    ready_to_receive: orders.filter(o => o.status === "ready_to_receive").length,
    received: orders.filter(o => o.status === "received").length,
  }), [orders]);

  if (loading) return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center">
        <div className="w-7 h-7 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
        <p className="text-sm text-gray-400">Loading...</p>
      </div>
    </div>
  );

  if (view === "form") return (
    <WeeklyOrderForm
      branches={branches}
      inventoryItems={inventoryItems}
      editingOrder={selectedOrder}
      onSaved={() => { loadData(); setView("list"); setSelectedOrder(null); }}
      onCancel={() => { setView("list"); setSelectedOrder(null); }}
    />
  );

  if (view === "detail" && selectedOrder) return (
    <WeeklyOrderDetail
      order={selectedOrder}
      onBack={() => { setView("list"); setSelectedOrder(null); }}
      onEdit={() => setView("form")}
      onRefresh={loadData}
      isManager={isManager}
    />
  );

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-4 md:p-6">
      <div className="max-w-3xl mx-auto space-y-5">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Weekly Orders</h1>
            {staffSession
              ? <p className="text-sm text-violet-600 font-medium mt-0.5">👤 {staffSession.name} · {staffSession.branch_name || "All Branches"}</p>
              : <p className="text-sm text-gray-400 mt-0.5">Staff stock requests & PO planning</p>
            }
          </div>
          <div className="flex items-center gap-2">
            {staffSession && (
              <button onClick={handleStaffLogout} title="Logout"
                className="p-2 text-gray-400 hover:text-red-500 border border-gray-200 bg-white rounded-xl transition">
                <LogOut className="w-4 h-4" />
              </button>
            )}
            <button onClick={loadData}
              className="p-2 text-gray-400 hover:text-gray-600 border border-gray-200 bg-white rounded-xl transition">
              <RefreshCw className="w-4 h-4" />
            </button>
            <Button
              onClick={() => { setSelectedOrder(null); setView("form"); }}
              className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
              <Plus className="w-4 h-4" /> New Request
            </Button>
          </div>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Total",            key: "all",              color: "text-gray-700" },
            { label: "Processing",       key: "processing",       color: "text-amber-600" },
            { label: "Ready to Receive", key: "ready_to_receive", color: "text-orange-500" },
            { label: "Received",         key: "received",         color: "text-green-600" },
          ].map(({ label, key, color }) => (
            <div key={key} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-center">
              <p className={`text-2xl font-bold ${color}`}>{counts[key]}</p>
              <p className="text-xs text-gray-400 mt-1">{label}</p>
            </div>
          ))}
        </div>

        {/* Status tabs */}
        <div className="flex gap-1 bg-white border border-gray-200 rounded-xl p-1 overflow-x-auto">
          {STATUS_TABS.map(s => {
            const labels = { all: "All", processing: "Processing", ready_to_receive: "Ready", received: "Received" };
            return (
              <button key={s} onClick={() => setStatusFilter(s)}
                className={`flex-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap min-w-fit ${
                  statusFilter === s ? "bg-violet-600 text-white" : "text-gray-400 hover:text-gray-700"
                }`}>
                {labels[s]} ({counts[s] || 0})
              </button>
            );
          })}
        </div>

        {/* Info banner for staff */}
        {!isManager && (
          <div className="bg-blue-50 border border-blue-100 rounded-2xl px-4 py-3 text-xs text-blue-600">
            📋 Submit your request and a Draft Purchase Order will be automatically created for manager review.
          </div>
        )}

        <WeeklyOrderList
          orders={filtered}
          isManager={isManager}
          onSelect={(order) => { setSelectedOrder(order); setView("detail"); }}
        />
      </div>
    </div>
  );
}