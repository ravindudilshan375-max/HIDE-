import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Filter, Upload } from "lucide-react";
import { format } from "date-fns";
import PODetail from "@/components/purchaseorders/PODetail";
import POForm from "@/components/purchaseorders/POForm";



const TABS = ["All", "Draft", "Approved", "Sent", "Received", "Completed", "Cancelled"];

const STATUS_COLORS = {
  draft:     "text-gray-500",
  approved:  "text-blue-600",
  sent:      "text-violet-600",
  received:  "text-amber-600",
  completed: "text-green-600",
  cancelled: "text-red-500",
};

const STATUS_BADGES = {
  draft:     "bg-gray-100 text-gray-600",
  approved:  "bg-blue-100 text-blue-700",
  sent:      "bg-violet-100 text-violet-700",
  received:  "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-600",
};

export default function PurchaseOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("All");
  const [selectedPO, setSelectedPO] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [duplicateData, setDuplicateData] = useState(null);
  const [inventoryItems, setInventoryItems] = useState([]);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const [data, inv] = await Promise.all([
      base44.entities.PurchaseOrder.list("-created_date", 100),
      base44.entities.InventoryItem.list("name"),
    ]);
    setOrders(data);
    setInventoryItems(inv);
    setLoading(false);
  };

  const filteredOrders = orders.filter(o => {
    if (tab === "All") return true;
    return o.status === tab.toLowerCase();
  });

  const handleDuplicate = (po) => {
    const { id, created_date, updated_date, reference, ...rest } = po;
    setDuplicateData({ ...rest, status: "draft", reference: null });
    setSelectedPO(null);
    setShowForm(true);
  };

  const formatDate = (d) => {
    if (!d) return "—";
    try { return format(new Date(d), "MMMM dd, hh:mmaa"); } catch { return d; }
  };

  if (showForm) {
    return (
      <POForm
        initialData={duplicateData}
        onSaved={() => { setShowForm(false); setDuplicateData(null); load(); }}
        onCancel={() => { setShowForm(false); setDuplicateData(null); }}
      />
    );
  }

  if (selectedPO) {
    return (
      <PODetail
        po={selectedPO}
        inventoryItems={inventoryItems}
        onBack={() => { setSelectedPO(null); load(); }}
        onDuplicate={handleDuplicate}
        onEdit={(po) => { setDuplicateData(po); setSelectedPO(null); setShowForm(true); }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-5xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-gray-900">Purchase Orders</h1>
            <span className="w-5 h-5 rounded-full bg-gray-200 text-gray-500 text-xs flex items-center justify-center font-bold cursor-help" title="Manage your purchase orders">?</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm font-medium">
              <Upload className="w-4 h-4" /> Export
            </Button>
            <Button
              onClick={() => { setDuplicateData(null); setShowForm(true); }}
              className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
            >
              New Purchase Order
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 pt-4 pb-0 border-b border-gray-100">
            <div className="flex gap-1">
              {TABS.map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`px-4 py-2 text-sm font-medium rounded-t-lg transition border-b-2 ${
                    tab === t
                      ? "border-violet-600 text-violet-700"
                      : "border-transparent text-gray-400 hover:text-gray-700"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
            <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm mb-2">
              <Filter className="w-4 h-4" /> Filter
            </Button>
          </div>

          {loading ? (
            <div className="text-center py-16 text-gray-300 text-sm">Loading...</div>
          ) : filteredOrders.length === 0 ? (
            <div className="text-center py-16 text-gray-300 text-sm">No purchase orders found</div>
          ) : (
            <>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Reference</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Supplier</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Destination</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Business Date</th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Created</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map(order => (
                    <tr
                      key={order.id}
                      className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition cursor-pointer"
                      onClick={() => setSelectedPO(order)}
                    >
                      <td className="px-5 py-4 text-sm font-medium text-gray-700">{order.reference || "—"}</td>
                      <td className="px-4 py-4 text-sm text-gray-800">{order.supplier_name || "—"}</td>
                      <td className="px-4 py-4 text-sm text-gray-600">{order.destination_branch_name || "—"}</td>
                      <td className="px-4 py-4">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${STATUS_BADGES[order.status] || "bg-gray-100 text-gray-600"}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-sm text-gray-600">{order.business_date || "—"}</td>
                      <td className="px-5 py-4 text-sm text-gray-500">{formatDate(order.created_date)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="flex items-center justify-between px-5 py-3 border-t border-gray-100">
                <button className="text-sm text-gray-400 hover:text-gray-600">Previous</button>
                <button className="text-sm text-violet-600 hover:text-violet-800 font-medium">Next</button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}