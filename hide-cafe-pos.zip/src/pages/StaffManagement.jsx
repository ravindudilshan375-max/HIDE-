import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Search, Pencil, Trash2, KeyRound, Lock, Unlock, Eye, EyeOff, RefreshCw, Users, Shield, ArrowLeftRight, CheckCircle, XCircle, Clock, Package, ChevronDown, ChevronUp, X } from "lucide-react";

const ROLE_TYPES = [
  { value: "admin", label: "Admin", color: "bg-purple-100 text-purple-700" },
  { value: "manager", label: "Branch Manager", color: "bg-blue-100 text-blue-700" },
  { value: "cashier", label: "Cashier", color: "bg-green-100 text-green-700" },
  { value: "kitchen", label: "Kitchen Staff", color: "bg-orange-100 text-orange-700" },
  { value: "waiter", label: "Waiter", color: "bg-pink-100 text-pink-700" },
  { value: "transfer_manager", label: "Transfer Manager", color: "bg-teal-100 text-teal-700" },
];

// Roles allowed to approve/reject transfers
const TRANSFER_APPROVER_ROLES = ["admin", "manager", "transfer_manager"];

function PinSetModal({ staff, onClose, onSaved }) {
  const [pin, setPin] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleSave = async () => {
    if (pin.length < 4 || pin.length > 6) { setError("PIN must be 4–6 digits"); return; }
    if (!/^\d+$/.test(pin)) { setError("PIN must be numeric only"); return; }
    if (pin !== confirm) { setError("PINs do not match"); return; }

    setSaving(true);
    setError("");
    try {
      const res = await base44.functions.invoke("setStaffPin", {
        staff_member_id: staff.id,
        pin
      });
      if (res.data?.error) { setError(res.data.error); setSaving(false); return; }
      onSaved();
      onClose();
    } catch (e) {
      setError(e.message);
    }
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-1">Set PIN</h2>
        <p className="text-sm text-gray-500 mb-5">Set a 4–6 digit PIN for <strong>{staff.name}</strong></p>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">New PIN</label>
            <div className="relative">
              <input
                type={show ? "text" : "password"}
                value={pin}
                onChange={e => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="Enter PIN"
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm pr-10 focus:outline-none focus:border-violet-400 tracking-widest font-mono"
              />
              <button onClick={() => setShow(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Confirm PIN</label>
            <input
              type={show ? "text" : "password"}
              value={confirm}
              onChange={e => setConfirm(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="Confirm PIN"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400 tracking-widest font-mono"
            />
          </div>
          {error && <p className="text-red-500 text-xs">{error}</p>}
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button onClick={handleSave} disabled={saving || pin.length < 4} className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
            {saving ? "Saving…" : "Set PIN"}
          </button>
        </div>
      </div>
    </div>
  );
}

function StaffFormModal({ staff, branches, roles, departments, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: staff?.name || "",
    staff_id: staff?.staff_id || "",
    phone: staff?.phone || "",
    email: staff?.email || "",
    branch_id: staff?.branch_id || "",
    department_id: staff?.department_id || "",
    department_name: staff?.department_name || "",
    role_type: staff?.role_type || "cashier",
    role_id: staff?.role_id || "",
    role_name: staff?.role_name || "",
    hourly_rate: staff?.hourly_rate || "",
    employment_type: staff?.employment_type || "full_time",
    employment_status: staff?.employment_status || "active",
    is_active: staff?.is_active !== false,
    notes: staff?.notes || ""
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.name.trim() || !form.branch_id) return;
    setSaving(true);

    const branch = branches.find(b => b.id === form.branch_id);
    const role = roles.find(r => r.id === form.role_id);
    const dept = departments.find(d => d.id === form.department_id);
    const data = {
      ...form,
      branch_name: branch?.name || "",
      role_name: role?.name || form.role_type,
      department_name: dept?.name || "",
    };

    if (staff?.id) {
      await base44.entities.StaffMember.update(staff.id, data);
    } else {
      await base44.entities.StaffMember.create(data);
    }
    onSaved();
    onClose();
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-100 p-6 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">{staff ? "Edit Staff Member" : "Add Staff Member"}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Full Name *</label>
            <input
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Ahmed Al Rashidi"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Staff ID</label>
            <input
              value={form.staff_id}
              onChange={e => setForm({ ...form, staff_id: e.target.value })}
              placeholder="e.g. EMP-001"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Phone</label>
              <input
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                placeholder="+971 50 000 0000"
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="staff@example.com"
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Branch *</label>
            <select
              value={form.branch_id}
              onChange={e => setForm({ ...form, branch_id: e.target.value })}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-black focus:outline-none focus:border-violet-400"
            >
              <option value="">Select branch…</option>
              {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Department</label>
            <select
              value={form.department_id}
              onChange={e => setForm({ ...form, department_id: e.target.value })}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-black focus:outline-none focus:border-violet-400"
            >
              <option value="">No department</option>
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Role Type *</label>
            <select
              value={form.role_type}
              onChange={e => setForm({ ...form, role_type: e.target.value })}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-black focus:outline-none focus:border-violet-400"
            >
              {ROLE_TYPES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
          {roles.length > 0 && (
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Permission Role (optional)</label>
              <select
                value={form.role_id}
                onChange={e => setForm({ ...form, role_id: e.target.value })}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-black focus:outline-none focus:border-violet-400"
              >
                <option value="">None</option>
                {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Hourly Rate (AED)</label>
              <input
                type="number"
                min={0}
                value={form.hourly_rate}
                onChange={e => setForm({ ...form, hourly_rate: e.target.value })}
                placeholder="0.00"
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Employment Type</label>
              <select value={form.employment_type} onChange={e => setForm({ ...form, employment_type: e.target.value })}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-black focus:outline-none focus:border-violet-400">
                <option value="full_time">Full-Time</option>
                <option value="part_time">Part-Time</option>
                <option value="contract">Contract</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Employment Status</label>
            <select value={form.employment_status} onChange={e => setForm({ ...form, employment_status: e.target.value })}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-black focus:outline-none focus:border-violet-400">
              <option value="active">Active</option>
              <option value="on_leave">On Leave</option>
              <option value="suspended">Suspended</option>
              <option value="terminated">Terminated</option>
            </select>
          </div>
          <div className="flex items-center gap-3">
            <label className="text-sm font-semibold text-gray-700">POS Login Active</label>
            <button
              type="button"
              onClick={() => setForm({ ...form, is_active: !form.is_active })}
              className={`relative w-11 h-6 rounded-full transition-colors ${form.is_active ? "bg-violet-600" : "bg-gray-200"}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${form.is_active ? "translate-x-5" : "translate-x-0.5"}`} />
            </button>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Notes</label>
            <textarea
              value={form.notes}
              onChange={e => setForm({ ...form, notes: e.target.value })}
              rows={2}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400 resize-none"
            />
          </div>
        </div>

        <div className="border-t border-gray-100 p-6 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button
            onClick={handleSave}
            disabled={!form.name.trim() || !form.branch_id || saving}
            className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition"
          >
            {saving ? "Saving…" : staff ? "Update" : "Create"}
          </button>
        </div>
      </div>
    </div>
  );
}

const STATUS_STYLES = {
  pending: "bg-amber-100 text-amber-700",
  approved: "bg-blue-100 text-blue-700",
  in_transit: "bg-purple-100 text-purple-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-gray-100 text-gray-600",
  rejected: "bg-red-100 text-red-700",
};

function StatusBadge({ status }) {
  return (
    <span className={`inline-block text-xs px-2.5 py-1 rounded-full font-semibold capitalize ${STATUS_STYLES[status] || "bg-gray-100 text-gray-600"}`}>
      {status}
    </span>
  );
}

function CreateTransferModal({ branches, inventoryItems, user, onClose, onCreated }) {
  const [form, setForm] = useState({ from_branch_id: "", to_branch_id: "", notes: "", items: [] });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const fromInventory = inventoryItems.filter(i => i.branch_id === form.from_branch_id && i.is_active !== false);

  const addItem = () => setForm(f => ({ ...f, items: [...f.items, { inventory_item_id: "", item_name: "", quantity: 1, unit: "" }] }));
  const removeItem = (idx) => setForm(f => ({ ...f, items: f.items.filter((_, i) => i !== idx) }));
  const updateItem = (idx, field, value) => setForm(f => ({
    ...f,
    items: f.items.map((item, i) => {
      if (i !== idx) return item;
      if (field === "inventory_item_id") {
        const inv = fromInventory.find(x => x.id === value);
        return { ...item, inventory_item_id: value, item_name: inv?.name || "", unit: inv?.unit || "", quantity: item.quantity };
      }
      return { ...item, [field]: value };
    })
  }));

  const handleSubmit = async () => {
    if (!form.from_branch_id || !form.to_branch_id) { setError("Select both branches"); return; }
    if (form.from_branch_id === form.to_branch_id) { setError("Source and destination must differ"); return; }
    if (form.items.length === 0 || form.items.some(i => !i.inventory_item_id || i.quantity <= 0)) { setError("Add at least one valid item"); return; }
    setSaving(true);
    setError("");
    try {
      const fromBranch = branches.find(b => b.id === form.from_branch_id);
      const toBranch = branches.find(b => b.id === form.to_branch_id);
      const logEntry = [{
        timestamp: new Date().toISOString(),
        event: "created",
        user_email: user?.email || "",
        user_name: user?.full_name || "",
        details: "Transfer request submitted.",
      }];
      const itemsWithSent = form.items.map(i => ({ ...i, quantity_sent: i.quantity }));
      await base44.entities.BranchTransfer.create({
        from_branch_id: form.from_branch_id,
        from_branch_name: fromBranch?.name || "",
        to_branch_id: form.to_branch_id,
        to_branch_name: toBranch?.name || "",
        items: itemsWithSent,
        status: "pending",
        requested_by: user?.email || "",
        requested_by_name: user?.full_name || "",
        request_date: new Date().toISOString(),
        notes: form.notes,
        audit_log: logEntry,
      });
      onCreated();
    } catch (e) {
      setError("Failed to create transfer: " + (e?.message || "Unknown error"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-100 p-5 flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-900">New Transfer Request</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">From Branch *</label>
              <select value={form.from_branch_id} onChange={e => setForm(f => ({ ...f, from_branch_id: e.target.value, items: [] }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
                <option value="">Select…</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">To Branch *</label>
              <select value={form.to_branch_id} onChange={e => setForm(f => ({ ...f, to_branch_id: e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
                <option value="">Select…</option>
                {branches.filter(b => b.id !== form.from_branch_id).map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-gray-600">Items *</label>
              <button onClick={addItem} disabled={!form.from_branch_id}
                className="text-xs text-violet-600 hover:text-violet-700 font-semibold flex items-center gap-1 disabled:opacity-40">
                <Plus className="w-3 h-3" /> Add Item
              </button>
            </div>
            {form.items.length === 0 && (
              <p className="text-xs text-gray-400 text-center py-4 border border-dashed border-gray-200 rounded-xl">
                {form.from_branch_id ? "Click Add Item to start" : "Select a source branch first"}
              </p>
            )}
            <div className="space-y-2">
              {form.items.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-center">
                  <select value={item.inventory_item_id} onChange={e => updateItem(idx, "inventory_item_id", e.target.value)}
                    className="flex-1 border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:border-violet-400">
                    <option value="">Select item…</option>
                    {fromInventory.map(i => <option key={i.id} value={i.id}>{i.name} (Qty: {i.current_quantity ?? 0} {i.unit})</option>)}
                  </select>
                  <input type="number" min={1} value={item.quantity} onChange={e => updateItem(idx, "quantity", Number(e.target.value))}
                    className="w-16 border border-gray-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:border-violet-400" />
                  <span className="text-xs text-gray-400 w-8">{item.unit}</span>
                  <button onClick={() => removeItem(idx)} className="text-gray-300 hover:text-red-500"><X className="w-4 h-4" /></button>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={2}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400 resize-none" />
          </div>

          {error && <p className="text-red-500 text-xs">{error}</p>}
        </div>
        <div className="border-t border-gray-100 p-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button onClick={handleSubmit} disabled={saving}
            className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
            {saving ? "Submitting…" : "Submit Request"}
          </button>
        </div>
      </div>
    </div>
  );
}

function TransferRow({ transfer, onApprove, onReject, onComplete, user }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="border border-gray-100 rounded-xl overflow-hidden">
      <div className="flex items-center gap-3 px-4 py-3 bg-white hover:bg-gray-50 cursor-pointer" onClick={() => setExpanded(v => !v)}>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-sm text-gray-900">{transfer.from_branch_name}</span>
            <ArrowLeftRight className="w-3.5 h-3.5 text-gray-400" />
            <span className="font-semibold text-sm text-gray-900">{transfer.to_branch_name}</span>
            <StatusBadge status={transfer.status} />
          </div>
          <div className="text-xs text-gray-400 mt-0.5">
            {transfer.items?.length || 0} item(s) · Requested by {transfer.requested_by_name || "—"} · {transfer.request_date ? new Date(transfer.request_date).toLocaleDateString() : "—"}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {transfer.status === "pending" && (
            <>
              <button onClick={e => { e.stopPropagation(); onApprove(transfer); }} className="flex items-center gap-1 text-xs font-semibold text-green-700 bg-green-50 hover:bg-green-100 px-2.5 py-1 rounded-lg transition">
                <CheckCircle className="w-3.5 h-3.5" /> Approve
              </button>
              <button onClick={e => { e.stopPropagation(); onReject(transfer); }} className="flex items-center gap-1 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg transition">
                <XCircle className="w-3.5 h-3.5" /> Reject
              </button>
            </>
          )}
          {transfer.status === "approved" && (
            <button onClick={e => { e.stopPropagation(); onComplete(transfer); }} className="flex items-center gap-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-lg transition">
              <CheckCircle className="w-3.5 h-3.5" /> Mark Completed
            </button>
          )}
          {expanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
        </div>
      </div>
      {expanded && (
        <div className="border-t border-gray-100 bg-gray-50 px-4 py-3 space-y-3">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs text-gray-600">
            <div><span className="font-semibold text-gray-500 block">Sending Branch</span>{transfer.from_branch_name}</div>
            <div><span className="font-semibold text-gray-500 block">Receiving Branch</span>{transfer.to_branch_name}</div>
            <div><span className="font-semibold text-gray-500 block">Requested By</span>{transfer.requested_by_name || "—"}</div>
            <div><span className="font-semibold text-gray-500 block">Approved By</span>{transfer.approved_by_name || "—"}</div>
            <div><span className="font-semibold text-gray-500 block">Request Date</span>{transfer.request_date ? new Date(transfer.request_date).toLocaleString() : "—"}</div>
            <div><span className="font-semibold text-gray-500 block">Approval Date</span>{transfer.approval_date ? new Date(transfer.approval_date).toLocaleString() : "—"}</div>
            <div><span className="font-semibold text-gray-500 block">Completion Date</span>{transfer.completion_date ? new Date(transfer.completion_date).toLocaleString() : "—"}</div>
            {transfer.notes && <div className="col-span-2"><span className="font-semibold text-gray-500 block">Notes</span>{transfer.notes}</div>}
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 mb-1.5">Items</p>
            <div className="space-y-1">
              {transfer.items?.map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-xs bg-white rounded-lg px-3 py-1.5 border border-gray-100">
                  <Package className="w-3.5 h-3.5 text-gray-400" />
                  <span className="font-medium text-gray-800">{item.item_name}</span>
                  <span className="text-gray-500">×{item.quantity} {item.unit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Modal: Reject with reason
function RejectModal({ transfer, user, onClose, onRejected }) {
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);
  const handleReject = async () => {
    setSaving(true);
    const log = [...(transfer.audit_log || []), {
      timestamp: new Date().toISOString(),
      event: "rejected",
      user_email: user?.email || "",
      user_name: user?.full_name || "",
      details: reason || "No reason provided",
    }];
    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "rejected",
      approved_by: user?.email,
      approved_by_name: user?.full_name,
      rejection_reason: reason,
      audit_log: log,
    });
    setSaving(false);
    onRejected();
    onClose();
  };
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-1">Reject Transfer</h3>
        <p className="text-sm text-gray-500 mb-4">Optionally provide a reason for rejection.</p>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3} placeholder="Reason (optional)…"
          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-red-400 resize-none mb-4" />
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button onClick={handleReject} disabled={saving}
            className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
            {saving ? "Rejecting…" : "Confirm Reject"}
          </button>
        </div>
      </div>
    </div>
  );
}

// Modal: Receive items — confirm quantities
function ReceiveModal({ transfer, inventoryItems, user, onClose, onCompleted }) {
  const [receivedQtys, setReceivedQtys] = useState(
    Object.fromEntries((transfer.items || []).map(i => [i.inventory_item_id, i.quantity_sent || i.quantity || 0]))
  );
  const [saving, setSaving] = useState(false);

  const handleComplete = async () => {
    setSaving(true);
    const updatedItems = (transfer.items || []).map(i => ({
      ...i,
      quantity_received: receivedQtys[i.inventory_item_id] ?? i.quantity_sent ?? 0,
    }));

    // Deduct from source, add to destination
    for (const item of updatedItems) {
      const qtyReceived = item.quantity_received;
      const qtySent = item.quantity_sent || 0;
      // Deduct from sending branch
      const srcItem = inventoryItems.find(inv => inv.id === item.inventory_item_id && inv.branch_id === transfer.from_branch_id);
      if (srcItem) {
        await base44.entities.InventoryItem.update(srcItem.id, {
          current_quantity: Math.max(0, (srcItem.current_quantity || 0) - qtySent),
        });
      }
      // Add to receiving branch (match by name)
      const dstItem = inventoryItems.find(inv => inv.name === item.item_name && inv.branch_id === transfer.to_branch_id);
      if (dstItem) {
        await base44.entities.InventoryItem.update(dstItem.id, {
          current_quantity: (dstItem.current_quantity || 0) + qtyReceived,
        });
      }
    }

    const log = [...(transfer.audit_log || []), {
      timestamp: new Date().toISOString(),
      event: "completed",
      user_email: user?.email || "",
      user_name: user?.full_name || "",
      details: `Receiving branch confirmed items received.`,
    }];

    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "completed",
      items: updatedItems,
      received_by: user?.email,
      received_by_name: user?.full_name,
      completion_date: new Date().toISOString(),
      audit_log: log,
    });
    setSaving(false);
    onCompleted();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-100 p-5 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Confirm Received Items</h3>
            <p className="text-xs text-gray-400 mt-0.5">{transfer.from_branch_name} → {transfer.to_branch_name}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-3">
          <p className="text-xs text-gray-500">Verify quantities received. Adjust if different from what was sent.</p>
          {(transfer.items || []).map(item => (
            <div key={item.inventory_item_id} className="flex items-center gap-3 bg-gray-50 rounded-xl px-4 py-3">
              <Package className="w-4 h-4 text-gray-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-800">{item.item_name}</p>
                <p className="text-xs text-gray-400">Sent: {item.quantity_sent || item.quantity || 0} {item.unit}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Received:</span>
                <input
                  type="number"
                  min={0}
                  value={receivedQtys[item.inventory_item_id] ?? 0}
                  onChange={e => setReceivedQtys(q => ({ ...q, [item.inventory_item_id]: Number(e.target.value) }))}
                  className="w-20 border border-gray-200 rounded-lg px-2 py-1.5 text-sm text-center focus:outline-none focus:border-violet-400"
                />
                <span className="text-xs text-gray-400">{item.unit}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-100 p-5 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button onClick={handleComplete} disabled={saving}
            className="flex-1 py-2.5 bg-green-600 hover:bg-green-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition">
            {saving ? "Confirming…" : "Confirm & Complete"}
          </button>
        </div>
      </div>
    </div>
  );
}

// Workflow step indicator
function WorkflowSteps({ status }) {
  const steps = [
    { key: "pending", label: "Requested" },
    { key: "approved", label: "Approved" },
    { key: "in_transit", label: "In Transit" },
    { key: "completed", label: "Completed" },
  ];
  const ORDER = { pending: 0, approved: 1, in_transit: 2, completed: 3, rejected: -1, cancelled: -1 };
  const currentIdx = ORDER[status] ?? 0;
  if (status === "rejected" || status === "cancelled") {
    return (
      <div className="flex items-center gap-2">
        <XCircle className="w-4 h-4 text-red-500" />
        <span className="text-xs font-semibold text-red-600 capitalize">{status}</span>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1">
      {steps.map((s, idx) => (
        <React.Fragment key={s.key}>
          <div className={`flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full ${
            idx < currentIdx ? "bg-green-100 text-green-700" :
            idx === currentIdx ? "bg-violet-100 text-violet-700" :
            "bg-gray-100 text-gray-400"
          }`}>
            {idx < currentIdx && <CheckCircle className="w-3 h-3" />}
            {s.label}
          </div>
          {idx < steps.length - 1 && <div className="w-4 h-px bg-gray-200" />}
        </React.Fragment>
      ))}
    </div>
  );
}

function FullTransferRow({ transfer, user, inventoryItems, onRefresh, canApprove }) {
  const [expanded, setExpanded] = useState(false);
  const [showReject, setShowReject] = useState(false);
  const [showReceive, setShowReceive] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  const addLog = (existing, event, details) => [...(existing || []), {
    timestamp: new Date().toISOString(),
    event,
    user_email: user?.email || "",
    user_name: user?.full_name || "",
    details,
  }];

  const handleApprove = async (e) => {
    e.stopPropagation();
    setActionLoading(true);
    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "approved",
      approved_by: user?.email,
      approved_by_name: user?.full_name,
      approval_date: new Date().toISOString(),
      audit_log: addLog(transfer.audit_log, "approved", "Transfer approved."),
    });
    setActionLoading(false);
    onRefresh();
  };

  const handleMarkInTransit = async (e) => {
    e.stopPropagation();
    setActionLoading(true);
    await base44.entities.BranchTransfer.update(transfer.id, {
      status: "in_transit",
      shipped_date: new Date().toISOString(),
      audit_log: addLog(transfer.audit_log, "in_transit", "Items dispatched by sending branch."),
    });
    setActionLoading(false);
    onRefresh();
  };

  return (
    <>
      <div className="border border-gray-100 rounded-xl overflow-hidden bg-white">
        <div className="flex items-start gap-3 px-4 py-3 hover:bg-gray-50 cursor-pointer" onClick={() => setExpanded(v => !v)}>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="font-semibold text-sm text-gray-900">{transfer.from_branch_name}</span>
              <ArrowLeftRight className="w-3.5 h-3.5 text-gray-400" />
              <span className="font-semibold text-sm text-gray-900">{transfer.to_branch_name}</span>
            </div>
            <WorkflowSteps status={transfer.status} />
            <div className="text-xs text-gray-400 mt-1">
              {transfer.items?.length || 0} item(s) · By {transfer.requested_by_name || "—"} · {transfer.request_date ? new Date(transfer.request_date).toLocaleDateString() : "—"}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
            {transfer.status === "pending" && canApprove && (
              <>
                <button onClick={handleApprove} disabled={actionLoading}
                  className="flex items-center gap-1 text-xs font-semibold text-green-700 bg-green-50 hover:bg-green-100 px-2.5 py-1 rounded-lg transition disabled:opacity-40">
                  <CheckCircle className="w-3.5 h-3.5" /> Approve
                </button>
                <button onClick={e => { e.stopPropagation(); setShowReject(true); }}
                  className="flex items-center gap-1 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg transition">
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </button>
              </>
            )}
            {transfer.status === "approved" && (
              <button onClick={handleMarkInTransit} disabled={actionLoading}
                className="flex items-center gap-1 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 px-2.5 py-1 rounded-lg transition disabled:opacity-40">
                <Package className="w-3.5 h-3.5" /> Mark In Transit
              </button>
            )}
            {transfer.status === "in_transit" && (
              <button onClick={e => { e.stopPropagation(); setShowReceive(true); }}
                className="flex items-center gap-1 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-lg transition">
                <CheckCircle className="w-3.5 h-3.5" /> Confirm Receipt
              </button>
            )}
            {expanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </div>
        </div>

        {expanded && (
          <div className="border-t border-gray-100 bg-gray-50 px-4 py-4 space-y-4">
            {/* Meta */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs text-gray-600">
              <div><span className="font-semibold text-gray-400 block mb-0.5">Requested By</span>{transfer.requested_by_name || "—"}</div>
              <div><span className="font-semibold text-gray-400 block mb-0.5">Approved By</span>{transfer.approved_by_name || "—"}</div>
              <div><span className="font-semibold text-gray-400 block mb-0.5">Received By</span>{transfer.received_by_name || "—"}</div>
              <div><span className="font-semibold text-gray-400 block mb-0.5">Request Date</span>{transfer.request_date ? new Date(transfer.request_date).toLocaleString() : "—"}</div>
              <div><span className="font-semibold text-gray-400 block mb-0.5">Approval Date</span>{transfer.approval_date ? new Date(transfer.approval_date).toLocaleString() : "—"}</div>
              <div><span className="font-semibold text-gray-400 block mb-0.5">Completed Date</span>{transfer.completion_date ? new Date(transfer.completion_date).toLocaleString() : "—"}</div>
              {transfer.rejection_reason && (
                <div className="col-span-3 bg-red-50 rounded-lg px-3 py-2">
                  <span className="font-semibold text-red-500 block mb-0.5">Rejection Reason</span>
                  {transfer.rejection_reason}
                </div>
              )}
              {transfer.notes && <div className="col-span-3"><span className="font-semibold text-gray-400 block mb-0.5">Notes</span>{transfer.notes}</div>}
            </div>

            {/* Items */}
            <div>
              <p className="text-xs font-semibold text-gray-500 mb-1.5">Items</p>
              <div className="space-y-1">
                {transfer.items?.map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-xs bg-white rounded-lg px-3 py-2 border border-gray-100">
                    <Package className="w-3.5 h-3.5 text-gray-400" />
                    <span className="font-medium text-gray-800 flex-1">{item.item_name}</span>
                    <span className="text-gray-500">Sent: {item.quantity_sent || item.quantity || 0} {item.unit}</span>
                    {item.quantity_received !== undefined && (
                      <span className={`font-semibold ${item.quantity_received < (item.quantity_sent || 0) ? "text-amber-600" : "text-green-600"}`}>
                        Received: {item.quantity_received} {item.unit}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Audit Log */}
            {transfer.audit_log?.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-gray-500 mb-1.5">Audit Log</p>
                <div className="space-y-1.5">
                  {transfer.audit_log.map((entry, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-violet-400 mt-1.5 shrink-0" />
                      <div>
                        <span className="font-semibold text-gray-700 capitalize">{entry.event}</span>
                        {" "}by <span className="font-medium">{entry.user_name || entry.user_email || "System"}</span>
                        {" · "}{entry.timestamp ? new Date(entry.timestamp).toLocaleString() : ""}
                        {entry.details && <p className="text-gray-400 mt-0.5">{entry.details}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {showReject && (
        <RejectModal transfer={transfer} user={user} onClose={() => setShowReject(false)} onRejected={onRefresh} />
      )}
      {showReceive && (
        <ReceiveModal transfer={transfer} inventoryItems={inventoryItems} user={user} onClose={() => setShowReceive(false)} onCompleted={onRefresh} />
      )}
    </>
  );
}

function BranchTransfersTab({ branches }) {
  const [transfers, setTransfers] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [user, setUser] = useState(null);
  const [staffMember, setStaffMember] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterBranch, setFilterBranch] = useState("all");
  const [search, setSearch] = useState("");
  const [activeSubTab, setActiveSubTab] = useState("active");

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const [transferData, invData, userData] = await Promise.all([
      base44.entities.BranchTransfer.list("-created_date"),
      base44.entities.InventoryItem.list(),
      base44.auth.me().catch(() => null),
    ]);
    setTransfers(transferData);
    setInventoryItems(invData);
    setUser(userData);
    setLoading(false);
  };

  // Check if current user can approve (admin/manager/transfer_manager in system roles)
  const canApprove = user?.role === "admin" || user?.role === "manager";

  const filtered = transfers.filter(t => {
    if (filterStatus !== "all" && t.status !== filterStatus) return false;
    if (filterBranch !== "all" && t.from_branch_id !== filterBranch && t.to_branch_id !== filterBranch) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!t.from_branch_name?.toLowerCase().includes(q) &&
          !t.to_branch_name?.toLowerCase().includes(q) &&
          !t.requested_by_name?.toLowerCase().includes(q) &&
          !t.items?.some(i => i.item_name?.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  const activeTransfers = filtered.filter(t => ["pending", "approved", "in_transit"].includes(t.status));
  const historyTransfers = filtered.filter(t => ["completed", "rejected", "cancelled"].includes(t.status));
  const pendingCount = transfers.filter(t => t.status === "pending").length;

  if (loading) return <div className="p-8 text-center text-gray-400 text-sm">Loading transfers…</div>;

  return (
    <div className="p-6 space-y-5">
      {/* Role info banner */}
      <div className="bg-teal-50 border border-teal-200 rounded-xl px-4 py-3 flex items-start gap-3">
        <Shield className="w-4 h-4 text-teal-600 mt-0.5 shrink-0" />
        <div className="text-xs text-teal-800">
          <span className="font-semibold">Branch Transfer Manager</span> role can create, view, approve/reject, and monitor all transfers.
          Assign this role in <span className="font-semibold">Staff Members → Role Type</span>.
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Pending", count: transfers.filter(t => t.status === "pending").length, color: "text-amber-600", bg: "bg-amber-50" },
          { label: "Approved", count: transfers.filter(t => t.status === "approved").length, color: "text-blue-600", bg: "bg-blue-50" },
          { label: "In Transit", count: transfers.filter(t => t.status === "in_transit").length, color: "text-purple-600", bg: "bg-purple-50" },
          { label: "Completed", count: transfers.filter(t => t.status === "completed").length, color: "text-green-600", bg: "bg-green-50" },
          { label: "Rejected", count: transfers.filter(t => t.status === "rejected" || t.status === "cancelled").length, color: "text-red-500", bg: "bg-red-50" },
        ].map(s => (
          <div key={s.label} className={`${s.bg} rounded-xl p-4`}>
            <p className={`text-2xl font-bold ${s.color}`}>{s.count}</p>
            <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search…"
            className="bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-violet-400 w-48" />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="in_transit">In Transit</option>
          <option value="completed">Completed</option>
          <option value="rejected">Rejected</option>
        </select>
        <select value={filterBranch} onChange={e => setFilterBranch(e.target.value)}
          className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
          <option value="all">All Branches</option>
          {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <button onClick={loadData} className="text-gray-400 hover:text-gray-600 transition">
          <RefreshCw className="w-4 h-4" />
        </button>
        <button onClick={() => setShowCreate(true)}
          className="ml-auto flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl px-4 py-2 text-sm transition">
          <Plus className="w-4 h-4" /> New Transfer
        </button>
      </div>

      {/* Sub-tabs */}
      <div className="flex gap-1">
        <button onClick={() => setActiveSubTab("active")}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition ${activeSubTab === "active" ? "bg-violet-600 text-white" : "text-gray-500 hover:bg-gray-100"}`}>
          <Clock className="w-4 h-4" /> Active Transfers
          {pendingCount > 0 && <span className="bg-amber-500 text-white text-xs rounded-full px-1.5 py-0.5 leading-none">{pendingCount}</span>}
        </button>
        <button onClick={() => setActiveSubTab("history")}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition ${activeSubTab === "history" ? "bg-violet-600 text-white" : "text-gray-500 hover:bg-gray-100"}`}>
          <ArrowLeftRight className="w-4 h-4" /> Transfer Log
        </button>
      </div>

      {/* Active Transfers */}
      {activeSubTab === "active" && (
        <div className="space-y-2">
          {activeTransfers.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 py-12 text-center">
              <ArrowLeftRight className="w-10 h-10 text-gray-200 mx-auto mb-2" />
              <p className="text-sm text-gray-400">No active transfers</p>
              <button onClick={() => setShowCreate(true)} className="mt-3 text-sm text-violet-600 font-semibold hover:underline">Create one</button>
            </div>
          )}
          {activeTransfers.map(t => (
            <FullTransferRow key={t.id} transfer={t} user={user} inventoryItems={inventoryItems} onRefresh={loadData} canApprove={canApprove} />
          ))}
        </div>
      )}

      {/* Transfer Log (History) */}
      {activeSubTab === "history" && (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Date</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">From → To</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Items Sent / Received</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Requested By</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Approved By</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Completed Date</th>
                  <th className="text-center py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody>
                {historyTransfers.length === 0 && (
                  <tr><td colSpan={7} className="text-center text-gray-400 py-10 text-sm">No completed or rejected transfers yet</td></tr>
                )}
                {historyTransfers.map(t => (
                  <tr key={t.id} className="border-b border-gray-50 hover:bg-gray-50 transition">
                    <td className="py-3 px-4 text-xs text-gray-500">{t.request_date ? new Date(t.request_date).toLocaleDateString() : "—"}</td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-gray-800 text-xs">{t.from_branch_name}</span>
                      <span className="text-gray-300 mx-1">→</span>
                      <span className="font-medium text-gray-800 text-xs">{t.to_branch_name}</span>
                    </td>
                    <td className="py-3 px-4 text-xs text-gray-500">
                      {t.items?.map(i => `${i.item_name}: ${i.quantity_sent || i.quantity || 0}${i.quantity_received !== undefined ? `→${i.quantity_received}` : ""} ${i.unit}`).join(", ")}
                    </td>
                    <td className="py-3 px-4 text-xs text-gray-500">{t.requested_by_name || "—"}</td>
                    <td className="py-3 px-4 text-xs text-gray-500">{t.approved_by_name || "—"}</td>
                    <td className="py-3 px-4 text-xs text-gray-500">{t.completion_date ? new Date(t.completion_date).toLocaleDateString() : "—"}</td>
                    <td className="py-3 px-4 text-center"><StatusBadge status={t.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showCreate && (
        <CreateTransferModal
          branches={branches}
          inventoryItems={inventoryItems}
          user={user}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); loadData(); }}
        />
      )}
    </div>
  );
}

const TABS = [
  { id: "staff", label: "Staff Members", icon: Users },
  { id: "roles", label: "Roles & Permissions", icon: Shield },
  { id: "transfers", label: "Branch Transfers", icon: ArrowLeftRight },
];

export default function StaffManagement() {
  const [activeTab, setActiveTab] = useState("staff");
  const [staffList, setStaffList] = useState([]);
  const [branches, setBranches] = useState([]);
  const [roles, setRoles] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterBranch, setFilterBranch] = useState("");
  const [filterRole, setFilterRole] = useState("");
  const [formModal, setFormModal] = useState(null); // null | "new" | staff obj
  const [pinModal, setPinModal] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [staff, branchData, roleData, deptData] = await Promise.all([
      base44.entities.StaffMember.list("-created_date"),
      base44.entities.Branch.list(),
      base44.entities.Role.list(),
      base44.entities.Department.list(),
    ]);
    setStaffList(staff);
    setBranches(branchData.filter(b => b.is_active !== false));
    setRoles(roleData);
    setDepartments(deptData);
    setLoading(false);
  };

  const deleteStaff = async (id) => {
    if (!confirm("Delete this staff member?")) return;
    await base44.entities.StaffMember.delete(id);
    setStaffList(prev => prev.filter(s => s.id !== id));
  };

  const toggleActive = async (staff) => {
    const updated = await base44.entities.StaffMember.update(staff.id, { is_active: !staff.is_active });
    setStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, is_active: !s.is_active } : s));
  };

  const unlockAccount = async (staff) => {
    await base44.entities.StaffMember.update(staff.id, { failed_attempts: 0, locked_until: null });
    setStaffList(prev => prev.map(s => s.id === staff.id ? { ...s, failed_attempts: 0, locked_until: null } : s));
  };

  const filtered = staffList.filter(s => {
    const matchSearch = !search || s.name?.toLowerCase().includes(search.toLowerCase()) || s.staff_id?.toLowerCase().includes(search.toLowerCase());
    const matchBranch = !filterBranch || s.branch_id === filterBranch;
    const matchRole = !filterRole || s.role_type === filterRole;
    return matchSearch && matchBranch && matchRole;
  });

  const getRoleStyle = (roleType) => ROLE_TYPES.find(r => r.value === roleType)?.color || "bg-gray-100 text-gray-600";
  const getRoleLabel = (roleType) => ROLE_TYPES.find(r => r.value === roleType)?.label || roleType;

  const isLocked = (staff) => {
    if (!staff.locked_until) return false;
    return new Date(staff.locked_until) > new Date();
  };

  if (loading) return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  // Dashboard stats
  const totalStaff = staffList.length;
  const activeStaff = staffList.filter(s => s.is_active !== false).length;
  const lockedStaff = staffList.filter(s => s.locked_until && new Date(s.locked_until) > new Date()).length;
  const noPin = staffList.filter(s => !s.pin_hash).length;
  const byRole = ROLE_TYPES.map(r => ({
    ...r,
    count: staffList.filter(s => s.role_type === r.value).length,
  }));

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Dashboard Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 pt-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">Staff Management</h1>
            <p className="text-violet-200 text-sm mt-0.5">Manage staff members, roles and branch transfers</p>
          </div>
          {activeTab === "staff" && (
            <button
              onClick={() => setFormModal("new")}
              className="flex items-center gap-2 bg-white text-violet-700 font-semibold rounded-xl px-4 py-2.5 transition text-sm hover:bg-violet-50 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Add Staff
            </button>
          )}
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-white/15 border border-white/20 rounded-2xl px-4 py-4">
            <p className="text-violet-200 text-xs font-medium mb-1">Total Staff</p>
            <p className="text-white text-3xl font-bold">{totalStaff}</p>
          </div>
          <div className="bg-white/15 border border-white/20 rounded-2xl px-4 py-4">
            <p className="text-violet-200 text-xs font-medium mb-1">Active</p>
            <p className="text-white text-3xl font-bold">{activeStaff}</p>
          </div>
          <div className={`border rounded-2xl px-4 py-4 ${lockedStaff > 0 ? "bg-red-500/30 border-red-400/40" : "bg-white/15 border-white/20"}`}>
            <p className="text-violet-200 text-xs font-medium mb-1">Locked Accounts</p>
            <p className="text-white text-3xl font-bold">{lockedStaff}</p>
          </div>
          <div className={`border rounded-2xl px-4 py-4 ${noPin > 0 ? "bg-amber-500/30 border-amber-400/40" : "bg-white/15 border-white/20"}`}>
            <p className="text-violet-200 text-xs font-medium mb-1">No PIN Set</p>
            <p className="text-white text-3xl font-bold">{noPin}</p>
          </div>
        </div>
      </div>

      {/* Role Breakdown */}
      <div className="px-6 -mt-4 mb-2">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {byRole.map(r => (
              <div key={r.value} className="text-center">
                <p className="text-2xl font-bold text-gray-900">{r.count}</p>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${r.color}`}>{r.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <div>
          {/* Tabs */}
          <div className="flex gap-1">
            {TABS.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition ${
                    activeTab === tab.id
                      ? "bg-violet-600 text-white"
                      : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
        </div>
      </div>

      {/* Roles Tab — info panel */}
      {activeTab === "roles" && (
        <div className="p-6">
          <div className="bg-white rounded-2xl border border-gray-200 p-8 text-center shadow-sm">
            <Shield className="w-12 h-12 text-violet-400 mx-auto mb-3" />
            <h2 className="text-lg font-bold text-gray-900 mb-1">Roles & Permissions</h2>
            <p className="text-sm text-gray-400 mb-5">Create and manage roles, assign permissions and branch access.</p>
            <a
              href="/Roles"
              className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl px-5 py-2.5 transition text-sm"
            >
              <Shield className="w-4 h-4" />
              Go to Roles & Permissions
            </a>
          </div>
        </div>
      )}

      {/* Branch Transfers Tab */}
      {activeTab === "transfers" && (
        <BranchTransfersTab branches={branches} />
      )}

      {/* Staff Members Tab */}
      {activeTab === "staff" && <div>

      {/* Filters */}
      <div className="px-6 py-4 flex flex-wrap gap-3 bg-white border-b border-gray-100">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name or ID…"
            className="bg-gray-50 border border-gray-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-violet-400 w-56"
          />
        </div>
        <select
          value={filterBranch}
          onChange={e => setFilterBranch(e.target.value)}
          className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
        >
          <option value="">All Branches</option>
          {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <select
          value={filterRole}
          onChange={e => setFilterRole(e.target.value)}
          className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
        >
          <option value="">All Roles</option>
          {ROLE_TYPES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        <button onClick={loadData} className="ml-auto text-gray-400 hover:text-gray-600 transition">
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Table */}
      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Staff</th>
                <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Branch / Dept</th>
                 <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Role</th>
                <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Pay</th>
                <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-5 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-5 py-12 text-center text-gray-400 text-sm">No staff members found</td>
                </tr>
              ) : (
                filtered.map(staff => (
                  <tr key={staff.id} className="hover:bg-gray-50 transition">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-violet-100 flex items-center justify-center text-sm font-bold text-violet-600">
                          {staff.name?.[0]?.toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{staff.name}</p>
                          {staff.staff_id && <p className="text-xs text-gray-400">{staff.staff_id}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <p className="text-sm text-gray-600">{staff.branch_name || "—"}</p>
                      {staff.department_name && <p className="text-xs text-violet-500 font-medium">{staff.department_name}</p>}
                      {staff.phone && <p className="text-xs text-gray-400">{staff.phone}</p>}
                    </td>
                    <td className="px-5 py-3">
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${getRoleStyle(staff.role_type)}`}>
                        {getRoleLabel(staff.role_type)}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      {staff.hourly_rate ? (
                        <div>
                          <p className="text-sm font-semibold text-gray-800">AED {staff.hourly_rate}/hr</p>
                          <p className="text-xs text-gray-400 capitalize">{(staff.employment_type || "full_time").replace("_", "-")}</p>
                        </div>
                      ) : <span className="text-xs text-gray-300">—</span>}
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {isLocked(staff) ? (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-red-100 text-red-700 font-medium flex items-center gap-1">
                            <Lock className="w-3 h-3" /> Locked
                          </span>
                        ) : staff.is_active ? (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-green-100 text-green-700 font-medium">Active</span>
                        ) : (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-500 font-medium">Inactive</span>
                        )}
                        {staff.employment_status === "on_leave" && (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-blue-100 text-blue-700 font-medium">On Leave</span>
                        )}
                        {staff.employment_status === "suspended" && (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-orange-100 text-orange-700 font-medium">Suspended</span>
                        )}
                        {staff.employment_status === "terminated" && (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-red-100 text-red-700 font-medium">Terminated</span>
                        )}
                        {!staff.pin_hash && (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">No PIN</span>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-2">
                        {isLocked(staff) && (
                          <button onClick={() => unlockAccount(staff)} title="Unlock account" className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition">
                            <Unlock className="w-4 h-4" />
                          </button>
                        )}
                        <button onClick={() => setPinModal(staff)} title="Set PIN" className="p-1.5 text-gray-400 hover:text-violet-600 hover:bg-violet-50 rounded-lg transition">
                          <KeyRound className="w-4 h-4" />
                        </button>
                        <button onClick={() => toggleActive(staff)} title={staff.is_active ? "Deactivate" : "Activate"} className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">
                          {staff.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                        <button onClick={() => setFormModal(staff)} title="Edit" className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteStaff(staff.id)} title="Delete" className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      </div>}

      {formModal && (
        <StaffFormModal
          staff={formModal === "new" ? null : formModal}
          branches={branches}
          roles={roles}
          departments={departments}
          onClose={() => setFormModal(null)}
          onSaved={loadData}
        />
      )}

      {pinModal && (
        <PinSetModal
          staff={pinModal}
          onClose={() => setPinModal(null)}
          onSaved={loadData}
        />
      )}
    </div>
  );
}