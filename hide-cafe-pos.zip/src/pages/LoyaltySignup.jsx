import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Star, Gift, Award, ChevronRight, Phone, User, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const TIERS = [
  { name: "Silver", min: 0, max: 199, color: "from-gray-400 to-gray-500", icon: "🥈" },
  { name: "Gold", min: 200, max: 499, color: "from-amber-400 to-yellow-500", icon: "🥇" },
  { name: "Platinum", min: 500, max: Infinity, color: "from-slate-600 to-slate-800", icon: "💎" },
];

const REWARDS = [
  { points: 50, reward: "Free Cookie 🍪" },
  { points: 100, reward: "Free Coffee ☕" },
  { points: 200, reward: "Free Cake 🎂" },
  { points: 500, reward: "VIP Reward 🌟" },
];

const getTier = (points) => {
  if (points >= 500) return "Platinum";
  if (points >= 200) return "Gold";
  return "Silver";
};

const generateLoyaltyId = () => `LOY-${Math.floor(10000 + Math.random() * 90000)}`;

export default function LoyaltySignup() {
  const [tab, setTab] = useState("signup"); // "signup" | "mycard"
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [lookupPhone, setLookupPhone] = useState("");
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSignup = async () => {
    if (!name.trim() || !phone.trim()) { setError("Please enter your name and phone number."); return; }
    setError("");
    setLoading(true);
    // Check if already exists
    const all = await base44.entities.Customer.list();
    const existing = all.find(c => (c.phone || "").replace(/\s/g, "") === phone.trim().replace(/\s/g, ""));
    if (existing) {
      setCustomer(existing);
      setLoading(false);
      return;
    }
    const loyalty_id = generateLoyaltyId();
    const c = await base44.entities.Customer.create({
      name: name.trim(),
      phone: phone.trim(),
      loyalty_id,
      tier: "Silver",
      points: 0,
      total_spent: 0,
      visit_count: 0,
    });
    setCustomer(c);
    setLoading(false);
  };

  const handleLookup = async () => {
    if (!lookupPhone.trim()) return;
    setError("");
    setLoading(true);
    const all = await base44.entities.Customer.list();
    const found = all.find(c =>
      (c.phone || "").replace(/\s/g, "") === lookupPhone.trim().replace(/\s/g, "") ||
      c.loyalty_id === lookupPhone.trim()
    );
    if (found) {
      setCustomer(found);
    } else {
      setError("No account found. Please sign up first.");
    }
    setLoading(false);
  };

  const tier = getTier(customer?.points || 0);
  const tierInfo = TIERS.find(t => t.name === tier) || TIERS[0];
  const nextTier = TIERS.find(t => t.min > (customer?.points || 0));
  const pointsToNext = nextTier ? nextTier.min - (customer?.points || 0) : 0;
  const qrUrl = customer?.loyalty_id
    ? `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(customer.loyalty_id)}&bgcolor=ffffff&color=1a1a2e`
    : null;

  if (customer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-slate-900 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-sm space-y-4">
          {/* Digital Card */}
          <div className={`rounded-3xl p-6 bg-gradient-to-br ${tierInfo.color} shadow-2xl relative overflow-hidden`}>
            {/* Background pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white translate-x-8 -translate-y-8" />
              <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full bg-white -translate-x-6 translate-y-6" />
            </div>
            <div className="relative">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-white/60 text-xs uppercase tracking-widest font-semibold">Loyalty Card</p>
                  <p className="text-white font-black text-xl mt-0.5">DENDAX</p>
                </div>
                <div className="text-3xl">{tierInfo.icon}</div>
              </div>

              <div className="flex items-end justify-between mb-6">
                <div>
                  <p className="text-white/60 text-xs uppercase tracking-wider">Member</p>
                  <p className="text-white font-bold text-lg leading-tight">{customer.name}</p>
                  <span className="text-xs font-bold bg-white/20 text-white px-2 py-0.5 rounded-full mt-1 inline-block">{tier}</span>
                </div>
                <div className="text-right">
                  <p className="text-white/60 text-xs uppercase tracking-wider">Points</p>
                  <p className="text-white font-black text-3xl">{(customer.points || 0).toLocaleString()}</p>
                </div>
              </div>

              {/* QR Code */}
              <div className="flex items-center gap-4">
                <div className="bg-white rounded-xl p-2">
                  {qrUrl && <img src={qrUrl} alt="QR" className="w-20 h-20" />}
                </div>
                <div>
                  <p className="text-white/60 text-[10px] uppercase tracking-wider">Loyalty ID</p>
                  <p className="text-white font-bold text-sm font-mono">{customer.loyalty_id}</p>
                  <p className="text-white/50 text-[10px] mt-1">Show this to earn points</p>
                </div>
              </div>
            </div>
          </div>

          {/* Progress to next tier */}
          {nextTier && (
            <div className="bg-white/10 backdrop-blur rounded-2xl p-4">
              <div className="flex justify-between items-center mb-2">
                <p className="text-white/70 text-xs font-medium">Progress to {nextTier.name}</p>
                <p className="text-white text-xs font-bold">{pointsToNext} pts away</p>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-400 rounded-full transition-all"
                  style={{ width: `${Math.min(100, ((customer.points || 0) / nextTier.min) * 100)}%` }}
                />
              </div>
            </div>
          )}

          {/* Rewards */}
          <div className="bg-white/10 backdrop-blur rounded-2xl p-4">
            <p className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
              <Gift className="w-4 h-4 text-amber-400" /> Rewards
            </p>
            <div className="space-y-2">
              {REWARDS.map(r => {
                const unlocked = (customer.points || 0) >= r.points;
                return (
                  <div key={r.points} className={`flex items-center justify-between py-1.5 border-b border-white/5 last:border-0 ${unlocked ? "opacity-100" : "opacity-50"}`}>
                    <span className="text-white text-sm">{r.reward}</span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${unlocked ? "bg-green-400/20 text-green-400" : "bg-white/10 text-white/60"}`}>
                      {unlocked ? "✓ Unlocked" : `${r.points} pts`}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <p className="text-white/30 text-xs text-center">Earn 1 point per AED spent • Screenshot this card</p>

          <button onClick={() => { setCustomer(null); setName(""); setPhone(""); setLookupPhone(""); }}
            className="w-full flex items-center justify-center gap-2 text-white/40 hover:text-white/70 text-xs transition py-2">
            <ArrowLeft className="w-3 h-3" /> Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-slate-900 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Star className="w-8 h-8 text-black" />
          </div>
          <h1 className="text-3xl font-black text-white">DENDAX</h1>
          <p className="text-white/50 text-sm mt-1">Loyalty Rewards Program</p>
        </div>

        {/* Tabs */}
        <div className="flex bg-white/10 rounded-xl p-1 mb-5">
          <button onClick={() => { setTab("signup"); setError(""); }}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${tab === "signup" ? "bg-white text-gray-900" : "text-white/60"}`}>
            Join Now
          </button>
          <button onClick={() => { setTab("mycard"); setError(""); }}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${tab === "mycard" ? "bg-white text-gray-900" : "text-white/60"}`}>
            My Card
          </button>
        </div>

        <div className="bg-white/10 backdrop-blur rounded-2xl p-5 space-y-3">
          {tab === "signup" ? (
            <>
              <p className="text-white/60 text-sm">Join our loyalty program and earn 1 point per AED spent!</p>
              <div className="space-y-3">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <Input placeholder="Your full name *" value={name} onChange={e => setName(e.target.value)}
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl pl-9" />
                </div>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <Input placeholder="Phone number *" value={phone} onChange={e => setPhone(e.target.value)}
                    type="tel"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl pl-9" />
                </div>
              </div>
              {error && <p className="text-red-400 text-xs">{error}</p>}
              <Button onClick={handleSignup} disabled={loading} className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11">
                {loading ? "Creating..." : "Get My Card →"}
              </Button>
            </>
          ) : (
            <>
              <p className="text-white/60 text-sm">Enter your phone number or Loyalty ID to access your card.</p>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                <Input placeholder="Phone number or LOY-XXXXX"
                  value={lookupPhone}
                  onChange={e => setLookupPhone(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleLookup()}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl pl-9" />
              </div>
              {error && <p className="text-red-400 text-xs">{error}</p>}
              <Button onClick={handleLookup} disabled={loading} className="w-full bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-xl h-11">
                {loading ? "Looking up..." : "Find My Card →"}
              </Button>
            </>
          )}
        </div>

        {/* Perks preview */}
        <div className="mt-5 grid grid-cols-2 gap-2">
          {REWARDS.map(r => (
            <div key={r.points} className="bg-white/5 rounded-xl p-3 flex items-center gap-2">
              <span className="text-lg">{r.reward.split(" ").slice(-1)[0]}</span>
              <div>
                <p className="text-white text-xs font-semibold">{r.reward.split(" ").slice(0, -1).join(" ")}</p>
                <p className="text-white/40 text-[10px]">{r.points} points</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}