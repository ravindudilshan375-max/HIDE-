import React, { useState } from "react";
import { Printer, FileSpreadsheet, Truck } from "lucide-react";
import PrinterSettings from "@/components/settings/PrinterSettings";
import InventoryImportExport from "@/components/settings/InventoryImportExport";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const TABS = [
  { key: "printers", label: "Printers & Devices", icon: Printer },
  { key: "import-export", label: "Menu Import / Export", icon: FileSpreadsheet },
];

export default function Integrations() {
  const [activeTab, setActiveTab] = useState("printers");

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Integrations</h1>
          <p className="text-gray-400 text-sm mt-0.5">Connect printers and manage menu data</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white border border-gray-100 rounded-2xl p-1 w-fit shadow-sm">
          {TABS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                activeTab === key ? "bg-violet-600 text-white shadow-sm" : "text-gray-500 hover:text-gray-800"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {/* Delivery Integrations shortcut */}
        <Link to={createPageUrl("DeliveryIntegrations")} className="flex items-center gap-4 p-4 bg-orange-50 border border-orange-200 rounded-2xl hover:bg-orange-100 transition">
          <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center">
            <Truck className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <p className="text-sm font-semibold text-orange-800">Delivery Integrations</p>
            <p className="text-xs text-orange-600">Connect Talabat, Deliveroo & Careem</p>
          </div>
          <span className="ml-auto text-orange-400">→</span>
        </Link>

        {activeTab === "printers" && <PrinterSettings />}
        {activeTab === "import-export" && <InventoryImportExport />}
      </div>
    </div>
  );
}