import React, { useState, useEffect, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Clock, LogIn, LogOut, Coffee, CheckCircle2, XCircle, Loader2, MapPin, ChevronDown, Home, FileText, Users } from "lucide-react";
import { format, differenceInMinutes, parseISO } from "date-fns";
import StaffGPSButton from "@/components/StaffGPSButton";

function formatDuration(minutes) {
  if (!minutes && minutes !== 0) return "0m";
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="text-center">
      <div className="text-7xl font-black text-white tracking-tight tabular-nums leading-none">
        {format(now, "hh:mm")}
        <span className="text-4xl text-white/40">{format(now, ":ss")}</span>
      </div>
      <div className="text-white/40 text-base mt-2">{format(now, "EEEE, MMMM d")}</div>
    </div>
  );
}

function ShiftTimer({ clockIn }) {
  const [elapsed, setElapsed] = useState("");
  useEffect(() => {
    const update = () => setElapsed(formatDuration(differenceInMinutes(new Date(), parseISO(clockIn))));
    update();
    const t = setInterval(update, 30000);
    return () => clearInterval(t);
  }, [clockIn]);
  return <span>{elapsed}</span>;
}

function PinDots({ length }) {
  return (
    <div className="flex gap-5 justify-center my-4">
      {[0, 1, 2, 3].map(i => (
        <div key={i} className={`w-6 h-6 rounded-full border-2 transition-all duration-150 ${
          i < length ? "bg-violet-400 border-violet-400 scale-125" : "bg-transparent border-white/25"
        }`} />
      ))}
    </div>
  );
}

function NumPad({ onPress, disabled }) {
  const keys = [1, 2, 3, 4, 5, 6, 7, 8, 9, null, 0, "⌫"];
  return (
    <div className="grid grid-cols-3 gap-3 w-full max-w-[300px] mx-auto">
      {keys.map((k, i) => (
        <button
          key={i}
          disabled={disabled || k === null}
          onClick={() => k !== null && onPress(String(k))}
          className={`h-[72px] rounded-2xl text-2xl font-bold transition-all active:scale-95 ${
            k === null ? "invisible" :
            k === "⌫" ? "bg-white/10 hover:bg-white/20 text-white/60 text-3xl" :
            "bg-white/10 hover:bg-white/20 text-white border border-white/10 shadow-inner"
          }`}
        >
          {k}
        </button>
      ))}
    </div>
  );
}

function ActionButton({ onClick, color, icon: Icon, label, sublabel }) {
  const colors = {
    green:  "bg-green-600 hover:bg-green-500 active:bg-green-700 shadow-green-900/40",
    amber:  "bg-amber-500 hover:bg-amber-400 active:bg-amber-600 shadow-amber-900/40",
    red:    "bg-red-600   hover:bg-red-500   active:bg-red-700   shadow-red-900/40",
  };
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-4 w-full px-6 py-5 rounded-2xl text-white font-bold text-xl transition-all active:scale-[0.98] shadow-lg ${colors[color]}`}
    >
      <div className="w-12 h-12 rounded-xl bg-black/20 flex items-center justify-center shrink-0">
        <Icon className="w-6 h-6" />
      </div>
      <div className="text-left">
        <div>{label}</div>
        {sublabel && <div className="text-sm font-normal opacity-70 mt-0.5">{sublabel}</div>}
      </div>
    </button>
  );
}

// Bottom Nav
function BottomNav({ activeTab, setActiveTab }) {
  const tabs = [
    { id: "clock", icon: Clock, label: "Time Clock" },
    { id: "timesheets", icon: FileText, label: "Timesheets" },
    { id: "team", icon: Users, label: "Team" },
  ];
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gray-950/95 backdrop-blur border-t border-white/10 flex"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      {tabs.map(({ id, icon: Icon, label }) => (
        <button key={id} onClick={() => setActiveTab(id)}
          className={`flex-1 flex flex-col items-center justify-center py-3 gap-1 transition-colors ${
            activeTab === id ? "text-violet-400" : "text-white/30 hover:text-white/60"
          }`}>
          <Icon className="w-5 h-5" />
          <span className="text-[11px] font-medium">{label}</span>
        </button>
      ))}
    </nav>
  );
}

// Timesheets tab — today's timecards for selected branch
function TimesheetsTab({ branchId }) {
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!branchId) { setLoading(false); return; }
    const today = new Date().toISOString().split("T")[0];
    base44.entities.StaffTimecard.list("-clock_in", 50).then(data => {
      const filtered = data.filter(c => c.branch_id === branchId && c.clock_in?.startsWith(today));
      setCards(filtered);
      setLoading(false);
    });
  }, [branchId]);

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
    </div>
  );

  return (
    <div className="px-4 py-6 space-y-3">
      <h2 className="text-white font-bold text-xl mb-4">Today's Timesheets</h2>
      {cards.length === 0 && (
        <div className="text-center py-16">
          <Clock className="w-12 h-12 text-white/10 mx-auto mb-3" />
          <p className="text-white/30">No timecards today</p>
        </div>
      )}
      {cards.map(card => (
        <div key={card.id} className="bg-white/5 border border-white/10 rounded-2xl px-4 py-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-violet-600/50 flex items-center justify-center text-white font-bold text-sm">
                {card.staff_name?.[0]?.toUpperCase()}
              </div>
              <div>
                <p className="text-white font-semibold">{card.staff_name}</p>
                <p className="text-white/40 text-xs">In: {format(parseISO(card.clock_in), "h:mm a")}</p>
              </div>
            </div>
            <span className={`text-xs px-3 py-1 rounded-full font-semibold ${
              card.status === "active" ? "bg-green-500/20 text-green-400" :
              card.status === "on_break" ? "bg-amber-500/20 text-amber-400" :
              "bg-white/10 text-white/40"
            }`}>
              {card.status === "active" ? "Working" : card.status === "on_break" ? "On Break" : "Done"}
            </span>
          </div>
          <div className="flex gap-4 text-xs text-white/40 mt-1 pl-[52px]">
            {card.clock_out && <span>Out: {format(parseISO(card.clock_out), "h:mm a")}</span>}
            {card.duration_minutes > 0 && <span>⏱ {formatDuration(card.duration_minutes)}</span>}
            {card.break_minutes > 0 && <span>☕ {formatDuration(card.break_minutes)} break</span>}
          </div>
        </div>
      ))}
    </div>
  );
}

// Team tab — who's currently clocked in
function TeamTab({ branchId }) {
  const [active, setActive] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!branchId) { setLoading(false); return; }
    base44.entities.StaffTimecard.filter({ branch_id: branchId }).then(data => {
      setActive(data.filter(c => c.status === "active" || c.status === "on_break"));
      setLoading(false);
    });
  }, [branchId]);

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
    </div>
  );

  return (
    <div className="px-4 py-6 space-y-3">
      <h2 className="text-white font-bold text-xl mb-4">
        Currently Working <span className="text-white/30 text-base font-normal">({active.length})</span>
      </h2>
      {active.length === 0 && (
        <div className="text-center py-16">
          <Users className="w-12 h-12 text-white/10 mx-auto mb-3" />
          <p className="text-white/30">No staff clocked in</p>
        </div>
      )}
      {active.map(card => (
        <div key={card.id} className="bg-white/5 border border-white/10 rounded-2xl px-4 py-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-violet-600/50 flex items-center justify-center text-white font-bold text-lg shrink-0">
            {card.staff_name?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1">
            <p className="text-white font-semibold">{card.staff_name}</p>
            <p className="text-white/40 text-sm">Since {format(parseISO(card.clock_in), "h:mm a")}</p>
          </div>
          <div className="text-right">
            <span className={`text-xs px-3 py-1 rounded-full font-semibold block mb-1 ${
              card.status === "on_break" ? "bg-amber-500/20 text-amber-400" : "bg-green-500/20 text-green-400"
            }`}>
              {card.status === "on_break" ? "On Break" : "Working"}
            </span>
            <p className="text-white/30 text-xs">
              <ShiftTimer clockIn={card.clock_in} />
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function StaffTimeClock() {
  const [activeTab, setActiveTab] = useState("clock");
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState("");
  const [showBranchPicker, setShowBranchPicker] = useState(false);
  const [pin, setPin] = useState("");
  const [clockStep, setClockStep] = useState("idle"); // idle | verifying | dashboard | loading | confirmed | error
  const [staffData, setStaffData] = useState(null);
  const [activeTimecard, setActiveTimecard] = useState(null);
  const [confirmedAction, setConfirmedAction] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [gpsCoords, setGpsCoords] = useState(null);
  const timerRef = useRef(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const branchParam = urlParams.get("branch");
    base44.entities.Branch.list().then(data => {
      const active = data.filter(b => b.is_active !== false);
      setBranches(active);
      if (branchParam && active.find(b => b.id === branchParam)) {
        setSelectedBranchId(branchParam);
      } else {
        const saved = localStorage.getItem("timeclock_branch_id");
        const found = active.find(b => b.id === saved);
        if (found) setSelectedBranchId(found.id);
        else if (active.length === 1) setSelectedBranchId(active[0].id);
      }
    });
    return () => clearTimeout(timerRef.current);
  }, []);

  const selectedBranch = branches.find(b => b.id === selectedBranchId);

  const scheduleReset = (delay = 4000) => {
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      setPin(""); setClockStep("idle"); setStaffData(null);
      setActiveTimecard(null); setConfirmedAction(null); setErrorMsg("");
    }, delay);
  };

  const handlePinKey = (key) => {
    if (clockStep === "verifying" || clockStep === "loading") return;
    if (key === "⌫") { setPin(p => p.slice(0, -1)); return; }
    const next = (pin + key).slice(0, 6);
    setPin(next);
    if (next.length === 4) verifyPin(next);
  };

  const verifyPin = async (enteredPin) => {
    if (!selectedBranchId) return;
    setClockStep("verifying");
    const res = await base44.functions.invoke("verifyStaffPin", {
      pin: enteredPin, branch_id: selectedBranchId,
    });
    if (!res.data?.success) {
      setErrorMsg(res.data?.error || "Invalid PIN. Try again.");
      setClockStep("error");
      scheduleReset(2500);
      return;
    }
    const staff = res.data.staff;
    setStaffData(staff);
    const timecards = await base44.entities.StaffTimecard.filter({ branch_id: selectedBranchId, staff_name: staff.name });
    const active = timecards.find(t => t.status === "active" || t.status === "on_break");
    setActiveTimecard(active || null);
    setClockStep("dashboard");
  };

  const performAction = async (action) => {
    setClockStep("loading");
    const now = new Date().toISOString();

    if (action === "clock_in") {
      // Use GPS-verified clock-in if coordinates are available
      if (gpsCoords) {
        const res = await base44.functions.invoke("clockInWithGPS", {
          pin: pin,
          branch_id: selectedBranchId,
          latitude: gpsCoords.latitude,
          longitude: gpsCoords.longitude
        });
        if (!res.data?.success) {
          setErrorMsg(res.data?.error || "GPS clock-in failed. Are you near the branch?");
          setClockStep("error");
          setGpsCoords(null);
          scheduleReset(3000);
          return;
        }
      } else {
        // Fallback to PIN-only clock-in (shouldn't happen with required GPS)
        await base44.entities.StaffTimecard.create({
          staff_email: staffData.staff_id || staffData.name,
          staff_name: staffData.name,
          branch_id: selectedBranchId,
          branch_name: selectedBranch?.name || "",
          clock_in: now, status: "active",
          clock_in_method: "pin", breaks: [], break_minutes: 0,
        });
      }
    } else if (action === "start_break") {
      const breaks = [...(activeTimecard.breaks || []), { break_start: now }];
      await base44.entities.StaffTimecard.update(activeTimecard.id, { status: "on_break", breaks });
    } else if (action === "end_break") {
      const breaks = (activeTimecard.breaks || []).map((b, i, arr) =>
        i === arr.length - 1 && !b.break_end
          ? { ...b, break_end: now, duration_minutes: differenceInMinutes(new Date(), new Date(b.break_start)) }
          : b
      );
      const breakMins = breaks.reduce((s, b) => s + (b.duration_minutes || 0), 0);
      await base44.entities.StaffTimecard.update(activeTimecard.id, { status: "active", breaks, break_minutes: breakMins });
    } else if (action === "clock_out") {
      const totalMins = differenceInMinutes(new Date(), parseISO(activeTimecard.clock_in));
      let breaks = activeTimecard.breaks || [];
      if (activeTimecard.status === "on_break") {
        breaks = breaks.map((b, i, arr) =>
          i === arr.length - 1 && !b.break_end
            ? { ...b, break_end: now, duration_minutes: differenceInMinutes(new Date(), new Date(b.break_start)) }
            : b
        );
      }
      const breakMins = breaks.reduce((s, b) => s + (b.duration_minutes || 0), 0);
      await base44.entities.StaffTimecard.update(activeTimecard.id, {
        clock_out: now, breaks, break_minutes: breakMins,
        duration_minutes: Math.max(0, totalMins - breakMins), status: "completed",
      });
    }

    setConfirmedAction(action);
    setClockStep("confirmed");
    scheduleReset(4000);
  };

  const resetClock = () => {
    clearTimeout(timerRef.current);
    setPin(""); setClockStep("idle"); setStaffData(null);
    setActiveTimecard(null); setConfirmedAction(null); setErrorMsg(""); setGpsCoords(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-900 to-violet-950 flex flex-col"
      style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 64px)", paddingTop: "env(safe-area-inset-top)" }}>

      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-5 pb-3 shrink-0">
        <div>
          <h1 className="text-white font-bold text-lg leading-tight">Staff Time Clock</h1>
          <p className="text-white/30 text-xs">DENDAX</p>
        </div>
        <div className="relative">
          <button onClick={() => setShowBranchPicker(v => !v)}
            className="flex items-center gap-2 text-white/50 hover:text-white/80 text-sm transition px-3 py-2 rounded-xl bg-white/5">
            <MapPin className="w-3.5 h-3.5" />
            <span className="max-w-[120px] truncate">{selectedBranch?.name || "Branch"}</span>
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
          {showBranchPicker && (
            <div className="absolute right-0 top-full mt-2 bg-white rounded-2xl shadow-2xl border border-gray-100 py-2 z-50 min-w-[180px]">
              {branches.map(b => (
                <button key={b.id}
                  onClick={() => { setSelectedBranchId(b.id); localStorage.setItem("timeclock_branch_id", b.id); setShowBranchPicker(false); resetClock(); }}
                  className={`w-full text-left px-4 py-3 text-sm font-medium transition ${b.id === selectedBranchId ? "text-violet-700 bg-violet-50" : "text-gray-700 hover:bg-gray-50"}`}>
                  {b.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* CLOCK TAB */}
      {activeTab === "clock" && (
        <div className="flex-1 flex flex-col items-center justify-center px-5 gap-8">

          {/* IDLE — clock + PIN */}
          {clockStep === "idle" && (
            <>
              <LiveClock />
              {!selectedBranchId ? (
                <p className="text-amber-400 text-sm text-center">⚠ Select a branch above to continue</p>
              ) : (
                <div className="w-full max-w-xs flex flex-col items-center gap-2">
                  <p className="text-white/30 text-sm">Enter your PIN</p>
                  <PinDots length={pin.length} />
                  <NumPad onPress={handlePinKey} disabled={false} />
                </div>
              )}
            </>
          )}

          {/* VERIFYING */}
          {clockStep === "verifying" && (
            <div className="flex flex-col items-center gap-4 text-center">
              <Loader2 className="w-16 h-16 text-violet-400 animate-spin" />
              <p className="text-white/50 text-lg">Checking PIN…</p>
            </div>
          )}

          {/* ERROR */}
          {clockStep === "error" && (
            <div className="flex flex-col items-center gap-5 text-center">
              <XCircle className="w-20 h-20 text-red-500" />
              <div>
                <p className="text-white text-2xl font-bold">Access Denied</p>
                <p className="text-white/40 mt-2">{errorMsg}</p>
              </div>
            </div>
          )}

          {/* DASHBOARD */}
          {clockStep === "dashboard" && staffData && (
            <div className="w-full max-w-sm flex flex-col gap-5">
              {/* Staff card */}
              <div className="bg-white/5 border border-white/10 rounded-3xl p-5 flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-violet-600 flex items-center justify-center text-2xl font-black text-white shrink-0 shadow-lg">
                  {staffData.name?.[0]?.toUpperCase()}
                </div>
                <div>
                  <p className="text-white text-xl font-bold">{staffData.name}</p>
                  <p className="text-white/40 text-sm capitalize">{staffData.role_type}</p>
                  {activeTimecard && (
                    <p className="text-white/30 text-xs mt-1">
                      Since {format(parseISO(activeTimecard.clock_in), "h:mm a")} ·{" "}
                      <ShiftTimer clockIn={activeTimecard.clock_in} />
                    </p>
                  )}
                </div>
              </div>

              {/* Status banner */}
              {activeTimecard ? (
                <div className={`rounded-2xl px-4 py-3 text-center ${
                  activeTimecard.status === "on_break" ? "bg-amber-500/15 border border-amber-500/30" : "bg-green-500/15 border border-green-500/30"
                }`}>
                  <p className={`font-semibold ${activeTimecard.status === "on_break" ? "text-amber-400" : "text-green-400"}`}>
                    {activeTimecard.status === "on_break" ? "🟡 Currently on break" : "🟢 Currently working"}
                  </p>
                  {activeTimecard.break_minutes > 0 && (
                    <p className="text-white/30 text-xs mt-0.5">Total breaks: {formatDuration(activeTimecard.break_minutes)}</p>
                  )}
                </div>
              ) : (
                <div className="bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-center">
                  <p className="text-white/40">⚪ Not clocked in</p>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex flex-col gap-3">
                {!activeTimecard && (
                  <>
                    {!gpsCoords ? (
                      <StaffGPSButton
                        staffName={staffData.name}
                        branchName={selectedBranch?.name}
                        onClockInSuccess={(coords) => {
                          setGpsCoords(coords);
                          performAction("clock_in");
                        }}
                        onError={(msg) => {
                          setErrorMsg(msg);
                          setClockStep("error");
                          scheduleReset(3000);
                        }}
                      />
                    ) : (
                      <ActionButton onClick={() => performAction("clock_in")} color="green"
                        icon={LogIn} label="Confirm Clock In" sublabel="GPS verified" />
                    )}
                  </>
                )}
                {activeTimecard?.status === "active" && (
                  <>
                    <ActionButton onClick={() => performAction("start_break")} color="amber"
                      icon={Coffee} label="Start Break" />
                    <ActionButton onClick={() => performAction("clock_out")} color="red"
                      icon={LogOut} label="Clock Out"
                      sublabel={`Shift: ${formatDuration(differenceInMinutes(new Date(), parseISO(activeTimecard.clock_in)))}`} />
                  </>
                )}
                {activeTimecard?.status === "on_break" && (
                  <>
                    <ActionButton onClick={() => performAction("end_break")} color="green"
                      icon={Coffee} label="End Break — Back to Work" />
                    <ActionButton onClick={() => performAction("clock_out")} color="red"
                      icon={LogOut} label="Clock Out" />
                  </>
                )}
              </div>

              <button onClick={resetClock}
                className="text-white/20 hover:text-white/50 text-sm text-center transition mt-2">
                ← Not you? Switch staff
              </button>
            </div>
          )}

          {/* LOADING */}
          {clockStep === "loading" && (
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-16 h-16 text-violet-400 animate-spin" />
              <p className="text-white/50 text-lg">Processing…</p>
            </div>
          )}

          {/* CONFIRMED */}
          {clockStep === "confirmed" && (
            <div className="flex flex-col items-center gap-6 text-center">
              <CheckCircle2 className="w-28 h-28 text-green-400" />
              <div>
                <p className="text-4xl font-black text-white mb-3">
                  {confirmedAction === "clock_in" && "Clocked In!"}
                  {confirmedAction === "clock_out" && "Clocked Out!"}
                  {confirmedAction === "start_break" && "Enjoy your break!"}
                  {confirmedAction === "end_break" && "Welcome back!"}
                </p>
                <p className="text-white/40">{staffData?.name} · {format(new Date(), "h:mm a")}</p>
              </div>
              <p className="text-white/20 text-sm">Screen resets automatically…</p>
            </div>
          )}
        </div>
      )}

      {/* TIMESHEETS TAB */}
      {activeTab === "timesheets" && <TimesheetsTab branchId={selectedBranchId} />}

      {/* TEAM TAB */}
      {activeTab === "team" && <TeamTab branchId={selectedBranchId} />}

      {/* Bottom Nav */}
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}