import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { ShoppingBag, Delete } from "lucide-react";

export default function WeeklyOrdersLogin() {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // If already logged in, redirect
    const session = localStorage.getItem("weekly_orders_session");
    if (session) {
      navigate("/WeeklyOrders");
    }
  }, []);

  const handlePinPress = (digit) => {
    if (pin.length < 4) setPin(p => p + digit);
  };

  const handleDelete = () => setPin(p => p.slice(0, -1));

  const handleLogin = async () => {
    if (pin.length < 4) return;
    setLoading(true);
    setError("");

    const res = await base44.functions.invoke("verifyWeeklyOrderPin", { pin });
    const data = res.data;

    if (!data?.success) {
      setError(data?.error || "Invalid PIN. Please try again.");
      setPin("");
      setLoading(false);
      return;
    }

    const staff = data.staff;
    localStorage.setItem("weekly_orders_session", JSON.stringify({
      staff_id: staff.id,
      name: staff.name,
      role: staff.role_type || "staff",
      branch_id: staff.branch_id,
      branch_name: staff.branch_name || "",
      logged_in_at: new Date().toISOString(),
    }));

    navigate("/WeeklyOrders");
    setLoading(false);
  };

  useEffect(() => {
    if (pin.length === 4) handleLogin();
  }, [pin]);

  const digits = ["1","2","3","4","5","6","7","8","9","","0","del"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 to-white flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm">

        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-3"
            style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <ShoppingBag className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Weekly Orders</h1>
          <p className="text-sm text-gray-400 mt-1">Enter your staff PIN to continue</p>
        </div>

        {/* PIN dots */}
        <div className="flex justify-center gap-4 mb-8">
          {[0,1,2,3].map(i => (
            <div key={i} className={`w-4 h-4 rounded-full border-2 transition-all ${
              pin.length > i
                ? "bg-violet-600 border-violet-600 scale-110"
                : "bg-white border-gray-300"
            }`} />
          ))}
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 text-sm text-center rounded-xl px-4 py-2 mb-4">
            {error}
          </div>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-3">
          {digits.map((d, i) => {
            if (d === "") return <div key={i} />;
            if (d === "del") return (
              <button key={i} onClick={handleDelete}
                className="h-16 rounded-2xl bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200 active:scale-95 transition">
                <Delete className="w-5 h-5" />
              </button>
            );
            return (
              <button key={i} onClick={() => handlePinPress(d)}
                className="h-16 rounded-2xl bg-white border border-gray-200 shadow-sm text-xl font-bold text-gray-800 hover:bg-violet-50 hover:border-violet-300 active:scale-95 transition">
                {d}
              </button>
            );
          })}
        </div>

        {loading && (
          <div className="flex justify-center mt-6">
            <div className="w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
          </div>
        )}

        <p className="text-center text-xs text-gray-300 mt-8">Hide Cafe LLC · Weekly Orders System</p>
      </div>
    </div>
  );
}