import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Star, Phone, Mail, Pencil, Trash2, Plus, X, Printer, Home, ClipboardList, LayoutGrid } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const POINTS_RATE = 10; // points per $1
const REDEEM_RATE = 1000; // points = $10

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", notes: "" });

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.Customer.list("-points");
    setCustomers(data);
    setLoading(false);
  };

  const openNew = () => { setEditing(null); setForm({ name: "", phone: "", email: "", notes: "" }); setShowForm(true); };
  const openEdit = (c) => { setEditing(c); setForm({ name: c.name, phone: c.phone || "", email: c.email || "", notes: c.notes || "" }); setShowForm(true); };

  const save = async () => {
    if (!form.name.trim()) return;
    if (editing) {
      await base44.entities.Customer.update(editing.id, form);
    } else {
      await base44.entities.Customer.create({ ...form, points: 0, total_spent: 0, visit_count: 0 });
    }
    setShowForm(false);
    load();
  };

  const del = async (id) => {
    await base44.entities.Customer.delete(id);
    load();
  };

  const printBill = async (customer) => {
    const orders = await base44.entities.Order.filter({ customer_name: customer.name, status: "paid" }, "-created_date", 50);
    const win = window.open("", "_blank");
    const t = tier(customer.points || 0);
    const rows = orders.map(o => `
      <tr>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;">${new Date(o.created_date).toLocaleDateString()}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;">${o.order_number || o.id.slice(-6)}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;">${o.type}</td>
        <td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right;">AED ${(o.total || 0).toFixed(2)}</td>
      </tr>`).join("");
    const totalSpent = orders.reduce((s, o) => s + (o.total || 0), 0);
    win.document.write(`
      <!DOCTYPE html><html><head><title>Customer Bill - ${customer.name}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 30px; color: #333; max-width: 700px; margin: 0 auto; }
        h1 { font-size: 22px; margin: 0 0 4px; }
        .subtitle { color: #888; font-size: 13px; margin-bottom: 24px; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; background: #f9f9f9; border-radius: 10px; padding: 16px; margin-bottom: 24px; }
        .info-item label { display: block; font-size: 11px; color: #999; text-transform: uppercase; letter-spacing: 0.5px; }
        .info-item span { font-size: 15px; font-weight: 600; color: #333; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        thead tr { background: #f5f5fa; }
        thead th { padding: 8px; text-align: left; font-size: 11px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; }
        thead th:last-child { text-align: right; }
        .total-row td { padding: 10px 8px; font-weight: 700; font-size: 14px; border-top: 2px solid #333; }
        .total-row td:last-child { text-align: right; }
        .tier { display:inline-block; padding:2px 10px; border-radius:20px; font-size:12px; font-weight:600; background:#fef9c3; color:#b45309; }
        @media print { button { display: none; } }
      </style></head><body>
      <h1>Customer Statement</h1>
      <p class="subtitle">Printed on ${new Date().toLocaleString()}</p>
      <div class="info-grid">
        <div class="info-item"><label>Customer</label><span>${customer.name}</span></div>
        <div class="info-item"><label>Tier</label><span class="tier">${t.label}</span></div>
        ${customer.phone ? `<div class="info-item"><label>Phone</label><span>${customer.phone}</span></div>` : ""}
        ${customer.email ? `<div class="info-item"><label>Email</label><span>${customer.email}</span></div>` : ""}
        <div class="info-item"><label>Loyalty Points</label><span>⭐ ${(customer.points || 0).toLocaleString()}</span></div>
        <div class="info-item"><label>Total Visits</label><span>${customer.visit_count || 0}</span></div>
      </div>
      <table>
        <thead><tr>
          <th>Date</th><th>Order #</th><th>Type</th><th style="text-align:right">Amount</th>
        </tr></thead>
        <tbody>${rows || `<tr><td colspan="4" style="padding:20px;text-align:center;color:#aaa;">No paid orders found</td></tr>`}</tbody>
        ${orders.length > 0 ? `<tfoot><tr class="total-row"><td colspan="3">Total (${orders.length} orders)</td><td>AED ${totalSpent.toFixed(2)}</td></tr></tfoot>` : ""}
      </table>
      <br/><button onclick="window.print()" style="padding:10px 24px;background:#5B2CC0;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;">🖨 Print</button>
      </body></html>`);
    win.document.close();
  };

  const tier = (pts) => {
    if (pts >= 5000) return { label: "Gold", color: "text-yellow-400 bg-yellow-400/10 border-yellow-400/30" };
    if (pts >= 1000) return { label: "Silver", color: "text-slate-300 bg-slate-300/10 border-slate-300/30" };
    return { label: "Bronze", color: "text-orange-400 bg-orange-400/10 border-orange-400/30" };
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] flex flex-col p-6">
      <div className="max-w-5xl mx-auto flex-1">
         {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Loyalty Customers</h1>
            <p className="text-gray-400 text-sm mt-0.5">{POINTS_RATE} pts per $1 · {REDEEM_RATE} pts = $10 off</p>
          </div>
          <Button onClick={openNew} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold gap-2">
            <Plus className="w-4 h-4" /> Add Customer
          </Button>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { label: "Total Members", value: customers.length },
            { label: "Total Points Issued", value: customers.reduce((s, c) => s + (c.points || 0), 0).toLocaleString() },
            { label: "Total Spent", value: `$${customers.reduce((s, c) => s + (c.total_spent || 0), 0).toFixed(2)}` },
          ].map(s => (
            <div key={s.label} className="bg-white border border-gray-100 shadow-sm rounded-2xl p-4">
              <p className="text-gray-400 text-xs">{s.label}</p>
              <p className="text-xl font-bold text-gray-900 mt-1">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
          {loading ? (
            <div className="py-20 text-center text-gray-300">Loading...</div>
          ) : customers.length === 0 ? (
            <div className="py-20 text-center text-gray-300">No customers yet</div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-gray-400 text-xs">
                  <th className="text-left px-5 py-3 font-medium">Customer</th>
                  <th className="text-left px-4 py-3 font-medium">Contact</th>
                  <th className="text-left px-4 py-3 font-medium">Tier</th>
                  <th className="text-right px-4 py-3 font-medium">Points</th>
                  <th className="text-right px-4 py-3 font-medium">Visits</th>
                  <th className="text-right px-4 py-3 font-medium">Total Spent</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {customers.map(c => {
                  const t = tier(c.points || 0);
                  return (
                    <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50 transition">
                      <td className="px-5 py-3">
                        <p className="font-medium text-gray-800">{c.name}</p>
                        {c.notes && <p className="text-xs text-gray-400 truncate max-w-[160px]">{c.notes}</p>}
                      </td>
                      <td className="px-4 py-3 text-gray-500">
                        {c.phone && <p className="flex items-center gap-1"><Phone className="w-3 h-3" />{c.phone}</p>}
                        {c.email && <p className="flex items-center gap-1"><Mail className="w-3 h-3" />{c.email}</p>}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${t.color}`}>{t.label}</span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className="flex items-center justify-end gap-1 text-amber-500 font-semibold">
                          <Star className="w-3.5 h-3.5" />{(c.points || 0).toLocaleString()}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right text-gray-500">{c.visit_count || 0}</td>
                      <td className="px-4 py-3 text-right text-gray-700">${(c.total_spent || 0).toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => printBill(c)} className="p-1.5 rounded-lg hover:bg-violet-50 text-gray-300 hover:text-violet-500 transition" title="Print Bill"><Printer className="w-3.5 h-3.5" /></button>
                          <button onClick={() => openEdit(c)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-300 hover:text-gray-600 transition"><Pencil className="w-3.5 h-3.5" /></button>
                          <button onClick={() => del(c.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-300 hover:text-red-500 transition"><Trash2 className="w-3.5 h-3.5" /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Bottom nav */}
      <div className="bg-white border-t border-gray-200 flex items-center mt-6">
        <Link to={createPageUrl("Dashboard")} className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold">
          <Home className="w-5 h-5" /> HOME
        </Link>
        <Link to={createPageUrl("Orders")} className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold">
          <ClipboardList className="w-5 h-5" /> ORDERS
        </Link>
        <Link to={createPageUrl("Tables")} className="flex-1 flex flex-col items-center justify-center gap-1 py-3 text-gray-500 hover:text-violet-600 transition text-xs font-semibold">
          <LayoutGrid className="w-5 h-5" /> TABLES
        </Link>
      </div>

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-gray-900">{editing ? "Edit Customer" : "New Customer"}</h3>
              <button onClick={() => setShowForm(false)} className="text-gray-300 hover:text-gray-600"><X className="w-4 h-4" /></button>
            </div>
            {[["name", "Name *"], ["phone", "Phone"], ["email", "Email"], ["notes", "Notes"]].map(([k, label]) => (
              <div key={k}>
                <label className="text-xs text-gray-400 mb-1 block">{label}</label>
                <Input value={form[k]} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))}
                  className="border-gray-200 rounded-xl" />
              </div>
            ))}
            <div className="flex gap-2 pt-1">
              <Button onClick={save} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-semibold">Save</Button>
              <Button variant="ghost" onClick={() => setShowForm(false)} className="flex-1 text-gray-400 border border-gray-200">Cancel</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}