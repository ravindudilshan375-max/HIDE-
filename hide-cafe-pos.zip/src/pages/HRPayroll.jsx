import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Download, Calendar, RefreshCw, DollarSign, Clock, Users, AlertTriangle } from "lucide-react";
import { format, startOfMonth, endOfMonth, parseISO } from "date-fns";

export default function HRPayroll() {
  const [staff, setStaff] = useState([]);
  const [timecards, setTimecards] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [filterDept, setFilterDept] = useState("");

  useEffect(() => { loadData(); }, [startDate, endDate]);

  const loadData = async () => {
    setLoading(true);
    const [staffData, cardData, deptData] = await Promise.all([
      base44.entities.StaffMember.list(),
      base44.entities.StaffTimecard.filter({ status: "completed" }),
      base44.entities.Department.list(),
    ]);
    setStaff(staffData);
    setTimecards(cardData.filter(tc => {
      if (!tc.clock_in) return false;
      const date = tc.clock_in.split("T")[0];
      return date >= startDate && date <= endDate;
    }));
    setDepartments(deptData);
    setLoading(false);
  };

  const payrollData = staff
    .filter(s => s.is_active !== false && s.employment_status !== "terminated")
    .filter(s => filterDept ? s.department_id === filterDept : true)
    .map(s => {
      const cards = timecards.filter(tc => tc.staff_email === s.email || tc.staff_name === s.name);
      const totalMinutes = cards.reduce((sum, tc) => sum + (tc.duration_minutes || 0), 0);
      const totalHours = totalMinutes / 60;
      const OT_THRESHOLD = 160;
      const regularHours = Math.min(totalHours, OT_THRESHOLD);
      const overtimeHours = Math.max(0, totalHours - OT_THRESHOLD);
      const hourlyRate = s.hourly_rate || 0;
      const regularPay = regularHours * hourlyRate;
      const overtimePay = overtimeHours * hourlyRate * 1.5;
      const totalPay = regularPay + overtimePay;
      const dept = departments.find(d => d.id === s.department_id);
      return {
        ...s,
        dept_resolved: dept?.name || s.department_name || "—",
        dept_color: dept?.color || "#7C3AED",
        totalHours: Math.round(totalHours * 10) / 10,
        regularHours: Math.round(regularHours * 10) / 10,
        overtimeHours: Math.round(overtimeHours * 10) / 10,
        regularPay: Math.round(regularPay * 100) / 100,
        overtimePay: Math.round(overtimePay * 100) / 100,
        totalPay: Math.round(totalPay * 100) / 100,
        shiftCount: cards.length,
      };
    });

  const totalLaborCost = payrollData.reduce((s, p) => s + p.totalPay, 0);
  const totalHours = payrollData.reduce((s, p) => s + p.totalHours, 0);
  const totalOTHours = payrollData.reduce((s, p) => s + p.overtimeHours, 0);
  const staffWithShifts = payrollData.filter(p => p.shiftCount > 0).length;

  const exportCSV = () => {
    const headers = ["Name", "Department", "Employment Type", "Shifts", "Regular Hours", "OT Hours", "Total Hours", "Rate/hr", "Regular Pay", "OT Pay (1.5x)", "Total Pay (AED)"];
    const rows = payrollData.map(p => [
      p.name, p.dept_resolved, (p.employment_type || "full_time").replace("_", "-"),
      p.shiftCount, p.regularHours, p.overtimeHours, p.totalHours,
      p.hourly_rate || 0, p.regularPay, p.overtimePay, p.totalPay
    ]);
    const csv = [headers, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `payroll_${startDate}_to_${endDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 pt-6 pb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Payroll</h1>
            <p className="text-violet-200 text-sm mt-0.5">Calculate wages from completed timecards</p>
          </div>
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 bg-white text-violet-700 font-semibold rounded-xl px-4 py-2.5 text-sm hover:bg-violet-50 shadow-sm transition"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      <div className="px-6 -mt-4 pb-8 space-y-5">
        {/* Filters */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex flex-wrap gap-3 items-center">
          <Calendar className="w-4 h-4 text-gray-400 shrink-0" />
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400" />
          <span className="text-gray-400 text-sm">to</span>
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400" />
          {departments.length > 0 && (
            <select value={filterDept} onChange={e => setFilterDept(e.target.value)}
              className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
              <option value="">All Departments</option>
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          )}
          <button onClick={loadData} className="text-gray-400 hover:text-violet-600 transition">
            <RefreshCw className="w-4 h-4" />
          </button>
          <p className="ml-auto text-xs text-gray-400 hidden md:block">Overtime rate: 1.5× after 160 hrs/month</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { icon: DollarSign, label: "Total Labor Cost", value: `AED ${totalLaborCost.toFixed(2)}`, color: "bg-violet-50 text-violet-600", sub: "for this period" },
            { icon: Clock, label: "Total Hours", value: `${totalHours.toFixed(1)}h`, color: "bg-blue-50 text-blue-600", sub: `${totalOTHours.toFixed(1)}h overtime` },
            { icon: Users, label: "Staff w/ Shifts", value: `${staffWithShifts}`, color: "bg-green-50 text-green-600", sub: `of ${payrollData.length} active` },
            { icon: AlertTriangle, label: "Avg Cost/Person", value: staffWithShifts > 0 ? `AED ${(totalLaborCost / staffWithShifts).toFixed(0)}` : "—", color: "bg-amber-50 text-amber-600", sub: "per staff" },
          ].map(k => {
            const Icon = k.icon;
            return (
              <div key={k.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${k.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-semibold text-gray-500 uppercase">{k.label}</p>
                </div>
                <p className="text-2xl font-bold text-gray-900">{k.value}</p>
                <p className="text-xs text-gray-400 mt-0.5">{k.sub}</p>
              </div>
            );
          })}
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="font-bold text-gray-900">Payroll Summary</h2>
            <p className="text-xs text-gray-400 mt-0.5">
              {format(parseISO(startDate), "MMM d")} – {format(parseISO(endDate), "MMM d, yyyy")}
            </p>
          </div>
          {loading ? (
            <div className="py-10 text-center text-gray-400 text-sm">Loading payroll data…</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-left py-3 px-5 text-xs font-semibold text-gray-500 uppercase">Employee</th>
                    <th className="text-left py-3 px-5 text-xs font-semibold text-gray-500 uppercase hidden md:table-cell">Department</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-gray-500 uppercase">Shifts</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-gray-500 uppercase">Reg. Hrs</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-gray-500 uppercase">OT Hrs</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-gray-500 uppercase hidden md:table-cell">Rate</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-gray-500 uppercase hidden md:table-cell">Base Pay</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-gray-500 uppercase hidden md:table-cell">OT Pay</th>
                    <th className="text-right py-3 px-5 text-xs font-semibold text-violet-700 uppercase">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {payrollData.length === 0 ? (
                    <tr><td colSpan={9} className="text-center py-10 text-gray-400 text-sm">No payroll data for this period</td></tr>
                  ) : (
                    payrollData.map(p => (
                      <tr key={p.id} className="hover:bg-gray-50 transition">
                        <td className="py-3 px-5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0" style={{ backgroundColor: p.dept_color }}>
                              {p.name?.[0]?.toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{p.name}</p>
                              <p className="text-xs text-gray-400 capitalize">{(p.employment_type || "full_time").replace("_", "-")}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-5 text-gray-500 hidden md:table-cell">{p.dept_resolved}</td>
                        <td className="py-3 px-5 text-right text-gray-600">{p.shiftCount}</td>
                        <td className="py-3 px-5 text-right text-gray-600">{p.regularHours}h</td>
                        <td className="py-3 px-5 text-right">
                          {p.overtimeHours > 0
                            ? <span className="text-amber-600 font-semibold">{p.overtimeHours}h</span>
                            : <span className="text-gray-300">—</span>}
                        </td>
                        <td className="py-3 px-5 text-right text-gray-500 hidden md:table-cell">
                          {p.hourly_rate ? `AED ${p.hourly_rate}` : <span className="text-gray-300">—</span>}
                        </td>
                        <td className="py-3 px-5 text-right text-gray-700 hidden md:table-cell">AED {p.regularPay.toFixed(2)}</td>
                        <td className="py-3 px-5 text-right hidden md:table-cell">
                          {p.overtimePay > 0
                            ? <span className="text-amber-600">AED {p.overtimePay.toFixed(2)}</span>
                            : <span className="text-gray-300">—</span>}
                        </td>
                        <td className="py-3 px-5 text-right font-bold text-gray-900">AED {p.totalPay.toFixed(2)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
                {payrollData.length > 0 && (
                  <tfoot>
                    <tr className="bg-violet-50 border-t-2 border-violet-200">
                      <td className="py-3 px-5 font-bold text-gray-800">TOTAL</td>
                      <td className="hidden md:table-cell" />
                      <td className="py-3 px-5 text-right font-bold text-gray-700">{payrollData.reduce((s, p) => s + p.shiftCount, 0)}</td>
                      <td className="py-3 px-5 text-right font-bold text-gray-700">{payrollData.reduce((s, p) => s + p.regularHours, 0).toFixed(1)}h</td>
                      <td className="py-3 px-5 text-right font-bold text-amber-600">
                        {totalOTHours > 0 ? `${totalOTHours.toFixed(1)}h` : "—"}
                      </td>
                      <td className="hidden md:table-cell" />
                      <td className="py-3 px-5 text-right font-bold text-gray-700 hidden md:table-cell">
                        AED {payrollData.reduce((s, p) => s + p.regularPay, 0).toFixed(2)}
                      </td>
                      <td className="py-3 px-5 text-right font-bold text-amber-600 hidden md:table-cell">
                        {totalOTHours > 0 ? `AED ${payrollData.reduce((s, p) => s + p.overtimePay, 0).toFixed(2)}` : "—"}
                      </td>
                      <td className="py-3 px-5 text-right font-bold text-violet-700 text-base">AED {totalLaborCost.toFixed(2)}</td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          )}
        </div>

        {/* No hourly rate warning */}
        {payrollData.some(p => !p.hourly_rate && p.shiftCount > 0) && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl px-5 py-4 flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
            <p className="text-sm text-amber-800">
              <strong>Note:</strong> Some staff members have no hourly rate set. Go to <strong>Staff Members</strong> to add their rates so payroll calculates correctly.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}