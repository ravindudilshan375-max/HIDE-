import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const REASONS = ["spoilage", "overproduction", "damage", "expiry", "contamination", "other"];

const REASON_COLORS = {
  spoilage: "bg-red-100 text-red-700",
  overproduction: "bg-orange-100 text-orange-700",
  damage: "bg-amber-100 text-amber-700",
  expiry: "bg-rose-100 text-rose-700",
  contamination: "bg-purple-100 text-purple-700",
  other: "bg-gray-100 text-gray-600",
};

export default function WasteLog() {
  const [logs, setLogs] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ menu_item_id: "", quantity: "", qty_ctn: "", qty_pcs: "", reason: "spoilage", notes: "", staff_name: "" });
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.WasteLog.list("-created_date", 100),
      base44.entities.InventoryItem.list(),
      base44.entities.Branch.list(),
      base44.auth.me().catch(() => null),
    ]).then(([logData, items, branchData, currentUser]) => {
      setLogs(logData);
      setInventoryItems(items);
      setBranches(branchData);
      setUser(currentUser);
      setLoading(false);
    });
  }, []);

  const selectedItem = inventoryItems.find(i => i.id === form.menu_item_id);
  const unitCost = selectedItem?.unit_cost || 0;
  const factor = selectedItem?.factor || 1;
  const costPerUnit = unitCost / factor; // cost per ingredient unit
  
  const calculateQuantity = () => {
    if (selectedItem?.storage_unit) {
      const ctn = parseFloat(form.qty_ctn) || 0;
      const pcs = parseFloat(form.qty_pcs) || 0;
      return ctn * factor + pcs;
    }
    return parseFloat(form.quantity) || 0;
  };
  
  const totalQuantity = calculateQuantity();
  const totalCost = totalQuantity * costPerUnit;

  const save = async () => {
    if (!form.menu_item_id || totalQuantity <= 0) {
      toast.error("Select an item and enter a valid quantity");
      return;
    }
    setSaving(true);
    const item = inventoryItems.find(i => i.id === form.menu_item_id);
    const branch = branches[0];

    const itemFactor = item?.factor || 1;
    const itemCostPerUnit = (item?.unit_cost || 0) / itemFactor;
    await base44.entities.WasteLog.create({
      date: new Date().toISOString().split("T")[0],
      menu_item_id: form.menu_item_id,
      item_name: item?.name || "",
      quantity: totalQuantity,
      unit_cost: itemCostPerUnit,
      total_cost: totalQuantity * itemCostPerUnit,
      reason: form.reason,
      notes: form.notes,
      recorded_by: form.staff_name || user?.full_name || "",
      branch_id: branch?.id || "",
    });

    // Deduct stock if tracked
    if (item && item.current_quantity !== null && item.current_quantity !== undefined) {
      const newQty = Math.max(0, (item.current_quantity || 0) - totalQuantity);
      await base44.entities.InventoryItem.update(item.id, { current_quantity: newQty });
    }

    toast.success("Waste recorded and stock updated");
    setForm({ menu_item_id: "", quantity: "", qty_ctn: "", qty_pcs: "", reason: "spoilage", notes: "", staff_name: "" });
    setShowForm(false);
    setSaving(false);

    // Reload
    base44.entities.WasteLog.list("-created_date", 100).then(setLogs);
    base44.entities.InventoryItem.list().then(setInventoryItems);
  };

  const deleteLog = async (id) => {
    await base44.entities.WasteLog.delete(id);
    toast.success("Log deleted");
    setLogs(prev => prev.filter(l => l.id !== id));
  };

  const todayTotal = logs
    .filter(l => l.date === new Date().toISOString().split("T")[0])
    .reduce((s, l) => s + (l.total_cost || 0), 0);

  const filteredItems = inventoryItems.filter(i => i.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">

        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
              <Link to={createPageUrl("InventoryHub")} className="hover:text-violet-600 transition">Inventory</Link>
              <span>/</span><span className="text-gray-600">Waste & Loss Log</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Waste & Loss Log</h1>
            <p className="text-xs text-gray-400 mt-0.5">Today's waste cost: <span className="font-semibold text-rose-600">AED {todayTotal.toFixed(2)}</span></p>
          </div>
          <Button onClick={() => setShowForm(v => !v)} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
            <Plus className="w-4 h-4" /> Record Waste
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4 shadow-sm">
            <h2 className="font-bold text-gray-900">New Waste Entry</h2>

            {!form.menu_item_id ? (
              <div className="space-y-3">
                <Input placeholder="Search raw ingredient..." value={search} onChange={e => setSearch(e.target.value)} className="border-gray-200 rounded-xl" />
                <div className="max-h-52 overflow-y-auto space-y-1.5">
                   {filteredItems.map(item => (
                     <button key={item.id} onClick={() => setForm(f => ({ ...f, menu_item_id: item.id }))}
                       className="w-full text-left px-4 py-3 bg-gray-50 hover:bg-violet-50 border border-gray-200 hover:border-violet-300 rounded-xl transition">
                       <p className="text-sm font-medium text-gray-900">{item.name}</p>
                       <p className="text-xs text-gray-400">Stock: {item.current_quantity ?? "—"} {item.unit} · Cost: ${item.unit_cost?.toFixed(2) || "0.00"}/unit</p>
                     </button>
                   ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-900">{selectedItem?.name}</p>
                    <p className="text-xs text-gray-400">Cost/unit: AED {costPerUnit.toFixed(5)} · Stock: {selectedItem?.current_quantity ?? "—"} {selectedItem?.unit}</p>
                  </div>
                  <button onClick={() => setForm(f => ({ ...f, menu_item_id: "" }))} className="text-xs text-violet-600 hover:underline">Change</button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {selectedItem?.storage_unit ? (
                    <>
                      <div>
                        <label className="text-xs text-gray-600 mb-1 block font-medium">Quantity ({selectedItem.storage_unit})</label>
                        <Input type="number" min="0" placeholder="0" value={form.qty_ctn} onChange={e => setForm(f => ({ ...f, qty_ctn: e.target.value }))} className="border-gray-200 rounded-xl" />
                      </div>
                      <div>
                        <label className="text-xs text-gray-600 mb-1 block font-medium">Quantity ({selectedItem.unit})</label>
                        <Input type="number" min="0" placeholder="0" value={form.qty_pcs} onChange={e => setForm(f => ({ ...f, qty_pcs: e.target.value }))} className="border-gray-200 rounded-xl" />
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <label className="text-xs text-gray-600 mb-1 block font-medium">Quantity Wasted ({selectedItem?.unit})</label>
                        <Input type="number" min="0" placeholder="0" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} className="border-gray-200 rounded-xl" />
                      </div>
                      <div>
                        <label className="text-xs text-gray-600 mb-1 block font-medium">Reason</label>
                        <select value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                          className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                          {REASONS.map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                      </div>
                    </>
                  )}
                </div>
                {selectedItem?.storage_unit && (
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block font-medium">Reason</label>
                    <select value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                      className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400">
                      {REASONS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                )}

                {/* Staff name */}
                <div>
                  <label className="text-xs text-gray-600 mb-1 block font-medium">Staff</label>
                  <Input
                    placeholder={user?.full_name || "Staff name"}
                    value={form.staff_name}
                    onChange={e => setForm(f => ({ ...f, staff_name: e.target.value }))}
                    className="border-gray-200 rounded-xl"
                  />
                </div>

                {totalCost > 0 && (
                  <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <p className="text-sm text-rose-700 font-medium">Estimated waste cost: <strong>AED {totalCost.toFixed(2)}</strong></p>
                  </div>
                )}

                <textarea placeholder="Notes (optional)" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400" rows="2" />

                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setShowForm(false)} className="flex-1 border-gray-200 rounded-xl">Cancel</Button>
                  <Button onClick={save} disabled={saving} className="flex-[2] bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
                    {saving ? "Saving..." : "Record Waste"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Log list */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100 grid grid-cols-12 text-xs text-gray-400 uppercase font-semibold tracking-wide bg-gray-50">
            <span className="col-span-3">Item</span>
            <span className="col-span-2">Date</span>
            <span className="col-span-1 text-right">Qty</span>
            <span className="col-span-2 text-right">Cost</span>
            <span className="col-span-2">Reason</span>
            <span className="col-span-1">By</span>
            <span className="col-span-1"></span>
          </div>
          {loading ? (
            <p className="text-center py-10 text-gray-300 text-sm">Loading…</p>
          ) : logs.length === 0 ? (
            <p className="text-center py-10 text-gray-300 text-sm">No waste logs yet</p>
          ) : (
            logs.map(log => (
              <div key={log.id} className="grid grid-cols-12 px-5 py-3.5 border-b border-gray-50 hover:bg-gray-50 transition items-center text-sm">
                <div className="col-span-3 font-medium text-gray-800">{log.item_name}</div>
                <div className="col-span-2 text-gray-400 text-xs">{log.date}</div>
                <div className="col-span-1 text-right text-gray-700 font-semibold">{log.quantity}</div>
                <div className="col-span-2 text-right text-rose-600 font-semibold">AED {(log.total_cost || 0).toFixed(2)}</div>
                <div className="col-span-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${REASON_COLORS[log.reason] || REASON_COLORS.other}`}>{log.reason}</span>
                </div>
                <div className="col-span-1 text-gray-400 text-xs truncate">{log.recorded_by || "—"}</div>
                <div className="col-span-1 flex justify-end">
                  <button onClick={() => deleteLog(log.id)} className="text-gray-300 hover:text-red-500 transition p-1">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}