import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Package, AlertTriangle, TrendingDown, DollarSign,
  ArrowRight, RefreshCw, Trash2, Boxes, ClipboardList
} from "lucide-react";

const LOW_DEFAULT = 10;

function StatCard({ icon: Icon, label, value, color = "text-violet-600", bg = "bg-violet-50", border = "border-gray-100" }) {
  return (
    <div className={`bg-white border ${border} rounded-2xl p-5 shadow-sm`}>
      <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-sm text-gray-400 mt-1">{label}</p>
    </div>
  );
}

const QUICK_LINKS = [
  { title: "Inventory Items", description: "Raw ingredients & supplies (separate from menu)", page: "InventoryItems", icon: Boxes },
  { title: "Menu Stock Levels", description: "Track stock deducted via POS sales", page: "Inventory", icon: Package },
  { title: "Waste & Loss Log", description: "Record spoilage, overproduction, damage", page: "WasteLog", icon: Trash2 },
  { title: "Quantity Adjustment", description: "Manual corrections with reason tracking", page: "QuantityAdjustment", icon: ClipboardList },
  { title: "Cost Management", description: "Update supplier & unit costs", page: "CostAdjustment", icon: DollarSign },
  { title: "Purchase Orders", description: "Track supplier orders & receipts", page: "OrderTransaction", icon: Package },
  { title: "Inventory Count", description: "Full stock audits with variance tracking", page: "InventoryCount", icon: ClipboardList },
];

export default function InventoryHub() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [wasteStats, setWasteStats] = useState({ count: 0, cost: 0 });

  useEffect(() => {
    Promise.all([
      base44.entities.MenuItem.list(),
      base44.entities.Branch.list(),
      base44.entities.WasteLog.list("-created_date", 100),
    ]).then(([menuItems, branchList, wasteLogs]) => {
      setItems(menuItems);
      setBranches(branchList);
      const today = new Date().toISOString().split("T")[0];
      const todayWaste = wasteLogs.filter(w => w.date === today);
      setWasteStats({
        count: todayWaste.reduce((s, w) => s + (w.quantity || 0), 0),
        cost: todayWaste.reduce((s, w) => s + (w.total_cost || 0), 0),
      });
      setLoading(false);
    });
  }, []);

  const filtered = useMemo(() =>
    selectedBranch === "all" ? items : items.filter(i => i.branch_id === selectedBranch),
    [items, selectedBranch]
  );

  const stats = useMemo(() => {
    const tracked = filtered.filter(i => i.stock_quantity !== null && i.stock_quantity !== undefined);
    const threshold = (item) => item.low_stock_threshold ?? LOW_DEFAULT;
    return {
      total: filtered.length,
      tracked: tracked.length,
      low: tracked.filter(i => i.stock_quantity > 0 && i.stock_quantity <= threshold(i)).length,
      out: tracked.filter(i => i.stock_quantity === 0).length,
    };
  }, [filtered]);

  const alerts = useMemo(() =>
    filtered.filter(i => {
      const s = i.stock_quantity;
      if (s === null || s === undefined) return false;
      const t = i.low_stock_threshold ?? LOW_DEFAULT;
      return s <= t;
    }).sort((a, b) => (a.stock_quantity || 0) - (b.stock_quantity || 0)),
    [filtered]
  );

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-8">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Inventory Management</h1>
            <p className="text-gray-400 text-sm mt-0.5">Stock control across all branches</p>
          </div>
          <div className="flex items-center gap-3">
            {branches.length > 1 && (
              <select
                value={selectedBranch}
                onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400"
              >
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <button
              onClick={() => { setLoading(true); base44.entities.MenuItem.list().then(setItems).finally(() => setLoading(false)); }}
              className="flex items-center gap-2 text-sm font-medium bg-white border border-gray-200 hover:border-violet-400 text-gray-600 px-3 py-2 rounded-xl transition"
            >
              <RefreshCw className="w-4 h-4" /> Refresh
            </button>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={Package} label="Total Items" value={stats.total} />
          <StatCard icon={AlertTriangle} label="Low Stock" value={stats.low} color="text-amber-600" bg="bg-amber-50" border="border-amber-100" />
          <StatCard icon={TrendingDown} label="Out of Stock" value={stats.out} color="text-red-600" bg="bg-red-50" border="border-red-100" />
          <StatCard icon={DollarSign} label={`Waste Today ($)`} value={`$${wasteStats.cost.toFixed(2)}`} color="text-rose-600" bg="bg-rose-50" border="border-rose-100" />
        </div>

        {/* Low-Stock Alerts */}
        {alerts.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <h2 className="font-bold text-amber-800">{alerts.length} Low-Stock Alert{alerts.length > 1 ? "s" : ""}</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {alerts.slice(0, 9).map(item => {
                const threshold = item.low_stock_threshold ?? LOW_DEFAULT;
                const isOut = item.stock_quantity === 0;
                return (
                  <div key={item.id} className={`bg-white rounded-xl border p-3 flex items-center justify-between ${isOut ? "border-red-200" : "border-amber-200"}`}>
                    <div>
                      <p className="text-sm font-semibold text-gray-800">{item.name}</p>
                      <p className="text-xs text-gray-400">{item.category} · threshold: {threshold}</p>
                    </div>
                    <span className={`text-sm font-bold px-2.5 py-1 rounded-full ${isOut ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                      {isOut ? "OUT" : item.stock_quantity}
                    </span>
                  </div>
                );
              })}
            </div>
            {alerts.length > 9 && (
              <p className="text-xs text-amber-600 mt-3 text-center">+ {alerts.length - 9} more items</p>
            )}
          </div>
        )}

        {/* Quick Access */}
        <div>
          <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Modules</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {QUICK_LINKS.map(({ title, description, page, icon: Icon }) => (
              <Link
                key={page}
                to={createPageUrl(page)}
                className="bg-white border border-gray-100 rounded-2xl p-5 hover:shadow-md hover:border-violet-200 transition-all group"
              >
                <div className="w-10 h-10 bg-violet-50 rounded-xl flex items-center justify-center mb-3">
                  <Icon className="w-5 h-5 text-violet-600" />
                </div>
                <h3 className="font-bold text-gray-900 group-hover:text-violet-600 transition text-sm">{title}</h3>
                <p className="text-xs text-gray-400 mt-1">{description}</p>
                <div className="flex items-center gap-1 mt-3 text-violet-600 opacity-0 group-hover:opacity-100 transition text-xs font-medium">
                  Open <ArrowRight className="w-3 h-3" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}