import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";

export default function InventoryCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ name: "", description: "", color: "#8B5CF6" });

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    const data = await base44.entities.InventoryCategory.list();
    setCategories(data);
    setLoading(false);
  };

  const saveCategory = async () => {
    if (!formData.name.trim()) {
      toast.error("Enter category name");
      return;
    }

    if (editingId) {
      await base44.entities.InventoryCategory.update(editingId, formData);
      toast.success("Category updated");
    } else {
      await base44.entities.InventoryCategory.create(formData);
      toast.success("Category created");
    }

    setShowForm(false);
    setEditingId(null);
    setFormData({ name: "", description: "", color: "#8B5CF6" });
    loadCategories();
  };

  const deleteCategory = async (id) => {
    await base44.entities.InventoryCategory.delete(id);
    toast.success("Category deleted");
    loadCategories();
  };

  const startEdit = (cat) => {
    setFormData(cat);
    setEditingId(cat.id);
    setShowForm(true);
  };

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Inventory Categories</h1>
            <p className="text-gray-400 text-sm mt-0.5">Organize items into categories</p>
          </div>
          <Button
            onClick={() => {
              setShowForm(true);
              setEditingId(null);
              setFormData({ name: "", description: "", color: "#8B5CF6" });
            }}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Category
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">{editingId ? "Edit" : "New"} Category</h2>

            <Input
              placeholder="Category name"
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="border-gray-200 rounded-xl"
            />

            <textarea
              placeholder="Description (optional)"
              value={formData.description || ""}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-violet-400"
              rows="2"
            />

            <div>
              <label className="text-xs text-gray-600 mb-2 block font-medium">Color</label>
              <div className="flex gap-2">
                <input
                  type="color"
                  value={formData.color || "#8B5CF6"}
                  onChange={e => setFormData({ ...formData, color: e.target.value })}
                  className="w-12 h-10 rounded-lg border border-gray-200 cursor-pointer"
                />
                <Input
                  value={formData.color || "#8B5CF6"}
                  onChange={e => setFormData({ ...formData, color: e.target.value })}
                  className="border-gray-200 rounded-xl flex-1"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setShowForm(false);
                  setEditingId(null);
                }}
                variant="outline"
                className="border-gray-200 rounded-xl flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={saveCategory}
                className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
              >
                Save Category
              </Button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {categories.length === 0 ? (
            <p className="col-span-full text-center text-gray-400 py-12">No categories yet</p>
          ) : (
            categories.map(cat => (
              <div key={cat.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-4 h-4 rounded-full border-2 border-gray-200"
                      style={{ backgroundColor: cat.color || "#8B5CF6" }}
                    />
                    <p className="font-medium text-gray-900">{cat.name}</p>
                  </div>
                  {cat.description && (
                    <p className="text-xs text-gray-400 mt-1">{cat.description}</p>
                  )}
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => startEdit(cat)}
                    className="text-gray-300 hover:text-violet-600 transition p-2"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteCategory(cat.id)}
                    className="text-gray-300 hover:text-red-500 transition p-2"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}