import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AlertTriangle, TrendingDown, Clock, AlertCircle, Download, RefreshCw, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const PRIORITY_CONFIG = {
  urgent: { color: "bg-red-100 text-red-700", bg: "bg-red-50", border: "border-red-200", icon: AlertTriangle },
  high: { color: "bg-orange-100 text-orange-700", bg: "bg-orange-50", border: "border-orange-200", icon: Clock },
  normal: { color: "bg-amber-100 text-amber-700", bg: "bg-amber-50", border: "border-amber-200", icon: AlertCircle },
  overstock: { color: "bg-blue-100 text-blue-700", bg: "bg-blue-50", border: "border-blue-200", icon: TrendingDown },
};

export default function ReplenishmentReport() {
  const [suggestions, setSuggestions] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [days, setDays] = useState(7);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const branchData = await base44.entities.Branch.list();
    setBranches(branchData);
    await refreshSuggestions(branchData);
    setLoading(false);
  };

  const refreshSuggestions = async (branchData) => {
    const branchId = selectedBranch === "all" ? null : selectedBranch;
    const response = await base44.functions.invoke('getReplenishmentSuggestions', {
      days,
      branchId,
    });
    setSuggestions(response.data.suggestions || []);
  };

  const handleRefresh = async () => {
    await refreshSuggestions(branches);
    toast.success("Replenishment suggestions updated");
  };

  const handleExport = () => {
    const csv = [
      ["Item Name", "SKU", "Supplier", "Current Qty", "Par Level", "Daily Usage", "Days Until Stockout", "Suggested Order Qty", "Estimated Cost", "Priority"].join(","),
      ...suggestions.map(s => [
        `"${s.name}"`,
        s.sku || "",
        s.supplier || "",
        s.currentQty,
        s.parLevel,
        s.dailyUsage,
        s.daysUntilStockout,
        s.suggestedQuantity,
        `AED ${s.totalCost.toFixed(2)}`,
        s.priority,
      ].join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `replenishment-${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  const filtered = suggestions.filter(s => {
    if (filter === "urgent") return s.priority === "urgent";
    if (filter === "high") return s.priority === "high";
    if (filter === "overstock") return s.priority === "overstock";
    return true;
  });

  const stats = {
    urgent: suggestions.filter(s => s.priority === "urgent").length,
    high: suggestions.filter(s => s.priority === "high").length,
    totalCost: filtered.reduce((sum, s) => sum + s.totalCost, 0),
  };

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm text-gray-400 mb-1">
              <Link to={createPageUrl("InventoryHub")} className="hover:text-violet-600 transition">Inventory</Link>
              <span>/</span><span className="text-gray-700 font-medium">Replenishment Report</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Replenishment Report</h1>
            <p className="text-gray-400 text-sm mt-0.5">Intelligent restocking suggestions based on sales velocity</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button onClick={handleRefresh} variant="outline" className="border-gray-200 rounded-xl gap-2">
              <RefreshCw className="w-4 h-4" /> Refresh
            </Button>
            <Button onClick={handleExport} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
              <Download className="w-4 h-4" /> Export CSV
            </Button>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap gap-3 items-center bg-white rounded-2xl p-4 border border-gray-100">
          <div>
            <label className="text-xs text-gray-400 block mb-1">Analysis Period</label>
            <select
              value={days}
              onChange={e => setDays(parseInt(e.target.value))}
              className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
            >
              <option value={7}>Last 7 days</option>
              <option value={14}>Last 14 days</option>
              <option value={30}>Last 30 days</option>
            </select>
          </div>
          {branches.length > 1 && (
            <div>
              <label className="text-xs text-gray-400 block mb-1">Branch</label>
              <select
                value={selectedBranch}
                onChange={e => setSelectedBranch(e.target.value)}
                className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
              >
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
            <p className="text-xs text-red-700 font-semibold flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4" /> URGENT
            </p>
            <p className="text-2xl font-bold text-red-600">{stats.urgent}</p>
            <p className="text-xs text-red-600 mt-1">Items critical</p>
          </div>
          <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4">
            <p className="text-xs text-orange-700 font-semibold flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4" /> HIGH
            </p>
            <p className="text-2xl font-bold text-orange-600">{stats.high}</p>
            <p className="text-xs text-orange-600 mt-1">Items to order soon</p>
          </div>
          <div className="bg-violet-50 border border-violet-200 rounded-2xl p-4">
            <p className="text-xs text-violet-700 font-semibold mb-1">Est. Total Cost</p>
            <p className="text-2xl font-bold text-violet-600">AED {stats.totalCost.toFixed(2)}</p>
            <p className="text-xs text-violet-600 mt-1">{filtered.length} items</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          {["all", "urgent", "high", "overstock"].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition capitalize ${
                filter === f ? "bg-violet-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:border-violet-300"
              }`}
            >
              {f === "all" ? `All (${suggestions.length})` : f === "overstock" ? `Overstock (${suggestions.filter(s => s.priority === "overstock").length})` : `${f.charAt(0).toUpperCase() + f.slice(1)} (${suggestions.filter(s => s.priority === f).length})`}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {filtered.length === 0 ? (
            <p className="text-center py-12 text-gray-300 text-sm">No replenishment suggestions at this time</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-gray-100 bg-gray-50">
                  <tr>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Item</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Current</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Par Level</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Daily Usage</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Days Until Stockout</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Suggested Order</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Est. Cost</th>
                    <th className="text-left text-xs font-semibold text-gray-600 px-5 py-3">Priority</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((item, idx) => {
                    const config = PRIORITY_CONFIG[item.priority] || PRIORITY_CONFIG.normal;
                    const Icon = config.icon;
                    return (
                      <tr key={item.id} className={`border-b border-gray-50 hover:bg-gray-50/50 transition ${idx === filtered.length - 1 ? "border-b-0" : ""}`}>
                        <td className="px-5 py-4">
                          <div>
                            <p className="font-semibold text-gray-900 text-sm">{item.name}</p>
                            {item.sku && <p className="text-xs text-gray-400 mt-0.5">{item.sku}</p>}
                            {item.supplier && <p className="text-xs text-gray-300">{item.supplier}</p>}
                          </div>
                        </td>
                        <td className="px-5 py-4">
                          <p className="font-semibold text-gray-700 text-sm">{item.currentQty}</p>
                          <p className="text-xs text-gray-400">{item.unit}</p>
                        </td>
                        <td className="px-5 py-4">
                          <p className="font-semibold text-gray-700 text-sm">{item.parLevel}</p>
                          <p className="text-xs text-gray-400">{item.unit}</p>
                        </td>
                        <td className="px-5 py-4">
                          <p className="font-semibold text-gray-700 text-sm">{item.dailyUsage}</p>
                          <p className="text-xs text-gray-400">{item.unit}/day</p>
                        </td>
                        <td className="px-5 py-4">
                          <div className={item.daysUntilStockout <= 3 ? "text-red-600 font-bold" : item.daysUntilStockout <= 7 ? "text-orange-600 font-semibold" : "text-gray-700"}>
                            {item.daysUntilStockout > 999 ? "∞" : `${item.daysUntilStockout} days`}
                          </div>
                        </td>
                        <td className="px-5 py-4">
                          <p className="font-bold text-violet-600 text-sm">{item.suggestedQuantity}</p>
                          <p className="text-xs text-gray-400">{item.unit}</p>
                        </td>
                        <td className="px-5 py-4">
                          <p className="font-semibold text-gray-700">AED {item.totalCost.toFixed(2)}</p>
                        </td>
                        <td className="px-5 py-4">
                          <div className={`flex items-center gap-1.5 w-fit px-2.5 py-1 rounded-full text-xs font-semibold ${config.color}`}>
                            <Icon className="w-3.5 h-3.5" />
                            {item.priority.charAt(0).toUpperCase() + item.priority.slice(1)}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}