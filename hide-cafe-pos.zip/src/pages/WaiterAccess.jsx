import React, { useState } from "react";
import { createPageUrl } from "@/utils";
import { Copy, Check, QrCode, Smartphone, Link2, Users, Printer, Info } from "lucide-react";
import { toast } from "sonner";

export default function WaiterAccess() {
  const [copied, setCopied] = useState(false);

  const waiterUrl = `${window.location.origin}${createPageUrl("WaiterPOS")}`;

  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(waiterUrl)}&size=280x280&margin=12`;

  const copyLink = () => {
    navigator.clipboard.writeText(waiterUrl);
    setCopied(true);
    toast.success("Link copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-2xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Waiter POS Access</h1>
          <p className="text-sm text-gray-500 mt-1">Share this link or QR code with your waitstaff to access the Waiter POS on any device.</p>
        </div>

        {/* QR Code Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 flex flex-col items-center text-center">
          <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center mb-4">
            <QrCode className="w-6 h-6 text-violet-600" />
          </div>
          <h2 className="font-bold text-gray-900 text-lg mb-1">Scan to Open Waiter POS</h2>
          <p className="text-sm text-gray-400 mb-6">Staff scan this code to open the login screen on their phone or tablet</p>

          <div className="bg-gray-50 rounded-2xl p-4 mb-6 border border-gray-100">
            <img
              src={qrSrc}
              alt="Waiter POS QR Code"
              className="w-56 h-56 rounded-xl"
            />
          </div>

          {/* URL display */}
          <div className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3">
            <Link2 className="w-4 h-4 text-gray-400 shrink-0" />
            <span className="flex-1 text-sm text-gray-600 truncate text-left">{waiterUrl}</span>
            <button
              onClick={copyLink}
              className="shrink-0 flex items-center gap-1.5 bg-violet-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-violet-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>

        {/* Instructions Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">How Staff Access the System</h3>
              <p className="text-xs text-gray-400">Works on any phone, tablet, or POS terminal</p>
            </div>
          </div>

          <ol className="space-y-3">
            {[
              { step: "1", text: "Share the QR code or link with your staff" },
              { step: "2", text: "Staff open the link on their device" },
              { step: "3", text: "Enter Staff ID and 4-digit PIN" },
              { step: "4", text: "Start taking orders immediately" },
            ].map(({ step, text }) => (
              <li key={step} className="flex items-center gap-3">
                <span className="w-7 h-7 rounded-full bg-violet-100 text-violet-700 text-xs font-bold flex items-center justify-center shrink-0">{step}</span>
                <span className="text-sm text-gray-600">{text}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* SUNMI Printing Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
              <Printer className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">SUNMI Printer Setup</h3>
              <p className="text-xs text-gray-400">For SUNMI V3 / T2 / T3 devices</p>
            </div>
          </div>
          <ol className="space-y-3 mb-4">
            {[
              { step: "1", text: "Open the Waiter POS using SUNMI Browser (not Chrome)" },
              { step: "2", text: "The app auto-detects the SUNMI JS bridge" },
              { step: "3", text: "A Print button appears on the order screen when ready" },
              { step: "4", text: "Tap Print to send directly to the internal thermal printer" },
            ].map(({ step, text }) => (
              <li key={step} className="flex items-center gap-3">
                <span className="w-7 h-7 rounded-full bg-green-100 text-green-700 text-xs font-bold flex items-center justify-center shrink-0">{step}</span>
                <span className="text-sm text-gray-600">{text}</span>
              </li>
            ))}
          </ol>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <p className="text-xs text-blue-700">If not using a SUNMI device, printing works via LAN (configure printer IP in <strong>Settings → Devices</strong>).</p>
          </div>
        </div>

        {/* Staff Management hint */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
          <Users className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-800">Staff not set up yet?</p>
            <p className="text-xs text-amber-700 mt-0.5">Go to <strong>Staff Members</strong> to create accounts with role <strong>Waiter</strong> and assign a PIN. Only active waiter accounts can log in.</p>
          </div>
        </div>

      </div>
    </div>
  );
}