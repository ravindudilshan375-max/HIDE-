import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Search, Shield, RefreshCw, ChevronDown, ChevronUp, Filter } from "lucide-react";
import { format } from "date-fns";

const ACTION_COLORS = {
  create: "bg-green-100 text-green-700",
  update: "bg-blue-100 text-blue-700",
  delete: "bg-red-100 text-red-700",
  invite: "bg-purple-100 text-purple-700",
  assign_role: "bg-indigo-100 text-indigo-700",
  set_password: "bg-orange-100 text-orange-700",
  void: "bg-red-100 text-red-700",
  refund: "bg-yellow-100 text-yellow-700",
  approve: "bg-green-100 text-green-700",
  reject: "bg-red-100 text-red-700",
  export: "bg-gray-100 text-gray-700",
  login: "bg-teal-100 text-teal-700",
  other: "bg-gray-100 text-gray-600",
};

const SEVERITY_COLORS = {
  info: "bg-gray-100 text-gray-600",
  warning: "bg-yellow-100 text-yellow-700",
  critical: "bg-red-100 text-red-700",
};

export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterAction, setFilterAction] = useState("all");
  const [filterEntity, setFilterEntity] = useState("all");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [expandedId, setExpandedId] = useState(null);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 50;

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    const data = await base44.entities.AuditLog.list("-created_date", 500);
    setLogs(data);
    setLoading(false);
  };

  const entityTypes = [...new Set(logs.map(l => l.entity_type).filter(Boolean))].sort();
  const actions = [...new Set(logs.map(l => l.action).filter(Boolean))].sort();

  const filtered = logs.filter(log => {
    const matchSearch =
      !search ||
      log.description?.toLowerCase().includes(search.toLowerCase()) ||
      log.actor_email?.toLowerCase().includes(search.toLowerCase()) ||
      log.actor_name?.toLowerCase().includes(search.toLowerCase()) ||
      log.entity_name?.toLowerCase().includes(search.toLowerCase()) ||
      log.entity_type?.toLowerCase().includes(search.toLowerCase());
    const matchAction = filterAction === "all" || log.action === filterAction;
    const matchEntity = filterEntity === "all" || log.entity_type === filterEntity;
    const matchSeverity = filterSeverity === "all" || log.severity === filterSeverity;
    return matchSearch && matchAction && matchEntity && matchSeverity;
  });

  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-violet-100 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-violet-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Audit Log</h1>
              <p className="text-sm text-gray-500">Track all significant actions performed by users</p>
            </div>
          </div>
          <button
            onClick={loadLogs}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-600 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6 bg-white border border-gray-200 rounded-xl p-4">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              placeholder="Search by user, action, record..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-violet-400"
            />
          </div>

          <select
            value={filterAction}
            onChange={e => { setFilterAction(e.target.value); setPage(1); }}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50 focus:outline-none focus:border-violet-400"
          >
            <option value="all">All Actions</option>
            {actions.map(a => (
              <option key={a} value={a}>{a.replace(/_/g, " ")}</option>
            ))}
          </select>

          <select
            value={filterEntity}
            onChange={e => { setFilterEntity(e.target.value); setPage(1); }}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50 focus:outline-none focus:border-violet-400"
          >
            <option value="all">All Record Types</option>
            {entityTypes.map(e => (
              <option key={e} value={e}>{e}</option>
            ))}
          </select>

          <select
            value={filterSeverity}
            onChange={e => { setFilterSeverity(e.target.value); setPage(1); }}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50 focus:outline-none focus:border-violet-400"
          >
            <option value="all">All Severities</option>
            <option value="info">Info</option>
            <option value="warning">Warning</option>
            <option value="critical">Critical</option>
          </select>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <p className="text-xs text-gray-500 mb-1">Total Events</p>
            <p className="text-2xl font-bold text-gray-900">{filtered.length}</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <p className="text-xs text-gray-500 mb-1">Warnings</p>
            <p className="text-2xl font-bold text-yellow-600">{filtered.filter(l => l.severity === "warning").length}</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4">
            <p className="text-xs text-gray-500 mb-1">Critical</p>
            <p className="text-2xl font-bold text-red-600">{filtered.filter(l => l.severity === "critical").length}</p>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
          {loading ? (
            <div className="py-16 text-center text-gray-400 text-sm">Loading audit logs...</div>
          ) : paginated.length === 0 ? (
            <div className="py-16 text-center">
              <Shield className="w-10 h-10 text-gray-200 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">No audit events found</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-5 py-3 text-left font-semibold text-gray-600 text-xs uppercase tracking-wide">When</th>
                  <th className="px-5 py-3 text-left font-semibold text-gray-600 text-xs uppercase tracking-wide">User</th>
                  <th className="px-5 py-3 text-left font-semibold text-gray-600 text-xs uppercase tracking-wide">Action</th>
                  <th className="px-5 py-3 text-left font-semibold text-gray-600 text-xs uppercase tracking-wide">Record</th>
                  <th className="px-5 py-3 text-left font-semibold text-gray-600 text-xs uppercase tracking-wide">Description</th>
                  <th className="px-5 py-3 text-left font-semibold text-gray-600 text-xs uppercase tracking-wide">Severity</th>
                  <th className="px-5 py-3 w-10"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {paginated.map(log => (
                  <React.Fragment key={log.id}>
                    <tr
                      className="hover:bg-gray-50 transition cursor-pointer"
                      onClick={() => setExpandedId(expandedId === log.id ? null : log.id)}
                    >
                      <td className="px-5 py-3 text-gray-500 whitespace-nowrap text-xs">
                        {log.created_date
                          ? format(new Date(log.created_date), "MMM d, yyyy HH:mm")
                          : "—"}
                      </td>
                      <td className="px-5 py-3">
                        <p className="font-medium text-gray-900">{log.actor_name || log.actor_email}</p>
                        {log.actor_name && <p className="text-xs text-gray-400">{log.actor_email}</p>}
                      </td>
                      <td className="px-5 py-3">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${ACTION_COLORS[log.action] || ACTION_COLORS.other}`}>
                          {log.action?.replace(/_/g, " ")}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <p className="font-medium text-gray-700">{log.entity_type}</p>
                        {log.entity_name && <p className="text-xs text-gray-400 truncate max-w-32">{log.entity_name}</p>}
                      </td>
                      <td className="px-5 py-3 text-gray-600 max-w-xs truncate">{log.description || "—"}</td>
                      <td className="px-5 py-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold capitalize ${SEVERITY_COLORS[log.severity] || SEVERITY_COLORS.info}`}>
                          {log.severity || "info"}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-gray-400">
                        {expandedId === log.id
                          ? <ChevronUp className="w-4 h-4" />
                          : <ChevronDown className="w-4 h-4" />}
                      </td>
                    </tr>
                    {expandedId === log.id && (
                      <tr className="bg-violet-50">
                        <td colSpan={7} className="px-8 py-4">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <p className="text-xs font-semibold text-gray-500 uppercase mb-1">Record ID</p>
                              <p className="text-gray-800 font-mono text-xs break-all">{log.entity_id || "—"}</p>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-gray-500 uppercase mb-1">Branch</p>
                              <p className="text-gray-800">{log.branch_name || log.branch_id || "—"}</p>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-gray-500 uppercase mb-1">IP Address</p>
                              <p className="text-gray-800">{log.ip_address || "—"}</p>
                            </div>
                            {log.changes && (
                              <div className="col-span-2 md:col-span-4">
                                <p className="text-xs font-semibold text-gray-500 uppercase mb-1">Changes</p>
                                <pre className="bg-white border border-gray-200 rounded-lg p-3 text-xs text-gray-700 overflow-auto max-h-40">
                                  {JSON.stringify(log.changes, null, 2)}
                                </pre>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 text-sm text-gray-600">
            <p>{filtered.length} total events</p>
            <div className="flex gap-2">
              <button
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="px-3 py-1.5 border border-gray-200 rounded-lg bg-white disabled:opacity-40 hover:bg-gray-50 transition"
              >
                Previous
              </button>
              <span className="px-3 py-1.5 bg-white border border-gray-200 rounded-lg">
                {page} / {totalPages}
              </span>
              <button
                disabled={page === totalPages}
                onClick={() => setPage(p => p + 1)}
                className="px-3 py-1.5 border border-gray-200 rounded-lg bg-white disabled:opacity-40 hover:bg-gray-50 transition"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}