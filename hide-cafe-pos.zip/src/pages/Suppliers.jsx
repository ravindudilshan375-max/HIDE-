import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Upload, Download, X, ChevronLeft, Edit2, Eye, Trash2, Phone, Mail, User } from "lucide-react";
import { toast } from "sonner";

const EMPTY = {
  name: "", supplier_code: "", contact_name: "", email: "",
  phone: "", address: "", notes: "", is_active: true
};

const CSV_HEADERS = ["name", "supplier_code", "contact_name", "email", "phone", "address", "notes"];

function exportCSV(suppliers) {
  const rows = [CSV_HEADERS.join(",")];
  suppliers.forEach(s => {
    rows.push(CSV_HEADERS.map(h => `"${(s[h] || "").toString().replace(/"/g, '""')}"`).join(","));
  });
  const blob = new Blob([rows.join("\n")], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "suppliers.csv";
  a.click();
}

function downloadTemplate() {
  const template = CSV_HEADERS.join(",") + "\nSafco,SUP01,Ahmed,safco@email.com,0551234567,Dubai,\nGlobal Food,SUP02,Khalid,global@email.com,0508889999,Abu Dhabi,";
  const blob = new Blob([template], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "suppliers_template.csv";
  a.click();
}

function parseCSV(text) {
  const lines = text.trim().split("\n");
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map(h => h.trim().replace(/^"|"$/g, "").toLowerCase());
  return lines.slice(1).map(line => {
    const vals = [];
    let cur = "", inQ = false;
    for (let i = 0; i < line.length; i++) {
      if (line[i] === '"') { inQ = !inQ; }
      else if (line[i] === "," && !inQ) { vals.push(cur); cur = ""; }
      else cur += line[i];
    }
    vals.push(cur);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = (vals[i] || "").trim(); });
    return obj;
  }).filter(r => r.name);
}

// ── Add / Edit Modal ──────────────────────────────────────────────────────────
function SupplierModal({ supplier, onClose, onSaved, allSuppliers = [] }) {
  const isEdit = !!supplier;

  const autoCode = () => {
    const nums = allSuppliers
      .map(s => parseInt((s.supplier_code || "").replace("SUP-", ""), 10))
      .filter(n => !isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1;
    return "SUP-" + String(next).padStart(4, "0");
  };

  const [form, setForm] = useState(supplier ? { ...supplier } : { ...EMPTY, supplier_code: autoCode() });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!form.name.trim()) { toast.error("Supplier name is required"); return; }
    setSaving(true);
    if (isEdit) {
      await base44.entities.Supplier.update(supplier.id, form);
      toast.success("Supplier updated");
    } else {
      await base44.entities.Supplier.create(form);
      toast.success("Supplier added");
    }
    setSaving(false);
    onSaved();
    onClose();
  };

  const fields = [
    { label: "Supplier Name *", key: "name", full: true },
    { label: "Supplier Code", key: "supplier_code" },
    { label: "Contact Person", key: "contact_name" },
    { label: "Email", key: "email", type: "email" },
    { label: "Phone", key: "phone", type: "tel" },
    { label: "Address", key: "address", full: true },
    { label: "Notes", key: "notes", full: true },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
          <h2 className="text-lg font-bold text-gray-900">{isEdit ? "Edit Supplier" : "Add New Supplier"}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {fields.map(f => (
            <div key={f.key} className={f.full ? "sm:col-span-2" : ""}>
              <label className="block text-xs font-medium text-gray-500 mb-1">{f.label}</label>
              <Input
                type={f.type || "text"}
                value={form[f.key] || ""}
                onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                className="border-gray-200 rounded-xl"
                placeholder={f.label.replace(" *", "")}
              />
            </div>
          ))}
        </div>
        <div className="flex gap-3 px-6 pb-6">
          <Button variant="outline" className="flex-1 border-gray-200 rounded-xl" onClick={onClose}>Cancel</Button>
          <Button disabled={saving} onClick={save} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
            {saving ? "Saving..." : isEdit ? "Save Changes" : "Save Supplier"}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Import Modal ──────────────────────────────────────────────────────────────
function ImportModal({ onClose, onImported }) {
  const [preview, setPreview] = useState(null);
  const [importing, setImporting] = useState(false);
  const fileRef = useRef();

  const handleFile = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setPreview(parseCSV(ev.target.result));
    reader.readAsText(file);
  };

  const doImport = async () => {
    if (!preview?.length) return;
    setImporting(true);
    for (const row of preview) await base44.entities.Supplier.create({ ...row, is_active: true });
    toast.success(`Imported ${preview.length} suppliers`);
    setImporting(false);
    onImported();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-900">Import Suppliers</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div className="bg-violet-50 border border-violet-100 rounded-xl p-4">
            <p className="text-xs font-semibold text-violet-700 mb-1">CSV Format</p>
            <p className="text-xs text-violet-600 font-mono">name, supplier_code, contact_name, email, phone, address, notes</p>
          </div>
          <Button variant="outline" className="w-full border-gray-200 rounded-xl gap-2 text-sm" onClick={downloadTemplate}>
            <Download className="w-4 h-4" /> Download Template
          </Button>
          <div>
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleFile} />
            <Button variant="outline" className="w-full border-dashed border-gray-300 rounded-xl gap-2 text-sm h-12" onClick={() => fileRef.current.click()}>
              <Upload className="w-4 h-4 text-gray-400" />
              {preview ? `${preview.length} rows ready` : "Choose CSV File"}
            </Button>
          </div>
          {preview?.length > 0 && (
            <div className="border border-gray-100 rounded-xl overflow-hidden">
              {preview.slice(0, 5).map((r, i) => (
                <div key={i} className="px-4 py-2 text-sm text-gray-700 border-b border-gray-50 last:border-0 flex justify-between">
                  <span className="font-medium">{r.name}</span>
                  <span className="text-gray-400 text-xs">{r.supplier_code}</span>
                </div>
              ))}
              {preview.length > 5 && <div className="px-4 py-2 text-xs text-gray-400">+{preview.length - 5} more rows</div>}
            </div>
          )}
        </div>
        <div className="flex gap-3 px-6 pb-6">
          <Button variant="outline" className="flex-1 border-gray-200 rounded-xl" onClick={onClose}>Cancel</Button>
          <Button disabled={!preview?.length || importing} onClick={doImport} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
            {importing ? "Importing..." : `Import${preview ? ` ${preview.length}` : ""} Suppliers`}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Supplier Detail ───────────────────────────────────────────────────────────
function SupplierDetail({ supplier, onBack, onEdit }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.PurchaseOrder.filter({ supplier_name: supplier.name })
      .then(data => { setOrders(data); setLoading(false); });
  }, [supplier.id]);

  const totalSpend = orders.reduce((s, o) => s + (o.total_cost || o.total_amount || 0), 0);

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Top bar */}
      <div className="bg-white border-b border-gray-100 px-4 sm:px-6 py-4 flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 font-medium">
          <ChevronLeft className="w-4 h-4" /> Suppliers
        </button>
        <Button onClick={onEdit} size="sm" className="bg-violet-600 hover:bg-violet-700 text-white rounded-xl gap-2">
          <Edit2 className="w-3.5 h-3.5" /> Edit
        </Button>
      </div>

      <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-5">
        {/* Info card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{supplier.name}</h1>
              {supplier.supplier_code && (
                <span className="text-xs font-mono bg-gray-100 text-gray-500 px-2 py-0.5 rounded-lg mt-1 inline-block">{supplier.supplier_code}</span>
              )}
            </div>
            <span className={`text-xs font-semibold px-3 py-1 rounded-full ${supplier.is_active !== false ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-500"}`}>
              {supplier.is_active !== false ? "Active" : "Inactive"}
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-gray-50">
            {supplier.contact_name && (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-violet-50 rounded-lg flex items-center justify-center"><User className="w-4 h-4 text-violet-600" /></div>
                <div><p className="text-xs text-gray-400">Contact</p><p className="text-sm font-medium text-gray-800">{supplier.contact_name}</p></div>
              </div>
            )}
            {supplier.phone && (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center"><Phone className="w-4 h-4 text-blue-600" /></div>
                <div><p className="text-xs text-gray-400">Phone</p><p className="text-sm font-medium text-gray-800">{supplier.phone}</p></div>
              </div>
            )}
            {supplier.email && (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-orange-50 rounded-lg flex items-center justify-center"><Mail className="w-4 h-4 text-orange-500" /></div>
                <div><p className="text-xs text-gray-400">Email</p><p className="text-sm font-medium text-gray-800">{supplier.email}</p></div>
              </div>
            )}
          </div>
          {(supplier.address || supplier.notes) && (
            <div className="mt-4 pt-4 border-t border-gray-50 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {supplier.address && <div><p className="text-xs text-gray-400 mb-0.5">Address</p><p className="text-sm text-gray-700">{supplier.address}</p></div>}
              {supplier.notes && <div><p className="text-xs text-gray-400 mb-0.5">Notes</p><p className="text-sm text-gray-700">{supplier.notes}</p></div>}
            </div>
          )}
        </div>

        {/* Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-center">
            <p className="text-2xl font-bold text-gray-900">{orders.length}</p>
            <p className="text-xs text-gray-400 mt-1">Purchase Orders</p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-center">
            <p className="text-2xl font-bold text-violet-600">AED {totalSpend.toLocaleString()}</p>
            <p className="text-xs text-gray-400 mt-1">Total Purchased</p>
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 text-center col-span-2 sm:col-span-1">
            <p className="text-2xl font-bold text-green-600">{orders.filter(o => o.status === "received").length}</p>
            <p className="text-xs text-gray-400 mt-1">Completed Orders</p>
          </div>
        </div>

        {/* Purchase History */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="text-base font-bold text-gray-900">Purchase History</h2>
          </div>
          {loading ? (
            <div className="py-12 text-center text-sm text-gray-300">Loading...</div>
          ) : orders.length === 0 ? (
            <div className="py-12 text-center text-sm text-gray-400">No purchase orders yet</div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-50">
                  <th className="px-5 py-3 text-left text-xs font-semibold text-gray-400 uppercase">Date</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-gray-400 uppercase">Reference</th>
                  <th className="px-5 py-3 text-left text-xs font-semibold text-gray-400 uppercase">Status</th>
                  <th className="px-5 py-3 text-right text-xs font-semibold text-gray-400 uppercase">Amount</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.id} className="border-b border-gray-50 last:border-0">
                    <td className="px-5 py-3.5 text-sm text-gray-600">{o.delivery_date || o.created_date?.slice(0, 10) || "—"}</td>
                    <td className="px-5 py-3.5 text-sm font-mono font-medium text-gray-800">{o.reference || "—"}</td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                        o.status === "received" ? "bg-green-50 text-green-700" :
                        o.status === "pending" ? "bg-yellow-50 text-yellow-700" :
                        o.status === "closed" ? "bg-gray-100 text-gray-600" :
                        "bg-blue-50 text-blue-700"
                      }`}>{o.status || "draft"}</span>
                    </td>
                    <td className="px-5 py-3.5 text-sm font-semibold text-gray-900 text-right">
                      AED {(o.total_cost || o.total_amount || 0).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function Suppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [modal, setModal] = useState(null); // null | "add" | "edit" | "import"
  const [editTarget, setEditTarget] = useState(null);
  const [page, setPage] = useState(1);
  const PER_PAGE = 10;

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.Supplier.list("name");
    setSuppliers(data);
    setLoading(false);
  };

  const filtered = suppliers.filter(s =>
    !search ||
    s.name?.toLowerCase().includes(search.toLowerCase()) ||
    s.supplier_code?.toLowerCase().includes(search.toLowerCase()) ||
    s.contact_name?.toLowerCase().includes(search.toLowerCase()) ||
    s.phone?.includes(search) ||
    s.email?.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paged = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const handleDelete = async (s, e) => {
    e.stopPropagation();
    if (!confirm(`Delete "${s.name}"?`)) return;
    await base44.entities.Supplier.delete(s.id);
    toast.success("Supplier deleted");
    load();
  };

  if (selectedSupplier) {
    return (
      <SupplierDetail
        supplier={selectedSupplier}
        onBack={() => setSelectedSupplier(null)}
        onEdit={() => { setEditTarget(selectedSupplier); setModal("edit"); }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 px-4 sm:px-6 py-4">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <h1 className="text-2xl font-bold text-gray-900">Suppliers</h1>
          <Button onClick={() => setModal("add")} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
            <Plus className="w-4 h-4" /> Add Supplier
          </Button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-4">
        {/* Search + actions */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search suppliers..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              className="pl-9 border-gray-200 rounded-xl bg-white"
            />
          </div>
          <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm" onClick={() => setModal("import")}>
            <Upload className="w-4 h-4" /> Import CSV
          </Button>
          <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm" onClick={() => exportCSV(filtered)}>
            <Download className="w-4 h-4" /> Export CSV
          </Button>
        </div>

        {/* Desktop Table */}
        <div className="hidden sm:block bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="px-5 py-3.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Supplier Name</th>
                <th className="px-5 py-3.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Code</th>
                <th className="px-5 py-3.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Contact</th>
                <th className="px-5 py-3.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Phone</th>
                <th className="px-5 py-3.5 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">Email</th>
                <th className="px-5 py-3.5 text-right text-xs font-semibold text-gray-400 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="text-center py-16 text-sm text-gray-300">Loading...</td></tr>
              ) : paged.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-16 text-sm text-gray-400">No suppliers found</td></tr>
              ) : paged.map(s => (
                <tr key={s.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition cursor-pointer" onClick={() => setSelectedSupplier(s)}>
                  <td className="px-5 py-3.5">
                    <p className="text-sm font-semibold text-gray-900">{s.name}</p>
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-0.5 rounded">{s.supplier_code || "—"}</span>
                  </td>
                  <td className="px-5 py-3.5 text-sm text-gray-600">{s.contact_name || "—"}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-600">{s.phone || "—"}</td>
                  <td className="px-5 py-3.5 text-sm text-gray-500">{s.email || "—"}</td>
                  <td className="px-5 py-3.5" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedSupplier(s)}
                        className="text-xs text-violet-600 hover:text-violet-800 font-medium flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-violet-50"
                      >
                        <Eye className="w-3.5 h-3.5" /> View
                      </button>
                      <button
                        onClick={() => { setEditTarget(s); setModal("edit"); }}
                        className="text-xs text-gray-500 hover:text-gray-800 font-medium flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-gray-100"
                      >
                        <Edit2 className="w-3.5 h-3.5" /> Edit
                      </button>
                      <button onClick={e => handleDelete(s, e)} className="text-xs text-red-400 hover:text-red-600 px-2 py-1 rounded-lg hover:bg-red-50">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pagination */}
          {filtered.length > PER_PAGE && (
            <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between">
              <p className="text-xs text-gray-400">
                Showing {(page - 1) * PER_PAGE + 1}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length} suppliers
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="rounded-lg border-gray-200 text-xs" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
                <Button variant="outline" size="sm" className="rounded-lg border-gray-200 text-xs" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </div>

        {/* Mobile Cards */}
        <div className="sm:hidden space-y-3">
          {loading ? (
            <div className="text-center py-12 text-sm text-gray-300">Loading...</div>
          ) : paged.length === 0 ? (
            <div className="text-center py-12 text-sm text-gray-400">No suppliers found</div>
          ) : paged.map(s => (
            <div key={s.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4" onClick={() => setSelectedSupplier(s)}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-bold text-gray-900">{s.name}</p>
                  {s.supplier_code && <span className="text-xs font-mono text-gray-400">{s.supplier_code}</span>}
                </div>
                <button onClick={e => { e.stopPropagation(); setEditTarget(s); setModal("edit"); }}
                  className="text-gray-400 hover:text-gray-600 p-1">
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
              {s.contact_name && <p className="text-sm text-gray-600 mt-2 flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-gray-400" />{s.contact_name}</p>}
              {s.phone && <p className="text-sm text-gray-600 flex items-center gap-1.5"><Phone className="w-3.5 h-3.5 text-gray-400" />{s.phone}</p>}
              {s.email && <p className="text-sm text-gray-500 flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-gray-400" />{s.email}</p>}
            </div>
          ))}
          {filtered.length > PER_PAGE && (
            <div className="flex gap-2 justify-center pt-2">
              <Button variant="outline" size="sm" className="rounded-xl border-gray-200" disabled={page === 1} onClick={() => setPage(p => p - 1)}>Previous</Button>
              <Button variant="outline" size="sm" className="rounded-xl border-gray-200" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Next</Button>
            </div>
          )}
        </div>

        {!loading && <p className="text-xs text-gray-400 text-center">Showing {Math.min(paged.length, filtered.length)} of {filtered.length} suppliers</p>}
      </div>

      {/* Modals */}
      {modal === "add" && (
        <SupplierModal onClose={() => setModal(null)} onSaved={load} allSuppliers={suppliers} />
      )}
      {modal === "edit" && editTarget && (
        <SupplierModal
          supplier={editTarget}
          onClose={() => { setModal(null); setEditTarget(null); }}
          onSaved={() => {
            load();
            if (selectedSupplier?.id === editTarget.id) {
              base44.entities.Supplier.filter({ id: editTarget.id }).then(d => d[0] && setSelectedSupplier(d[0]));
            }
          }}
        />
      )}
      {modal === "import" && (
        <ImportModal onClose={() => setModal(null)} onImported={load} />
      )}
    </div>
  );
}