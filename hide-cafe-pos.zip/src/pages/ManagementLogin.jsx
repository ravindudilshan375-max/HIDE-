import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Shield, Delete, CheckCircle2, AlertCircle, ChevronLeft, Loader2 } from "lucide-react";

const MANAGEMENT_ROLES = ["admin", "manager"];

export default function ManagementLogin() {
  const [step, setStep] = useState("id"); // "id" | "pin"
  const [staffId, setStaffId] = useState("");
  const [staff, setStaff] = useState(null);
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Auto-submit when 6 digits entered
  useEffect(() => {
    if (pin.length === 6 && !loading) {
      handlePinSubmit(pin);
    }
  }, [pin]);

  const handleIdSubmit = async () => {
    if (!staffId.trim()) return;
    setLoading(true);
    setError("");
    try {
      const results = await base44.entities.StaffMember.filter({ staff_id: staffId.trim() });
      const found = results?.[0];
      if (!found) {
        setError("Staff ID not found.");
        setLoading(false);
        return;
      }
      if (!MANAGEMENT_ROLES.includes(found.role_type)) {
        setError("This account does not have management access.");
        setLoading(false);
        return;
      }
      if (!found.is_active) {
        setError("This account is inactive.");
        setLoading(false);
        return;
      }
      if (found.locked_until && new Date(found.locked_until) > new Date()) {
        setError("This account is temporarily locked. Please contact your administrator.");
        setLoading(false);
        return;
      }
      setStaff(found);
      setStep("pin");
    } catch (e) {
      setError("Failed to look up staff. Please try again.");
    }
    setLoading(false);
  };

  const handlePinPress = (digit) => {
    if (pin.length < 6 && !loading) {
      setPin(p => p + digit);
    }
  };

  const handleBackspace = () => {
    setPin(p => p.slice(0, -1));
    setError("");
  };

  const handlePinSubmit = async (currentPin) => {
    const pinToVerify = currentPin || pin;
    if (pinToVerify.length < 4) return;
    setLoading(true);
    setError("");
    try {
      const res = await base44.functions.invoke("verifyStaffPin", {
        pin: pinToVerify,
        admin_mode: true,
        staff_id: staff.staff_id,
      });
      if (res.data?.success) {
        localStorage.setItem("pos_staff_session", JSON.stringify({
          id: staff.id,
          name: staff.name,
          staff_id: staff.staff_id,
          role_type: staff.role_type,
          branch_id: staff.branch_id,
          branch_name: staff.branch_name,
          logged_in_at: new Date().toISOString(),
        }));
        window.location.href = createPageUrl("Dashboard");
      } else {
        setError("Incorrect PIN. Please try again.");
        setPin("");
      }
    } catch (e) {
      setError("Verification failed. Please try again.");
      setPin("");
    }
    setLoading(false);
  };

  const KEYS = [
    ["1", "2", "3"],
    ["4", "5", "6"],
    ["7", "8", "9"],
    [null, "0", "back"],
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)" }}>
      <div className="w-full max-w-sm">

        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl"
            style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-white font-bold text-2xl tracking-tight">Management Access</h1>
          <p className="text-white/50 text-sm mt-1">Secure PIN Login</p>
        </div>

        {/* Card */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-white/10">

          {step === "id" ? (
            <>
              <p className="text-white/70 text-sm font-medium text-center mb-4">Enter your Staff ID</p>
              <input
                type="text"
                value={staffId}
                onChange={e => { setStaffId(e.target.value); setError(""); }}
                onKeyDown={e => e.key === "Enter" && handleIdSubmit()}
                placeholder="Staff ID"
                autoFocus
                className="w-full bg-white/10 border border-white/20 text-white placeholder-white/30 rounded-2xl px-4 py-3 text-center text-lg font-semibold focus:outline-none focus:border-violet-400 mb-4"
              />
              {error && (
                <div className="flex items-center gap-2 text-red-300 text-sm bg-red-500/10 rounded-xl px-3 py-2 mb-3">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}
              <button
                onClick={handleIdSubmit}
                disabled={loading || !staffId.trim()}
                className="w-full py-3 rounded-2xl font-bold text-white text-base transition disabled:opacity-40 flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Continue"}
              </button>
            </>
          ) : (
            <>
              {/* Back button + staff info */}
              <div className="flex items-center gap-3 mb-5">
                <button onClick={() => { setStep("id"); setPin(""); setError(""); }}
                  className="text-white/40 hover:text-white/70 transition p-1">
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-2 flex-1">
                  <div className="w-8 h-8 rounded-full bg-violet-500 flex items-center justify-center text-white font-bold text-sm">
                    {staff?.name?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{staff?.name}</p>
                    <p className="text-white/40 text-xs capitalize">{staff?.role_type}</p>
                  </div>
                </div>
              </div>

              {/* PIN dots */}
              <p className="text-white/60 text-xs font-medium text-center mb-3 uppercase tracking-widest">Enter PIN</p>
              <div className="flex justify-center gap-3 mb-5">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className={`w-3 h-3 rounded-full transition-all duration-150 ${
                    i < pin.length
                      ? "bg-violet-400 scale-110"
                      : "bg-white/20"
                  }`} />
                ))}
              </div>

              {error && (
                <div className="flex items-center gap-2 text-red-300 text-xs bg-red-500/10 rounded-xl px-3 py-2 mb-3">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  {error}
                </div>
              )}

              {/* Keypad */}
              <div className="grid gap-2">
                {KEYS.map((row, ri) => (
                  <div key={ri} className="grid grid-cols-3 gap-2">
                    {row.map((key, ki) => {
                      if (key === null) return <div key={ki} />;
                      if (key === "back") return (
                        <button key={ki} onClick={handleBackspace}
                          className="h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/60 hover:bg-white/15 active:scale-95 transition-all">
                          <Delete className="w-5 h-5" />
                        </button>
                      );
                      return (
                        <button key={ki} onClick={() => handlePinPress(key)}
                          disabled={loading}
                          className="h-14 rounded-2xl bg-white/10 border border-white/10 text-white text-xl font-semibold hover:bg-white/20 active:scale-95 transition-all disabled:opacity-40">
                          {key}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>

              {/* Manual submit if < 6 digits */}
              {pin.length >= 4 && pin.length < 6 && (
                <button
                  onClick={() => handlePinSubmit(pin)}
                  disabled={loading}
                  className="w-full mt-3 py-3 rounded-2xl font-bold text-white text-base transition disabled:opacity-40 flex items-center justify-center gap-2"
                  style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><CheckCircle2 className="w-5 h-5" /> Login</>}
                </button>
              )}
              {loading && pin.length === 6 && (
                <div className="flex justify-center mt-4">
                  <Loader2 className="w-6 h-6 text-violet-400 animate-spin" />
                </div>
              )}
            </>
          )}
        </div>

        <p className="text-white/20 text-xs text-center mt-6">DENDAX Restaurant OS · Management Access</p>
      </div>
    </div>
  );
}