import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { format, formatDistanceToNowStrict } from "date-fns";
import {
  UtensilsCrossed, ShoppingBag, Plus, Minus,
  Send, ChefHat, CheckCircle2, ChevronLeft, Search,
  CreditCard, X, Bell, LogOut, LayoutGrid, ClipboardList, Menu as MenuIcon, MoreHorizontal, Printer
} from "lucide-react";
import { printReceipt, isSunmiAvailable } from "@/components/pos/printBridge";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";
import WaiterLogin from "@/components/waiter/WaiterLogin";
import ModifierModal from "@/components/waiter/ModifierModal";
import CheckoutModal from "@/components/waiter/CheckoutModal";
import OrderTypeSelector from "@/components/waiter/OrderTypeSelector";
import OngoingOrdersBar from "@/components/waiter/OngoingOrdersBar";
import OrderTimeline from "@/components/waiter/OrderTimeline";
import OrdersListView from "@/components/waiter/OrdersListView";

const VAT_RATE = 0.05;

// Color scheme matching reference: dark=occupied, green=ready, orange=preparing, purple=bill, red=alert
const TABLE_COLORS = {
  available: { bg: "bg-white", border: "border-gray-200", text: "text-gray-600", label: "Available" },
  occupied:  { bg: "bg-gray-900", border: "border-gray-900", text: "text-white", label: "Open" },
  preparing: { bg: "bg-orange-500", border: "border-orange-500", text: "text-white", label: "Preparing" },
  ready:     { bg: "bg-green-500", border: "border-green-500", text: "text-white", label: "Ready" },
  bill:      { bg: "bg-purple-600", border: "border-purple-600", text: "text-white", label: "Pay" },
  reserved:  { bg: "bg-blue-500", border: "border-blue-500", text: "text-white", label: "Reserved" },
};

function playBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = "sine"; osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.4, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
    osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.15);
  } catch (_) {}
}

function ElapsedTime({ dateStr }) {
  const [label, setLabel] = useState("");
  useEffect(() => {
    const update = () => {
      if (!dateStr) return;
      try {
        const d = new Date(dateStr);
        const mins = Math.floor((Date.now() - d.getTime()) / 60000);
        if (mins < 60) setLabel(`${mins}m`);
        else setLabel(`${Math.floor(mins / 60)}h ${mins % 60}m`);
      } catch {}
    };
    update();
    const t = setInterval(update, 30000);
    return () => clearInterval(t);
  }, [dateStr]);
  return <span className="text-xs opacity-80">{label}</span>;
}

function BottomNav({ activeTab, onTab, onLogout, readyAlert }) {
  const tabs = [
    { key: "tables", label: "Floor Plan", icon: LayoutGrid },
    { key: "orders", label: "Orders", icon: ClipboardList },
    { key: "menu_quick", label: "Menu", icon: MenuIcon },
    { key: "more", label: "More", icon: MoreHorizontal },
  ];
  return (
    <div className="bg-white border-t border-gray-200 flex items-center px-2 py-1" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      {/* Logout */}
      <button
        onClick={onLogout}
        className="flex flex-col items-center gap-0.5 px-3 py-1.5 text-gray-500 hover:text-gray-700 min-w-[56px]"
      >
        <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
          <LogOut className="w-3.5 h-3.5 text-gray-600" />
        </div>
        <span className="text-[10px] font-medium">Log out</span>
      </button>
      <div className="w-px h-8 bg-gray-200 mx-1" />
      {tabs.map(({ key, label, icon: Icon }) => {
        const active = activeTab === key;
        const isOrders = key === "orders" && readyAlert;
        return (
          <button
            key={key}
            onClick={() => onTab(key)}
            className={`flex-1 flex flex-col items-center gap-0.5 py-1.5 transition-colors relative ${
              active ? "text-blue-600" : "text-gray-500 hover:text-gray-700"
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{label}</span>
            {isOrders && (
              <span className="absolute top-1 right-1/4 w-2 h-2 bg-red-500 rounded-full" />
            )}
          </button>
        );
      })}
    </div>
  );
}

export default function WaiterPOS() {
  const [session, setSession] = useState(null);
  const [view, setView] = useState("tables");
  const [tables, setTables] = useState([]);
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [selectedTable, setSelectedTable] = useState(null);
  const [currentOrder, setCurrentOrder] = useState(null);
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [isPickup, setIsPickup] = useState(false);
  const [modifierItem, setModifierItem] = useState(null);
  const [readyAlert, setReadyAlert] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showOrderTypeSelector, setShowOrderTypeSelector] = useState(false);
  const [pickupInfo, setPickupInfo] = useState(null);

  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem("pos_staff_session") || "null");
      if (s) setSession(s);
    } catch {}
  }, []);

  useEffect(() => {
    if (!session) return;
    const branchId = session.branch_id;
    if (branchId) {
      setSelectedBranchId(branchId);
    } else {
      base44.entities.Branch.list().then(bs => {
        if (bs[0]) setSelectedBranchId(bs[0].id);
        else toast.error("No branch found. Please contact admin.");
      });
    }
  }, [session]);

  useEffect(() => {
    if (!selectedBranchId) return;
    loadData();
    const unsub = base44.entities.Order.subscribe(event => {
      if (event.type === "update" || event.type === "create") {
        setOrders(prev => {
          const idx = prev.findIndex(o => o.id === event.id);
          if (idx >= 0) return prev.map(o => o.id === event.id ? event.data : o);
          return [event.data, ...prev];
        });
        setCurrentOrder(prev => prev && prev.id === event.id ? event.data : prev);
        if (event.data?.status === "ready") {
          setReadyAlert(true);
          setTimeout(() => setReadyAlert(false), 4000);
          playBeep();
          toast.success(`Order Ready — Table ${event.data.table_number || "Pickup"}`);
        }
      }
    });
    return () => unsub();
  }, [selectedBranchId]);

  const loadData = async () => {
    const [allTables, o, m] = await Promise.all([
      base44.entities.Table.list(),
      base44.entities.Order.list("-created_date", 300),
      base44.entities.MenuItem.filter({ branch_id: selectedBranchId, is_available: true }),
    ]);
    setTables(allTables);
    setOrders(o.filter(order =>
      ["pending", "preparing", "ready", "served"].includes(order.status)
    ));
    setMenuItems(m);
  };

  const getTableOrder = (table) =>
    orders.find(o => o.table_number === table.number && ["pending","preparing","ready","served"].includes(o.status));

  const getTableStatus = (table) => {
    const order = getTableOrder(table);
    if (!order) return table.status === "reserved" ? "reserved" : "available";
    if (order.status === "ready") return "ready";
    if (order.status === "preparing") return "preparing";
    if (order.status === "served") return "bill";
    return "occupied";
  };

  const openTable = (table) => {
    const order = getTableOrder(table);
    setSelectedTable(table);
    setIsPickup(false);
    setCurrentOrder(order || null);
    setCart([]);
    setView("order");
  };

  const handleOrderTypeSelect = (type, info) => {
    if (type === "dine-in") {
      setShowOrderTypeSelector(false);
      setView("tables");
    } else if (type === "takeaway") {
      setSelectedTable(null);
      setIsPickup(true);
      setCurrentOrder(null);
      setCart([]);
      setPickupInfo(info);
      setShowOrderTypeSelector(false);
      setView("order");
    }
  };

  const addToCart = (item) => {
    if (item.modifiers?.length > 0) {
      setModifierItem(item);
      return;
    }
    addCartItem({
      menu_item_id: item.id,
      name: item.name,
      price: item.base_price || 0,
      quantity: 1,
      subtotal: item.base_price || 0,
      modifiers: [],
      notes: ""
    });
  };

  const addCartItem = (cartItem) => {
    setCart(prev => [...prev, cartItem]);
    playBeep();
  };

  const updateQty = (idx, delta) => {
    setCart(prev => {
      const next = [...prev];
      const newQty = next[idx].quantity + delta;
      if (newQty <= 0) { next.splice(idx, 1); return next; }
      next[idx] = { ...next[idx], quantity: newQty, subtotal: newQty * next[idx].price };
      return next;
    });
  };

  const cartSubtotal = cart.reduce((s, c) => s + c.subtotal, 0);

  const sendOrder = async () => {
    if (cart.length === 0) { toast.error("Cart is empty"); return; }
    if (!selectedBranchId) { toast.error("No branch selected"); return; }
    setLoading(true);
    try {
      if (currentOrder) {
        const merged = [...(currentOrder.items || []), ...cart];
        const newSubtotal = merged.reduce((s, i) => s + (i.subtotal || 0), 0);
        const newTax = newSubtotal * VAT_RATE;
        await base44.entities.Order.update(currentOrder.id, {
          items: merged, subtotal: newSubtotal, tax: newTax,
          total: newSubtotal + newTax, status: "pending",
          branch_id: currentOrder.branch_id || selectedBranchId
        });
        toast.success("Items added to order!");
      } else {
        const subtotal = cartSubtotal;
        const tax = subtotal * VAT_RATE;
        const total = subtotal + tax;
        const orderNumber = `W${Date.now().toString().slice(-6)}`;
        const created = await base44.entities.Order.create({
          order_number: orderNumber,
          type: isPickup ? "takeaway" : "dine-in",
          table_number: selectedTable?.number || "",
          customer_name: pickupInfo?.customer_name || "",
          customer_phone: pickupInfo?.customer_phone || "",
          pickup_time: pickupInfo?.pickup_time || "",
          items: cart, status: "pending", subtotal, tax, total,
          cashier_name: session?.name || "Waiter",
          branch_id: selectedBranchId, platform: "pos"
        });
        if (selectedTable) {
          const tBranchId = selectedTable.branch_id || selectedBranchId;
          await base44.entities.Table.update(selectedTable.id, { status: "occupied", current_order_id: created.id, ...(tBranchId ? { branch_id: tBranchId } : {}) });
          setTables(prev => prev.map(t => t.id === selectedTable.id ? { ...t, status: "occupied" } : t));
        }
        setCurrentOrder(created);
        toast.success("Order sent to kitchen!");
      }
      setCart([]);
      setView("order");
    } catch {
      toast.error("Failed to send order");
    }
    setLoading(false);
  };

  const markServed = async () => {
    if (!currentOrder) return;
    await base44.entities.Order.update(currentOrder.id, { status: "served", branch_id: currentOrder.branch_id || selectedBranchId });
    toast.success("Marked as served");
  };

  const closeTable = async () => {
    if (selectedTable) {
      const branchId = selectedTable.branch_id || selectedBranchId;
      await base44.entities.Table.update(selectedTable.id, { status: "available", current_order_id: "", ...(branchId ? { branch_id: branchId } : {}) });
      setTables(prev => prev.map(t => t.id === selectedTable.id ? { ...t, status: "available" } : t));
    }
    setView("tables");
    setCurrentOrder(null);
    setSelectedTable(null);
    setCart([]);
    setPickupInfo(null);
  };

  const logout = () => {
    localStorage.removeItem("pos_staff_session");
    setSession(null);
  };

  const categories = ["all", ...Array.from(new Set(menuItems.map(m => m.category).filter(Boolean)))];
  const filteredMenu = menuItems.filter(m => {
    const catMatch = selectedCategory === "all" || m.category === selectedCategory;
    const searchMatch = !searchQuery || m.name.toLowerCase().includes(searchQuery.toLowerCase());
    return catMatch && searchMatch;
  });

  if (!session) return <WaiterLogin onLogin={setSession} />;

  // ── ORDERS LIST VIEW ─────────────────────────────────────────
  if (view === "orders") {
    const openOrderFromList = (order) => {
      if (order.type === "takeaway") {
        setSelectedTable(null);
        setIsPickup(true);
        setPickupInfo({ customer_name: order.customer_name, customer_phone: order.customer_phone });
      } else {
        const table = tables.find(t => t.number === order.table_number);
        setSelectedTable(table || null);
        setIsPickup(false);
      }
      setCurrentOrder(order);
      setCart([]);
      setView("order");
    };
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <div className="bg-white border-b border-gray-100 px-5 py-4">
          <h1 className="font-bold text-gray-900 text-xl">Orders</h1>
          <p className="text-xs text-gray-400 mt-0.5">{orders.filter(o => ["pending","preparing","ready","served"].includes(o.status)).length} active</p>
        </div>
        <div className="flex-1 overflow-hidden">
          <OrdersListView orders={orders} onOpenOrder={openOrderFromList} />
        </div>
        <BottomNav activeTab="orders" onTab={setView} onLogout={logout} readyAlert={readyAlert} />
      </div>
    );
  }

  // ── TABLES VIEW ──────────────────────────────────────────────
  if (view === "tables") {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header */}
        <div className="bg-white px-5 pt-5 pb-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Dining Room</h1>
              <p className="text-xs text-gray-400 mt-0.5">{session.name} · {format(new Date(), "EEE d MMM, HH:mm")}</p>
            </div>
            <div className="flex items-center gap-2">
              {readyAlert && (
                <span className="flex items-center gap-1 bg-green-100 text-green-700 text-xs font-semibold px-3 py-1.5 rounded-full">
                  <Bell className="w-3 h-3" /> Ready!
                </span>
              )}
              <button
                onClick={() => setShowOrderTypeSelector(true)}
                className="flex items-center gap-1.5 bg-blue-600 text-white text-sm font-semibold px-4 py-2 rounded-xl hover:bg-blue-700"
              >
                <Plus className="w-4 h-4" /> New Order
              </button>
            </div>
          </div>
          {/* Status Legend */}
          <div className="flex gap-3 mt-3 flex-wrap">
            {Object.entries(TABLE_COLORS).map(([k, v]) => (
              <span key={k} className="flex items-center gap-1.5 text-xs text-gray-500">
                <span className={`w-2.5 h-2.5 rounded-sm ${v.bg} border ${v.border}`} />
                {v.label}
              </span>
            ))}
          </div>
        </div>

        {/* Table Grid */}
        <div className="flex-1 overflow-y-auto p-5">
          {tables.length === 0 ? (
            <div className="text-center py-20 text-gray-300">
              <UtensilsCrossed className="w-10 h-10 mx-auto mb-2" />
              <p>No tables configured</p>
            </div>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-3">
              {tables.map(table => {
                const order = getTableOrder(table);
                const statusKey = getTableStatus(table);
                const cfg = TABLE_COLORS[statusKey];
                return (
                  <button
                    key={table.id}
                    onClick={() => openTable(table)}
                    className={`rounded-xl border-2 px-3 py-3 flex flex-col items-start gap-1 transition-all hover:opacity-90 active:scale-95 ${cfg.bg} ${cfg.border}`}
                  >
                    <span className={`font-bold text-sm ${cfg.text}`}>Table {table.number}</span>
                    {order?.created_date && (
                      <ElapsedTime dateStr={order.created_date} />
                    )}
                    {!order && <span className={`text-[10px] opacity-60 ${cfg.text}`}>{cfg.label}</span>}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <OngoingOrdersBar
          orders={orders}
          onOpenOrder={(order) => {
            if (order.type === "takeaway") {
              setSelectedTable(null);
              setIsPickup(true);
              setPickupInfo({ customer_name: order.customer_name, customer_phone: order.customer_phone });
            } else {
              setSelectedTable(tables.find(t => t.number === order.table_number) || null);
              setIsPickup(false);
            }
            setCurrentOrder(order);
            setCart([]);
            setView("order");
          }}
        />
        <BottomNav activeTab="tables" onTab={(t) => t === "more" ? setShowOrderTypeSelector(true) : setView(t)} onLogout={logout} readyAlert={readyAlert} />
        {showOrderTypeSelector && (
          <OrderTypeSelector onSelect={handleOrderTypeSelect} onClose={() => setShowOrderTypeSelector(false)} />
        )}
      </div>
    );
  }

  // ── ORDER VIEW ───────────────────────────────────────────────
  if (view === "order") {
    const orderItems = currentOrder?.items || [];
    const existingSubtotal = orderItems.reduce((s, i) => s + (i.subtotal || 0), 0);
    const grandSubtotal = existingSubtotal + cartSubtotal;
    const grandVat = grandSubtotal * VAT_RATE;
    const grandTotal = grandSubtotal + grandVat;

    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3">
          <button onClick={() => setView("tables")} className="p-1.5 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="font-bold text-gray-900">
              {isPickup ? `Pickup — ${pickupInfo?.customer_name || "New Order"}` : `Table ${selectedTable?.number}`}
            </h1>
            {currentOrder && (
              <span className="text-xs text-gray-400 capitalize">{currentOrder.status}</span>
            )}
          </div>
          <button
            onClick={() => setView("menu")}
            className="flex items-center gap-1.5 bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold"
          >
            <Plus className="w-4 h-4" /> Add Items
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Bill */}
          <div className="bg-white mx-4 mt-4 rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-50 flex items-center gap-2">
              <span className="font-bold text-gray-900 text-sm">Bill</span>
              {currentOrder && <span className="text-xs text-gray-400">#{currentOrder.order_number}</span>}
            </div>
            {/* Sent items */}
            {orderItems.map((item, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-2.5 border-b border-gray-50 last:border-0">
                <span className="text-sm text-gray-800">
                  {item.quantity > 1 ? `${item.name} x ${item.quantity}` : item.name}
                </span>
                <span className="text-sm font-medium text-gray-700">AED {(item.subtotal || 0).toFixed(2)}</span>
              </div>
            ))}
            {/* New cart items */}
            {cart.map((item, i) => (
              <div key={`c${i}`} className="flex items-center gap-3 px-4 py-2.5 border-b border-gray-50 last:border-0 bg-blue-50/40">
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={() => updateQty(i, -1)} className="w-6 h-6 bg-gray-100 rounded-md flex items-center justify-center text-gray-600 hover:bg-gray-200">
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-5 text-center text-xs font-bold">{item.quantity}</span>
                  <button onClick={() => updateQty(i, 1)} className="w-6 h-6 bg-blue-100 text-blue-600 rounded-md flex items-center justify-center hover:bg-blue-200">
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
                <span className="flex-1 text-sm text-gray-800">{item.name}</span>
                <span className="text-sm font-medium text-gray-700">AED {item.subtotal.toFixed(2)}</span>
                <button onClick={() => setCart(p => p.filter((_, j) => j !== i))} className="text-gray-300 hover:text-red-400">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {orderItems.length === 0 && cart.length === 0 && (
              <div className="text-center py-12 text-gray-300">
                <ChefHat className="w-10 h-10 mx-auto mb-2" />
                <p className="text-sm">No items yet</p>
              </div>
            )}
          </div>

          {/* Order Timeline */}
          {currentOrder && <OrderTimeline status={currentOrder.status} />}

          {/* Totals */}
          {grandSubtotal > 0 && (
            <div className="mx-4 mt-3 mb-4 bg-white rounded-2xl border border-gray-100 shadow-sm px-4 py-3 space-y-2">
              <div className="flex justify-between text-sm text-gray-500">
                <span>GST (5%)</span>
                <span>AED {grandVat.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-gray-900 border-t border-gray-100 pt-2">
                <span>Total</span>
                <span>AED {grandTotal.toFixed(2)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Actions */}
        <div className="bg-white border-t border-gray-100 p-4 space-y-2">
          {cart.length > 0 && (
            <button
              onClick={sendOrder}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-gray-900 text-white py-3.5 rounded-xl font-semibold text-sm hover:bg-gray-800 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              {loading ? "Sending..." : currentOrder ? "Add Items to Order" : "Send to Kitchen"}
            </button>
          )}
          <div className="flex gap-2">
            {currentOrder?.status === "ready" && (
              <button onClick={markServed} className="flex-1 flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-xl font-semibold text-sm hover:bg-green-600">
                <CheckCircle2 className="w-4 h-4" /> Served
              </button>
            )}
            {currentOrder && isSunmiAvailable() && (
              <button
                onClick={async () => {
                  try {
                    await printReceipt({ ...currentOrder, restaurant_name: "DENDAX" }, null);
                    toast.success("Printing...");
                  } catch { toast.error("Print failed"); }
                }}
                className="px-4 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 flex items-center gap-1.5 text-sm font-semibold"
              >
                <Printer className="w-4 h-4" /> Print
              </button>
            )}
            {currentOrder && (
              <button
                onClick={() => setShowCheckout(true)}
                className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700"
              >
                <CreditCard className="w-4 h-4" /> Pay
              </button>
            )}
            {currentOrder && (
              <button onClick={closeTable} className="px-4 py-3 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {showCheckout && currentOrder && (
          <CheckoutModal
            order={currentOrder}
            table={selectedTable}
            waiterName={session?.name || "Waiter"}
            onClose={() => setShowCheckout(false)}
            onPaid={() => {
              setTables(prev => prev.map(t => t.id === selectedTable?.id ? { ...t, status: "available" } : t));
              setCurrentOrder(null);
              setShowCheckout(false);
              setView("tables");
            }}
          />
        )}
      </div>
    );
  }

  // ── MENU VIEW (from order) ────────────────────────────────────────────────
  if (view === "menu") {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header */}
        <div className="bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3">
          <button onClick={() => setView("order")} className="p-1.5 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-gray-900 flex-1">
            {isPickup ? "Pickup" : `Table ${selectedTable?.number}`}
          </h1>
          {cart.length > 0 && (
            <button onClick={() => setView("order")} className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-semibold">
              Cart ({cart.length})
            </button>
          )}
        </div>

        {/* Search */}
        <div className="bg-white px-4 pb-3 pt-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search..."
              className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm bg-gray-50 focus:outline-none focus:border-blue-400"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-2 px-4 pb-3 overflow-x-auto scrollbar-hide">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`shrink-0 px-4 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                selectedCategory === cat
                  ? "bg-gray-900 text-white"
                  : "bg-white text-gray-600 border border-gray-200 hover:bg-gray-50"
              }`}
            >
              {cat === "all" ? "All Items" : cat}
            </button>
          ))}
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {filteredMenu.map(item => {
              const inCart = cart.filter(c => c.menu_item_id === item.id).reduce((s, c) => s + c.quantity, 0);
              return (
                <button
                  key={item.id}
                  onClick={() => addToCart(item)}
                  className={`relative bg-white rounded-xl border text-left p-3 transition-all hover:shadow-sm active:scale-95 ${
                    inCart > 0 ? "border-blue-400 ring-1 ring-blue-400" : "border-gray-200"
                  }`}
                >
                  {inCart > 0 && (
                    <span className="absolute top-2 right-2 w-5 h-5 bg-blue-600 text-white rounded-full text-xs font-bold flex items-center justify-center">
                      {inCart}
                    </span>
                  )}
                  <p className="font-semibold text-gray-900 text-sm leading-tight pr-6">{item.name}</p>
                  {item.category && <p className="text-xs text-gray-400 mt-0.5">{item.category}</p>}
                  <p className="mt-2 text-blue-600 font-bold text-sm">AED {(item.base_price || 0).toFixed(2)}</p>
                </button>
              );
            })}
          </div>
        </div>

        {cart.length > 0 && (
          <div className="bg-white border-t border-gray-100 p-4">
            <button
              onClick={() => setView("order")}
              className="w-full bg-blue-600 text-white py-3.5 rounded-xl font-semibold text-sm hover:bg-blue-700"
            >
              View Order — {cart.length} items · AED {cartSubtotal.toFixed(2)}
            </button>
          </div>
        )}

        {modifierItem && (
          <ModifierModal
            item={modifierItem}
            onAdd={addCartItem}
            onClose={() => setModifierItem(null)}
          />
        )}
      </div>
    );
  }

  return null;
}