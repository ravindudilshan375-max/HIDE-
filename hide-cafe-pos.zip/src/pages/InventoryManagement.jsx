import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight } from "lucide-react";
import { usePermissions, PermissionProvider } from "@/components/inventory/PermissionsProvider";
import AccessDenied from "@/components/inventory/AccessDenied";

const FEATURES = [
  {
    title: "Quantity Adjustment",
    description: "Adjust stock for damage, expiry, or recount",
    page: "QuantityAdjustment",
    icon: "📦"
  },
  {
    title: "Cost Adjustment",
    description: "Update supplier costs and unit prices",
    page: "CostAdjustment",
    icon: "💰"
  },
  {
    title: "Order Transactions",
    description: "Track purchase orders and receipts",
    page: "OrderTransaction",
    icon: "📋"
  },
  {
    title: "Inventory Categories",
    description: "Organize items into categories",
    page: "InventoryCategories",
    icon: "🏷️"
  },
  {
    title: "Inventory Count",
    description: "Full stock audits with variance tracking",
    page: "InventoryCount",
    icon: "✔️"
  },
  {
    title: "Spot Check",
    description: "Random item verification",
    page: "InventorySpotCheck",
    icon: "🔍"
  },
  {
    title: "Warehouses",
    description: "Manage warehouse locations",
    page: "Warehouses",
    icon: "🏢"
  }
];

function InventoryManagementInner() {
  const { user, loading, hasPermission } = usePermissions();

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  if (!hasPermission("view_inventory")) {
    return <AccessDenied feature="Inventory Management" currentRole={user?.role || "unknown"} />;
  }

  const filterFeatures = FEATURES.filter(feature => {
    if (feature.page === "CostAdjustment" && !hasPermission("adjust_cost")) return false;
    if (feature.page === "QuantityAdjustment" && !hasPermission("adjust_quantity")) return false;
    if (feature.page === "OrderTransaction" && !hasPermission("create_orders")) return false;
    if (feature.page === "InventoryCategories" && !hasPermission("manage_categories")) return false;
    if (feature.page === "Warehouses" && !hasPermission("manage_warehouses")) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Inventory Management</h1>
          <p className="text-gray-400 text-sm mt-1">Complete stock control and auditing</p>
          {user && (
            <p className="text-xs text-gray-500 mt-2">
              Role: <span className="font-medium capitalize">{user.role.replace(/_/g, " ")}</span>
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filterFeatures.map(feature => (
            <Link
              key={feature.page}
              to={createPageUrl(feature.page)}
              className="bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-lg hover:border-violet-200 transition-all group"
            >
              <div className="text-4xl mb-3">{feature.icon}</div>
              <h3 className="font-bold text-gray-900 group-hover:text-violet-600 transition">{feature.title}</h3>
              <p className="text-xs text-gray-400 mt-1">{feature.description}</p>
              <div className="flex items-center gap-2 mt-3 text-violet-600 opacity-0 group-hover:opacity-100 transition text-xs font-medium">
                View <ArrowRight className="w-3 h-3" />
              </div>
            </Link>
          ))}
        </div>

        {filterFeatures.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400">No inventory features available for your role.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function InventoryManagement() {
  return (
    <PermissionProvider>
      <InventoryManagementInner />
    </PermissionProvider>
  );
}