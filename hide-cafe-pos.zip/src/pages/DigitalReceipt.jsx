import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Star } from "lucide-react";

export default function DigitalReceipt() {
  const [order, setOrder] = useState(null);
  const [branding, setBranding] = useState({});
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [feedbackLoading, setFeedbackLoading] = useState(false);

  useEffect(() => {
    const hashQuery = window.location.hash.includes('?') ? window.location.hash.split('?')[1] : '';
    const params = new URLSearchParams(hashQuery || window.location.search);
    // Try DB first, fall back to localStorage
    base44.functions.invoke("getReceiptSettings", {}).then(res => {
      if (res?.data?.settings) {
        const s = res.data.settings;
        setBranding({
          businessName: s.business_name,
          address: s.address,
          phone: s.phone,
          logo: s.logo,
          trnNumber: s.trn_number,
          vatRate: String(s.vat_rate || 5),
          footer: s.footer,
          showLocation: s.show_location,
          showPaymentMethod: s.show_payment_method,
          showTaxBreakdown: s.show_tax_breakdown,
          showDiscounts: s.show_discounts,
        });
      } else {
        const saved = JSON.parse(localStorage.getItem("receipt_branding_v2") || "{}");
        setBranding(saved);
      }
    }).catch(() => {
      const saved = JSON.parse(localStorage.getItem("receipt_branding_v2") || "{}");
      setBranding(saved);
    });

    // Support ?order_id= param (same as ?id=)
    const orderIdParam = params.get("order_id") || params.get("id");
    if (orderIdParam) {
      loadByOrderNumber(orderIdParam);
      return;
    }

    const dataParam = params.get("data");
    if (dataParam) {
      localStorage.setItem("pending_receipt_data", dataParam);
      try {
        const jsonStr = new TextDecoder().decode(
          Uint8Array.from(atob(decodeURIComponent(dataParam)), c => c.charCodeAt(0))
        );
        const decoded = JSON.parse(jsonStr);
        setOrder(decoded);
        setLoading(false);
        return;
      } catch (e) {
        console.error("Failed to decode receipt data", e);
      }
    }

    const pendingData = localStorage.getItem("pending_receipt_data");
    if (pendingData) {
      try {
        const jsonStr = new TextDecoder().decode(
          Uint8Array.from(atob(decodeURIComponent(pendingData)), c => c.charCodeAt(0))
        );
        const decoded = JSON.parse(jsonStr);
        setOrder(decoded);
        setLoading(false);
        return;
      } catch (e) {
        localStorage.removeItem("pending_receipt_data");
      }
    }

    setNotFound(true);
    setLoading(false);
  }, []);

  const loadByOrderNumber = async (orderNumber) => {
    try {
      const res = await base44.functions.invoke("getPublicReceipt", { order_number: orderNumber });
      const o = res?.data?.order;
      if (!o) { setNotFound(true); setLoading(false); return; }
      setOrder(o);
      setLoading(false);
    } catch (e) {
      setNotFound(true);
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <Loader2 className="w-7 h-7 text-gray-400 animate-spin" />
    </div>
  );

  if (notFound) return (
    <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center gap-3 text-gray-400 p-6">
      <span className="text-5xl">🧾</span>
      <p className="text-lg font-semibold text-gray-300">Receipt not found</p>
      <p className="text-sm text-center">This receipt link may be invalid or expired.</p>
    </div>
  );

  const submitFeedback = async () => {
    if (!rating) return;
    setFeedbackLoading(true);
    await base44.entities.CustomerFeedback.create({
      order_id: order.id,
      order_number: order.order_number,
      branch_id: order.branch_id,
      customer_name: order.customer_name || "",
      rating,
      comment,
      submitted_at: new Date().toISOString(),
    });
    setFeedbackSent(true);
    setFeedbackLoading(false);
  };

  const vatRate = parseFloat(branding.vatRate) || 5;
  const total = order.total || 0;
  const dateStr = order.created_date
    ? new Date(order.created_date).toLocaleString("en-AE", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" })
    : new Date().toLocaleString("en-AE", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });

  return (
    <div className="min-h-screen bg-gray-900 flex items-start justify-center py-10 px-4">
      <div
        className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden"
        style={{ fontFamily: "'Courier New', 'Courier', monospace" }}
      >
        {/* Header */}
        <div className="px-8 pt-8 pb-4 text-center">
          {branding.logo ? (
            <div className="flex justify-center mb-3">
              <img src={branding.logo} alt="logo" className="h-16 object-contain" style={{ filter: "grayscale(100%)" }} />
            </div>
          ) : (
            <div className="flex justify-center mb-3">
              <div className="w-14 h-14 bg-gray-100 rounded flex items-center justify-center text-[10px] font-bold text-gray-600">
                {(branding.businessName || "CAFE").slice(0, 4).toUpperCase()}
              </div>
            </div>
          )}
          <h1 className="font-black text-gray-900 text-lg tracking-widest uppercase">
            {branding.businessName || "RESTAURANT"}
          </h1>
          {branding.address && (
            <p className="text-gray-500 text-xs mt-1 tracking-wider uppercase">{branding.address}</p>
          )}
          {branding.trnNumber && (
            <p className="text-gray-400 text-xs mt-1">TRN: {branding.trnNumber}</p>
          )}
          {order.order_number && (
            <p className="text-gray-400 text-xs mt-1">#{order.order_number}</p>
          )}
        </div>

        {/* Dashed divider */}
        <div className="mx-6 border-t-2 border-dashed border-gray-300 my-2" />

        {/* Items */}
        <div className="px-6 py-2 space-y-3">
          {(order.items || []).map((item, i) => {
            const regPrice = item.price * item.quantity;
            const finalSubtotal = item.subtotal ?? regPrice;
            const itemDiscount = regPrice - finalSubtotal;

            return (
              <div key={i}>
                <div className="flex justify-between items-baseline">
                  <span className="font-bold text-gray-900 text-sm">{item.name}</span>
                  <span className="font-bold text-gray-900 text-sm" dir="rtl">{finalSubtotal.toFixed(2)}|د.إ</span>
                </div>
                {itemDiscount > 0.001 && (
                  <>
                    <div className="flex justify-between items-baseline">
                      <span className="text-gray-400 text-xs">Reg price</span>
                      <span className="text-gray-400 text-xs line-through" dir="rtl">{regPrice.toFixed(2)}|د.إ</span>
                    </div>
                    <div className="flex justify-between items-baseline">
                      <span className="text-gray-400 text-xs">Discount: Item Sale</span>
                      <span className="text-gray-400 text-xs" dir="rtl">{itemDiscount.toFixed(2)}|د.إ</span>
                    </div>
                  </>
                )}
                {item.notes && (
                  <p className="text-gray-400 text-xs italic">{item.notes}</p>
                )}
                {item.modifiers?.map((m, mi) => (
                  <div key={mi} className="flex justify-between items-baseline">
                    <span className="text-gray-400 text-xs">+ {m.name}</span>
                    {m.price > 0 && <span className="text-gray-400 text-xs" dir="rtl">{m.price.toFixed(2)}|د.إ</span>}
                  </div>
                ))}
              </div>
            );
          })}
        </div>

        {/* Dashed divider */}
        <div className="mx-6 border-t-2 border-dashed border-gray-300 my-2" />

        {/* Totals */}
        <div className="px-6 pb-4 space-y-1 text-sm">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal</span>
            <span dir="rtl">{(order.subtotal || 0).toFixed(2)}|د.إ</span>
          </div>
          {(order.discount || 0) > 0 && (
            <div className="flex justify-between text-gray-600">
              <span>Discount</span>
              <span dir="rtl">-{order.discount.toFixed(2)}|د.إ</span>
            </div>
          )}
          <div className="flex justify-between text-gray-600">
            <span>Tax ({vatRate}%)</span>
            <span dir="rtl">{(order.tax || 0).toFixed(2)}|د.إ</span>
          </div>
          <div className="flex justify-between font-black text-gray-900 text-base pt-1">
            <span>Total</span>
            <span dir="rtl">{total.toFixed(2)}|د.إ</span>
          </div>
          {order.payment_method && (
            <div className="flex justify-between text-gray-400 text-xs pt-1">
              <span className="capitalize">{order.payment_method === "card" ? "Credit Card" : order.payment_method}</span>
              <span>{dateStr}</span>
            </div>
          )}
        </div>

        {/* Map */}
        {branding.address && (
          <div className="mx-6 mb-4 rounded-lg overflow-hidden bg-gray-100">
            <iframe
              title="location"
              width="100%"
              height="120"
              frameBorder="0"
              style={{ border: 0 }}
              src={`https://maps.google.com/maps?q=${encodeURIComponent(branding.address)}&output=embed`}
              allowFullScreen
            />
          </div>
        )}

        {/* Feedback */}
        <div className="mx-6 mb-4 bg-gray-50 rounded-2xl p-5 text-center">
          {feedbackSent ? (
            <div>
              <span className="text-2xl">🙏</span>
              <p className="font-bold text-gray-800 text-sm mt-1">Thank you for your feedback!</p>
            </div>
          ) : (
            <>
              <p className="font-bold text-gray-800 text-sm mb-3">How was your experience?</p>
              <div className="flex justify-center gap-2 mb-3">
                {[1,2,3,4,5].map(star => (
                  <button
                    key={star}
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      className="w-8 h-8"
                      fill={(hoverRating || rating) >= star ? "#FBBF24" : "none"}
                      stroke={(hoverRating || rating) >= star ? "#FBBF24" : "#D1D5DB"}
                    />
                  </button>
                ))}
              </div>
              {rating > 0 && (
                <>
                  <textarea
                    value={comment}
                    onChange={e => setComment(e.target.value)}
                    placeholder="Leave a comment (optional)..."
                    rows={2}
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-700 resize-none focus:outline-none focus:border-gray-400 mb-2"
                  />
                  <button
                    onClick={submitFeedback}
                    disabled={feedbackLoading}
                    className="w-full bg-gray-900 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-gray-700 disabled:opacity-50 transition"
                  >
                    {feedbackLoading ? "Submitting..." : "Submit Feedback"}
                  </button>
                </>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 pb-8 text-center border-t border-gray-100 pt-4">
          <p className="font-bold text-gray-700 text-sm tracking-widest uppercase mb-2">
            {branding.businessName || "RESTAURANT"}
          </p>
          {branding.footer && (
            <p className="text-gray-400 text-xs whitespace-pre-line">{branding.footer}</p>
          )}
          <p className="text-gray-300 text-[10px] mt-4">Powered by DENDAX POS</p>
        </div>
      </div>
    </div>
  );
}