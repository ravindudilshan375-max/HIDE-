import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, isAfter } from "date-fns";
import { TrendingDown, DollarSign, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function VoidsReturnsReport() {
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 500),
    ]).then(([u, b, o]) => {
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setOrders(o);
      setLoading(false);
    });
  }, []);

  const periodStart = useMemo(() => startOfMonth(new Date()), []);

  const voidData = useMemo(() => {
    const cancelledOrders = orders.filter(o => 
      o.status === "cancelled" && 
      o.created_date && 
      isAfter(new Date(o.created_date), periodStart) &&
      (!selectedBranchId || o.branch_id === selectedBranchId)
    );

    const totalVoided = cancelledOrders.reduce((s, o) => s + (o.total || 0), 0);
    const voidCount = cancelledOrders.length;

    const map = {};
    cancelledOrders.forEach(o => {
      const date = format(new Date(o.created_date), "MMM dd");
      if (!map[date]) map[date] = 0;
      map[date] += o.total || 0;
    });

    return {
      totalVoided,
      voidCount,
      chartData: Object.entries(map).map(([date, amount]) => ({ date, amount })).sort((a, b) => a.date.localeCompare(b.date)),
    };
  }, [orders, periodStart, selectedBranchId]);

  const refundData = useMemo(() => {
    const refundedOrders = orders.filter(o => 
      o.is_refunded && 
      o.refund_amount > 0 && 
      o.created_date && 
      isAfter(new Date(o.created_date), periodStart) &&
      (!selectedBranchId || o.branch_id === selectedBranchId)
    );

    const totalRefunded = refundedOrders.reduce((s, o) => s + (o.refund_amount || 0), 0);
    const refundCount = refundedOrders.length;

    return { totalRefunded, refundCount };
  }, [orders, periodStart, selectedBranchId]);

  if (loading) return <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Voids & Returns Report</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-3">
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
        </div>

        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingDown className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-2xl font-bold text-red-600">AED {voidData.totalVoided.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Total Voided</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center mb-3">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
            </div>
            <p className="text-2xl font-bold text-orange-600">{voidData.voidCount}</p>
            <p className="text-xs text-gray-400 mt-1">Void Count</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">AED {refundData.totalRefunded.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Total Refunded</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center mb-3">
              <AlertTriangle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">{refundData.refundCount}</p>
            <p className="text-xs text-gray-400 mt-1">Refund Count</p>
          </div>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
          <h3 className="font-semibold text-sm mb-4 text-gray-500">Void Amount Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={voidData.chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} tickFormatter={v => `AED ${v}`} />
              <Tooltip formatter={(v) => `AED ${v.toFixed(2)}`} />
              <Bar dataKey="amount" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}