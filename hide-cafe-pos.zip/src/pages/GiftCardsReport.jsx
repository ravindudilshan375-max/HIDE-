import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, startOfDay, isAfter } from "date-fns";
import { Gift, DollarSign, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function GiftCardsReport() {
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [period, setPeriod] = useState("month");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 500),
    ]).then(([u, b, o]) => {
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setOrders(o);
      setLoading(false);
    });
  }, []);

  const filteredOrders = useMemo(() => {
    const periodStart = period === "day" ? startOfDay(new Date()) : startOfMonth(new Date());
    return orders.filter(o => 
      o.status === "paid" && 
      o.created_date && 
      isAfter(new Date(o.created_date), periodStart) &&
      (!selectedBranchId || o.branch_id === selectedBranchId)
    );
  }, [orders, period, selectedBranchId]);

  const giftCardStats = useMemo(() => {
    const totalSales = filteredOrders.reduce((s, o) => s + (o.total || 0), 0);
    const count = filteredOrders.length;
    return { 
      totalSales,
      count,
      avgValue: count ? totalSales / count : 0,
    };
  }, [filteredOrders]);

  const chartData = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      const date = format(new Date(o.created_date), "MMM dd");
      if (!map[date]) map[date] = 0;
      map[date] += o.total || 0;
    });
    return Object.entries(map).map(([date, sales]) => ({ date, sales })).sort((a, b) => a.date.localeCompare(b.date));
  }, [filteredOrders]);

  if (loading) return <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Gift Cards Report</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-3 flex-wrap">
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
          <div className="flex bg-white border border-gray-200 rounded-lg p-1 gap-1">
            {[{ label: "Today", key: "day" }, { label: "This Month", key: "month" }].map(p => (
              <button key={p.key} onClick={() => setPeriod(p.key)}
                className={`px-4 py-1.5 rounded text-sm font-medium transition-all ${period === p.key ? "bg-violet-600 text-white" : "text-gray-500 hover:text-gray-800"}`}>
                {p.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-pink-50 rounded-xl flex items-center justify-center mb-3">
              <Gift className="w-5 h-5 text-pink-600" />
            </div>
            <p className="text-2xl font-bold text-pink-600">AED {giftCardStats.totalSales.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Total Gift Card Sales</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">{giftCardStats.count}</p>
            <p className="text-xs text-gray-400 mt-1">Gift Cards Issued</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">AED {giftCardStats.avgValue.toFixed(2)}</p>
            <p className="text-xs text-gray-400 mt-1">Average Value</p>
          </div>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
          <h3 className="font-semibold text-sm mb-4 text-gray-500">Gift Card Sales Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} tickFormatter={v => `AED ${v}`} />
              <Tooltip formatter={(v) => `AED ${v.toFixed(2)}`} />
              <Bar dataKey="sales" fill="#ec4899" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}