import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Edit2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const DEFAULT_CATEGORIES = [
  { name: "Cost of Goods Sold", icon: "📦", tax_deductible: true },
  { name: "Payroll", icon: "⏰", tax_deductible: true },
  { name: "Utilities", icon: "💡", tax_deductible: true },
  { name: "Rent", icon: "🏢", tax_deductible: true },
  { name: "Marketing", icon: "📢", tax_deductible: true },
  { name: "Equipment", icon: "☕", tax_deductible: true },
  { name: "Transport", icon: "🚗", tax_deductible: true },
  { name: "Advertising", icon: "📣", tax_deductible: true },
  { name: "Business Meals", icon: "🍽️", tax_deductible: true },
  { name: "Insurance", icon: "🛡️", tax_deductible: true },
  { name: "Legal & Professional", icon: "👔", tax_deductible: true },
  { name: "Supplies & Materials", icon: "🧴", tax_deductible: true },
];

export default function ExpenseCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({ name: "", icon: "📄", tax_deductible: false });

  useEffect(() => { load(); }, []);

  const load = () => {
    base44.entities.ExpenseCategory.list("name").then(cats => {
      setCategories(cats);
      setLoading(false);
    });
  };

  const seedDefaults = async () => {
    for (const cat of DEFAULT_CATEGORIES) {
      await base44.entities.ExpenseCategory.create(cat);
    }
    toast.success("Default categories added!");
    load();
  };

  const save = async () => {
    if (!form.name.trim()) { toast.error("Name required"); return; }
    if (editingId) {
      await base44.entities.ExpenseCategory.update(editingId, form);
      toast.success("Updated");
    } else {
      await base44.entities.ExpenseCategory.create(form);
      toast.success("Category added");
    }
    setShowForm(false);
    load();
  };

  const del = async (id) => {
    await base44.entities.ExpenseCategory.delete(id);
    setCategories(prev => prev.filter(c => c.id !== id));
    toast.success("Deleted");
  };

  const toggleTaxDeductible = async (cat) => {
    await base44.entities.ExpenseCategory.update(cat.id, { tax_deductible: !cat.tax_deductible });
    setCategories(prev => prev.map(c => c.id === cat.id ? { ...c, tax_deductible: !c.tax_deductible } : c));
  };

  const openEdit = (cat) => { setEditingId(cat.id); setForm({ name: cat.name, icon: cat.icon || "📄", tax_deductible: cat.tax_deductible || false }); setShowForm(true); };

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-4 md:p-6">
      <div className="max-w-2xl mx-auto space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Expense Categories</h1>
            <p className="text-gray-400 text-sm">{categories.length} categories</p>
          </div>
          <div className="flex gap-2">
            {categories.length === 0 && (
              <Button onClick={seedDefaults} variant="outline" className="border-gray-200 rounded-xl text-sm">
                Add Defaults
              </Button>
            )}
            <Button onClick={() => { setEditingId(null); setForm({ name: "", icon: "📄", tax_deductible: false }); setShowForm(true); }}
              className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
              <Plus className="w-4 h-4" /> Add Category
            </Button>
          </div>
        </div>

        {/* Tax Deductible section */}
        {categories.filter(c => c.tax_deductible).length > 0 && (
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Tax Deductible</p>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              {categories.filter(c => c.tax_deductible).map((cat, i, arr) => (
                <CategoryRow key={cat.id} cat={cat} isLast={i === arr.length - 1} onEdit={openEdit} onDelete={del} onToggle={toggleTaxDeductible} />
              ))}
            </div>
          </div>
        )}

        {/* Non-deductible */}
        {categories.filter(c => !c.tax_deductible).length > 0 && (
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Other</p>
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              {categories.filter(c => !c.tax_deductible).map((cat, i, arr) => (
                <CategoryRow key={cat.id} cat={cat} isLast={i === arr.length - 1} onEdit={openEdit} onDelete={del} onToggle={toggleTaxDeductible} />
              ))}
            </div>
          </div>
        )}

        {!loading && categories.length === 0 && (
          <div className="text-center py-16 text-gray-300">
            <p className="text-sm font-medium">No categories yet</p>
            <p className="text-xs mt-1">Click "Add Defaults" to seed common categories</p>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900">{editingId ? "Edit Category" : "New Category"}</h3>
              <button onClick={() => setShowForm(false)}><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            <div className="space-y-3">
              <div className="flex gap-3">
                <Input value={form.icon} onChange={e => setForm(f => ({ ...f, icon: e.target.value }))} className="border-gray-200 rounded-xl w-16 text-center text-xl" maxLength={2} />
                <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Category name" className="border-gray-200 rounded-xl flex-1" />
              </div>
              <div className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded-xl">
                <span className="text-sm text-gray-700">Tax Deductible</span>
                <button onClick={() => setForm(f => ({ ...f, tax_deductible: !f.tax_deductible }))}
                  className={`w-10 h-6 rounded-full transition-colors ${form.tax_deductible ? "bg-green-500" : "bg-gray-200"} relative`}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.tax_deductible ? "translate-x-5" : "translate-x-1"}`} />
                </button>
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <Button onClick={() => setShowForm(false)} variant="outline" className="flex-1 border-gray-200 rounded-xl">Cancel</Button>
              <Button onClick={save} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl">Save</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CategoryRow({ cat, isLast, onEdit, onDelete, onToggle }) {
  return (
    <div className={`flex items-center gap-4 px-5 py-4 border-b border-gray-50 hover:bg-gray-50/50 transition group ${isLast ? "border-b-0" : ""}`}>
      <span className="text-2xl w-8 text-center">{cat.icon || "📄"}</span>
      <div className="flex-1">
        <p className="font-semibold text-gray-800 text-sm">{cat.name}</p>
        {cat.tax_deductible && <p className="text-xs text-green-600 font-medium">✓ Tax Deductible</p>}
      </div>
      <button onClick={() => onToggle(cat)}
        className={`w-9 h-5 rounded-full transition-colors ${cat.tax_deductible ? "bg-green-500" : "bg-gray-200"} relative shrink-0`}>
        <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${cat.tax_deductible ? "translate-x-4" : "translate-x-0.5"}`} />
      </button>
      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition">
        <button onClick={() => onEdit(cat)} className="p-1.5 text-gray-400 hover:text-violet-600"><Edit2 className="w-3.5 h-3.5" /></button>
        <button onClick={() => onDelete(cat.id)} className="p-1.5 text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
      </div>
    </div>
  );
}