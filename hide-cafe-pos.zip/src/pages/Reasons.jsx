import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Plus, Trash2, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";

const CATEGORIES = [
  { key: "void_and_return", label: "Void and Return Reason" },
  { key: "quantity_adjustment", label: "Quantity Adjustment Reason" },
  { key: "drawer_operation", label: "Drawer Operation Reason" }
];

export default function Reasons() {
  const navigate = useNavigate();
  const [reasons, setReasons] = useState([]);
  const [tab, setTab] = useState("General");
  const [loading, setLoading] = useState(true);
  const [creatingCategory, setCreatingCategory] = useState(null);
  const [newReasonName, setNewReasonName] = useState("");

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.Reason.list();
    setReasons(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleCreateReason = async (category) => {
    if (!newReasonName.trim()) return;
    
    await base44.entities.Reason.create({
      name: newReasonName,
      category
    });
    
    setNewReasonName("");
    setCreatingCategory(null);
    toast.success("Reason created");
    load();
  };

  const handleDeleteReason = async (reason) => {
    if (!window.confirm(`Delete "${reason.name}"?`)) return;
    
    if (tab === "General") {
      await base44.entities.Reason.update(reason.id, { is_deleted: true });
    } else {
      await base44.entities.Reason.delete(reason.id);
    }
    
    toast.success("Reason deleted");
    load();
  };

  const getFilteredReasons = (category) => {
    return reasons.filter(r => 
      r.category === category && 
      (tab === "General" ? !r.is_deleted : r.is_deleted)
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <button
          onClick={() => navigate(createPageUrl("Manage"))}
          className="flex items-center gap-2 text-sm font-semibold text-gray-600 hover:text-violet-600 transition mb-4"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Reasons</h1>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 px-6 flex gap-6">
        {["General", "Deleted"].map(t => (
          <button 
            key={t}
            onClick={() => setTab(t)}
            className={`text-sm font-semibold py-3 border-b-2 transition ${
              tab === t 
                ? "text-gray-900 border-violet-600" 
                : "text-gray-400 border-transparent hover:text-gray-600"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="p-6 space-y-8">
        {loading ? (
          <div className="text-center py-12 text-gray-400">Loading...</div>
        ) : (
          CATEGORIES.map(({ key, label }) => {
            const filtered = getFilteredReasons(key);
            return (
              <div key={key}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-base font-semibold text-gray-800">{label}</h2>
                  <Button
                    onClick={() => setCreatingCategory(key)}
                    variant="outline"
                    className="text-sm rounded-lg"
                  >
                    Create Reason
                  </Button>
                </div>

                <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
                  {filtered.length === 0 ? (
                    <div className="py-8 text-center text-gray-400 text-sm">
                      No reasons yet
                    </div>
                  ) : (
                    <div className="divide-y divide-gray-100">
                      {filtered.map(reason => (
                        <div
                          key={reason.id}
                          className="px-5 py-4 flex items-center justify-between hover:bg-gray-50 transition"
                        >
                          <span className="text-gray-800 font-medium">{reason.name}</span>
                          <button
                            onClick={() => handleDeleteReason(reason)}
                            className="text-gray-400 hover:text-red-600 transition p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {creatingCategory === key && (
                  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-2xl shadow-lg p-6 max-w-sm w-full">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-bold text-gray-900">Create Reason</h3>
                        <button
                          onClick={() => { setCreatingCategory(null); setNewReasonName(""); }}
                          className="text-gray-400 hover:text-gray-600"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                      <Input
                        placeholder="Reason name..."
                        value={newReasonName}
                        onChange={e => setNewReasonName(e.target.value)}
                        onKeyPress={e => e.key === "Enter" && handleCreateReason(key)}
                        className="mb-4"
                        autoFocus
                      />
                      <div className="flex gap-3 justify-end">
                        <Button
                          variant="outline"
                          onClick={() => { setCreatingCategory(null); setNewReasonName(""); }}
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={() => handleCreateReason(key)}
                          disabled={!newReasonName.trim()}
                          className="bg-violet-600 hover:bg-violet-700 text-white"
                        >
                          Create
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}