import React, { useState, useEffect } from "react";
import { ChevronLeft, Plus, MoreVertical, Info } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function TaxesAndGroups() {
  const [activeTab, setActiveTab] = useState("general");
  const [taxes, setTaxes] = useState([]);
  const [taxGroups, setTaxGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showTaxForm, setShowTaxForm] = useState(false);
  const [showGroupForm, setShowGroupForm] = useState(false);
  const [editingTax, setEditingTax] = useState(null);
  const [editingGroup, setEditingGroup] = useState(null);
  const [taxData, setTaxData] = useState({ name: "", rate: 0 });
  const [groupData, setGroupData] = useState({ name: "", taxes: [] });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    // For now, using localStorage to simulate data persistence
    const savedTaxes = JSON.parse(localStorage.getItem("taxes") || "[]");
    const savedGroups = JSON.parse(localStorage.getItem("taxGroups") || "[]");
    setTaxes(savedTaxes);
    setTaxGroups(savedGroups);
    setLoading(false);
  };

  const saveTax = async () => {
    if (!taxData.name.trim()) {
      toast.error("Tax name is required");
      return;
    }
    if (taxData.rate < 0 || taxData.rate > 100) {
      toast.error("Rate must be between 0 and 100");
      return;
    }

    let updated;
    if (editingTax) {
      updated = taxes.map(t => t.id === editingTax.id ? { ...taxData, id: editingTax.id, deleted: false } : t);
      toast.success("Tax updated");
    } else {
      updated = [...taxes, { ...taxData, id: Date.now().toString(), deleted: false }];
      toast.success("Tax created");
    }
    setTaxes(updated);
    localStorage.setItem("taxes", JSON.stringify(updated));
    resetTaxForm();
  };

  const deleteTax = (id) => {
    const updated = taxes.map(t => t.id === id ? { ...t, deleted: true } : t);
    setTaxes(updated);
    localStorage.setItem("taxes", JSON.stringify(updated));
    toast.success("Tax deleted");
  };

  const editTax = (tax) => {
    setEditingTax(tax);
    setTaxData({ name: tax.name, rate: tax.rate });
    setShowTaxForm(true);
  };

  const resetTaxForm = () => {
    setEditingTax(null);
    setTaxData({ name: "", rate: 0 });
    setShowTaxForm(false);
  };

  const saveGroup = async () => {
    if (!groupData.name.trim()) {
      toast.error("Group name is required");
      return;
    }
    if (groupData.taxes.length === 0) {
      toast.error("Select at least one tax");
      return;
    }

    let updated;
    if (editingGroup) {
      updated = taxGroups.map(g => g.id === editingGroup.id ? { ...groupData, id: editingGroup.id, deleted: false } : g);
      toast.success("Tax group updated");
    } else {
      updated = [...taxGroups, { ...groupData, id: Date.now().toString(), deleted: false }];
      toast.success("Tax group created");
    }
    setTaxGroups(updated);
    localStorage.setItem("taxGroups", JSON.stringify(updated));
    resetGroupForm();
  };

  const deleteGroup = (id) => {
    const updated = taxGroups.map(g => g.id === id ? { ...g, deleted: true } : g);
    setTaxGroups(updated);
    localStorage.setItem("taxGroups", JSON.stringify(updated));
    toast.success("Tax group deleted");
  };

  const editGroup = (group) => {
    setEditingGroup(group);
    setGroupData({ name: group.name, taxes: group.taxes || [] });
    setShowGroupForm(true);
  };

  const resetGroupForm = () => {
    setEditingGroup(null);
    setGroupData({ name: "", taxes: [] });
    setShowGroupForm(false);
  };

  const filteredTaxes = taxes.filter(t => activeTab === "general" ? !t.deleted : t.deleted);
  const filteredGroups = taxGroups.filter(g => activeTab === "general" ? !g.deleted : g.deleted);

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <Link to={createPageUrl("Manage")} className="text-gray-600 hover:text-gray-900 transition">
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Taxes & Groups</h1>
          <Info className="w-5 h-5 text-gray-400" />
        </div>

        {/* Tabs */}
        <div className="flex gap-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("general")}
            className={`py-3 font-medium text-sm border-b-2 transition-colors ${
              activeTab === "general"
                ? "border-violet-600 text-gray-900"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            General
          </button>
          <button
            onClick={() => setActiveTab("deleted")}
            className={`py-3 font-medium text-sm border-b-2 transition-colors ${
              activeTab === "deleted"
                ? "border-violet-600 text-gray-900"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            Deleted
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 max-w-4xl">
        {/* Taxes Section */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Taxes</h2>
            {activeTab === "general" && (
              <button
                onClick={() => setShowTaxForm(true)}
                className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg font-semibold text-sm transition"
              >
                Create Tax
              </button>
            )}
          </div>

          {filteredTaxes.length === 0 ? (
            <p className="text-gray-400 text-sm">No taxes yet</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredTaxes.map(tax => (
                <div key={tax.id} className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-900">{tax.name}</p>
                    <p className="text-sm text-gray-500">{tax.rate}%</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => editTax(tax)}
                      className="text-gray-400 hover:text-violet-600 transition p-2"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <hr className="my-8" />

        {/* Tax Groups Section */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Tax Groups</h2>
            {activeTab === "general" && (
              <button
                onClick={() => setShowGroupForm(true)}
                className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg font-semibold text-sm transition"
              >
                Create Tax Group
              </button>
            )}
          </div>

          {filteredGroups.length === 0 ? (
            <p className="text-gray-400 text-sm">No tax groups yet</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredGroups.map(group => (
                <div key={group.id} className="bg-white border border-gray-200 rounded-xl p-4">
                  <div className="flex items-start justify-between mb-3">
                    <p className="font-semibold text-gray-900">{group.name}</p>
                    <button
                      onClick={() => editGroup(group)}
                      className="text-gray-400 hover:text-violet-600 transition p-1"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {group.taxes?.map((taxId, i) => {
                      const tax = taxes.find(t => t.id === taxId);
                      return tax ? (
                        <span key={i} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-medium">
                          {tax.name}
                        </span>
                      ) : null;
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Tax Form Modal */}
      {showTaxForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4">
            <h3 className="text-lg font-bold text-gray-900 mb-4">{editingTax ? "Edit Tax" : "Create Tax"}</h3>
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax Name</label>
                <input
                  type="text"
                  value={taxData.name}
                  onChange={(e) => setTaxData({ ...taxData, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500"
                  placeholder="e.g., VAT"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rate (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={taxData.rate}
                  onChange={(e) => setTaxData({ ...taxData, rate: parseFloat(e.target.value) })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500"
                  placeholder="e.g., 5"
                />
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={resetTaxForm}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              {editingTax && (
                <button
                  onClick={() => {
                    deleteTax(editingTax.id);
                    resetTaxForm();
                  }}
                  className="flex-1 px-4 py-2 border border-red-300 rounded-lg font-medium text-red-600 hover:bg-red-50 transition"
                >
                  Delete
                </button>
              )}
              <button
                onClick={saveTax}
                className="flex-1 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg font-medium transition"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tax Group Form Modal */}
      {showGroupForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold text-gray-900 mb-4">{editingGroup ? "Edit Tax Group" : "Create Tax Group"}</h3>
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Group Name</label>
                <input
                  type="text"
                  value={groupData.name}
                  onChange={(e) => setGroupData({ ...groupData, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-500"
                  placeholder="e.g., VAT"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Taxes</label>
                <div className="space-y-2">
                  {taxes.filter(t => !t.deleted).map(tax => (
                    <label key={tax.id} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={groupData.taxes.includes(tax.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setGroupData({ ...groupData, taxes: [...groupData.taxes, tax.id] });
                          } else {
                            setGroupData({ ...groupData, taxes: groupData.taxes.filter(id => id !== tax.id) });
                          }
                        }}
                        className="w-4 h-4 rounded border-gray-300 text-violet-600 focus:ring-violet-500"
                      />
                      <span className="text-sm text-gray-700">{tax.name} ({tax.rate}%)</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={resetGroupForm}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              {editingGroup && (
                <button
                  onClick={() => {
                    deleteGroup(editingGroup.id);
                    resetGroupForm();
                  }}
                  className="flex-1 px-4 py-2 border border-red-300 rounded-lg font-medium text-red-600 hover:bg-red-50 transition"
                >
                  Delete
                </button>
              )}
              <button
                onClick={saveGroup}
                className="flex-1 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg font-medium transition"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}