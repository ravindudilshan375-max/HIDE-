import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, isAfter, differenceInMinutes } from "date-fns";
import {
  TrendingUp, DollarSign, Clock, Trophy, Plus, Pencil, Trash2,
  CheckCircle2, Circle, Loader, CalendarDays, ClipboardList, Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import TaskModal from "@/components/staff/TaskModal";
import ScheduleModal from "@/components/staff/ScheduleModal";

const TABS = ["Performance", "Tasks", "Schedule"];

const PRIORITY_STYLE = {
  high: "text-red-400 bg-red-400/10 border-red-400/30",
  medium: "text-amber-400 bg-amber-400/10 border-amber-400/30",
  low: "text-blue-400 bg-blue-400/10 border-blue-400/30",
};

const TASK_STATUS_ICON = {
  pending: Circle,
  in_progress: Loader,
  done: CheckCircle2,
};

export default function Staff() {
  const [orders, setOrders] = useState([]);
  const [users, setUsers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("Performance");

  // Modals
  const [taskModal, setTaskModal] = useState(null); // null | "new" | task object
  const [scheduleModal, setScheduleModal] = useState(null);
  const [scheduleWeek, setScheduleWeek] = useState(format(new Date(), "yyyy-MM-dd").slice(0, 10));

  useEffect(() => {
    Promise.all([
      base44.entities.Order.list("-created_date", 500),
      base44.entities.User.list(),
      base44.entities.StaffTask.list("-created_date", 200),
      base44.entities.StaffSchedule.list("-date", 200),
    ]).then(([o, u, t, s]) => {
      setOrders(o);
      setUsers(u);
      setTasks(t);
      setSchedules(s);
      setLoading(false);
    });
  }, []);

  // ---- Performance ----
  const monthStart = startOfMonth(new Date());
  const paidOrders = useMemo(() =>
    orders.filter(o => o.status === "paid" && o.created_date && isAfter(new Date(o.created_date), monthStart)),
    [orders]
  );

  const staffPerf = useMemo(() => {
    const map = {};
    paidOrders.forEach(o => {
      const name = o.cashier_name || "Unknown";
      if (!map[name]) map[name] = { name, orders: 0, revenue: 0, avgFulfill: [] };
      map[name].orders += 1;
      map[name].revenue += o.total || 0;
    });
    // Fulfillment time: orders that went pending -> paid (approx: updated_date - created_date)
    orders.filter(o => o.status === "paid" && o.created_date && o.updated_date).forEach(o => {
      const name = o.cashier_name || "Unknown";
      if (!map[name]) return;
      const mins = differenceInMinutes(new Date(o.updated_date), new Date(o.created_date));
      if (mins > 0 && mins < 180) map[name].avgFulfill.push(mins);
    });
    return Object.values(map).map(s => ({
      ...s,
      avgTime: s.avgFulfill.length ? Math.round(s.avgFulfill.reduce((a, b) => a + b, 0) / s.avgFulfill.length) : null,
    })).sort((a, b) => b.revenue - a.revenue);
  }, [paidOrders, orders]);

  const topPerformer = staffPerf[0];

  // ---- Tasks ----
  const saveTask = async (form) => {
    if (taskModal?.id) {
      await base44.entities.StaffTask.update(taskModal.id, form);
      setTasks(prev => prev.map(t => t.id === taskModal.id ? { ...t, ...form } : t));
    } else {
      const created = await base44.entities.StaffTask.create(form);
      setTasks(prev => [created, ...prev]);
    }
    setTaskModal(null);
  };

  const deleteTask = async (id) => {
    await base44.entities.StaffTask.delete(id);
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const cycleTaskStatus = async (task) => {
    const next = { pending: "in_progress", in_progress: "done", done: "pending" }[task.status];
    await base44.entities.StaffTask.update(task.id, { status: next });
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: next } : t));
  };

  // ---- Schedule ----
  const saveSchedule = async (form) => {
    if (scheduleModal?.id) {
      await base44.entities.StaffSchedule.update(scheduleModal.id, form);
      setSchedules(prev => prev.map(s => s.id === scheduleModal.id ? { ...s, ...form } : s));
    } else {
      const created = await base44.entities.StaffSchedule.create(form);
      setSchedules(prev => [created, ...prev]);
    }
    setScheduleModal(null);
  };

  const deleteSchedule = async (id) => {
    await base44.entities.StaffSchedule.delete(id);
    setSchedules(prev => prev.filter(s => s.id !== id));
  };

  // Show schedules for selected week (7 days)
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(scheduleWeek);
    d.setDate(d.getDate() + i);
    return format(d, "yyyy-MM-dd");
  });

  const schedulesForWeek = schedules.filter(s => weekDays.includes(s.date));

  if (loading) return (
    <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center">
      <p className="text-gray-400 text-sm">Loading staff data…</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-100 bg-white flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Staff</h1>
          <p className="text-sm text-gray-400 mt-0.5">Performance, tasks & schedules</p>
        </div>
        {activeTab === "Tasks" && (
          <Button onClick={() => setTaskModal("new")} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold gap-2">
            <Plus className="w-4 h-4" /> New Task
          </Button>
        )}
        {activeTab === "Schedule" && (
          <Button onClick={() => setScheduleModal("new")} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold gap-2">
            <Plus className="w-4 h-4" /> Add Shift
          </Button>
        )}
      </div>

      {/* Tabs */}
      <div className="px-6 pt-4 flex gap-1 border-b border-gray-100 bg-white">
        {TABS.map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 text-sm font-medium rounded-t-xl transition-all ${activeTab === tab ? "bg-gray-50 text-violet-700 border border-b-0 border-gray-200" : "text-gray-400 hover:text-gray-700"}`}>
            {tab}
          </button>
        ))}
      </div>

      <div className="p-6 space-y-6">

        {/* PERFORMANCE */}
        {activeTab === "Performance" && (
          <>
            {topPerformer && (
              <div className="bg-gradient-to-r from-violet-50 to-transparent border border-violet-100 rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center text-xl font-bold text-violet-600">
                  {topPerformer.name[0]?.toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-500" />
                    <span className="text-amber-600 font-semibold text-sm">Top Performer This Month</span>
                  </div>
                  <p className="font-bold text-lg mt-0.5 text-gray-900">{topPerformer.name}</p>
                  <p className="text-gray-400 text-xs">{topPerformer.orders} orders · ${topPerformer.revenue.toFixed(2)} revenue</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
                <Users className="w-5 h-5 text-blue-600 mb-3" />
                <p className="text-2xl font-bold text-blue-600">{users.length}</p>
                <p className="text-xs text-gray-400 mt-1">Total Staff</p>
              </div>
              <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
                <ClipboardList className="w-5 h-5 text-green-600 mb-3" />
                <p className="text-2xl font-bold text-green-600">{tasks.filter(t => t.status !== "done").length}</p>
                <p className="text-xs text-gray-400 mt-1">Open Tasks</p>
              </div>
              <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
                <CalendarDays className="w-5 h-5 text-purple-600 mb-3" />
                <p className="text-2xl font-bold text-purple-600">{schedulesForWeek.length}</p>
                <p className="text-xs text-gray-400 mt-1">Shifts This Week</p>
              </div>
            </div>

            <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider">
                Staff Performance — This Month
              </div>
              <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 grid grid-cols-5">
                <span className="col-span-2">Name</span>
                <span className="text-right">Orders</span>
                <span className="text-right">Revenue</span>
                <span className="text-right">Avg. Fulfill</span>
              </div>
              {staffPerf.length === 0 && <p className="text-center py-10 text-gray-300 text-sm">No paid orders this month yet</p>}
              {staffPerf.map((s, i) => (
                <div key={s.name} className="grid grid-cols-5 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm items-center">
                  <div className="col-span-2 flex items-center gap-3">
                    <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                    <div className="w-7 h-7 rounded-full bg-violet-100 flex items-center justify-center text-xs font-bold text-violet-600">
                      {s.name[0]?.toUpperCase()}
                    </div>
                    <span className="font-medium text-gray-800">{s.name}</span>
                  </div>
                  <span className="text-right text-blue-600 font-semibold">{s.orders}</span>
                  <span className="text-right text-violet-700 font-semibold">${s.revenue.toFixed(2)}</span>
                  <span className="text-right text-gray-400 text-xs">{s.avgTime ? `${s.avgTime} min` : "—"}</span>
                </div>
              ))}
            </div>
          </>
        )}

        {/* TASKS */}
        {activeTab === "Tasks" && (
          <div className="space-y-3">
            {tasks.length === 0 && (
              <div className="text-center py-16 text-gray-300 text-sm">No tasks yet. Create one!</div>
            )}
            {tasks.map(task => {
              const StatusIcon = TASK_STATUS_ICON[task.status] || Circle;
              return (
                <div key={task.id} className={`bg-white border rounded-2xl p-4 flex items-start gap-4 shadow-sm transition ${task.status === "done" ? "border-gray-100 opacity-60" : "border-gray-100"}`}>
                  <button onClick={() => cycleTaskStatus(task)} className="mt-0.5 shrink-0">
                    <StatusIcon className={`w-5 h-5 ${task.status === "done" ? "text-green-500" : task.status === "in_progress" ? "text-amber-500" : "text-gray-300"}`} />
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className={`font-medium text-sm ${task.status === "done" ? "line-through text-gray-400" : "text-gray-800"}`}>{task.title}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full border capitalize ${PRIORITY_STYLE[task.priority]}`}>{task.priority}</span>
                      {task.status !== "done" && <span className="text-xs bg-gray-50 border border-gray-200 text-gray-400 px-2 py-0.5 rounded-full capitalize">{task.status.replace("_", " ")}</span>}
                    </div>
                    {task.description && <p className="text-xs text-gray-400 mt-0.5">{task.description}</p>}
                    <div className="flex items-center gap-3 mt-1.5 text-xs text-gray-300">
                      {task.assigned_to_name && <span>👤 {task.assigned_to_name}</span>}
                      {task.due_date && <span>📅 {task.due_date}</span>}
                    </div>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button onClick={() => setTaskModal(task)} className="text-gray-300 hover:text-gray-600 transition">
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button onClick={() => deleteTask(task.id)} className="text-gray-300 hover:text-red-500 transition">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* SCHEDULE */}
        {activeTab === "Schedule" && (
          <>
            <div className="flex items-center gap-3">
              <label className="text-sm text-gray-400">Week starting:</label>
              <input type="date" value={scheduleWeek} onChange={e => setScheduleWeek(e.target.value)}
                className="bg-white border border-gray-200 text-gray-800 text-sm rounded-xl px-3 py-2 focus:outline-none" />
            </div>

            <div className="space-y-2">
              {weekDays.map(day => {
                const dayShifts = schedulesForWeek.filter(s => s.date === day);
                return (
                  <div key={day} className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
                    <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
                      <span className="text-sm font-semibold text-gray-800">{format(new Date(day + "T00:00"), "EEEE, MMM d")}</span>
                      <span className="text-xs text-gray-400">{dayShifts.length} shift{dayShifts.length !== 1 ? "s" : ""}</span>
                    </div>
                    {dayShifts.length === 0 ? (
                      <p className="px-5 py-3 text-xs text-gray-300">No shifts scheduled</p>
                    ) : (
                      dayShifts.map(s => (
                        <div key={s.id} className="flex items-center justify-between px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition">
                          <div className="flex items-center gap-3">
                            <div className="w-7 h-7 rounded-full bg-violet-100 flex items-center justify-center text-xs font-bold text-violet-600">
                              {(s.staff_name || s.staff_email)?.[0]?.toUpperCase()}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-800">{s.staff_name || s.staff_email}</p>
                              {s.notes && <p className="text-xs text-gray-400">{s.notes}</p>}
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="text-sm text-violet-600 font-mono">{s.shift_start} – {s.shift_end}</span>
                            <button onClick={() => setScheduleModal(s)} className="text-gray-300 hover:text-gray-600 transition">
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button onClick={() => deleteSchedule(s.id)} className="text-gray-300 hover:text-red-500 transition">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* Modals */}
      {taskModal && (
        <TaskModal
          users={users}
          task={taskModal === "new" ? null : taskModal}
          onSave={saveTask}
          onClose={() => setTaskModal(null)}
        />
      )}
      {scheduleModal && (
        <ScheduleModal
          users={users}
          shift={scheduleModal === "new" ? null : scheduleModal}
          onSave={saveSchedule}
          onClose={() => setScheduleModal(null)}
        />
      )}
    </div>
  );
}