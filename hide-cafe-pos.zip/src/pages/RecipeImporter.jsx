import React, { useState } from "react";
import { Upload, CheckCircle, AlertCircle, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function RecipeImporter() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const parseCSV = (text) => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map(h => h.trim().replace(/^\uFEFF/, ''));
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const row = {};
      headers.forEach((header, idx) => {
        row[header] = values[idx] || '';
      });
      data.push(row);
    }

    return data;
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'text/csv' || selectedFile.name.endsWith('.csv')) {
      setFile(selectedFile);
      setResult(null);
    } else {
      toast.error('Please select a valid CSV file');
    }
  };

  const handleUpload = async () => {
    if (!file) {
      toast.error('Please select a file');
      return;
    }

    setLoading(true);
    try {
      const text = await file.text();
      const csvData = parseCSV(text);

      if (csvData.length === 0) {
        toast.error('No valid data found in CSV');
        setLoading(false);
        return;
      }

      const response = await base44.functions.invoke('bulkUpdateProductRecipes', { csvData });
      setResult(response.data);
      toast.success(`Updated ${response.data.updated} products!`);
    } catch (error) {
      toast.error(`Upload failed: ${error.message}`);
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Bulk Update Product Recipes</h1>
          <p className="text-sm text-gray-500 mb-6">Upload a CSV file with product-ingredient mappings to update all recipes at once.</p>

          {/* File Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center mb-6 hover:border-violet-400 transition cursor-pointer" onClick={() => document.getElementById('file-input').click()}>
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-3" />
            <p className="text-sm font-semibold text-gray-700">Click to select CSV file</p>
            <p className="text-xs text-gray-500 mt-1">or drag and drop</p>
            <input
              id="file-input"
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {/* Selected File */}
          {file && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 flex items-center justify-between">
              <div>
                <p className="font-semibold text-blue-900 text-sm">{file.name}</p>
                <p className="text-xs text-blue-700">{(file.size / 1024).toFixed(2)} KB</p>
              </div>
              <button onClick={() => setFile(null)} className="text-blue-600 hover:text-blue-800 font-semibold text-sm">Remove</button>
            </div>
          )}

          {/* Upload Button */}
          <Button
            onClick={handleUpload}
            disabled={!file || loading}
            className="w-full bg-violet-600 hover:bg-violet-700 text-white py-2.5"
          >
            {loading ? (
              <>
                <Loader className="w-4 h-4 animate-spin mr-2" />
                Processing...
              </>
            ) : (
              'Upload & Update Recipes'
            )}
          </Button>

          {/* Results */}
          {result && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-900 mb-2">Upload Complete!</p>
                  <ul className="text-sm text-green-800 space-y-1">
                    <li>✓ Updated: <span className="font-bold">{result.updated}</span> products</li>
                    <li>✗ Skipped: <span className="font-bold">{result.skipped}</span> products (not found)</li>
                    <li>📊 Total rows: <span className="font-bold">{result.total}</span></li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Help Text */}
          <div className="mt-8 pt-6 border-t border-gray-100">
            <p className="text-xs font-semibold text-gray-500 uppercase mb-3">CSV Format Required</p>
            <p className="text-sm text-gray-600">Your CSV must have these columns:</p>
            <div className="bg-gray-50 rounded-lg p-3 mt-2 text-xs text-gray-700 font-mono">
              product_sku, product_name, inventory_item_sku, inventory_item_name, quantity, unit, ingredient_cost
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}