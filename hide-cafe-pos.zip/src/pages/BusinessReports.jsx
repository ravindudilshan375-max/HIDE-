import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { DollarSign, Gift, Calculator, Layers, BarChart3, RefreshCw, LogsIcon, TrendingDown, Activity } from "lucide-react";

const REPORT_CARDS = [
  { id: "taxes", label: "Taxes", icon: Calculator, page: "TaxesReport", description: "Tax collection & compliance" },
  { id: "tips", label: "Tips", icon: DollarSign, page: "TipsReport", description: "Tips & gratuity reports" },
  { id: "gift-cards", label: "Gift Cards", icon: Gift, page: "GiftCardsReport", description: "Gift card sales & redemptions" },
  { id: "business-days", label: "Business Days", icon: BarChart3, page: "BusinessDaysReport", description: "Daily business metrics" },
  { id: "shifts", label: "Shifts", icon: Layers, page: "ShiftsReport", description: "Staff shift analytics" },
  { id: "tills", label: "Tills", icon: Calculator, page: "TillsReport", description: "Till & cash management" },
  { id: "drawer-ops", label: "Drawer Operations", icon: RefreshCw, page: "DrawerOpsReport", description: "Drawer opening & closing" },
  { id: "voids-returns", label: "Voids & Returns", icon: TrendingDown, page: "VoidsReturnsReport", description: "Void & return transactions" },
  { id: "activity", label: "Activity Log", icon: Activity, page: "ActivityLog", description: "All system activity" },
];

export default function BusinessReports() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Business Reports</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {REPORT_CARDS.map(card => {
            const Icon = card.icon;
            return (
              <Link
                key={card.id}
                to={createPageUrl(card.page)}
                className="bg-white border border-gray-100 rounded-2xl p-5 hover:border-violet-300 hover:shadow-lg transition-all group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 bg-violet-50 rounded-xl flex items-center justify-center group-hover:bg-violet-100 transition">
                    <Icon className="w-5 h-5 text-violet-600" />
                  </div>
                  <span className="text-xl text-gray-200 group-hover:text-gray-300 transition">›</span>
                </div>
                <h3 className="font-semibold text-gray-900 group-hover:text-violet-600 transition">{card.label}</h3>
                <p className="text-xs text-gray-400 mt-1">{card.description}</p>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}