import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import SignatureViewModal from "@/components/orders/SignatureViewModal";
import { Input } from "@/components/ui/input";
import { format, subDays, startOfMonth, startOfDay, endOfDay } from "date-fns";
import {
  ArrowLeft, RefreshCw, Clock, AlertTriangle,
  AlertCircle, CheckCircle2, Smartphone, Globe, ShoppingBag, Monitor, X, PenLine, Receipt, Download, Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import OrderDetailModal from "@/components/orders/OrderDetailModal";

const STATUS_COLORS = {
  pending:   "bg-yellow-100 text-yellow-700 border-yellow-200",
  preparing: "bg-blue-100 text-blue-700 border-blue-200",
  ready:     "bg-green-100 text-green-700 border-green-200",
  served:    "bg-purple-100 text-purple-700 border-purple-200",
  paid:      "bg-gray-100 text-gray-500 border-gray-200",
  cancelled: "bg-red-100 text-red-700 border-red-200",
  voided:    "bg-red-100 text-red-700 border-red-300",
};

const RISK_CONFIG = {
  low:    { color: "text-green-600 bg-green-50 border-green-200",    icon: CheckCircle2,   label: "Low" },
  medium: { color: "text-amber-600 bg-amber-50 border-amber-200",    icon: AlertTriangle,  label: "Med" },
  high:   { color: "text-red-600 bg-red-50 border-red-200",          icon: AlertCircle,    label: "High" },
};

const PLATFORM_CONFIG = {
  pos:      { label: "POS",      color: "bg-violet-50 text-violet-600 border-violet-200",  icon: Monitor },
  talabat:  { label: "Talabat",  color: "bg-orange-50 text-orange-600 border-orange-200",  icon: Smartphone },
  website:  { label: "Website",  color: "bg-blue-50 text-blue-600 border-blue-200",        icon: Globe },
  careem:   { label: "Careem",   color: "bg-green-50 text-green-600 border-green-200",     icon: Smartphone },
  other:    { label: "Other",    color: "bg-gray-50 text-gray-500 border-gray-200",        icon: ShoppingBag },
};

const TABS = ["ALL", "PAID", "DONE", "VOID", "DISCOUNT"];
const PLATFORMS = ["ALL", "pos", "talabat", "website", "careem", "other"];

function PlatformBadge({ platform }) {
  const cfg = PLATFORM_CONFIG[platform] || PLATFORM_CONFIG.other;
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border font-medium ${cfg.color}`}>
      <Icon className="w-3 h-3" /> {cfg.label}
    </span>
  );
}

function RiskBadge({ risk }) {
  const cfg = RISK_CONFIG[risk] || RISK_CONFIG.low;
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border font-medium ${cfg.color}`}>
      <Icon className="w-3 h-3" /> {cfg.label}
    </span>
  );
}

export default function Orders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [tab, setTab] = useState("ALL");
  const [platformFilter, setPlatformFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [voidingOrder, setVoidingOrder] = useState(null);
  const [voidReason, setVoidReason] = useState("");
  const [voidReasons, setVoidReasons] = useState([]);
  const [selectedVoidReason, setSelectedVoidReason] = useState("");
  const [viewingSignatureOrder, setViewingSignatureOrder] = useState(null);
  const todayStr = format(new Date(), "yyyy-MM-dd");
  const [startDate, setStartDate] = useState(todayStr);
  const [endDate, setEndDate] = useState(todayStr);
  const [quickFilter, setQuickFilter] = useState("today");

  const applyQuickFilter = (key) => {
    setQuickFilter(key);
    const today = new Date();
    if (key === "today") { setStartDate(format(today, "yyyy-MM-dd")); setEndDate(format(today, "yyyy-MM-dd")); }
    else if (key === "yesterday") { const y = subDays(today, 1); setStartDate(format(y, "yyyy-MM-dd")); setEndDate(format(y, "yyyy-MM-dd")); }
    else if (key === "7days") { setStartDate(format(subDays(today, 6), "yyyy-MM-dd")); setEndDate(format(today, "yyyy-MM-dd")); }
    else if (key === "month") { setStartDate(format(startOfMonth(today), "yyyy-MM-dd")); setEndDate(format(today, "yyyy-MM-dd")); }
    else if (key === "custom") { /* keep current dates */ }
  };

  const load = async () => {
    setLoading(true);
    const branchId = localStorage.getItem("selectedBranchId");
    const orders = await base44.entities.Order.list("-created_date", 500);
    const filtered = branchId ? orders.filter(o => o.branch_id === branchId) : orders;
    setOrders(filtered);
    setSelectedBranchId(branchId);
    setLoading(false);
    base44.entities.Reason.filter({ category: "void_and_return" }).then(reasons => {
      setVoidReasons(reasons.filter(r => !r.is_deleted));
    }).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const voidOrder = async (order) => {
    if (!voidReason.trim()) return;
    const session = (() => { try { return JSON.parse(localStorage.getItem("pos_staff_session") || "{}"); } catch { return {}; } })();
    const updates = {
      status: "voided",
      void_reason: voidReason,
      voided_by: session.name || "Manager",
      void_time: new Date().toISOString(),
    };
    await base44.entities.Order.update(order.id, updates);
    await base44.entities.AuditLog.create({
      actor_email: session.email || "pos",
      actor_name: session.name || "Manager",
      action: "void",
      entity_type: "Order",
      entity_id: order.id,
      entity_name: order.order_number || order.id,
      description: `Order voided — ${voidReason}`,
      severity: "warning",
    }).catch(() => {});
    setOrders(prev => prev.map(o => o.id === order.id ? { ...o, ...updates } : o));
    setVoidingOrder(null);
    setVoidReason("");
  };

  const exportCSV = () => {
    const rows = filtered;
    const headers = ["Order #", "Date", "Type", "Platform", "Customer", "Status", "Total", "Discount", "Commission", "Profit"];
    const lines = rows.map(o => {
      const rev = o.total || 0;
      const comm = rev * ((o.commission_rate || 0) / 100);
      return [
        o.order_number || o.id,
        o.created_date ? format(new Date(o.created_date), "yyyy-MM-dd HH:mm") : "",
        o.type || "",
        o.platform || "pos",
        o.customer_name || "",
        o.status || "",
        rev.toFixed(2),
        (o.discount || 0).toFixed(2),
        comm.toFixed(2),
        (rev - comm).toFixed(2),
      ].join(",");
    });
    const csv = [headers.join(","), ...lines].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `orders_${startDate}_${endDate}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const getFiltered = () => {
    let f = orders;
    if (selectedBranchId) f = f.filter(o => o.branch_id === selectedBranchId);
    f = f.filter(o => !o.order_number?.startsWith("KDS-"));
    // Date filter
    if (startDate) {
      const start = new Date(startDate + "T00:00:00");
      f = f.filter(o => o.created_date && new Date(o.created_date) >= start);
    }
    if (endDate) {
      const end = new Date(endDate + "T23:59:59");
      f = f.filter(o => o.created_date && new Date(o.created_date) <= end);
    }
    if (tab === "PAID") f = f.filter(o => o.status === "paid");
    else if (tab === "DONE") f = f.filter(o => o.status === "served");
    else if (tab === "VOID") f = f.filter(o => o.status === "cancelled" || o.status === "voided");
    else if (tab === "DISCOUNT") f = f.filter(o => o.discount && o.discount > 0);
    if (platformFilter !== "ALL") f = f.filter(o => (o.platform || "pos") === platformFilter);
    if (search) f = f.filter(o =>
      o.order_number?.toLowerCase().includes(search.toLowerCase()) ||
      o.customer_name?.toLowerCase().includes(search.toLowerCase())
    );
    return f;
  };

  const filtered = getFiltered();

  // Summary stats
  const totalRevenue = filtered.reduce((s, o) => s + (o.total || 0), 0);
  const totalCommission = filtered.reduce((s, o) => s + ((o.total || 0) * ((o.commission_rate || 0) / 100)), 0);
  const netProfit = totalRevenue - totalCommission;
  const refundedCount = filtered.filter(o => o.is_refunded).length;

  return (
    <div className="flex flex-col h-screen bg-gray-50">

      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 space-y-3">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate(createPageUrl("Dashboard"))}
            className="flex items-center gap-2 text-sm font-semibold text-gray-600 hover:text-violet-600 transition"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-lg font-bold text-gray-900">Orders</h1>
          </div>
          <button
            onClick={load}
            className="flex items-center gap-2 text-sm font-semibold bg-violet-600 hover:bg-violet-700 text-white px-3 py-2 rounded-lg transition"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Sync
          </button>
        </div>

        {/* Quick date filters */}
        <div className="flex gap-1 flex-wrap items-center">
          <Calendar className="w-3.5 h-3.5 text-gray-400" />
          {[["today","Today"],["yesterday","Yesterday"],["7days","7 Days"],["month","This Month"],["custom","Custom"]].map(([k,l]) => (
            <button key={k} onClick={() => applyQuickFilter(k)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                quickFilter === k ? "bg-violet-600 text-white border-violet-600" : "bg-white text-gray-500 border-gray-200 hover:border-violet-400 hover:text-violet-600"
              }`}>
              {l}
            </button>
          ))}
          <div className="flex items-center gap-2 ml-2">
            <input type="date" value={startDate} onChange={e => { setStartDate(e.target.value); setQuickFilter("custom"); }}
              className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:ring-1 focus:ring-violet-400" />
            <span className="text-gray-400 text-xs">—</span>
            <input type="date" value={endDate} onChange={e => { setEndDate(e.target.value); setQuickFilter("custom"); }}
              className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs text-gray-700 focus:outline-none focus:ring-1 focus:ring-violet-400" />
          </div>
          <Button variant="outline" size="sm" onClick={exportCSV} className="ml-auto border-gray-200 text-xs gap-1">
            <Download className="w-3.5 h-3.5" /> Export CSV
          </Button>
        </div>

        {/* Search + Platform Filter row */}
        <div className="flex gap-3 flex-wrap">
          <Input
            placeholder="Search order # or customer..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="flex-1 min-w-48 bg-gray-50 border-gray-200 text-sm"
          />
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1 overflow-x-auto">
            {PLATFORMS.map(p => (
              <button key={p}
                onClick={() => setPlatformFilter(p)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition whitespace-nowrap ${
                  platformFilter === p ? "bg-white text-violet-700 shadow-sm" : "text-gray-400 hover:text-gray-700"
                }`}>
                {p === "ALL" ? "All Platforms" : PLATFORM_CONFIG[p]?.label || p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200 px-6 flex gap-6">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`text-sm font-semibold py-3 border-b-2 transition-all ${
              tab === t ? "text-gray-900 border-violet-600" : "text-gray-400 border-transparent hover:text-gray-600"
            }`}>
            {t}
          </button>
        ))}
      </div>

      {/* Summary Bar */}
      {filtered.length > 0 && (
        <div className="bg-white border-b border-gray-100 px-6 py-2.5 flex gap-6 text-xs overflow-x-auto">
          <div className="flex items-center gap-1.5 text-gray-500">
            <span className="font-medium text-gray-700">{filtered.length}</span> orders
          </div>
          <div className="flex items-center gap-1.5 text-gray-500">
            Revenue: <span className="font-semibold text-gray-800">${totalRevenue.toFixed(2)}</span>
          </div>
          <div className="flex items-center gap-1.5 text-red-500">
            Commission: <span className="font-semibold">−${totalCommission.toFixed(2)}</span>
          </div>
          <div className="flex items-center gap-1.5 text-green-600">
            Net Profit: <span className="font-semibold">${netProfit.toFixed(2)}</span>
          </div>
          {refundedCount > 0 && (
            <div className="flex items-center gap-1.5 text-amber-600">
              <AlertTriangle className="w-3 h-3" />
              <span className="font-semibold">{refundedCount} refunded</span>
            </div>
          )}
        </div>
      )}

      {/* Orders Table */}
      <div className="flex-1 overflow-auto p-4">
        {loading && <div className="text-center py-12 text-gray-400 text-sm">Loading orders...</div>}
        {!loading && filtered.length === 0 && (
          <div className="text-center py-12 text-gray-400 text-sm">No orders found</div>
        )}

        {!loading && filtered.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {/* Table Header */}
            <div className="grid grid-cols-12 px-5 py-3 border-b border-gray-100 bg-gray-50 text-xs font-semibold text-gray-400 uppercase tracking-wide">
              <span className="col-span-2">Order</span>
              <span className="col-span-1">Platform</span>
              <span className="col-span-1">Type</span>
              <span className="col-span-1">Time</span>
              <span className="col-span-1">Risk</span>
              <span className="col-span-1 text-right">Revenue</span>
              <span className="col-span-1 text-right">Commission</span>
              <span className="col-span-1 text-right">Profit</span>
              <span className="col-span-1 text-center">Refund</span>
              <span className="col-span-2 text-center">Status</span>
            </div>

            {filtered.map(order => {
              const platform = order.platform || "pos";
              const risk = order.risk_level || "low";
              const commissionRate = order.commission_rate || 0;
              const revenue = order.total || 0;
              const commission = revenue * (commissionRate / 100);
              const profit = revenue - commission;
              const isRefunded = order.is_refunded;

              return (
                <div
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className={`grid grid-cols-12 px-5 py-3.5 border-b border-gray-50 hover:bg-gray-50 transition cursor-pointer items-center text-sm ${isRefunded ? "bg-amber-50/40" : ""} ${order.status === "voided" ? "bg-red-50/40" : ""}`}
                >
                  {/* Order # */}
                  <div className="col-span-2">
                    <div className="flex items-center gap-2">
                      {isRefunded && <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />}
                      <div>
                        <p className="font-semibold text-gray-800 text-xs">{order.order_number || `#${order.id?.slice(-6)}`}</p>
                        <p className="text-xs text-gray-400">{order.customer_name || order.cashier_name || "—"}</p>
                        {order.status === "voided" && order.voided_by && (
                          <p className="text-[10px] text-red-500 mt-0.5">By: {order.voided_by}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Platform */}
                  <div className="col-span-1">
                    <PlatformBadge platform={platform} />
                  </div>

                  {/* Type */}
                  <div className="col-span-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${
                      order.type === "dine-in"
                        ? "bg-amber-50 text-amber-600 border-amber-200"
                        : "bg-blue-50 text-blue-600 border-blue-200"
                    }`}>
                      {order.type === "dine-in" ? `T${order.table_number}` : "Takeaway"}
                    </span>
                  </div>

                  {/* Time */}
                  <div className="col-span-1 flex items-center gap-1 text-xs text-gray-400">
                    <Clock className="w-3 h-3" />
                    {order.created_date ? format(new Date(order.created_date), "HH:mm") : "—"}
                  </div>

                  {/* Risk */}
                  <div className="col-span-1">
                    <RiskBadge risk={risk} />
                  </div>

                  {/* Revenue */}
                  <div className="col-span-1 text-right">
                    <span className="font-semibold text-gray-800">${revenue.toFixed(2)}</span>
                    {order.discount > 0 && (
                      <p className="text-[10px] text-orange-500 font-medium">−${Number(order.discount).toFixed(2)} disc</p>
                    )}
                  </div>

                  {/* Commission */}
                  <div className="col-span-1 text-right">
                    {commissionRate > 0 ? (
                      <div>
                        <span className="text-red-500 font-medium text-xs">−${commission.toFixed(2)}</span>
                        <p className="text-[10px] text-gray-300">{commissionRate}%</p>
                      </div>
                    ) : (
                      <span className="text-gray-300 text-xs">—</span>
                    )}
                  </div>

                  {/* Profit */}
                  <div className="col-span-1 text-right">
                    <span className={`font-semibold text-xs ${profit >= revenue * 0.7 ? "text-green-600" : profit > 0 ? "text-amber-600" : "text-red-600"}`}>
                      ${profit.toFixed(2)}
                    </span>
                  </div>

                  {/* Refund */}
                  <div className="col-span-1 text-center">
                    {isRefunded ? (
                      <div className="flex flex-col items-center">
                        <span className="text-xs font-semibold text-amber-600 bg-amber-50 border border-amber-200 rounded-full px-2 py-0.5">Refunded</span>
                        {order.refund_amount > 0 && <span className="text-[10px] text-gray-400 mt-0.5">−${order.refund_amount.toFixed(2)}</span>}
                      </div>
                    ) : (
                      <span className="text-gray-200 text-xs">—</span>
                    )}
                  </div>

                  {/* Status */}
                  <div className="col-span-2 flex justify-center gap-2 items-center" onClick={e => e.stopPropagation()}>
                    <span className={`text-xs px-2 py-1 rounded-full border font-medium ${STATUS_COLORS[order.status]}`}>
                      {order.status}
                    </span>
                    {order.status !== "paid" && order.status !== "cancelled" && order.status !== "voided" && (
                    <button
                      onClick={() => setVoidingOrder(order)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 p-1 rounded transition"
                      title="Void order"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                    )}
                    <button
                      onClick={() => setViewingSignatureOrder(order)}
                      className="text-violet-400 hover:text-violet-600 hover:bg-violet-50 p-1 rounded transition"
                      title="View signature"
                    >
                      <PenLine className="w-3.5 h-3.5" />
                    </button>
                    {order.order_number && (
                      <a
                        href={createPageUrl(`DigitalReceipt`) + `?order_id=${order.order_number}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-green-500 hover:text-green-700 hover:bg-green-50 p-1 rounded transition"
                        title="View digital receipt"
                        onClick={e => e.stopPropagation()}
                      >
                        <Receipt className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {selectedOrder && (
        <OrderDetailModal order={selectedOrder} onClose={() => setSelectedOrder(null)} />
      )}

      {viewingSignatureOrder && (
        <SignatureViewModal
          orderId={viewingSignatureOrder.id}
          orderNumber={viewingSignatureOrder.order_number}
          onClose={() => setViewingSignatureOrder(null)}
        />
      )}

      {voidingOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-lg p-6 max-w-sm w-full">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Void Order</h2>
            <p className="text-sm text-gray-600 mb-4">Order: <span className="font-semibold">{voidingOrder.order_number}</span></p>
            
            {voidReasons.length > 0 ? (
              <div className="mb-4">
                <label className="block text-xs font-semibold text-gray-600 mb-2">Select Reason</label>
                <div className="space-y-2">
                  {voidReasons.map(reason => (
                    <button
                      key={reason.id}
                      onClick={() => setVoidReason(reason.name)}
                      className={`w-full text-left px-3 py-2 rounded-lg border-2 transition ${
                        voidReason === reason.name
                          ? "border-red-500 bg-red-50"
                          : "border-gray-200 hover:border-red-300"
                      }`}
                    >
                      <span className="text-sm text-gray-700">{reason.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <textarea
                placeholder="Enter reason for voiding this order..."
                value={voidReason}
                onChange={e => setVoidReason(e.target.value)}
                className="w-full border border-gray-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 mb-4"
                rows={4}
              />
            )}
            
            <div className="flex gap-3 justify-end">
              <Button
                variant="outline"
                onClick={() => { setVoidingOrder(null); setVoidReason(""); setSelectedVoidReason(""); }}
              >
                Cancel
              </Button>
              <Button
                onClick={() => voidOrder(voidingOrder)}
                disabled={!voidReason.trim()}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Void Order
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}