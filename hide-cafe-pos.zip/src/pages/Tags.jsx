import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, Plus, Trash2, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const TAG_TYPES = [
  { name: "Customer Tag", key: "customer", description: "Create tags to help you filter and group customers easily. You can create tags such as VIP Customers, Citizens, etc." },
  { name: "Branch Tag", key: "branch", description: "Create tags to help you filter and group branches easily. You can create tags such as Mall Branches, High Traffic, etc." },
  { name: "Inventory Item Tag", key: "inventory_item", description: "Create tags to help you filter and group inventory items easily. You can create tags such as Frozen Items, Dairy, etc." },
  { name: "Order Tag", key: "order", description: "Create tags to help you filter and group orders easily. You can create tags such as Phone Orders, VIP Delivery, etc." },
  { name: "Supplier Tag", key: "supplier", description: "Create tags to help you filter and group suppliers easily. You can create tags such as Cash Suppliers, High Quality, etc." },
  { name: "User Tag", key: "user", description: "Create tags to help you filter and group users easily. You can create tags such as Waiters, Managers, etc." },
  { name: "Product Tag", key: "product", description: "Create tags to help you filter and group products easily. You can create tags such as Vegan, Healthy, etc." },
  { name: "Device Tag", key: "device", description: "Create tags to help you filter and group devices easily. You can create tags such as Kitchen Printer, Main Register, etc." },
];

export default function Tags() {
  const [tags, setTags] = useState({});
  const [activeTab, setActiveTab] = useState("General");
  const [showForm, setShowForm] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [formData, setFormData] = useState({ name: "", color: "#7C3AED" });
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTags();
  }, []);

  const loadTags = async () => {
    setLoading(true);
    const allTags = {};
    TAG_TYPES.forEach(type => {
      allTags[type.key] = [];
    });
    setTags(allTags);
    setLoading(false);
  };

  const openForm = (type) => {
    setSelectedType(type);
    setFormData({ name: "", color: "#7C3AED" });
    setEditingId(null);
    setShowForm(true);
  };

  const saveTag = async () => {
    if (!formData.name.trim()) return;

    if (editingId) {
      // Update logic would go here
    } else {
      // Create logic would go here
      setTags(prev => ({
        ...prev,
        [selectedType.key]: [...(prev[selectedType.key] || []), { id: Date.now(), name: formData.name, color: formData.color }]
      }));
    }

    setShowForm(false);
    setFormData({ name: "", color: "#7C3AED" });
  };

  const deleteTag = (tagId) => {
    // Delete logic would go here
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Link to={createPageUrl("Manage")} className="text-gray-500 hover:text-gray-700">
            <ChevronLeft className="w-6 h-6" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Tags</h1>
            <p className="text-sm text-gray-500 mt-1">Manage and organize tags for different entities</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-8 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("General")}
            className={`pb-3 font-semibold transition-colors ${activeTab === "General" ? "text-violet-600 border-b-2 border-violet-600" : "text-gray-500 hover:text-gray-700"}`}
          >
            General
          </button>
          <button
            onClick={() => setActiveTab("Deleted")}
            className={`pb-3 font-semibold transition-colors ${activeTab === "Deleted" ? "text-violet-600 border-b-2 border-violet-600" : "text-gray-500 hover:text-gray-700"}`}
          >
            Deleted
          </button>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              placeholder="Search tags..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none focus:border-violet-400"
            />
          </div>
        </div>

        {/* Tag Types */}
        <div className="space-y-6">
          {TAG_TYPES.map(type => (
            <div key={type.key} className="bg-white rounded-2xl border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{type.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{type.description}</p>
                </div>
                <button
                  onClick={() => openForm(type)}
                  className="flex items-center gap-2 bg-white border border-gray-200 hover:border-violet-400 rounded-lg px-3 py-2 text-sm font-semibold text-gray-600 hover:text-violet-600 transition"
                >
                  <Plus className="w-4 h-4" />
                  Create Tag
                </button>
              </div>

              {/* Tags List */}
              <div className="space-y-2">
                {tags[type.key] && tags[type.key].length > 0 ? (
                  tags[type.key].map(tag => (
                    <div key={tag.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                      <div className="flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: tag.color }} />
                        <span className="text-sm font-medium text-gray-700">{tag.name}</span>
                      </div>
                      <button
                        onClick={() => deleteTag(tag.id)}
                        className="text-gray-400 hover:text-red-500 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-gray-400 text-center py-4">No tags created yet</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Tag Modal */}
      {showForm && selectedType && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full mx-4 space-y-4">
            <h2 className="text-xl font-bold text-gray-900">Create {selectedType.name}</h2>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Tag Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., VIP Customers"
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Color</label>
              <div className="flex gap-2">
                {["#7C3AED", "#EC4899", "#F59E0B", "#10B981", "#3B82F6", "#EF4444"].map(color => (
                  <button
                    key={color}
                    onClick={() => setFormData({ ...formData, color })}
                    className={`w-8 h-8 rounded-lg border-2 transition ${formData.color === color ? "border-gray-800" : "border-transparent"}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={saveTag}
                disabled={!formData.name.trim()}
                className="flex-1 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition"
              >
                Create Tag
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}