import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Users, Clock, DollarSign, AlertTriangle, TrendingUp, Building2, Calendar, CheckCircle, ArrowRight, RefreshCw } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";

export default function HRDashboard() {
  const [staff, setStaff] = useState([]);
  const [timecards, setTimecards] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [salesToday, setSalesToday] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    setLoading(true);
    const today = new Date().toISOString().split("T")[0];
    const [staffData, timecardData, deptData, scheduleData, ordersData] = await Promise.all([
      base44.entities.StaffMember.list(),
      base44.entities.StaffTimecard.filter({ status: "active" }),
      base44.entities.Department.list(),
      base44.entities.StaffSchedule.filter({ date: today }),
      base44.entities.Order.list("-created_date", 300),
    ]);
    setStaff(staffData);
    setTimecards(timecardData);
    setDepartments(deptData);
    setSchedules(scheduleData);
    const todayOrders = ordersData.filter(o => o.status === "paid" && o.created_date?.startsWith(today));
    setSalesToday(todayOrders.reduce((s, o) => s + (o.total || 0), 0));
    setLoading(false);
  };

  const activeStaff = staff.filter(s => s.is_active !== false && s.employment_status !== "terminated");

  const laborCostToday = timecards.reduce((sum, tc) => {
    const member = staff.find(s => s.email === tc.staff_email || s.name === tc.staff_name);
    const hourlyRate = member?.hourly_rate || 0;
    const hoursWorked = (Date.now() - new Date(tc.clock_in).getTime()) / (1000 * 60 * 60);
    return sum + Math.max(0, hourlyRate * hoursWorked);
  }, 0);

  const laborPct = salesToday > 0 ? ((laborCostToday / salesToday) * 100).toFixed(1) : 0;

  const overtimeAlerts = timecards.filter(tc => {
    const hours = (Date.now() - new Date(tc.clock_in).getTime()) / (1000 * 60 * 60);
    return hours > 8;
  });

  const deptStats = departments.map(d => ({
    ...d,
    count: staff.filter(s => s.department_id === d.id && s.is_active !== false).length,
    clockedIn: timecards.filter(tc => {
      const member = staff.find(m => m.email === tc.staff_email || m.name === tc.staff_name);
      return member?.department_id === d.id;
    }).length,
  }));

  const noDeptCount = activeStaff.filter(s => !s.department_id).length;

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <p className="text-gray-400 text-sm">Loading HR data…</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 pt-6 pb-10">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">HR Dashboard</h1>
            <p className="text-violet-200 text-sm mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={loadData} className="p-2 bg-white/20 hover:bg-white/30 text-white rounded-xl transition">
              <RefreshCw className="w-4 h-4" />
            </button>
            <Link to={createPageUrl("StaffManagement")} className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white font-semibold rounded-xl px-4 py-2 text-sm transition">
              <Users className="w-4 h-4" /> Manage Staff
            </Link>
          </div>
        </div>
      </div>

      <div className="px-6 -mt-6 pb-8 space-y-5">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-xl bg-violet-100 flex items-center justify-center">
                <Users className="w-4 h-4 text-violet-600" />
              </div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Total Staff</p>
            </div>
            <p className="text-3xl font-bold text-gray-900">{activeStaff.length}</p>
            <p className="text-xs text-gray-400 mt-1">{staff.filter(s => s.employment_status === "terminated").length} terminated</p>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-xl bg-green-100 flex items-center justify-center">
                <Clock className="w-4 h-4 text-green-600" />
              </div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Clocked In</p>
            </div>
            <p className="text-3xl font-bold text-gray-900">{timecards.length}</p>
            <p className="text-xs text-gray-400 mt-1">of {activeStaff.length} active staff</p>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-xl bg-blue-100 flex items-center justify-center">
                <DollarSign className="w-4 h-4 text-blue-600" />
              </div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Labor Cost Today</p>
            </div>
            <p className="text-3xl font-bold text-gray-900">AED {laborCostToday.toFixed(0)}</p>
            <p className="text-xs text-gray-400 mt-1">
              {salesToday > 0 ? `${laborPct}% of AED ${salesToday.toFixed(0)} sales` : "no sales data yet"}
            </p>
          </div>

          <div className={`rounded-2xl border shadow-sm p-5 ${overtimeAlerts.length > 0 ? "bg-red-50 border-red-200" : "bg-white border-gray-100"}`}>
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${overtimeAlerts.length > 0 ? "bg-red-100" : "bg-amber-100"}`}>
                <AlertTriangle className={`w-4 h-4 ${overtimeAlerts.length > 0 ? "text-red-600" : "text-amber-600"}`} />
              </div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Overtime Alerts</p>
            </div>
            <p className="text-3xl font-bold text-gray-900">{overtimeAlerts.length}</p>
            <p className="text-xs text-gray-400 mt-1">staff over 8 hrs today</p>
          </div>
        </div>

        {/* Two Column */}
        <div className="grid md:grid-cols-2 gap-5">
          {/* Currently Clocked In */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-bold text-gray-900 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 inline-block animate-pulse" />
                Working Now ({timecards.length})
              </h2>
              <Link to={createPageUrl("StaffTimecards")} className="text-xs text-violet-600 font-semibold hover:underline">View All →</Link>
            </div>
            <div className="divide-y divide-gray-50 max-h-80 overflow-y-auto">
              {timecards.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-10">No staff currently clocked in</p>
              ) : (
                timecards.map(tc => {
                  const hours = (Date.now() - new Date(tc.clock_in).getTime()) / (1000 * 60 * 60);
                  const isOT = hours > 8;
                  return (
                    <div key={tc.id} className={`flex items-center gap-3 px-5 py-3 ${isOT ? "bg-red-50" : ""}`}>
                      <div className="w-8 h-8 rounded-full bg-violet-100 flex items-center justify-center text-xs font-bold text-violet-600 shrink-0">
                        {tc.staff_name?.[0]?.toUpperCase() || "?"}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-900">{tc.staff_name}</p>
                        <p className="text-xs text-gray-400">{tc.branch_name} · Since {tc.clock_in ? format(new Date(tc.clock_in), "HH:mm") : "—"}</p>
                      </div>
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full shrink-0 ${isOT ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`}>
                        {hours.toFixed(1)}h {isOT ? "⚠️" : ""}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Departments */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-bold text-gray-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-gray-400" />
                Departments ({departments.length})
              </h2>
              <Link to={createPageUrl("HRDepartments")} className="text-xs text-violet-600 font-semibold hover:underline">Manage →</Link>
            </div>
            <div className="divide-y divide-gray-50">
              {deptStats.length === 0 ? (
                <div className="py-10 text-center">
                  <p className="text-sm text-gray-400 mb-2">No departments created yet</p>
                  <Link to={createPageUrl("HRDepartments")} className="text-xs text-violet-600 font-semibold hover:underline">Add Departments</Link>
                </div>
              ) : (
                deptStats.map(d => (
                  <div key={d.id} className="flex items-center gap-3 px-5 py-3">
                    <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: d.color || "#7C3AED" }} />
                    <p className="text-sm font-semibold text-gray-900 flex-1">{d.name}</p>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-gray-500">{d.count} staff</span>
                      {d.clockedIn > 0 && (
                        <span className="bg-green-100 text-green-700 font-semibold px-2 py-0.5 rounded-full">{d.clockedIn} in</span>
                      )}
                    </div>
                  </div>
                ))
              )}
              {noDeptCount > 0 && (
                <div className="flex items-center gap-3 px-5 py-3">
                  <div className="w-3 h-3 rounded-full bg-gray-200 shrink-0" />
                  <p className="text-sm text-gray-400 flex-1">Unassigned</p>
                  <span className="text-xs text-gray-400">{noDeptCount} staff</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-bold text-gray-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-400" />
              Today's Schedule ({schedules.length} shifts)
            </h2>
            <Link to={createPageUrl("Staff")} className="text-xs text-violet-600 font-semibold hover:underline">Manage →</Link>
          </div>
          {schedules.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-8">No shifts scheduled for today</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="text-left py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Employee</th>
                    <th className="text-left py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Shift</th>
                    <th className="text-left py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase hidden md:table-cell">Role</th>
                    <th className="text-left py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {schedules.map(s => {
                    const isClockedIn = timecards.some(tc => tc.staff_email === s.staff_email || tc.staff_name === s.staff_name);
                    return (
                      <tr key={s.id} className="hover:bg-gray-50">
                        <td className="py-3 px-5 font-medium text-gray-900">{s.staff_name}</td>
                        <td className="py-3 px-5 text-gray-600">{s.shift_start} – {s.shift_end}</td>
                        <td className="py-3 px-5 text-gray-500 hidden md:table-cell">{s.role || "—"}</td>
                        <td className="py-3 px-5">
                          {isClockedIn ? (
                            <span className="inline-flex items-center gap-1 text-xs bg-green-100 text-green-700 font-semibold px-2.5 py-1 rounded-full">
                              <CheckCircle className="w-3 h-3" /> Clocked In
                            </span>
                          ) : (
                            <span className="inline-block text-xs bg-gray-100 text-gray-500 font-semibold px-2.5 py-1 rounded-full">Scheduled</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: "Staff Members", page: "StaffManagement", icon: Users, color: "bg-violet-50 text-violet-600" },
            { label: "Timecards", page: "StaffTimecards", icon: Clock, color: "bg-green-50 text-green-600" },
            { label: "Payroll", page: "HRPayroll", icon: DollarSign, color: "bg-blue-50 text-blue-600" },
            { label: "Labor Reports", page: "HRLaborReports", icon: TrendingUp, color: "bg-amber-50 text-amber-600" },
          ].map(link => {
            const Icon = link.icon;
            return (
              <Link key={link.page} to={createPageUrl(link.page)}
                className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center gap-3 hover:shadow-md transition group">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${link.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="font-semibold text-sm text-gray-900 flex-1">{link.label}</span>
                <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-gray-600 transition" />
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}