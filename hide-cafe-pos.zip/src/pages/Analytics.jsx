import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import {
  startOfDay, startOfWeek, startOfMonth, isAfter,
  format, eachDayOfInterval, eachWeekOfInterval, subDays
} from "date-fns";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell, Legend
} from "recharts";
import {
  TrendingUp, ShoppingBag, DollarSign, Clock,
  CreditCard, Award, BarChart2, Star
} from "lucide-react";

const PERIODS = [
  { label: "Today", key: "day" },
  { label: "This Week", key: "week" },
  { label: "This Month", key: "month" },
];

const PAYMENT_COLORS = {
  cash: "#10b981",
  card: "#6366f1",
  mobile: "#f59e0b",
  online: "#3b82f6",
  split: "#8b5cf6",
};

const CHART_COLORS = ["#7c3aed", "#6366f1", "#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#f97316", "#84cc16"];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-100 shadow-lg rounded-xl px-4 py-3 text-sm">
      <p className="text-gray-400 text-xs mb-1.5">{label}</p>
      {payload.map((p, i) => (
        <p key={i} className="font-semibold" style={{ color: p.color }}>
          {p.name}: {p.name === "Revenue" || p.name?.includes("$") ? `$${Number(p.value).toFixed(2)}` : p.value}
        </p>
      ))}
    </div>
  );
};

function StatCard({ icon: Icon, label, value, sub, color = "text-violet-600", bg = "bg-violet-50" }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-sm text-gray-500 mt-1">{label}</p>
      {sub && <p className="text-xs text-gray-300 mt-0.5">{sub}</p>}
    </div>
  );
}

function SectionHeader({ title, description }) {
  return (
    <div className="mb-4">
      <h2 className="text-base font-bold text-gray-800">{title}</h2>
      {description && <p className="text-xs text-gray-400 mt-0.5">{description}</p>}
    </div>
  );
}

export default function Analytics() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState("week");

  useEffect(() => {
    base44.entities.Order.list("-created_date", 1000).then(data => {
      setOrders(data);
      setLoading(false);
    });
  }, []);

  const periodStart = useMemo(() => {
    if (period === "day") return startOfDay(new Date());
    if (period === "week") return startOfWeek(new Date(), { weekStartsOn: 1 });
    return startOfMonth(new Date());
  }, [period]);

  const paidOrders = useMemo(() =>
    orders.filter(o => o.status === "paid" && o.created_date && isAfter(new Date(o.created_date), periodStart)),
    [orders, periodStart]
  );

  // ── Sales Trend ──
  const salesTrendData = useMemo(() => {
    if (period === "day") {
      const hours = Array.from({ length: 24 }, (_, h) => ({ label: `${h}:00`, Revenue: 0, Orders: 0 }));
      paidOrders.forEach(o => {
        const h = new Date(o.created_date).getHours();
        hours[h].Revenue += o.total || 0;
        hours[h].Orders += 1;
      });
      return hours.filter((_, i) => i >= 6); // show from 6am
    }
    if (period === "week") {
      const days = eachDayOfInterval({ start: periodStart, end: new Date() });
      return days.map(d => {
        const dayOrders = paidOrders.filter(o => format(new Date(o.created_date), "yyyy-MM-dd") === format(d, "yyyy-MM-dd"));
        return {
          label: format(d, "EEE"),
          Revenue: dayOrders.reduce((s, o) => s + (o.total || 0), 0),
          Orders: dayOrders.length
        };
      });
    }
    // month — by day
    const days = eachDayOfInterval({ start: periodStart, end: new Date() });
    return days.map(d => {
      const dayOrders = paidOrders.filter(o => format(new Date(o.created_date), "yyyy-MM-dd") === format(d, "yyyy-MM-dd"));
      return {
        label: format(d, "d"),
        Revenue: dayOrders.reduce((s, o) => s + (o.total || 0), 0),
        Orders: dayOrders.length
      };
    });
  }, [paidOrders, period, periodStart]);

  // ── Top Selling Items ──
  const topItems = useMemo(() => {
    const map = {};
    paidOrders.forEach(o => {
      (o.items || []).forEach(item => {
        if (!map[item.name]) map[item.name] = { name: item.name, qty: 0, revenue: 0 };
        map[item.name].qty += item.quantity || 1;
        map[item.name].revenue += item.subtotal || 0;
      });
    });
    return Object.values(map).sort((a, b) => b.qty - a.qty).slice(0, 8);
  }, [paidOrders]);

  // ── Revenue by Payment Method ──
  const paymentMethodData = useMemo(() => {
    const map = {};
    paidOrders.forEach(o => {
      const method = o.payment_method || "other";
      if (!map[method]) map[method] = { name: method, value: 0, count: 0 };
      map[method].value += o.total || 0;
      map[method].count += 1;
    });
    return Object.values(map).sort((a, b) => b.value - a.value);
  }, [paidOrders]);

  // ── Peak Order Times ──
  const peakHoursData = useMemo(() => {
    const hours = Array.from({ length: 24 }, (_, h) => ({ hour: `${h}:00`, Orders: 0, Revenue: 0 }));
    paidOrders.forEach(o => {
      const h = new Date(o.created_date).getHours();
      hours[h].Orders += 1;
      hours[h].Revenue += o.total || 0;
    });
    return hours.filter((_, i) => i >= 6 && i <= 23);
  }, [paidOrders]);

  const peakHour = useMemo(() => {
    if (!peakHoursData.length) return null;
    return peakHoursData.reduce((max, h) => h.Orders > max.Orders ? h : max, peakHoursData[0]);
  }, [peakHoursData]);

  // ── Summary Stats ──
  const stats = useMemo(() => {
    const revenue = paidOrders.reduce((s, o) => s + (o.total || 0), 0);
    const count = paidOrders.length;
    const avg = count ? revenue / count : 0;
    const totalItems = paidOrders.reduce((s, o) => s + (o.items || []).reduce((a, i) => a + (i.quantity || 1), 0), 0);
    return { revenue, count, avg, totalItems };
  }, [paidOrders]);

  if (loading) return (
    <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center">
      <p className="text-gray-400 text-sm animate-pulse">Loading analytics…</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 px-6 py-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BarChart2 className="w-6 h-6 text-violet-600" /> Analytics
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
        </div>
        <div className="flex bg-gray-100 rounded-xl p-1 gap-1">
          {PERIODS.map(p => (
            <button key={p.key} onClick={() => setPeriod(p.key)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${period === p.key ? "bg-violet-600 text-white shadow-sm" : "text-gray-500 hover:text-gray-800"}`}>
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-8">

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={DollarSign} label="Total Revenue" value={`$${stats.revenue.toFixed(2)}`} />
          <StatCard icon={ShoppingBag} label="Total Orders" value={stats.count} color="text-blue-600" bg="bg-blue-50" />
          <StatCard icon={TrendingUp} label="Avg Order Value" value={`$${stats.avg.toFixed(2)}`} color="text-green-600" bg="bg-green-50" />
          <StatCard icon={Star} label="Items Sold" value={stats.totalItems} color="text-amber-500" bg="bg-amber-50" />
        </div>

        {/* Sales Trend */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <SectionHeader title="Sales Trends" description="Revenue and order volume over time" />
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={salesTrendData} margin={{ left: 10, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="label" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `$${v}`} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12, paddingTop: 12 }} />
              <Line yAxisId="left" type="monotone" dataKey="Revenue" stroke="#7c3aed" strokeWidth={2.5} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="Orders" stroke="#3b82f6" strokeWidth={2} dot={false} strokeDasharray="4 2" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Top Items + Payment Method side by side */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {/* Top Selling Items */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <SectionHeader title="Top-Selling Items" description="By quantity sold in this period" />
            {topItems.length === 0 ? (
              <p className="text-gray-300 text-sm text-center py-10">No sales data for this period</p>
            ) : (
              <>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={topItems} layout="vertical" margin={{ left: 0, right: 30 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
                    <XAxis type="number" tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis dataKey="name" type="category" tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} width={90} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="qty" name="Qty Sold" radius={[0, 4, 4, 0]}>
                      {topItems.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                <div className="mt-3 space-y-1.5">
                  {topItems.slice(0, 3).map((item, i) => (
                    <div key={item.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: CHART_COLORS[i] }}>{i + 1}</span>
                        <span className="text-gray-700 font-medium">{item.name}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs">
                        <span className="text-gray-400">{item.qty} sold</span>
                        <span className="text-violet-600 font-semibold">${item.revenue.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Revenue by Payment Method */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
            <SectionHeader title="Revenue by Payment Method" description="Breakdown of how customers pay" />
            {paymentMethodData.length === 0 ? (
              <p className="text-gray-300 text-sm text-center py-10">No payment data for this period</p>
            ) : (
              <>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={paymentMethodData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} innerRadius={45}>
                      {paymentMethodData.map((entry, i) => (
                        <Cell key={i} fill={PAYMENT_COLORS[entry.name] || CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v) => [`$${Number(v).toFixed(2)}`, "Revenue"]} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-2.5 mt-2">
                  {paymentMethodData.map((m, i) => {
                    const total = paymentMethodData.reduce((s, x) => s + x.value, 0);
                    const pct = total ? ((m.value / total) * 100).toFixed(1) : 0;
                    const color = PAYMENT_COLORS[m.name] || CHART_COLORS[i % CHART_COLORS.length];
                    return (
                      <div key={m.name} className="flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full shrink-0" style={{ background: color }} />
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-600 capitalize font-medium">{m.name}</span>
                            <span className="text-gray-800 font-semibold">${m.value.toFixed(2)}</span>
                          </div>
                          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
                          </div>
                        </div>
                        <span className="text-xs text-gray-400 w-10 text-right">{pct}%</span>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Peak Order Times */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-start justify-between mb-4">
            <SectionHeader title="Peak Order Times" description="Order volume by hour of day" />
            {peakHour && peakHour.Orders > 0 && (
              <div className="flex items-center gap-2 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2">
                <Clock className="w-4 h-4 text-amber-500" />
                <div>
                  <p className="text-xs text-amber-600 font-semibold">Peak Hour</p>
                  <p className="text-sm font-bold text-amber-700">{peakHour.hour} · {peakHour.Orders} orders</p>
                </div>
              </div>
            )}
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={peakHoursData} margin={{ left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="hour" tick={{ fill: "#9ca3af", fontSize: 10 }} axisLine={false} tickLine={false} interval={1} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="Orders" radius={[4, 4, 0, 0]}>
                {peakHoursData.map((entry, i) => (
                  <Cell key={i} fill={entry.hour === peakHour?.hour ? "#7c3aed" : "#e9d5ff"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          {/* Hour grid heatmap-style summary */}
          <div className="mt-4 grid grid-cols-6 lg:grid-cols-9 gap-2">
            {["6am–9am", "9am–12pm", "12pm–3pm", "3pm–6pm", "6pm–9pm", "9pm+"].map((slot, i) => {
              const startH = [6, 9, 12, 15, 18, 21][i];
              const endH = [9, 12, 15, 18, 21, 24][i];
              const slotOrders = peakHoursData.filter(h => {
                const hr = parseInt(h.hour);
                return hr >= startH && hr < endH;
              }).reduce((s, h) => s + h.Orders, 0);
              const maxSlot = 20;
              const intensity = Math.min(slotOrders / maxSlot, 1);
              return (
                <div key={slot} className="text-center">
                  <div className="h-8 rounded-lg mb-1" style={{ background: `rgba(124,58,237,${0.1 + intensity * 0.85})` }} />
                  <p className="text-[10px] text-gray-400">{slot}</p>
                  <p className="text-xs font-semibold text-gray-600">{slotOrders}</p>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}