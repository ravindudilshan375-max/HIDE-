import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { Delete } from "lucide-react";

export default function POSLogin() {
  const navigate = useNavigate();
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [loadingBranches, setLoadingBranches] = useState(true);
  const [loginMode, setLoginMode] = useState("branch"); // "branch" | "admin"

  useEffect(() => {
    base44.entities.Branch.list().then(data => {
      const active = data.filter(b => b.is_active !== false);
      setBranches(active);
      // Auto-select if only one branch
      if (active.length === 1) setSelectedBranch(active[0]);
      setLoadingBranches(false);
    });
  }, []);

  const pressKey = (digit) => {
    if (pin.length >= 6) return;
    setError("");
    setPin(prev => prev + digit);
  };

  const clearAll = () => {
    setPin("");
    setError("");
  };

  const backspace = () => {
    setPin(prev => prev.slice(0, -1));
    setError("");
  };

  const handleLogin = async () => {
    if (loginMode === "branch" && !selectedBranch) {
      setError("Please select a branch first");
      return;
    }
    if (pin.length < 4) {
      setError("PIN must be at least 4 digits");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await base44.functions.invoke("verifyStaffPin", {
        pin,
        branch_id: loginMode === "admin" ? null : selectedBranch.id,
        admin_mode: loginMode === "admin"
      });

      const data = res.data;

      if (data.locked) {
        setError(`Account locked. Try again in ${data.locked_minutes} minute(s)`);
        setPin("");
        setLoading(false);
        return;
      }

      if (!data.success) {
        setError("Incorrect PIN. Please try again.");
        setPin("");
        setLoading(false);
        return;
      }

      // Store staff session in localStorage
      localStorage.setItem("pos_staff_session", JSON.stringify({
        ...data.staff,
        logged_in_at: new Date().toISOString()
      }));
      localStorage.setItem("selectedBranchId", selectedBranch.id);

      // Redirect based on role
      const role = data.staff.role_type;
      if (role === "kitchen") {
        navigate(createPageUrl("Kitchen"));
      } else if (role === "cashier") {
        navigate(createPageUrl("POS"));
      } else if (role === "admin") {
        navigate(createPageUrl("Dashboard"));
      } else if (role === "manager") {
        navigate(createPageUrl("Dashboard"));
      } else {
        navigate(createPageUrl("Dashboard"));
      }

    } catch (err) {
      setError("Login failed. Please try again.");
      setPin("");
    }
    setLoading(false);
  };

  // Auto-submit when 6 digits entered
  useEffect(() => {
    if (pin.length === 6 && (selectedBranch || loginMode === "admin") && !loading) {
      handleLogin();
    }
  }, [pin]);

  if (loadingBranches) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-400">Loading…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4" style={{ fontFamily: "'Inter', sans-serif" }}>
      <div className="w-full max-w-sm">
        {/* Logo / Brand */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <span className="text-white font-bold text-2xl">D</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">DENDAX</h1>
          <p className="text-gray-400 text-sm mt-1">Enter your login PIN</p>
        </div>

        {/* Mode Toggle: Branch Staff vs Admin */}
        <div className="flex bg-gray-100 rounded-2xl p-1 mb-6">
          <button
            onClick={() => { setLoginMode("branch"); setPin(""); setError(""); }}
            className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${loginMode === "branch" ? "bg-white shadow text-violet-700" : "text-gray-400 hover:text-gray-700"}`}
          >
            Branch Staff
          </button>
          <button
            onClick={() => { setLoginMode("admin"); setPin(""); setError(""); }}
            className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${loginMode === "admin" ? "bg-white shadow text-violet-700" : "text-gray-400 hover:text-gray-700"}`}
          >
            Admin / Manager
          </button>
        </div>

        {/* Branch Selector — only for branch staff mode */}
        {loginMode === "branch" && branches.length > 1 && (
          <div className="mb-6">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 text-center">Select Branch</label>
            <div className="grid grid-cols-2 gap-2">
              {branches.map(branch => (
                <button
                  key={branch.id}
                  onClick={() => { setSelectedBranch(branch); setPin(""); setError(""); }}
                  className={`py-2.5 px-3 rounded-xl text-sm font-medium border transition-all ${
                    selectedBranch?.id === branch.id
                      ? "bg-violet-600 text-white border-violet-600 shadow-md"
                      : "bg-white text-gray-700 border-gray-200 hover:border-violet-300"
                  }`}
                >
                  {branch.name}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Admin mode: show PIN input without branch selection */}
        {loginMode === "admin" && (
          <div className="mb-4 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-violet-50 border border-violet-200 rounded-xl">
              <div className="w-2 h-2 rounded-full bg-violet-500" />
              <span className="text-sm text-violet-700 font-medium">Admin / Manager Login — All Branches</span>
            </div>
          </div>
        )}

        {(selectedBranch || loginMode === "admin") && (
          <>
            {/* PIN Dots */}
            <div className="flex justify-center gap-3 mb-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-full border-2 transition-all duration-150 ${
                    i < pin.length
                      ? "bg-violet-600 border-violet-600 scale-110"
                      : "bg-white border-gray-300"
                  }`}
                />
              ))}
            </div>

            {/* Error */}
            {error && (
              <div className="mb-4 text-center text-sm text-red-500 bg-red-50 border border-red-100 rounded-xl py-2 px-3">
                {error}
              </div>
            )}

            {/* Keypad */}
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-5">
              <div className="grid grid-cols-3 gap-3">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => (
                  <button
                    key={n}
                    onClick={() => pressKey(String(n))}
                    disabled={loading}
                    className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-2xl font-medium text-gray-800 hover:bg-violet-50 hover:border-violet-200 hover:text-violet-700 active:scale-95 transition-all disabled:opacity-50"
                  >
                    {n}
                  </button>
                ))}
                {/* Bottom row: clear / 0 / backspace */}
                <button
                  onClick={clearAll}
                  disabled={loading}
                  className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-sm font-semibold text-gray-400 hover:bg-red-50 hover:border-red-200 hover:text-red-500 active:scale-95 transition-all disabled:opacity-50"
                >
                  C
                </button>
                <button
                  onClick={() => pressKey("0")}
                  disabled={loading}
                  className="h-16 rounded-2xl bg-gray-50 border border-gray-200 text-2xl font-medium text-gray-800 hover:bg-violet-50 hover:border-violet-200 hover:text-violet-700 active:scale-95 transition-all disabled:opacity-50"
                >
                  0
                </button>
                <button
                  onClick={backspace}
                  disabled={loading}
                  className="h-16 rounded-2xl bg-gray-50 border border-gray-200 flex items-center justify-center text-gray-400 hover:bg-orange-50 hover:border-orange-200 hover:text-orange-500 active:scale-95 transition-all disabled:opacity-50"
                >
                  <Delete className="w-5 h-5" />
                </button>
              </div>

              {/* Login Button */}
              <button
                onClick={handleLogin}
                disabled={pin.length < 4 || loading}
                className="mt-4 w-full h-14 rounded-2xl font-semibold text-white text-base transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}
              >
                {loading ? "Verifying…" : "Login"}
              </button>
            </div>

            {/* Branch info */}
            {loginMode === "branch" && selectedBranch && (
              <div className="text-center mt-6 space-y-0.5">
                <p className="text-xs text-gray-500 font-semibold">{selectedBranch.name}</p>
                {selectedBranch.location && <p className="text-xs text-gray-400">{selectedBranch.location}</p>}
              </div>
            )}
          </>
        )}

        {loginMode === "branch" && !selectedBranch && branches.length === 0 && (
          <p className="text-center text-gray-400 text-sm mt-4">No active branches found. Please contact your administrator.</p>
        )}
      </div>
    </div>
  );
}