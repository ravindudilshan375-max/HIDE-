import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import {
  Plus, Trash2, X, Search, ClipboardList, ChevronDown,
  Camera, Scan, CheckCircle2, AlertTriangle, AlertCircle,
  ArrowRight, FileText, LogOut, Share2, Copy, Check
} from "lucide-react";
import { toast } from "sonner";
import InventoryPinLogin from "@/components/inventory/InventoryPinLogin";

const PAGE_SIZE = 40;

// ── Dual CTN+PCS ItemCard ──────────────────────────────────────────
function ItemCard({ item, onUpdate, onRemove, highlighted }) {
  const hasFactor = item.factor > 1 && item.storage_unit;
  const factor = item.factor || 1;

  // Parse counted_quantity into ctn + pcs
  const getCtnPcs = (qty) => {
    if (qty === null || qty === undefined) return { ctn: "", pcs: "" };
    if (!hasFactor) return { ctn: qty, pcs: "" };
    const ctn = Math.floor(qty);
    const pcs = Math.round((qty - ctn) * factor);
    return { ctn: ctn === 0 && qty === null ? "" : ctn, pcs };
  };

  const [local, setLocal] = useState(() => getCtnPcs(item.counted_quantity));

  useEffect(() => {
    setLocal(getCtnPcs(item.counted_quantity));
  }, [item.counted_quantity]);

  const commitFromCtnPcs = (ctn, pcs) => {
    const ctnNum = Number(ctn) || 0;
    const pcsNum = Number(pcs) || 0;
    const total = hasFactor ? ctnNum + pcsNum / factor : ctnNum;
    onUpdate(total);
  };

  const counted = item.counted_quantity !== null && item.counted_quantity !== undefined;
  const countedTotal = hasFactor
    ? (Number(local.ctn) || 0) * factor + (Number(local.pcs) || 0)
    : Number(local.ctn) || 0;
  const expectedTotal = hasFactor ? item.system_quantity * factor : item.system_quantity;
  const variance = counted ? countedTotal - expectedTotal : null;

  const dotColor = !counted ? "bg-gray-300"
    : variance === 0 ? "bg-green-500"
    : variance < 0 ? "bg-red-500"
    : "bg-blue-500";

  const formatExpected = () => {
    if (!hasFactor) return `${item.system_quantity} ${item.storage_unit || item.unit}`;
    const ctn = Math.floor(item.system_quantity);
    const pcs = Math.round((item.system_quantity - ctn) * factor);
    return pcs > 0 ? `${ctn} ${item.storage_unit} + ${pcs} Pcs` : `${ctn} ${item.storage_unit}`;
  };

  const addCtn = (n) => {
    const newCtn = (Number(local.ctn) || 0) + n;
    const newLocal = { ...local, ctn: newCtn };
    setLocal(newLocal);
    commitFromCtnPcs(newCtn, local.pcs);
  };

  const addPcs = (n) => {
    const newPcs = (Number(local.pcs) || 0) + n;
    const newLocal = { ...local, pcs: newPcs };
    setLocal(newLocal);
    commitFromCtnPcs(local.ctn, newPcs);
  };

  const addSingle = (n) => {
    const cur = item.counted_quantity ?? 0;
    onUpdate(Math.max(0, cur + n));
  };

  return (
    <div className={`bg-white rounded-2xl border-2 p-4 transition-all duration-200 ${
      highlighted ? "border-violet-400 shadow-lg shadow-violet-100 scale-[1.01]"
      : counted && variance === 0 ? "border-green-200"
      : counted && variance < 0 ? "border-red-200"
      : counted ? "border-blue-200"
      : "border-gray-100"
    }`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start gap-2 flex-1 min-w-0">
          <div className={`w-2.5 h-2.5 rounded-full shrink-0 mt-1.5 ${dotColor}`} />
          <div className="min-w-0">
            <p className="font-bold text-gray-900 text-[15px] leading-tight">{item.item_name}</p>
            <p className="text-xs text-gray-400 mt-0.5 font-mono">
              {item.sku && <span>SKU: {item.sku} • </span>}
              Expected: <span className="font-bold text-gray-600">{formatExpected()}</span>
            </p>
          </div>
        </div>
        {variance !== null && variance !== 0 && (
          <span className={`shrink-0 text-xs font-bold px-2 py-1 rounded-lg ml-2 ${variance < 0 ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"}`}>
            {variance > 0 ? "+" : ""}{variance}{hasFactor ? " Pcs" : ""}
          </span>
        )}
      </div>

      {/* Inputs */}
      {hasFactor ? (
        <div className="mb-3">
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div>
              <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">{item.storage_unit}</p>
              <div className="grid mb-1" style={{ gridTemplateColumns: "40px 1fr 40px", gap: 6 }}>
                <button onPointerDown={e => e.preventDefault()} onClick={() => addCtn(-1)}
                  className="h-11 rounded-xl bg-gray-100 active:bg-gray-200 flex items-center justify-center text-gray-600 text-xl font-bold active:scale-95 transition select-none">−</button>
                <input type="number" min="0" inputMode="numeric"
                  value={local.ctn}
                  onChange={e => setLocal(l => ({ ...l, ctn: e.target.value }))}
                  onBlur={() => commitFromCtnPcs(local.ctn, local.pcs)}
                  onFocus={e => e.target.select()}
                  className="w-full h-11 text-center text-xl font-bold border-2 border-gray-200 rounded-xl focus:outline-none focus:border-violet-400 transition min-w-0" />
                <button onPointerDown={e => e.preventDefault()} onClick={() => addCtn(1)}
                  className="h-11 rounded-xl bg-violet-100 active:bg-violet-200 flex items-center justify-center text-violet-700 text-xl font-bold active:scale-95 transition select-none">+</button>
              </div>
            </div>
            <div>
              <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Pcs</p>
              <div className="grid mb-1" style={{ gridTemplateColumns: "40px 1fr 40px", gap: 6 }}>
                <button onPointerDown={e => e.preventDefault()} onClick={() => addPcs(-1)}
                  className="h-11 rounded-xl bg-gray-100 active:bg-gray-200 flex items-center justify-center text-gray-600 text-xl font-bold active:scale-95 transition select-none">−</button>
                <input type="number" min="0" inputMode="numeric"
                  value={local.pcs}
                  onChange={e => setLocal(l => ({ ...l, pcs: e.target.value }))}
                  onBlur={() => commitFromCtnPcs(local.ctn, local.pcs)}
                  onFocus={e => e.target.select()}
                  className="w-full h-11 text-center text-xl font-bold border-2 border-gray-200 rounded-xl focus:outline-none focus:border-violet-400 transition min-w-0" />
                <button onPointerDown={e => e.preventDefault()} onClick={() => addPcs(1)}
                  className="h-11 rounded-xl bg-violet-100 active:bg-violet-200 flex items-center justify-center text-violet-700 text-xl font-bold active:scale-95 transition select-none">+</button>
              </div>
            </div>
          </div>
          <p className="text-xs text-gray-400 text-center">1 {item.storage_unit} = {factor} Pcs · Total: <span className="font-semibold text-violet-600">{countedTotal} Pcs</span></p>
          <div className="grid grid-cols-2 gap-1.5 mt-2">
            {[1, 5].map(n => (
              <button key={n} onPointerDown={e => e.preventDefault()} onClick={() => addCtn(n)}
                className="py-2.5 text-sm font-bold text-violet-600 bg-violet-50 active:bg-violet-100 rounded-xl transition select-none">+{n} {item.storage_unit}</button>
            ))}
            {[5, 10].map(n => (
              <button key={n} onPointerDown={e => e.preventDefault()} onClick={() => addPcs(n)}
                className="py-2.5 text-sm font-bold text-violet-600 bg-violet-50 active:bg-violet-100 rounded-xl transition select-none">+{n} Pcs</button>
            ))}
          </div>
        </div>
      ) : (
        <div className="mb-3">
          <div className="grid mb-2" style={{ gridTemplateColumns: "48px 1fr 48px", gap: 8 }}>
            <button onPointerDown={e => e.preventDefault()} onClick={() => addSingle(-1)}
              className="h-12 rounded-xl bg-gray-100 active:bg-gray-200 flex items-center justify-center text-gray-600 text-2xl font-bold active:scale-95 transition select-none">−</button>
            <input type="number" min="0" inputMode="numeric"
              value={local.ctn}
              onChange={e => setLocal(l => ({ ...l, ctn: e.target.value }))}
              onBlur={e => onUpdate(Math.max(0, Number(e.target.value) || 0))}
              onFocus={e => e.target.select()}
              className="w-full h-12 text-center text-2xl font-bold border-2 border-gray-200 rounded-xl focus:outline-none focus:border-violet-400 transition min-w-0" />
            <button onPointerDown={e => e.preventDefault()} onClick={() => addSingle(1)}
              className="h-12 rounded-xl bg-violet-100 active:bg-violet-200 flex items-center justify-center text-violet-700 text-2xl font-bold active:scale-95 transition select-none">+</button>
          </div>
          <div className="grid grid-cols-4 gap-1.5">
            {[1, 5, 10, 25].map(n => (
              <button key={n} onPointerDown={e => e.preventDefault()} onClick={() => addSingle(n)}
                className="py-2.5 text-sm font-bold text-violet-600 bg-violet-50 active:bg-violet-100 rounded-xl transition select-none">+{n}</button>
            ))}
          </div>
        </div>
      )}

      <button onClick={onRemove} className="w-full flex items-center justify-center gap-1 text-xs text-gray-300 hover:text-red-400 transition py-1">
        <Trash2 className="w-3 h-3" /> Remove
      </button>
    </div>
  );
}

// ── Camera Barcode Scanner Modal ───────────────────────────────────
function BarcodeScanModal({ inventoryItems, onFound, onClose }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const detectorRef = useRef(null);
  const animFrameRef = useRef(null);
  const [detected, setDetected] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => { startCamera(); return () => stopCamera(); }, []);

  const stopCamera = () => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play(); }
      if ("BarcodeDetector" in window) {
        detectorRef.current = new window.BarcodeDetector({ formats: ["ean_13", "upc_a", "code_128", "qr_code", "code_39"] });
        detectLoop();
      } else {
        setError("Camera scanning not supported in this browser. Use the search box or a USB barcode scanner.");
      }
    } catch {
      setError("Camera access denied. Please allow camera permissions.");
    }
  };

  const detectLoop = () => {
    animFrameRef.current = requestAnimationFrame(async () => {
      if (videoRef.current && detectorRef.current && videoRef.current.readyState >= 2) {
        try {
          const barcodes = await detectorRef.current.detect(videoRef.current);
          if (barcodes.length > 0) { handleBarcode(barcodes[0].rawValue); return; }
        } catch (_) {}
      }
      detectLoop();
    });
  };

  const handleBarcode = (code) => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    const found = inventoryItems.find(i =>
      i.sku?.toLowerCase() === code.toLowerCase() ||
      i.barcode?.toLowerCase() === code.toLowerCase()
    );
    setDetected({ code, item: found || null });
  };

  return (
    <div className="fixed inset-0 bg-black z-[60] flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 bg-black/80 shrink-0">
        <h2 className="text-white font-bold text-lg">Scan Barcode</h2>
        <button onClick={onClose} className="text-white/70 hover:text-white p-1"><X className="w-6 h-6" /></button>
      </div>
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative w-72 h-44">
            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-violet-400 rounded-tl-lg" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-violet-400 rounded-tr-lg" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-violet-400 rounded-bl-lg" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-violet-400 rounded-br-lg" />
          </div>
        </div>
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-6">
            <div className="text-center">
              <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
              <p className="text-white text-sm">{error}</p>
            </div>
          </div>
        )}
      </div>
      <div className="bg-black/90 px-4 py-4 shrink-0">
        {!detected ? (
          <p className="text-center text-gray-400 text-sm py-2">Place barcode inside the frame</p>
        ) : (
          <div className={`rounded-2xl p-4 ${detected.item ? "bg-green-900/60 border border-green-500" : "bg-red-900/60 border border-red-500"}`}>
            <p className="text-xs text-gray-400 mb-1">Detected: <span className="font-mono text-white">{detected.code}</span></p>
            {detected.item ? (
              <>
                <p className="text-white font-bold text-xl">{detected.item.name || detected.item.item_name}</p>
                <p className="text-green-400 text-sm mb-3">SKU: {detected.item.sku}</p>
                <div className="flex gap-2">
                  <button onClick={() => { onFound(detected.item); setDetected(null); detectLoop(); }}
                    className="flex-1 py-3.5 bg-green-500 active:bg-green-600 text-white font-bold rounded-xl text-base active:scale-95 transition">
                    +1 Count
                  </button>
                  <button onClick={() => { setDetected(null); detectLoop(); }}
                    className="flex-1 py-3.5 bg-white/10 text-white rounded-xl text-sm">Rescan</button>
                </div>
              </>
            ) : (
              <>
                <p className="text-red-400 text-sm mb-2">Item not found in inventory</p>
                <button onClick={() => { setDetected(null); detectLoop(); }}
                  className="w-full py-3 bg-white/10 text-white rounded-xl text-sm">Try Again</button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main page ──────────────────────────────────────────────────────
export default function InventoryCount() {
  const [counts, setCounts] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [countName, setCountName] = useState("");
  const [countedBy, setCountedBy] = useState("");
  const [countItems, setCountItems] = useState([]);
  const [editingCountId, setEditingCountId] = useState(null);
  const [search, setSearch] = useState("");
  const [user, setUser] = useState(null);
  const [branches, setBranches] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState("all");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [highlightedId, setHighlightedId] = useState(null);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [expandedReportId, setExpandedReportId] = useState(null);
  const [staffSession, setStaffSession] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem("inv_staff_session") || "null"); } catch { return null; }
  });
  const [showShareModal, setShowShareModal] = useState(false);
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/InventoryCount`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleStaffLogin = (staff) => {
    sessionStorage.setItem("inv_staff_session", JSON.stringify(staff));
    setStaffSession(staff);
  };

  const handleStaffLogout = () => {
    sessionStorage.removeItem("inv_staff_session");
    setStaffSession(null);
  };

  const barcodeBuffer = useRef("");
  const barcodeTimer = useRef(null);
  const listRef = useRef(null);

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    if (!showForm) return;
    const handler = (e) => {
      if (e.key === "Enter" && barcodeBuffer.current.length > 2) {
        handleBarcodeInput(barcodeBuffer.current.trim());
        barcodeBuffer.current = "";
        return;
      }
      if (e.key.length === 1) {
        barcodeBuffer.current += e.key;
        clearTimeout(barcodeTimer.current);
        barcodeTimer.current = setTimeout(() => { barcodeBuffer.current = ""; }, 100);
      }
    };
    window.addEventListener("keydown", handler);
    return () => { window.removeEventListener("keydown", handler); clearTimeout(barcodeTimer.current); };
  }, [showForm, countItems, inventoryItems]);

  const handleBarcodeInput = useCallback((code) => {
    const inv = inventoryItems.find(i =>
      i.sku?.toLowerCase() === code.toLowerCase() ||
      i.barcode?.toLowerCase() === code.toLowerCase()
    );
    if (!inv) { toast.error(`Not found: ${code}`); return; }
    scanAddItem(inv);
  }, [inventoryItems, countItems]);

  const scanAddItem = useCallback((invItem) => {
    const id = invItem.id;
    setCountItems(prev => {
      const existing = prev.find(i => i.menu_item_id === id);
      const newQty = (existing?.counted_quantity ?? 0) + 1;
      toast.success(`✓ ${invItem.name || invItem.item_name}  +1  →  ${newQty}`, { duration: 1200, position: "top-center" });
      setHighlightedId(id);
      setTimeout(() => setHighlightedId(null), 1500);
      setSearch("");
      if (existing) {
        return prev.map(i => i.menu_item_id === id
          ? { ...i, counted_quantity: newQty, variance: newQty - i.system_quantity }
          : i);
      } else {
        return [...prev, {
          menu_item_id: id,
          item_name: invItem.name,
          sku: invItem.sku || "",
          barcode: invItem.barcode || "",
          system_quantity: invItem.current_quantity || 0,
          counted_quantity: 1,
          variance: 1 - (invItem.current_quantity || 0),
          unit: invItem.unit || "",
          storage_unit: invItem.storage_unit || "",
          factor: invItem.factor ?? 1,
        }];
      }
    });
  }, [inventoryItems]);

  const loadData = async () => {
    setLoading(true);
    const [countsData, invItems, branchData, currentUser] = await Promise.all([
      base44.entities.InventoryCount.list("-created_date"),
      base44.entities.InventoryItem.list("name"),
      base44.entities.Branch.list(),
      base44.auth.me().catch(() => null)
    ]);
    setCounts(countsData);
    setInventoryItems(invItems);
    setBranches(branchData);
    setUser(currentUser);
    setLoading(false);
  };

  const openNewCount = () => {
    if (selectedBranch === "all" && branches.length > 1) {
      toast.error("Please select a branch first");
      return;
    }
    const items = inventoryItems
      .filter(i => selectedBranch === "all" || i.branch_id === selectedBranch)
      .map(item => ({
        menu_item_id: item.id,
        item_name: item.name,
        sku: item.sku || "",
        barcode: item.barcode || "",
        system_quantity: item.current_quantity || 0,
        counted_quantity: null,
        variance: 0,
        unit: item.unit || "",
        storage_unit: item.storage_unit || "",
        factor: item.factor ?? 1,
      }));
    setCountItems(items);
    setCountedBy(staffSession?.name || user?.full_name || "");
    setCountName(`Count ${new Date().toLocaleDateString()}`);
    setSearch("");
    setVisibleCount(PAGE_SIZE);
    setEditingCountId(null);
    setShowForm(true);
  };

  const continueCount = (count) => {
    setCountItems(count.items || []);
    setCountName(count.name);
    setCountedBy(count.counted_by || "");
    setEditingCountId(count.id);
    setSearch("");
    setVisibleCount(PAGE_SIZE);
    setShowForm(true);
  };

  const updateItemQty = useCallback((menuItemId, qty) => {
    setCountItems(prev => prev.map(item =>
      item.menu_item_id !== menuItemId ? item :
      { ...item, counted_quantity: qty, variance: qty - item.system_quantity }
    ));
  }, []);

  const removeItem = useCallback((menuItemId) => {
    setCountItems(prev => prev.filter(i => i.menu_item_id !== menuItemId));
  }, []);

  const saveCount = async (asDraft = false) => {
    if (!countName.trim()) { toast.error("Enter a count name"); return; }
    const hasDiscrepancy = countItems.some(i => i.counted_quantity !== null && i.variance !== 0);
    const branchId = selectedBranch === "all" ? branches[0]?.id : selectedBranch;
    const status = asDraft ? "in_progress" : (hasDiscrepancy ? "discrepancy" : "completed");

    const payload = {
      date: new Date().toISOString().split("T")[0],
      name: countName, items: countItems,
      status,
      counted_by: countedBy, notes: "", branch_id: branchId,
    };

    if (editingCountId) {
      await base44.entities.InventoryCount.update(editingCountId, payload);
    } else {
      await base44.entities.InventoryCount.create(payload);
    }

    if (!asDraft) {
      for (const item of countItems.filter(i => i.counted_quantity !== null)) {
        await base44.entities.InventoryItem.update(item.menu_item_id, { current_quantity: item.counted_quantity }).catch(() => {});
      }
      toast.success("Count submitted & quantities updated");
    } else {
      toast.success("Draft saved");
    }

    setShowForm(false);
    setEditingCountId(null);
    loadData();
  };

  const deleteCount = async (id) => {
    await base44.entities.InventoryCount.delete(id).catch(() => {});
    toast.success("Deleted");
    setCounts(prev => prev.filter(c => c.id !== id));
  };

  const filteredItems = useMemo(() =>
    countItems.filter(i => !search ||
      i.item_name.toLowerCase().includes(search.toLowerCase()) ||
      i.sku?.toLowerCase().includes(search.toLowerCase())
    ), [countItems, search]
  );

  const visibleItems = filteredItems.slice(0, visibleCount);
  const countedNum = countItems.filter(i => i.counted_quantity !== null).length;
  const totalNum = countItems.length;
  const variantNum = countItems.filter(i => i.counted_quantity !== null && i.variance !== 0).length;
  const progressPct = totalNum > 0 ? Math.round((countedNum / totalNum) * 100) : 0;

  const filteredCounts = useMemo(() =>
    selectedBranch === "all" ? counts : counts.filter(c => c.branch_id === selectedBranch),
    [counts, selectedBranch]
  );

  const draftCounts = filteredCounts.filter(c => c.status === "in_progress");
  const submittedCounts = filteredCounts.filter(c => c.status !== "in_progress");

  if (!staffSession) return (
    <InventoryPinLogin
      branchId={selectedBranch !== "all" ? selectedBranch : null}
      onLogin={handleStaffLogin}
    />
  );

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  // ── List / Dashboard ─────────────────────────────────────────────
  if (!showForm) return (
    <div className="min-h-screen bg-[#f5f5fa] p-4 md:p-6">
      <div className="max-w-3xl mx-auto space-y-5">

        {/* Header */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-gray-900">Inventory Count</h1>
              <p className="text-gray-400 text-sm">
                Logged in as <span className="font-semibold text-violet-600">{staffSession.name}</span>
              </p>
            </div>
            <button onClick={handleStaffLogout}
              className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-red-500 transition px-2.5 py-1.5 border border-gray-200 rounded-xl">
              <LogOut className="w-3.5 h-3.5" /> Logout
            </button>
          </div>
          <div className="flex items-center gap-2">
            {branches.length > 1 && (
              <select value={selectedBranch} onChange={e => setSelectedBranch(e.target.value)}
                className="flex-1 bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-gray-700 focus:outline-none focus:border-violet-400">
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            )}
            <button onClick={() => setShowShareModal(true)}
              className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 bg-white rounded-xl text-sm text-gray-600 hover:text-violet-600 hover:border-violet-300 transition">
              <Share2 className="w-4 h-4" /> Share
            </button>
            <Button onClick={openNewCount} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2 whitespace-nowrap">
              <Plus className="w-4 h-4" /> New Count
            </Button>
          </div>
        </div>

        {/* Draft Counts */}
        {draftCounts.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              <h2 className="text-sm font-bold text-gray-700 uppercase tracking-wide">Draft Counts</h2>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full">{draftCounts.length}</span>
            </div>
            <div className="space-y-3">
              {draftCounts.map(count => {
                const counted = (count.items || []).filter(i => i.counted_quantity !== null).length;
                const total = (count.items || []).length;
                const pct = total > 0 ? Math.round((counted / total) * 100) : 0;
                return (
                  <div key={count.id} className="bg-white border-2 border-blue-100 rounded-2xl p-4 shadow-sm">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-bold text-gray-900">{count.name}</h3>
                        <p className="text-xs text-gray-400 mt-0.5">{count.date} · {count.counted_by}</p>
                      </div>
                      <button onClick={() => deleteCount(count.id)} className="text-gray-300 hover:text-red-500 transition p-1.5">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="mb-3">
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Items counted: <strong className="text-gray-900">{counted} / {total}</strong></span>
                        <span className="font-bold text-blue-600">{pct}%</span>
                      </div>
                      <div className="bg-gray-100 rounded-full h-1.5">
                        <div className="bg-blue-500 h-1.5 rounded-full transition-all" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                    <button onClick={() => continueCount(count)}
                      className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl transition">
                      <ArrowRight className="w-4 h-4" /> Continue Counting
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Submitted Counts */}
        {submittedCounts.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              <h2 className="text-sm font-bold text-gray-700 uppercase tracking-wide">Submitted Counts</h2>
              <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-semibold rounded-full">{submittedCounts.length}</span>
            </div>
            <div className="space-y-3">
              {submittedCounts.map(count => {
                const variances = (count.items || []).filter(i => i.variance !== 0).length;
                const isExpanded = expandedReportId === count.id;
                return (
                  <div key={count.id} className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
                    <div className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-bold text-gray-900">{count.name}</h3>
                            <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                              count.status === "completed" ? "bg-green-100 text-green-700" :
                              count.status === "discrepancy" ? "bg-orange-100 text-orange-700" :
                              "bg-gray-100 text-gray-500"
                            }`}>{count.status}</span>
                          </div>
                          <p className="text-xs text-gray-400 mt-0.5">{count.date} · {count.counted_by}</p>
                          <div className="flex gap-4 text-xs mt-1.5">
                            <span className="text-gray-600">{count.items?.length || 0} items</span>
                            {variances > 0 && <span className="text-orange-600 font-semibold">{variances} variances</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {variances > 0 && (
                            <button onClick={() => setExpandedReportId(isExpanded ? null : count.id)}
                              className="flex items-center gap-1 text-xs text-gray-500 hover:text-violet-600 px-2.5 py-1.5 border border-gray-200 rounded-lg transition">
                              <FileText className="w-3.5 h-3.5" /> {isExpanded ? "Hide" : "View"}
                            </button>
                          )}
                          <button onClick={() => deleteCount(count.id)} className="text-gray-300 hover:text-red-500 transition p-1.5">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                    {isExpanded && variances > 0 && (
                      <div className="border-t border-gray-100 px-4 pb-4 pt-3">
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-2">Variance Report</p>
                        <div className="space-y-1.5">
                          {count.items.filter(i => i.variance !== 0).map((i, idx) => (
                            <div key={idx} className="flex items-center justify-between bg-orange-50 rounded-lg px-3 py-1.5 text-xs">
                              <span className="text-gray-700 font-medium">{i.item_name}</span>
                              <span className={`font-bold ${i.variance > 0 ? "text-green-600" : "text-red-600"}`}>
                                {i.variance > 0 ? "+" : ""}{i.variance} {i.unit}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {filteredCounts.length === 0 && (
          <div className="text-center py-20 text-gray-300">
            <ClipboardList className="w-14 h-14 mx-auto mb-3 text-gray-200" />
            <p className="text-sm font-medium">No inventory counts yet</p>
            <p className="text-xs mt-1">Tap "New Count" to start</p>
          </div>
        )}
      </div>

      {/* Share Modal */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setShowShareModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-gray-900 text-lg">Share Inventory Count</h3>
              <button onClick={() => setShowShareModal(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
            </div>

            {/* QR Code via Google Charts API */}
            <div className="flex justify-center mb-5">
              <div className="p-3 border-2 border-gray-100 rounded-2xl">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}`}
                  alt="QR Code"
                  className="w-44 h-44 rounded-xl"
                />
              </div>
            </div>
            <p className="text-xs text-gray-400 text-center mb-4">Scan to open on mobile device</p>

            {/* URL copy */}
            <div className="flex gap-2">
              <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-gray-600 truncate font-mono">
                {shareUrl}
              </div>
              <button onClick={handleCopyLink}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-semibold transition ${copied ? "bg-green-600 text-white" : "bg-violet-600 hover:bg-violet-700 text-white"}`}>
                {copied ? <><Check className="w-4 h-4" /> Copied!</> : <><Copy className="w-4 h-4" /> Copy</>}
              </button>
            </div>

            {/* Native share if supported */}
            {navigator.share && (
              <button onClick={() => navigator.share({ title: "Inventory Count", url: shareUrl })}
                className="w-full mt-3 flex items-center justify-center gap-2 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 transition">
                <Share2 className="w-4 h-4" /> Share via…
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );

  // ── Count Form (full-screen) ──────────────────────────────────────
  return (
    <div className="fixed inset-0 bg-[#f5f5fa] z-50 flex flex-col">

      {/* Sticky Header */}
      <div className="bg-white border-b border-gray-100 px-4 py-3 shrink-0">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => setShowForm(false)} className="p-1 text-gray-400 hover:text-gray-700 transition">
            <X className="w-5 h-5" />
          </button>
          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-gray-900 text-base leading-tight">Inventory Count</h2>
            <p className="text-xs text-gray-400">
              {countedNum} / {totalNum} items · {variantNum > 0 ? <span className="text-orange-500">{variantNum} variances</span> : "no variances"}
            </p>
          </div>
          <div className="relative">
            <button onClick={() => setMoreMenuOpen(v => !v)}
              className="w-11 h-11 rounded-xl bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200 transition">
              <ChevronDown className="w-4 h-4" />
            </button>
            {moreMenuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setMoreMenuOpen(false)} />
                <div className="absolute right-0 top-12 z-20 bg-white rounded-2xl shadow-xl border border-gray-100 py-1.5 w-44">
                  <button onClick={() => { setMoreMenuOpen(false); }}
                    className="w-full text-left px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50">Print Sheets</button>
                  <button onClick={() => { setShowForm(false); setMoreMenuOpen(false); }}
                    className="w-full text-left px-4 py-2.5 text-sm font-medium text-red-500 hover:bg-gray-50">Discard Count</button>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-2">
          <input value={countName} onChange={e => setCountName(e.target.value)}
            className="h-10 border border-gray-200 rounded-xl px-3 text-sm text-gray-800 focus:outline-none focus:border-violet-400 bg-white"
            placeholder="Count name" />
          <input value={countedBy} onChange={e => setCountedBy(e.target.value)}
            className="h-10 border border-gray-200 rounded-xl px-3 text-sm text-gray-800 focus:outline-none focus:border-violet-400 bg-white"
            placeholder="Counted by" />
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          <input
            placeholder="Search item or type/scan barcode..."
            value={search}
            onChange={e => { setSearch(e.target.value); setVisibleCount(PAGE_SIZE); }}
            className="w-full h-10 border border-gray-200 rounded-xl pl-9 pr-4 text-sm focus:outline-none focus:border-violet-400 bg-white"
          />
        </div>
        <p className="text-[11px] text-gray-400 mt-1.5 flex items-center gap-1">
          <Scan className="w-3 h-3" /> USB/Bluetooth scanner ready — just scan any barcode
        </p>

        {/* Progress bar */}
        <div className="flex items-center gap-3 mt-2">
          <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
            <div className="bg-violet-500 h-1.5 rounded-full transition-all duration-300" style={{ width: `${progressPct}%` }} />
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500 shrink-0">
            {variantNum > 0 && <span className="flex items-center gap-0.5 text-orange-500"><AlertTriangle className="w-3 h-3" />{variantNum}</span>}
            <span className="flex items-center gap-0.5 text-green-600"><CheckCircle2 className="w-3 h-3" />{countedNum}</span>
            <span className="font-bold text-gray-600">{progressPct}%</span>
          </div>
        </div>
      </div>

      {/* Item cards */}
      <div ref={listRef} className="flex-1 overflow-y-auto px-3 py-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-w-5xl mx-auto">
          {visibleItems.map(item => (
            <ItemCard
              key={item.menu_item_id}
              item={item}
              highlighted={highlightedId === item.menu_item_id}
              onUpdate={(qty) => updateItemQty(item.menu_item_id, qty)}
              onRemove={() => removeItem(item.menu_item_id)}
            />
          ))}
        </div>
        {visibleCount < filteredItems.length && (
          <div className="flex justify-center mt-4 pb-2">
            <button onClick={() => setVisibleCount(v => v + PAGE_SIZE)}
              className="px-6 py-2.5 bg-white border border-gray-200 rounded-xl text-sm font-medium text-violet-600 hover:bg-violet-50 transition">
              Load more ({filteredItems.length - visibleCount} remaining)
            </button>
          </div>
        )}
        {filteredItems.length === 0 && (
          <div className="text-center py-16 text-gray-300">
            <Search className="w-10 h-10 mx-auto mb-2" />
            <p className="text-sm">No items found</p>
          </div>
        )}
      </div>

      {/* Sticky Bottom Bar */}
      <div className="bg-white border-t border-gray-100 px-4 pt-3 pb-4 shrink-0">
        <div className="flex items-center gap-4 text-sm mb-3">
          <span className="text-gray-500">Total: <strong className="text-gray-900">{totalNum}</strong></span>
          <span className="text-gray-500">Counted: <strong className="text-green-600">{countedNum}</strong></span>
          <span className="text-gray-500">Remaining: <strong className="text-orange-500">{totalNum - countedNum}</strong></span>
        </div>
        <div className="flex gap-2.5">
          <Button onClick={() => saveCount(true)} variant="outline"
            className="flex-1 border-gray-200 rounded-xl font-semibold text-gray-700" style={{ height: 52 }}>
            Save Draft
          </Button>
          <Button onClick={() => saveCount(false)}
            className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl" style={{ height: 52, fontSize: 16 }}>
            Submit Count
          </Button>
        </div>
      </div>

      {/* Floating Scan FAB */}
      <button
        onClick={() => setShowScanner(true)}
        className="fixed flex flex-col items-center justify-center gap-0.5 z-[51] text-white rounded-2xl shadow-2xl active:scale-95 transition"
        style={{ bottom: 90, right: 20, width: 64, height: 64, background: "linear-gradient(135deg, #7C3AED, #3B82F6)", boxShadow: "0 8px 24px rgba(109,40,217,0.45)" }}
      >
        <Camera className="w-6 h-6" />
        <span className="text-[10px] font-semibold">Scan</span>
      </button>

      {/* Camera scanner */}
      {showScanner && (
        <BarcodeScanModal
          inventoryItems={inventoryItems}
          onFound={(invItem) => { scanAddItem(invItem); setShowScanner(false); }}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  );
}