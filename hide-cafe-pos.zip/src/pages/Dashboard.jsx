import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfDay, startOfWeek, startOfMonth, subDays } from "date-fns";
import { RefreshCw } from "lucide-react";
import KPICards from "@/components/dashboard/KPICards";
import SalesTrendChart from "@/components/dashboard/SalesTrendChart";
import BranchPerformance from "@/components/dashboard/BranchPerformance";
import TopProducts from "@/components/dashboard/TopProducts";
import LiveOrders from "@/components/dashboard/LiveOrders";
import InventoryAlerts from "@/components/dashboard/InventoryAlerts";

const PERIODS = [
  { key: "today", label: "Today" },
  { key: "7d", label: "7 Days" },
  { key: "30d", label: "30 Days" },
  { key: "month", label: "This Month" },
];

function buildChartData(orders, period) {
  if (period === "today") {
    const hours = Array.from({ length: 24 }, (_, i) => ({ label: `${i}h`, fullLabel: `${i}:00`, sales: 0, orders: 0 }));
    orders.forEach(o => {
      if (!o.created_date) return;
      const h = new Date(o.created_date).getHours();
      hours[h].sales += o.total || 0;
      hours[h].orders += 1;
    });
    return hours;
  }
  const days = period === "7d" ? 7 : period === "30d" ? 30 : 30;
  const map = {};
  for (let i = days - 1; i >= 0; i--) {
    const d = subDays(new Date(), i);
    const key = format(d, "MM-dd");
    map[key] = { label: format(d, "MM/dd"), fullLabel: format(d, "MMM dd"), sales: 0, orders: 0 };
  }
  orders.forEach(o => {
    if (!o.created_date) return;
    const key = format(new Date(o.created_date), "MM-dd");
    if (map[key]) { map[key].sales += o.total || 0; map[key].orders += 1; }
  });
  return Object.values(map);
}

function computeTopProducts(orders) {
  const map = {};
  orders.forEach(order => {
    (order.items || []).forEach(item => {
      if (item.is_voided) return;
      if (!map[item.name]) map[item.name] = { name: item.name, qty: 0, revenue: 0 };
      map[item.name].qty += item.quantity || 1;
      map[item.name].revenue += item.subtotal || (item.price * (item.quantity || 1)) || 0;
    });
  });
  return Object.values(map).sort((a, b) => b.revenue - a.revenue).slice(0, 10);
}

function computeBranchPerformance(orders, branches) {
  const map = {};
  branches.forEach(b => { map[b.id] = { id: b.id, name: b.name, sales: 0, orders: 0 }; });
  orders.forEach(o => {
    if (!map[o.branch_id]) return;
    map[o.branch_id].sales += o.total || 0;
    map[o.branch_id].orders += 1;
  });
  return Object.values(map)
    .map(b => ({ ...b, avgOrder: b.orders > 0 ? b.sales / b.orders : 0 }))
    .sort((a, b) => b.sales - a.sales);
}

export default function Dashboard() {
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [period, setPeriod] = useState("today");
  const [selectedBranch, setSelectedBranch] = useState("all");

  const fetchData = async (showRefreshing = false) => {
    if (showRefreshing) setRefreshing(true);
    const cutoff = period === "today" ? startOfDay(new Date())
      : period === "7d" ? subDays(new Date(), 7)
      : period === "30d" ? subDays(new Date(), 30)
      : startOfMonth(new Date());

    const [orderData, branchData, inventoryData] = await Promise.all([
      base44.entities.Order.list("-created_date", 1000),
      base44.entities.Branch.list(),
      base44.entities.InventoryItem.list("-updated_date", 200),
    ]);
    setOrders(orderData);
    setBranches(branchData);
    setInventoryItems(inventoryData);
    setLoading(false);
    if (showRefreshing) setRefreshing(false);
  };

  useEffect(() => { fetchData(); }, [period]);

  // Auto refresh every 60s
  useEffect(() => {
    const interval = setInterval(() => fetchData(true), 60000);
    return () => clearInterval(interval);
  }, [period]);

  const periodStart = useMemo(() => {
    if (period === "today") return startOfDay(new Date());
    if (period === "7d") return subDays(new Date(), 7);
    if (period === "30d") return subDays(new Date(), 30);
    return startOfMonth(new Date());
  }, [period]);

  const filteredOrders = useMemo(() => {
    return orders.filter(o => {
      if (!o.created_date) return false;
      const d = new Date(o.created_date);
      if (d < periodStart) return false;
      if (selectedBranch !== "all" && o.branch_id !== selectedBranch) return false;
      return true;
    });
  }, [orders, periodStart, selectedBranch]);

  const paidOrders = useMemo(() => filteredOrders.filter(o => o.status === "paid"), [filteredOrders]);
  const liveOrders = useMemo(() => filteredOrders.filter(o => ["pending", "preparing", "ready", "served"].includes(o.status)), [filteredOrders]);

  const totalSales = paidOrders.reduce((s, o) => s + (o.total || 0), 0);
  const totalOrders = filteredOrders.length;
  const avgOrder = paidOrders.length > 0 ? totalSales / paidOrders.length : 0;
  const vatCollected = totalSales * 0.05 / 1.05;
  const discounts = paidOrders.reduce((s, o) => s + (o.discount || 0), 0);
  const activeBranches = new Set(filteredOrders.map(o => o.branch_id)).size;

  const kpiData = { totalSales, totalOrders, avgOrder, vatCollected, discounts, activeBranches };
  const chartData = useMemo(() => buildChartData(paidOrders, period), [paidOrders, period]);
  const topProducts = useMemo(() => computeTopProducts(paidOrders), [paidOrders]);
  const branchPerformance = useMemo(() => computeBranchPerformance(paidOrders, branches), [paidOrders, branches]);

  const lowStockItems = useMemo(() => {
    return inventoryItems.filter(item => {
      const qty = item.current_quantity || 0;
      const threshold = item.low_stock_threshold || 5;
      return qty <= threshold;
    }).slice(0, 10);
  }, [inventoryItems]);

  const now = new Date();
  const dateLabel = `${now.toLocaleDateString("en-AE", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}`;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 pt-6 pb-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-white">Business Overview</h1>
              <p className="text-violet-200 text-sm mt-0.5">{dateLabel}</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {/* Branch filter */}
              <select
                value={selectedBranch}
                onChange={e => setSelectedBranch(e.target.value)}
                className="bg-white/10 text-white border border-white/20 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-white/30"
              >
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>

              {/* Period tabs */}
              <div className="flex bg-white/10 border border-white/20 rounded-xl overflow-hidden">
                {PERIODS.map(p => (
                  <button
                    key={p.key}
                    onClick={() => setPeriod(p.key)}
                    className={`px-3 py-2 text-xs font-semibold transition-all ${period === p.key ? "bg-white text-violet-700" : "text-violet-200 hover:bg-white/10"}`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {/* Refresh */}
              <button
                onClick={() => fetchData(true)}
                disabled={refreshing}
                className="w-9 h-9 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-white hover:bg-white/20 transition"
              >
                <RefreshCw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 -mt-4 pb-10 space-y-5">

        {/* KPI Cards */}
        <KPICards data={kpiData} loading={loading} />

        {/* Inventory Alerts */}
        {!loading && lowStockItems.length > 0 && <InventoryAlerts items={lowStockItems} />}

        {/* Chart + Branch Performance */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <div className="xl:col-span-2">
            <SalesTrendChart data={chartData} period={period} />
          </div>
          <div>
            <BranchPerformance data={branchPerformance} loading={loading} />
          </div>
        </div>

        {/* Top Products + Live Orders */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          <TopProducts data={topProducts} loading={loading} />
          <LiveOrders orders={liveOrders} branches={branches} loading={loading} />
        </div>

        {/* VAT Summary */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <h3 className="font-semibold text-gray-900 mb-4">VAT Summary</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Gross Sales", value: `AED ${totalSales.toFixed(2)}` },
              { label: "Net (ex. VAT)", value: `AED ${(totalSales / 1.05).toFixed(2)}` },
              { label: "VAT Collected (5%)", value: `AED ${vatCollected.toFixed(2)}`, highlight: true },
              { label: "Discounts", value: `AED ${discounts.toFixed(2)}` },
            ].map(item => (
              <div key={item.label} className={`rounded-xl p-4 ${item.highlight ? "bg-violet-50 border border-violet-200" : "bg-gray-50"}`}>
                <p className="text-xs text-gray-500 mb-1">{item.label}</p>
                <p className={`text-lg font-bold ${item.highlight ? "text-violet-700" : "text-gray-900"}`}>{item.value}</p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}