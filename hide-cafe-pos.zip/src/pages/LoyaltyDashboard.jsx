import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Star, Users, TrendingUp, Gift, Award, QrCode, ExternalLink } from "lucide-react";
import { createPageUrl } from "@/utils";

const REWARDS = [
  { points: 50, reward: "Free Cookie 🍪" },
  { points: 100, reward: "Free Coffee ☕" },
  { points: 200, reward: "Free Cake 🎂" },
  { points: 500, reward: "VIP Reward 🌟" },
];

const TIER_CONFIG = {
  Platinum: { color: "bg-slate-700", text: "text-white", icon: "💎", min: 500 },
  Gold: { color: "bg-amber-500", text: "text-white", icon: "🥇", min: 200 },
  Silver: { color: "bg-gray-300", text: "text-gray-800", icon: "🥈", min: 0 },
};

export default function LoyaltyDashboard() {
  const [customers, setCustomers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Customer.list("-points", 200),
      base44.entities.LoyaltyTransaction.list("-created_date", 100),
    ]).then(([c, t]) => {
      setCustomers(c.filter(x => x.loyalty_id));
      setTransactions(t);
      setLoading(false);
    });
  }, []);

  const totalPoints = customers.reduce((s, c) => s + (c.points || 0), 0);
  const totalRedeemed = transactions.filter(t => t.type === "redeem").reduce((s, t) => s + Math.abs(t.points_change), 0);
  const totalEarned = transactions.filter(t => t.type === "earn").reduce((s, t) => s + (t.points_change || 0), 0);

  const tierCounts = { Silver: 0, Gold: 0, Platinum: 0 };
  customers.forEach(c => { const t = c.tier || "Silver"; if (tierCounts[t] !== undefined) tierCounts[t]++; });

  const signupUrl = `${window.location.origin}/LoyaltySignup`;

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-8 h-8 border-4 border-violet-200 border-t-violet-600 rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Star className="w-6 h-6 text-amber-500" /> Loyalty Program
            </h1>
            <p className="text-gray-500 text-sm mt-0.5">Manage rewards and track customer loyalty</p>
          </div>
          <a href={signupUrl} target="_blank" rel="noreferrer"
            className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-xl text-sm font-semibold transition">
            <QrCode className="w-4 h-4" /> Customer Signup Page <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { label: "Loyalty Members", value: customers.length.toLocaleString(), StatIcon: Users, color: "bg-violet-500" },
            { label: "Points Issued", value: totalEarned.toLocaleString(), StatIcon: Star, color: "bg-amber-500" },
            { label: "Points Redeemed", value: totalRedeemed.toLocaleString(), StatIcon: Gift, color: "bg-green-500" },
            { label: "Active Balance", value: totalPoints.toLocaleString(), StatIcon: Award, color: "bg-blue-500" },
          ].map(({ label, value, StatIcon, color }) => (
            <div key={label} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
              <div className={`w-9 h-9 ${color} rounded-xl flex items-center justify-center mb-3`}>
                <StatIcon className="w-4 h-4 text-white" />
              </div>
              <p className="text-2xl font-black text-gray-900">{value}</p>
              <p className="text-xs text-gray-500 mt-0.5 font-medium">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Tier Distribution */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-bold text-gray-900 mb-4">Tier Breakdown</h2>
            <div className="space-y-3">
              {Object.entries(tierCounts).map(([tier, count]) => {
                const cfg = TIER_CONFIG[tier];
                const pct = customers.length > 0 ? (count / customers.length) * 100 : 0;
                return (
                  <div key={tier}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span>{cfg.icon}</span>
                        <span className="text-sm font-medium text-gray-700">{tier}</span>
                        <span className="text-xs text-gray-400">({cfg.min}+ pts)</span>
                      </div>
                      <span className="text-sm font-bold text-gray-900">{count}</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className={`h-full ${cfg.color} rounded-full transition-all`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 pt-4 border-t border-gray-100">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Rewards Chart</p>
              <div className="space-y-2">
                {REWARDS.map(r => (
                  <div key={r.points} className="flex items-center justify-between">
                    <span className="text-xs text-gray-600">{r.reward}</span>
                    <span className="text-xs font-bold bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">{r.points} pts</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Top Customers */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-bold text-gray-900 mb-4">Top Customers</h2>
            <div className="space-y-2.5 max-h-80 overflow-y-auto">
              {customers.slice(0, 20).map((c, i) => {
                const tier = c.tier || "Silver";
                const cfg = TIER_CONFIG[tier];
                return (
                  <div key={c.id} className="flex items-center gap-3 py-1.5">
                    <div className={`w-7 h-7 rounded-full ${cfg.color} flex items-center justify-center text-xs font-bold shrink-0 ${cfg.text}`}>
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">{c.name}</p>
                      <p className="text-xs text-gray-400">{c.phone || c.loyalty_id || "—"}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold text-amber-600">{(c.points || 0).toLocaleString()}</p>
                      <p className="text-[10px] text-gray-400">{cfg.icon} {tier}</p>
                    </div>
                  </div>
                );
              })}
              {customers.length === 0 && (
                <p className="text-gray-400 text-sm text-center py-8">No loyalty members yet</p>
              )}
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <h2 className="font-bold text-gray-900 mb-4">Recent Activity</h2>
            <div className="space-y-2.5 max-h-80 overflow-y-auto">
              {transactions.slice(0, 25).map(t => (
                <div key={t.id} className="flex items-start justify-between py-1.5 border-b border-gray-50 last:border-0">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-gray-800 truncate">{t.customer_name}</p>
                    <p className="text-[10px] text-gray-400">{t.description || t.type}</p>
                  </div>
                  <span className={`text-xs font-bold ml-2 shrink-0 ${t.points_change > 0 ? "text-green-600" : "text-red-500"}`}>
                    {t.points_change > 0 ? "+" : ""}{t.points_change} pts
                  </span>
                </div>
              ))}
              {transactions.length === 0 && (
                <p className="text-gray-400 text-sm text-center py-8">No transactions yet</p>
              )}
            </div>
          </div>
        </div>

        {/* Signup QR */}
        <div className="mt-6 bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex items-center gap-6">
          <div className="bg-gray-50 rounded-xl p-3">
            <img
              src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(signupUrl)}`}
              alt="Signup QR"
              className="w-28 h-28"
            />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-lg">Customer Signup QR Code</h3>
            <p className="text-gray-500 text-sm mt-1">Print this QR code and display it at your counter. Customers scan it to join your loyalty program.</p>
            <p className="text-xs text-violet-600 font-mono mt-2">{signupUrl}</p>
          </div>
        </div>
      </div>
    </div>
  );
}