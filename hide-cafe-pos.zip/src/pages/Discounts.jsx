import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Edit2, X, Search, Zap } from "lucide-react";
import { toast } from "sonner";

const TYPE_CONFIG = {
  percentage: { label: "Percentage", color: "bg-blue-100 text-blue-700" },
  fixed_amount: { label: "Fixed Amount", color: "bg-green-100 text-green-700" },
  item_specific: { label: "Item Specific", color: "bg-purple-100 text-purple-700" },
};

export default function Discounts() {
  const [discounts, setDiscounts] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState(false);
  const [showPromoMenu, setShowPromoMenu] = useState(false);
  const [promoOrders, setPromoOrders] = useState([]);
  const [form, setForm] = useState({
    name: "",
    description: "",
    type: "percentage",
    value: 0,
    is_active: true,
    applicable_items: [],
    applicable_branches: [],
    customer_tags: [],
    usage_limit: 0,
    min_order_amount: 0,
    start_date: "",
    end_date: "",
    notes: "",
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [discountData, itemsData, branchesData, orderData] = await Promise.all([
      base44.entities.Discount.list("-created_date"),
      base44.entities.MenuItem.list("name"),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 100),
    ]);
    setDiscounts(discountData);
    setMenuItems(itemsData);
    setBranches(branchesData);
    setPromoOrders(orderData);
    setLoading(false);
  };

  const openForm = (discount = null) => {
    if (discount) {
      setForm(discount);
      setEditing(discount.id);
    } else {
      setForm({
        name: "",
        description: "",
        type: "percentage",
        value: 0,
        is_active: true,
        applicable_items: [],
        applicable_branches: [],
        customer_tags: [],
        usage_limit: 0,
        min_order_amount: 0,
        start_date: "",
        end_date: "",
        notes: "",
      });
      setEditing(null);
    }
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name.trim() || form.value <= 0) {
      toast.error("Enter discount name and value");
      return;
    }
    setSaving(true);

    try {
      if (editing) {
        await base44.entities.Discount.update(editing, form);
        toast.success("Discount updated");
      } else {
        await base44.entities.Discount.create(form);
        toast.success("Discount created");
      }
      setShowForm(false);
      loadData();
    } catch (e) {
      toast.error("Error saving discount");
    }
    setSaving(false);
  };

  const deleteDiscount = async (id) => {
    if (!confirm("Delete this discount?")) return;
    await base44.entities.Discount.delete(id);
    toast.success("Discount deleted");
    setDiscounts(prev => prev.filter(d => d.id !== id));
  };

  const canUseDiscount = (discount, customerTags = []) => {
    if (!discount.is_active) return false;
    const today = new Date().toISOString().split("T")[0];
    if (discount.start_date && discount.start_date > today) return false;
    if (discount.end_date && discount.end_date < today) return false;
    if (discount.usage_limit > 0 && discount.times_used >= discount.usage_limit) return false;
    if (discount.customer_tags?.length > 0 && !customerTags.some(t => discount.customer_tags.includes(t))) return false;
    return true;
  };

  const filteredDiscounts = discounts.filter(d =>
    d.name.toLowerCase().includes(search.toLowerCase())
  );

  const activePromos = discounts.filter(d => {
    const today = new Date().toISOString().split("T")[0];
    return d.is_active && 
      (!d.start_date || d.start_date <= today) &&
      (!d.end_date || d.end_date >= today) &&
      (d.usage_limit === 0 || d.times_used < d.usage_limit);
  });

  const sendPromoToPos = (discount) => {
    window.dispatchEvent(new CustomEvent("pos:applyPromo", { detail: discount }));
    toast.success(`Promo "${discount.name}" sent to POS!`);
    setShowPromoMenu(false);
  };

  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Discounts</h1>
            <p className="text-gray-400 text-sm mt-0.5">Manage promotional discounts</p>
          </div>
          <div className="flex gap-3">
            {activePromos.length > 0 && (
              <div className="relative">
                <button
                  onClick={() => setShowPromoMenu(!showPromoMenu)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition transform hover:scale-105 gap-2"
                >
                  <Zap className="w-5 h-5 animate-pulse" />
                  Active Promos ({activePromos.length})
                </button>
                {showPromoMenu && (
                  <div className="absolute top-full right-0 mt-2 bg-white border-2 border-amber-400 rounded-2xl shadow-2xl z-40 min-w-80 p-3">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-bold text-gray-900">✨ Quick Apply to POS</span>
                      <button onClick={() => setShowPromoMenu(false)} className="text-gray-400 hover:text-gray-600">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {activePromos.map(promo => {
                        const promoValue = promo.type === "percentage" ? `${promo.value}%` : `AED ${promo.value.toFixed(2)}`;
                        return (
                          <button
                            key={promo.id}
                            onClick={() => sendPromoToPos(promo)}
                            className="w-full text-left px-4 py-3 rounded-xl bg-gradient-to-r from-amber-50 to-orange-50 hover:from-amber-100 hover:to-orange-100 border-2 border-transparent hover:border-amber-400 transition group"
                          >
                            <div className="flex justify-between items-start gap-2">
                              <div className="flex-1">
                                <div className="font-bold text-gray-900 group-hover:text-amber-700">{promo.name}</div>
                                {promo.description && <div className="text-xs text-gray-600 mt-0.5">{promo.description}</div>}
                              </div>
                              <div className="text-right shrink-0">
                                <div className="font-bold text-lg text-orange-600">{promoValue}</div>
                                <div className="text-xs text-gray-500">Used: {promo.times_used || 0}</div>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
            <Button onClick={() => openForm()} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
              <Plus className="w-4 h-4" /> New Discount
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            placeholder="Search discounts..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full border border-gray-200 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-violet-400"
          />
        </div>

        {/* Discounts list */}
        <div className="space-y-3">
          {filteredDiscounts.length === 0 ? (
            <div className="text-center py-16 text-gray-300">
              <p className="text-sm">No discounts yet</p>
              <p className="text-xs mt-1">Click "New Discount" to create one</p>
            </div>
          ) : (
            filteredDiscounts.map(discount => {
              const applicableItemsInfo = discount.applicable_items?.length > 0
                ? `${discount.applicable_items.length} items`
                : "All items";
              const branchesInfo = discount.applicable_branches?.length > 0
                ? `${discount.applicable_branches.length} branches`
                : "All branches";

              return (
                <div key={discount.id} className="bg-white border border-gray-100 rounded-2xl p-4 hover:shadow-sm transition">
                  <div className="flex items-start justify-between flex-wrap gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 flex-wrap mb-2">
                        <h3 className="font-bold text-gray-900">{discount.name}</h3>
                        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${TYPE_CONFIG[discount.type].color}`}>
                          {TYPE_CONFIG[discount.type].label}
                        </span>
                        {!discount.is_active && (
                          <span className="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 font-semibold">Inactive</span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{discount.description}</p>
                      <div className="flex gap-4 text-xs text-gray-500 flex-wrap">
                        <span className="font-semibold text-gray-700">
                          {discount.type === "percentage" ? `${discount.value}%` : `AED ${discount.value.toFixed(2)}`}
                        </span>
                        <span>{applicableItemsInfo}</span>
                        <span>{branchesInfo}</span>
                        {discount.min_order_amount > 0 && <span>Min: AED {discount.min_order_amount.toFixed(2)}</span>}
                        {discount.usage_limit > 0 && <span>Used: {discount.times_used}/{discount.usage_limit}</span>}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => openForm(discount)} className="p-2 hover:bg-gray-100 rounded-lg transition text-gray-600">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteDiscount(discount.id)} className="p-2 hover:bg-red-50 rounded-lg transition text-gray-600 hover:text-red-600">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 sticky top-0 bg-white">
              <h2 className="font-bold text-gray-900 text-lg">{editing ? "Edit Discount" : "New Discount"}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-300 hover:text-gray-600 transition">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-6 py-4 space-y-4">
              {/* Name & Type */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Name *</label>
                  <Input
                    placeholder="e.g., Happy Hour 20% Off"
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    className="border-gray-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Type *</label>
                  <select
                    value={form.type}
                    onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                    className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
                  >
                    {Object.entries(TYPE_CONFIG).map(([key, val]) => (
                      <option key={key} value={key}>{val.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Value */}
              <div>
                <label className="text-xs text-gray-600 mb-1.5 block font-semibold">
                  Value * {form.type === "percentage" ? "(%)" : "(AED)"}
                </label>
                <Input
                  type="number"
                  min="0"
                  step={form.type === "percentage" ? "1" : "0.01"}
                  max={form.type === "percentage" ? "100" : undefined}
                  placeholder="0"
                  value={form.value}
                  onChange={e => setForm(f => ({ ...f, value: parseFloat(e.target.value) || 0 }))}
                  className="border-gray-200 rounded-xl"
                />
              </div>

              {/* Description */}
              <div>
                <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Description</label>
                <textarea
                  placeholder="e.g., Available on all beverages"
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
                  rows="2"
                />
              </div>

              {/* Conditions */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Min Order Amount (AED)</label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0"
                    value={form.min_order_amount}
                    onChange={e => setForm(f => ({ ...f, min_order_amount: parseFloat(e.target.value) || 0 }))}
                    className="border-gray-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Max Discount Amount (AED)</label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Unlimited"
                    value={form.max_discount_amount || ""}
                    onChange={e => setForm(f => ({ ...f, max_discount_amount: e.target.value ? parseFloat(e.target.value) : undefined }))}
                    className="border-gray-200 rounded-xl"
                  />
                </div>
              </div>

              {/* Usage Limit */}
              <div>
                <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Usage Limit (0 = unlimited)</label>
                <Input
                  type="number"
                  min="0"
                  placeholder="0"
                  value={form.usage_limit}
                  onChange={e => setForm(f => ({ ...f, usage_limit: parseInt(e.target.value) || 0 }))}
                  className="border-gray-200 rounded-xl"
                />
              </div>

              {/* Dates */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Start Date</label>
                  <Input
                    type="date"
                    value={form.start_date}
                    onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))}
                    className="border-gray-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">End Date</label>
                  <Input
                    type="date"
                    value={form.end_date}
                    onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))}
                    className="border-gray-200 rounded-xl"
                  />
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="active"
                  checked={form.is_active}
                  onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))}
                  className="w-4 h-4 rounded border-gray-200 accent-violet-600"
                />
                <label htmlFor="active" className="text-sm text-gray-700 font-medium cursor-pointer">
                  Active
                </label>
              </div>

              {/* Branches */}
              {branches.length > 1 && (
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Applicable Branches (leave empty for all)</label>
                  <div className="space-y-2">
                    {branches.map(branch => (
                      <label key={branch.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={form.applicable_branches.includes(branch.id)}
                          onChange={e => setForm(f => ({
                            ...f,
                            applicable_branches: e.target.checked
                              ? [...f.applicable_branches, branch.id]
                              : f.applicable_branches.filter(id => id !== branch.id),
                          }))}
                          className="w-4 h-4 rounded border-gray-200 accent-violet-600"
                        />
                        <span className="text-sm text-gray-700">{branch.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Item Specific */}
              {form.type === "item_specific" && (
                <div>
                  <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Applicable Items</label>
                  <div className="max-h-48 overflow-y-auto space-y-2 border border-gray-200 rounded-xl p-3">
                    {menuItems.length === 0 ? (
                      <p className="text-xs text-gray-400">No menu items available</p>
                    ) : (
                      menuItems.map(item => (
                        <label key={item.id} className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={form.applicable_items.includes(item.id)}
                            onChange={e => setForm(f => ({
                              ...f,
                              applicable_items: e.target.checked
                                ? [...f.applicable_items, item.id]
                                : f.applicable_items.filter(id => id !== item.id),
                            }))}
                            className="w-4 h-4 rounded border-gray-200 accent-violet-600"
                          />
                          <span className="text-sm text-gray-700">{item.name}</span>
                        </label>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="text-xs text-gray-600 mb-1.5 block font-semibold">Internal Notes</label>
                <textarea
                  placeholder="Internal notes..."
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
                  rows="2"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-gray-100 sticky bottom-0 bg-white">
              <Button onClick={() => setShowForm(false)} variant="outline" className="border-gray-200 rounded-xl">Cancel</Button>
              <Button onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl">
                {saving ? "Saving..." : "Save Discount"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}