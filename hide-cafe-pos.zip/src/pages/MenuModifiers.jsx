import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Pencil, Trash2, ChevronRight, Download, Filter, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { format } from "date-fns";
import ModifierGroupModal from "@/components/menu/ModifierGroupModal";

export default function MenuModifiers() {
  const [groups, setGroups] = useState([]);
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(null); // null | "create" | group object
  const [activeTab, setActiveTab] = useState("groups"); // "groups" | "options"
  const [optionFilter, setOptionFilter] = useState("All"); // "All", "Active", "Inactive", "Deleted"

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const groupsData = await base44.entities.ModifierGroup.list("-created_date");
    setGroups(groupsData);
    
    // Fetch all modifier options from all groups
    const allOptions = [];
    groupsData.forEach(group => {
      (group.options || []).forEach(opt => {
        allOptions.push({
          ...opt,
          group_id: group.id,
          group_name: group.name,
          sku: `option-${group.id.slice(0, 6)}-${allOptions.length + 1}`.toLowerCase()
        });
      });
    });
    setOptions(allOptions);
    setLoading(false);
  };

  const handleSave = async (formData) => {
    if (modal?.id) {
      await base44.entities.ModifierGroup.update(modal.id, formData);
      toast.success("Modifier group updated");
    } else {
      await base44.entities.ModifierGroup.create(formData);
      toast.success("Modifier group created");
    }
    setModal(null);
    load();
  };

  const handleDelete = async (group) => {
    if (!window.confirm(`Delete "${group.name}"? This cannot be undone.`)) return;
    await base44.entities.ModifierGroup.delete(group.id);
    toast.success("Deleted");
    setGroups(prev => prev.filter(g => g.id !== group.id));
  };

  const filteredOptions = optionFilter === "All" ? options : options.filter(opt => opt.active !== false);

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Tabs */}
        <div className="flex gap-8 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("groups")}
            className={`pb-3 text-sm font-medium transition ${activeTab === "groups" ? "text-gray-900 border-b-2 border-violet-600" : "text-gray-500 hover:text-gray-700"}`}
          >
            Modifiers Groups
          </button>
          <button
            onClick={() => setActiveTab("options")}
            className={`pb-3 text-sm font-medium transition ${activeTab === "options" ? "text-gray-900 border-b-2 border-violet-600" : "text-gray-500 hover:text-gray-700"}`}
          >
            Modifier Options
          </button>
        </div>

        {/* Groups Tab */}
        {activeTab === "groups" && (
          <div>
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Modifier Groups</h1>
                <p className="text-sm text-gray-400 mt-0.5">Create and manage modifier groups for your menu items</p>
              </div>
              <Button
                onClick={() => setModal("create")}
                className="bg-violet-600 hover:bg-violet-700 text-white gap-1.5"
              >
                <Plus className="w-4 h-4" /> Create Modifier
              </Button>
            </div>

            {/* Table */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="grid grid-cols-12 px-5 py-3 text-xs font-semibold text-gray-400 uppercase tracking-wider border-b border-gray-100">
            <div className="col-span-3">Name</div>
            <div className="col-span-2">Reference</div>
            <div className="col-span-2">Options</div>
            <div className="col-span-2">Rules</div>
            <div className="col-span-2">Created</div>
            <div className="col-span-1" />
          </div>

          {loading ? (
            <div className="text-center py-16 text-gray-300 text-sm">Loading...</div>
          ) : groups.length === 0 ? (
            <div className="text-center py-16 text-gray-300 text-sm">
              No modifier groups yet. Click "Create Modifier" to add one.
            </div>
          ) : (
            groups.map(group => (
              <div key={group.id} className="grid grid-cols-12 px-5 py-3.5 items-center border-b border-gray-50 last:border-0 hover:bg-gray-50 transition group">
                <div className="col-span-3 font-medium text-gray-800 text-sm flex items-center gap-2">
                  {group.name}
                  {group.required && <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full font-semibold">Required</span>}
                </div>
                <div className="col-span-2 text-sm text-gray-400">{group.reference || "—"}</div>
                <div className="col-span-2">
                  {group.options?.length > 0 ? (
                    <span className="text-sm text-violet-600 font-medium">Options ({group.options.length})</span>
                  ) : (
                    <span className="text-sm text-gray-300">Options (0)</span>
                  )}
                </div>
                <div className="col-span-2 text-xs text-gray-500">
                  Min: {group.min_select ?? 0} · Max: {group.max_select ?? 1}
                </div>
                <div className="col-span-2 text-sm text-gray-400">
                  {group.created_date ? format(new Date(group.created_date), "MMM dd, hh:mmaaa") : "—"}
                </div>
                <div className="col-span-1 flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition">
                  <button
                    onClick={() => setModal(group)}
                    className="p-1.5 text-gray-400 hover:text-violet-600 rounded-lg hover:bg-violet-50"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(group)}
                    className="p-1.5 text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
            </div>
          </div>
        )}

        {/* Options Tab */}
        {activeTab === "options" && (
          <div>
            {/* Header with title and buttons */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-bold text-gray-900">Modifier Options</h2>
                <button className="p-1 text-gray-400 hover:text-gray-600" title="Manage individual modifier options">
                  <HelpCircle className="w-5 h-5" />
                </button>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="border-gray-200 gap-2">
                  <Download className="w-4 h-4" />
                  Import / Export
                </Button>
                <Button onClick={() => setModal("create")} className="bg-violet-600 hover:bg-violet-700 text-white">
                  Create Option
                </Button>
              </div>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-3 mb-4">
              <div className="flex gap-2">
                {["All", "Active", "Inactive", "Deleted"].map(status => (
                  <button
                    key={status}
                    onClick={() => setOptionFilter(status)}
                    className={`text-sm font-medium transition ${optionFilter === status ? "text-gray-900 border-b-2 border-violet-600 pb-2" : "text-gray-500 hover:text-gray-700"}`}
                  >
                    {status}
                  </button>
                ))}
              </div>
              <div className="ml-auto">
                <Button variant="outline" className="border-gray-200 gap-2">
                  <Filter className="w-4 h-4" />
                  Filter
                </Button>
              </div>
            </div>

            {/* Options Table */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="grid grid-cols-12 px-5 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                <div className="col-span-1"><input type="checkbox" className="rounded w-4 h-4" /></div>
                <div className="col-span-3">Name</div>
                <div className="col-span-2">SKU</div>
                <div className="col-span-2">Modifier</div>
                <div className="col-span-2">Price</div>
                <div className="col-span-1">Tax Group</div>
                <div className="col-span-1">Active</div>
              </div>

              {loading ? (
                <div className="text-center py-16 text-gray-300 text-sm">Loading...</div>
              ) : filteredOptions.length === 0 ? (
                <div className="text-center py-16 text-gray-300 text-sm">
                  No modifier options yet.
                </div>
              ) : (
                filteredOptions.map((opt, idx) => (
                  <div key={idx} className="grid grid-cols-12 px-5 py-3.5 items-center border-b border-gray-50 last:border-0 hover:bg-gray-50 transition">
                    <div className="col-span-1"><input type="checkbox" className="rounded w-4 h-4" /></div>
                    <div className="col-span-3 font-medium text-gray-800 text-sm">{opt.name}</div>
                    <div className="col-span-2 text-sm text-gray-500 font-mono">{opt.sku}</div>
                    <div className="col-span-2 text-sm text-gray-600">{opt.group_name}</div>
                    <div className="col-span-2 text-sm text-gray-800 font-medium">฿ {opt.price || 0}</div>
                    <div className="col-span-1 text-sm text-gray-500">VAT</div>
                    <div className="col-span-1 text-sm font-medium text-green-600">Active</div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {modal && (
        <ModifierGroupModal
          group={modal === "create" ? null : modal}
          onSave={handleSave}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}