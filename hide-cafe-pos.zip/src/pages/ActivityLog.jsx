import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfDay, startOfMonth, isAfter, subDays } from "date-fns";
import { Activity, Users, ShoppingBag, Edit3, Trash2, Plus } from "lucide-react";

export default function ActivityLog() {
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.Order.list("-created_date", 200),
      base44.entities.Customer.list("-updated_date", 100),
    ]).then(([u, b, o, c]) => {
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setOrders(o);
      setCustomers(c);
      setLoading(false);
    });
  }, []);

  const activityLog = useMemo(() => {
    const events = [];

    // Add order events
    orders.forEach(o => {
      if (!selectedBranchId || o.branch_id === selectedBranchId) {
        events.push({
          timestamp: o.created_date,
          type: "order_created",
          icon: ShoppingBag,
          title: `Order #${o.order_number || o.id}`,
          description: `${o.customer_name || "Guest"} placed an order for AED ${(o.total || 0).toFixed(2)}`,
          color: "bg-blue-50 text-blue-600",
        });
        if (o.status === "paid") {
          events.push({
            timestamp: o.updated_date,
            type: "order_paid",
            icon: Edit3,
            title: `Order #${o.order_number || o.id} Paid`,
            description: `Payment received via ${o.payment_method || "unknown"}`,
            color: "bg-green-50 text-green-600",
          });
        }
      }
    });

    // Add customer events
    customers.forEach(c => {
      events.push({
        timestamp: c.created_date,
        type: "customer_created",
        icon: Users,
        title: `Customer: ${c.name}`,
        description: `New customer registered`,
        color: "bg-purple-50 text-purple-600",
      });
    });

    // Sort by timestamp descending
    return events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  }, [orders, customers, selectedBranchId]);

  const filtered = useMemo(() => {
    if (!searchTerm) return activityLog;
    const term = searchTerm.toLowerCase();
    return activityLog.filter(e => 
      e.title.toLowerCase().includes(term) || 
      e.description.toLowerCase().includes(term)
    );
  }, [activityLog, searchTerm]);

  if (loading) return <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Activity Log</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-3 flex-wrap">
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
          <input
            type="text"
            placeholder="Search activity…"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="px-4 py-1.5 rounded-lg text-sm bg-white border border-gray-200 text-gray-700 placeholder:text-gray-400 focus:outline-none focus:border-violet-400"
          />
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
          {filtered.length === 0 ? (
            <div className="py-16 text-center">
              <Activity className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">No activity found</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {filtered.map((event, idx) => {
                const Icon = event.icon;
                return (
                  <div key={idx} className="px-6 py-4 hover:bg-gray-50 transition flex items-start gap-4">
                    <div className={`w-10 h-10 ${event.color} rounded-lg flex items-center justify-center shrink-0 mt-0.5`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-800">{event.title}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{event.description}</p>
                      <p className="text-xs text-gray-300 mt-1">{format(new Date(event.timestamp), "MMM d, yyyy · h:mm a")}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}