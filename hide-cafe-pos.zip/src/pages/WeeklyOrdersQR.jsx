import React, { useEffect, useRef, useState } from "react";
import { Copy, Download, QrCode, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function WeeklyOrdersQR() {
  const canvasRef = useRef(null);
  const [copied, setCopied] = useState(false);

  const appUrl = window.location.origin + "/WeeklyOrdersLogin";

  useEffect(() => {
    // Simple QR code using a free API
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(appUrl)}&color=5B2CC0&bgcolor=FFFFFF`;
    img.onload = () => {
      canvas.width = 250;
      canvas.height = 250;
      ctx.drawImage(img, 0, 0);
    };
  }, [appUrl]);

  const handleCopy = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    toast.success("Link copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement("a");
    link.download = "weekly-orders-qr.png";
    link.href = canvas.toDataURL("image/png");
    link.click();
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-lg mx-auto space-y-6">

        <div>
          <h1 className="text-2xl font-bold text-gray-900">Weekly Orders Access</h1>
          <p className="text-sm text-gray-400 mt-1">Share this link or QR code with your staff</p>
        </div>

        {/* QR Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-2"
            style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}>
            <QrCode className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-lg font-bold text-gray-800">Scan to Open Weekly Orders</h2>
          <p className="text-xs text-gray-400 text-center">Print and place this in the kitchen or staff area</p>

          <div className="border-4 border-violet-100 rounded-2xl overflow-hidden p-2 bg-white shadow-sm">
            <canvas ref={canvasRef} className="rounded-xl" style={{ width: 200, height: 200 }} />
          </div>

          <div className="flex gap-3 w-full">
            <Button onClick={handleDownload} variant="outline" className="flex-1 rounded-xl border-gray-200 gap-2">
              <Download className="w-4 h-4" /> Download QR
            </Button>
          </div>
        </div>

        {/* Link Card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-3">
          <h3 className="text-sm font-semibold text-gray-700">Direct Link</h3>
          <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3">
            <span className="flex-1 text-sm text-gray-600 font-mono truncate">{appUrl}</span>
          </div>
          <Button onClick={handleCopy} className="w-full bg-violet-600 hover:bg-violet-700 text-white rounded-xl gap-2">
            {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? "Copied!" : "Copy Link"}
          </Button>
        </div>

        {/* Instructions */}
        <div className="bg-violet-50 border border-violet-100 rounded-2xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-violet-800">How it works</h3>
          <div className="space-y-2">
            {[
              "Staff scan the QR code or open the link on their phone",
              "They enter their 4-digit staff PIN",
              "They see the Weekly Orders page for their branch",
              "They can submit new requests or view existing ones",
            ].map((step, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className="w-5 h-5 rounded-full bg-violet-600 text-white text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </div>
                <p className="text-sm text-violet-700">{step}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Staff PIN note */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-sm text-amber-700">
          <strong>⚠️ Staff PINs</strong> are set in the <strong>Staff Management</strong> page. Make sure each staff member has a unique 4-digit PIN assigned before sharing this link.
        </div>

      </div>
    </div>
  );
}