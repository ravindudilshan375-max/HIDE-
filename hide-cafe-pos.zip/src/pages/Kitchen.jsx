import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { format, formatDistanceToNow } from "date-fns";
import { ChefHat, Clock, CheckCircle2, Flame, ChevronDown, Volume2, VolumeX } from "lucide-react";

const STATUS_ORDER = ["pending", "preparing", "ready"];

const COLUMN_CONFIG = {
  pending: {
    label: "Incoming",
    color: "text-yellow-600",
    border: "border-yellow-300",
    bg: "bg-yellow-50",
    headerBg: "bg-yellow-50",
    dot: "bg-yellow-400",
  },
  preparing: {
    label: "Preparing",
    color: "text-blue-600",
    border: "border-blue-200",
    bg: "bg-blue-50",
    headerBg: "bg-blue-50",
    dot: "bg-blue-400 animate-pulse",
  },
  ready: {
    label: "Ready",
    color: "text-green-600",
    border: "border-green-200",
    bg: "bg-green-50",
    headerBg: "bg-green-50",
    dot: "bg-green-400",
  },
};

function playNewOrderSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const beep = (freq, start, duration, vol = 0.5) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(vol, ctx.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + duration);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + duration);
    };
    beep(1047, 0, 0.18, 0.6);
    beep(880, 0.22, 0.18, 0.5);
    beep(1047, 0.5, 0.18, 0.6);
    beep(880, 0.72, 0.18, 0.5);
    beep(1175, 1.0, 0.3, 0.7);
  } catch (_) {}
}

function OrderCard({ order, onUpdateStatus, onToggleItem }) {
  const config = COLUMN_CONFIG[order.status] || COLUMN_CONFIG.pending;
  const age = order.created_date
    ? formatDistanceToNow(new Date(order.created_date), { addSuffix: false })
    : "";

  const items = order.items || [];
  const nonVoided = items.filter(it => !it.is_voided);
  const readyCount = nonVoided.filter(it => it.item_status === "ready").length;
  const allReady = nonVoided.length > 0 && readyCount === nonVoided.length;

  return (
    <div className={`rounded-2xl border-2 ${config.border} bg-white shadow-sm overflow-hidden`}>
      {/* Card Header */}
      <div className={`px-4 py-3 ${config.headerBg} flex items-start justify-between border-b ${config.border}`}>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-gray-900 text-base">
              {order.order_number || `#${order.id?.slice(-5)}`}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${
              order.type === "dine-in"
                ? "bg-amber-50 text-amber-600 border-amber-200"
                : order.type === "delivery"
                  ? "bg-blue-50 text-blue-600 border-blue-200"
                  : "bg-purple-50 text-purple-600 border-purple-200"
            }`}>
              {order.type === "dine-in" ? `Table ${order.table_number}` : order.type === "delivery" ? "Delivery" : "Takeaway"}
            </span>
          </div>
          {order.customer_name && (
            <p className="text-xs text-gray-500 mt-0.5">{order.customer_name}</p>
          )}
        </div>
        <div className="flex items-center gap-1 text-gray-400 text-xs">
          <Clock className="w-3 h-3" />
          <span>{age}</span>
        </div>
      </div>

      {/* Items with per-item checkboxes */}
      <ul className="divide-y divide-gray-50">
        {nonVoided.map((item, i) => {
          const isReady = item.item_status === "ready";
          return (
            <li
              key={i}
              onClick={() => onToggleItem(order, i)}
              className={`flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors select-none ${
                isReady ? "bg-green-50" : "hover:bg-gray-50"
              }`}
            >
              {/* Checkbox */}
              <div className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                isReady
                  ? "bg-green-500 border-green-500"
                  : "border-gray-300 bg-white"
              }`}>
                {isReady && (
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>

              {/* Qty badge */}
              <span className={`w-6 h-6 rounded-md text-xs flex items-center justify-center font-bold shrink-0 ${
                isReady ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-700"
              }`}>
                {item.quantity}
              </span>

              {/* Name + details */}
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-semibold leading-tight ${isReady ? "line-through text-gray-400" : "text-gray-800"}`}>
                  {item.name}
                  {item.isCustom && <span className="ml-1.5 text-xs bg-violet-100 text-violet-600 px-1.5 py-0.5 rounded">custom</span>}
                </p>
                {item.modifiers?.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-0.5">
                    {item.modifiers.map((m, mi) => (
                      <span key={mi} className="text-xs bg-orange-100 text-orange-700 border border-orange-200 px-1.5 py-0.5 rounded font-medium">
                        + {m.name}
                      </span>
                    ))}
                  </div>
                )}
                {item.notes && (
                  <p className="text-xs text-amber-600 italic mt-0.5">⚠ {item.notes}</p>
                )}
              </div>
            </li>
          );
        })}
      </ul>

      {/* Order Notes */}
      {order.notes && (
        <div className="px-4 pb-3">
          <p className="text-xs bg-amber-50 text-amber-700 rounded-lg px-3 py-2 border border-amber-200">
            📝 {order.notes}
          </p>
        </div>
      )}

      {/* Footer Action */}
      <div className="px-4 pb-4 pt-2">
        {order.status === "pending" && (
          <button
            onClick={(e) => { e.stopPropagation(); onUpdateStatus(order.id, "preparing"); }}
            className="w-full py-2.5 rounded-xl text-sm font-semibold bg-blue-500 hover:bg-blue-600 text-white transition-all"
          >
            Start Preparing
          </button>
        )}

        {order.status === "preparing" && !allReady && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-gray-500 px-1">
              <span>Tap items to mark ready</span>
              <span className={`font-semibold ${readyCount > 0 ? "text-green-600" : "text-gray-400"}`}>
                {readyCount}/{nonVoided.length}
              </span>
            </div>
            {/* Progress bar */}
            <div className="w-full bg-gray-100 rounded-full h-1.5">
              <div
                className="bg-green-400 h-1.5 rounded-full transition-all duration-300"
                style={{ width: nonVoided.length > 0 ? `${(readyCount / nonVoided.length) * 100}%` : "0%" }}
              />
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); onUpdateStatus(order.id, "ready"); }}
              className="w-full py-2.5 rounded-xl text-sm font-semibold bg-green-500 hover:bg-green-600 text-white transition-all"
            >
              Mark Order Ready
            </button>
          </div>
        )}

        {order.status === "preparing" && allReady && (
          <div className="space-y-2">
            <div className="flex items-center justify-center gap-2 py-1.5 text-green-600 text-sm font-semibold">
              <CheckCircle2 className="w-4 h-4" /> All items ready!
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); onUpdateStatus(order.id, "ready"); }}
              className="w-full py-2.5 rounded-xl text-sm font-semibold bg-green-500 hover:bg-green-600 text-white transition-all"
            >
              Complete Order
            </button>
          </div>
        )}

        {order.status === "ready" && (
          <div className="flex items-center justify-center gap-2 py-2 text-green-600 text-sm font-semibold">
            <CheckCircle2 className="w-4 h-4" /> Ready for pickup
          </div>
        )}
      </div>
    </div>
  );
}

export default function Kitchen() {
  const [orders, setOrders] = useState([]);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState("all");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [newOrderFlash, setNewOrderFlash] = useState(false);
  const initialLoadDone = useRef(false);
  const soundEnabledRef = useRef(true);

  useEffect(() => { soundEnabledRef.current = soundEnabled; }, [soundEnabled]);

  useEffect(() => {
    base44.entities.Branch.list().then(setBranches);

    base44.entities.Order.list("-created_date", 200).then(data => {
      setOrders(data.filter(o => ["pending", "preparing", "ready"].includes(o.status)));
      initialLoadDone.current = true;
    });

    const unsub = base44.entities.Order.subscribe((event) => {
      setLastUpdate(new Date());
      if (event.type === "create") {
        if (["pending", "preparing", "ready"].includes(event.data.status)) {
          setOrders(prev => [event.data, ...prev]);
          if (initialLoadDone.current && soundEnabledRef.current) {
            playNewOrderSound();
            setNewOrderFlash(true);
            setTimeout(() => setNewOrderFlash(false), 2000);
          }
        }
      } else if (event.type === "update") {
        setOrders(prev => {
          if (!["pending", "preparing", "ready"].includes(event.data.status)) {
            return prev.filter(o => o.id !== event.id);
          }
          const exists = prev.find(o => o.id === event.id);
          if (exists) return prev.map(o => o.id === event.id ? event.data : o);
          return [event.data, ...prev];
        });
      } else if (event.type === "delete") {
        setOrders(prev => prev.filter(o => o.id !== event.id));
      }
    });

    return () => unsub();
  }, []);

  const updateStatus = async (id, status) => {
    await base44.entities.Order.update(id, { status });
    setOrders(prev => {
      if (!["pending", "preparing", "ready"].includes(status)) {
        return prev.filter(o => o.id !== id);
      }
      return prev.map(o => o.id === id ? { ...o, status } : o);
    });
  };

  const toggleItem = async (order, itemIndex) => {
    // When tapping an item in 'pending', auto-start preparing first
    let currentStatus = order.status;
    const updatedItems = (order.items || []).map((it, i) => {
      if (i !== itemIndex) return it;
      return { ...it, item_status: it.item_status === "ready" ? "preparing" : "ready" };
    });

    const nonVoided = updatedItems.filter(it => !it.is_voided);
    const allReady = nonVoided.length > 0 && nonVoided.every(it => it.item_status === "ready");

    let newOrderStatus = currentStatus;
    if (currentStatus === "pending") newOrderStatus = "preparing";
    if (allReady) newOrderStatus = "ready";

    // Optimistic update
    setOrders(prev => prev.map(o => o.id === order.id
      ? { ...o, items: updatedItems, status: newOrderStatus }
      : o
    ));

    await base44.entities.Order.update(order.id, {
      items: updatedItems,
      status: newOrderStatus,
    });
  };

  const filteredOrders = selectedBranchId === "all"
    ? orders
    : orders.filter(o => o.branch_id === selectedBranchId);

  const columns = STATUS_ORDER.map(status => ({
    status,
    config: COLUMN_CONFIG[status],
    orders: filteredOrders.filter(o => o.status === status).sort((a, b) =>
      new Date(a.created_date) - new Date(b.created_date)
    ),
  }));

  return (
    <div className="min-h-screen bg-gray-900 text-gray-900 flex flex-col">
      {/* Header */}
      <div className={`px-6 py-3 border-b border-gray-700 flex items-center justify-between transition-colors duration-500 ${newOrderFlash ? "bg-yellow-900" : "bg-gray-800"}`}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-orange-500/20 flex items-center justify-center">
            <ChefHat className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">Kitchen Display</h1>
            <p className="text-xs text-gray-400">Updated {format(lastUpdate, "HH:mm:ss")}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-sm">
          {/* Branch Selector */}
          <div className="relative">
            <select
              value={selectedBranchId}
              onChange={e => setSelectedBranchId(e.target.value)}
              className="appearance-none bg-gray-700 border border-gray-600 rounded-xl px-4 py-2 pr-8 text-sm font-medium text-white focus:outline-none cursor-pointer"
            >
              <option value="all">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>

          {/* Sound toggle */}
          <button
            onClick={() => setSoundEnabled(v => !v)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium border transition ${
              soundEnabled
                ? "bg-green-900/50 text-green-400 border-green-700 hover:bg-green-900"
                : "bg-gray-700 text-gray-400 border-gray-600 hover:bg-gray-600"
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{soundEnabled ? "Sound On" : "Muted"}</span>
          </button>

          {/* Status counts */}
          {columns.map(({ status, config, orders: col }) => (
            <div key={status} className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${config.dot}`} />
              <span className={`font-semibold ${config.color}`}>{col.length}</span>
              <span className="text-gray-400">{config.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Columns */}
      <div className="flex-1 grid grid-cols-3 gap-0 overflow-hidden">
        {columns.map(({ status, config, orders: col }) => (
          <div key={status} className="flex flex-col overflow-hidden border-r border-gray-700 last:border-r-0">
            {/* Column Header */}
            <div className="px-4 py-3 border-b border-gray-700 bg-gray-800 flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${config.dot}`} />
              <span className={`font-semibold text-sm ${config.color}`}>{config.label}</span>
              <span className="ml-auto text-xs bg-gray-700 text-gray-300 rounded-full w-6 h-6 flex items-center justify-center font-medium">
                {col.length}
              </span>
            </div>

            {/* Cards */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {col.length === 0 && (
                <div className="flex flex-col items-center justify-center py-16 text-gray-600 gap-2">
                  <Flame className="w-8 h-8" />
                  <p className="text-sm">No orders</p>
                </div>
              )}
              {col.map(order => (
                <OrderCard
                  key={order.id}
                  order={order}
                  onUpdateStatus={updateStatus}
                  onToggleItem={toggleItem}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}