import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Truck, RefreshCw, CheckCircle2, AlertCircle, Clock, ShoppingBag,
  Zap, Settings, ToggleLeft, ToggleRight, ExternalLink, ChevronRight, Bell
} from "lucide-react";
import { format } from "date-fns";

const PLATFORMS = [
  {
    key: "talabat",
    name: "Talabat",
    logo: "🟠",
    color: "orange",
    bg: "bg-orange-50",
    border: "border-orange-200",
    accent: "text-orange-600",
    badge: "bg-orange-100 text-orange-700",
    description: "Receive Talabat orders directly into your POS and kitchen display.",
    setupUrl: "https://restaurant.talabat.com/",
  },
  {
    key: "deliveroo",
    name: "Deliveroo",
    logo: "🩵",
    color: "teal",
    bg: "bg-teal-50",
    border: "border-teal-200",
    accent: "text-teal-600",
    badge: "bg-teal-100 text-teal-700",
    description: "Sync Deliveroo orders and menu with your restaurant in real-time.",
    setupUrl: "https://restaurant-hub.deliveroo.com/",
  },
  {
    key: "careem",
    name: "Careem Food",
    logo: "🟢",
    color: "green",
    bg: "bg-green-50",
    border: "border-green-200",
    accent: "text-green-600",
    badge: "bg-green-100 text-green-700",
    description: "Connect Careem Food orders and manage your delivery menu.",
    setupUrl: "https://restaurant.careem.com/",
  },
];

const STATUS_MAP = {
  connected: { label: "Connected", icon: CheckCircle2, color: "text-green-600", bg: "bg-green-100" },
  disconnected: { label: "Not Connected", icon: AlertCircle, color: "text-gray-400", bg: "bg-gray-100" },
  error: { label: "Error", icon: AlertCircle, color: "text-red-600", bg: "bg-red-100" },
  syncing: { label: "Syncing…", icon: RefreshCw, color: "text-blue-600", bg: "bg-blue-100" },
};

function PlatformCard({ platform, config, onSave }) {
  const [expanded, setExpanded] = useState(false);
  const [form, setForm] = useState({
    api_key: config?.api_key || "",
    restaurant_id: config?.restaurant_id || "",
    webhook_url: config?.webhook_url || "",
    enabled: config?.enabled || false,
    auto_accept: config?.auto_accept !== false,
    auto_print: config?.auto_print !== false,
    auto_kitchen: config?.auto_kitchen !== false,
  });

  const status = config?.enabled
    ? (config?.api_key ? "connected" : "disconnected")
    : "disconnected";

  const s = STATUS_MAP[status];
  const StatusIcon = s.icon;

  const handleSave = () => {
    onSave(platform.key, form);
    setExpanded(false);
  };

  const today = config?.orders_today || 0;
  const todayRevenue = config?.revenue_today || 0;

  return (
    <div className={`bg-white border ${expanded ? platform.border : "border-gray-200"} rounded-2xl overflow-hidden transition-all shadow-sm`}>
      {/* Header Row */}
      <div
        className="flex items-center gap-4 p-5 cursor-pointer hover:bg-gray-50 transition"
        onClick={() => setExpanded(v => !v)}
      >
        <div className={`w-12 h-12 rounded-xl ${platform.bg} flex items-center justify-center text-2xl`}>
          {platform.logo}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-gray-900">{platform.name}</h3>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.bg} ${s.color} flex items-center gap-1`}>
              <StatusIcon className="w-3 h-3" />
              {s.label}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-0.5 truncate">{platform.description}</p>
        </div>
        {status === "connected" && (
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-gray-900">{today} orders</p>
            <p className="text-xs text-gray-400">today</p>
          </div>
        )}
        <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform shrink-0 ${expanded ? "rotate-90" : ""}`} />
      </div>

      {/* Expanded Config */}
      {expanded && (
        <div className={`border-t ${platform.border} p-5 space-y-5 ${platform.bg}`}>
          {/* Enable toggle */}
          <div className="flex items-center justify-between bg-white rounded-xl p-4 border border-gray-200">
            <div>
              <p className="text-sm font-semibold text-gray-800">Enable {platform.name} Integration</p>
              <p className="text-xs text-gray-400 mt-0.5">Toggle to activate or pause this platform</p>
            </div>
            <button
              onClick={() => setForm(f => ({ ...f, enabled: !f.enabled }))}
              className="shrink-0"
            >
              {form.enabled
                ? <ToggleRight className={`w-8 h-8 ${platform.accent}`} />
                : <ToggleLeft className="w-8 h-8 text-gray-300" />}
            </button>
          </div>

          {/* API Credentials */}
          <div className="bg-white rounded-xl p-4 border border-gray-200 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-gray-800">API Credentials</p>
              <a href={platform.setupUrl} target="_blank" rel="noopener noreferrer"
                className={`text-xs ${platform.accent} flex items-center gap-1 hover:underline`}>
                Get from {platform.name} <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">API Key / Token</label>
              <input
                type="password"
                value={form.api_key}
                onChange={e => setForm(f => ({ ...f, api_key: e.target.value }))}
                placeholder="Paste your API key here"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Restaurant / Branch ID</label>
              <input
                value={form.restaurant_id}
                onChange={e => setForm(f => ({ ...f, restaurant_id: e.target.value }))}
                placeholder="Your restaurant ID on this platform"
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-violet-400"
              />
            </div>
          </div>

          {/* Automation options */}
          <div className="bg-white rounded-xl p-4 border border-gray-200 space-y-3">
            <p className="text-sm font-semibold text-gray-800">Automation</p>
            {[
              { key: "auto_accept", label: "Auto-accept incoming orders" },
              { key: "auto_print", label: "Auto-print receipt on new order" },
              { key: "auto_kitchen", label: "Send orders to Kitchen Display automatically" },
            ].map(opt => (
              <label key={opt.key} className="flex items-center gap-3 cursor-pointer">
                <button
                  type="button"
                  onClick={() => setForm(f => ({ ...f, [opt.key]: !f[opt.key] }))}
                  className={`relative w-10 h-5 rounded-full transition-colors ${form[opt.key] ? "bg-violet-600" : "bg-gray-200"}`}
                >
                  <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${form[opt.key] ? "translate-x-5" : "translate-x-0.5"}`} />
                </button>
                <span className="text-sm text-gray-700">{opt.label}</span>
              </label>
            ))}
          </div>

          {/* How it works */}
          <div className="bg-white rounded-xl p-4 border border-gray-200">
            <p className="text-sm font-semibold text-gray-800 mb-2">How it works</p>
            <ol className="space-y-1.5 text-xs text-gray-500 list-decimal list-inside">
              <li>Get your API credentials from the {platform.name} restaurant portal</li>
              <li>Paste them above and enable the integration</li>
              <li>New {platform.name} orders will appear in Orders and Kitchen Display</li>
              <li>Order status updates sync back to the platform automatically</li>
            </ol>
            <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-700">
              ⚠️ <strong>Note:</strong> Direct API access requires a {platform.name} enterprise/partner account. Contact your {platform.name} account manager to enable API access.
            </div>
          </div>

          {/* Save */}
          <div className="flex gap-3">
            <button onClick={() => setExpanded(false)} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-white bg-white transition">
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white transition"
              style={{ background: "linear-gradient(135deg, #5B2CC0, #7C3AED)" }}
            >
              Save Settings
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function DeliveryOrderStats({ orders, branches }) {
  const deliveryOrders = orders.filter(o => ["talabat", "deliveroo", "careem"].includes(o.platform));
  const byPlatform = PLATFORMS.map(p => ({
    ...p,
    count: orders.filter(o => o.platform === p.key).length,
    revenue: orders.filter(o => o.platform === p.key && o.status === "paid")
      .reduce((s, o) => s + (o.total || 0), 0)
  }));

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
      <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
        <Truck className="w-4 h-4 text-violet-600" />
        Delivery Channel Performance (Today)
      </h3>
      <div className="grid grid-cols-3 gap-3">
        {byPlatform.map(p => (
          <div key={p.key} className={`${p.bg} border ${p.border} rounded-xl p-4`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xl">{p.logo}</span>
              <span className={`text-sm font-semibold ${p.accent}`}>{p.name}</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">{p.count}</p>
            <p className="text-xs text-gray-500">orders</p>
            <p className={`text-sm font-semibold mt-1 ${p.accent}`}>AED {p.revenue.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function DeliveryIntegrations() {
  const [configs, setConfigs] = useState({});
  const [orders, setOrders] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("platforms");
  const [recentDelivery, setRecentDelivery] = useState([]);

  useEffect(() => {
    // Load saved configs from localStorage
    try {
      const saved = JSON.parse(localStorage.getItem("delivery_integration_configs") || "{}");
      setConfigs(saved);
    } catch {}

    Promise.all([
      base44.entities.Order.list("-created_date", 200),
      base44.entities.Branch.list()
    ]).then(([orderData, branchData]) => {
      setOrders(orderData);
      setBranches(branchData);

      const deliveryOrders = orderData.filter(o =>
        ["talabat", "deliveroo", "careem"].includes(o.platform)
      );
      setRecentDelivery(deliveryOrders.slice(0, 20));
      setLoading(false);
    });
  }, []);

  const handleSaveConfig = (platform, data) => {
    const updated = { ...configs, [platform]: data };
    setConfigs(updated);
    localStorage.setItem("delivery_integration_configs", JSON.stringify(updated));
  };

  const TABS = [
    { key: "platforms", label: "Platforms" },
    { key: "orders", label: "Delivery Orders" },
    { key: "stats", label: "Performance" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Delivery Integrations</h1>
            <p className="text-sm text-gray-400 mt-0.5">Connect Talabat, Deliveroo, and Careem</p>
          </div>
          <div className="flex items-center gap-2">
            {PLATFORMS.map(p => {
              const cfg = configs[p.key];
              const connected = cfg?.enabled && cfg?.api_key;
              return (
                <div key={p.key} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium ${connected ? p.badge : "bg-gray-100 text-gray-400"}`}>
                  <span>{p.logo}</span> {p.name}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 pt-4 bg-white border-b border-gray-100">
        <div className="flex gap-1">
          {TABS.map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`px-5 py-2.5 text-sm font-medium rounded-t-xl transition-all ${activeTab === t.key ? "text-violet-700 border border-b-0 border-gray-200 bg-gray-50" : "text-gray-400 hover:text-gray-700"}`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 max-w-4xl mx-auto space-y-4">

        {/* Platform Config Tab */}
        {activeTab === "platforms" && (
          <>
            <div className="bg-violet-50 border border-violet-200 rounded-2xl p-4 flex gap-3">
              <Zap className="w-5 h-5 text-violet-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-violet-800">Connect your delivery platforms</p>
                <p className="text-xs text-violet-600 mt-0.5">
                  Incoming delivery orders will automatically appear in your Orders list and Kitchen Display System.
                  You need API access from each platform — contact your account manager to enable it.
                </p>
              </div>
            </div>
            {PLATFORMS.map(p => (
              <PlatformCard
                key={p.key}
                platform={p}
                config={configs[p.key]}
                onSave={handleSaveConfig}
              />
            ))}
          </>
        )}

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-semibold text-gray-800">Recent Delivery Orders</h3>
              <span className="text-xs text-gray-400">{recentDelivery.length} orders</span>
            </div>
            {loading ? (
              <div className="p-8 text-center text-gray-400 text-sm">Loading…</div>
            ) : recentDelivery.length === 0 ? (
              <div className="p-12 text-center">
                <Truck className="w-10 h-10 text-gray-200 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">No delivery orders yet.</p>
                <p className="text-gray-300 text-xs mt-1">Orders from Talabat, Deliveroo, and Careem will appear here.</p>
              </div>
            ) : (
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500">Order</th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500">Platform</th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500">Status</th>
                    <th className="px-5 py-3 text-left text-xs font-semibold text-gray-500">Branch</th>
                    <th className="px-5 py-3 text-right text-xs font-semibold text-gray-500">Amount</th>
                    <th className="px-5 py-3 text-right text-xs font-semibold text-gray-500">Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {recentDelivery.map(o => {
                    const platform = PLATFORMS.find(p => p.key === o.platform);
                    const branch = branches.find(b => b.id === o.branch_id);
                    return (
                      <tr key={o.id} className="hover:bg-gray-50 transition">
                        <td className="px-5 py-3 text-sm font-medium text-gray-900">
                          {o.order_number || `#${o.id?.slice(-6)}`}
                          {o.external_order_id && <span className="text-xs text-gray-400 block">{o.external_order_id}</span>}
                        </td>
                        <td className="px-5 py-3">
                          <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${platform?.badge || "bg-gray-100 text-gray-600"}`}>
                            {platform?.logo} {platform?.name || o.platform}
                          </span>
                        </td>
                        <td className="px-5 py-3">
                          <span className={`text-xs px-2.5 py-1 rounded-full font-medium capitalize ${
                            o.status === "paid" ? "bg-green-100 text-green-700" :
                            o.status === "preparing" ? "bg-blue-100 text-blue-700" :
                            o.status === "ready" ? "bg-purple-100 text-purple-700" :
                            "bg-gray-100 text-gray-600"
                          }`}>{o.status}</span>
                        </td>
                        <td className="px-5 py-3 text-sm text-gray-600">{branch?.name || "—"}</td>
                        <td className="px-5 py-3 text-right text-sm font-semibold text-gray-900">AED {(o.total || 0).toFixed(2)}</td>
                        <td className="px-5 py-3 text-right text-xs text-gray-400">
                          {o.created_date ? format(new Date(o.created_date), "HH:mm") : "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* Stats Tab */}
        {activeTab === "stats" && !loading && (
          <DeliveryOrderStats orders={orders} branches={branches} />
        )}
      </div>
    </div>
  );
}