import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Star, MessageSquare, TrendingUp, Users } from "lucide-react";
import { format } from "date-fns";

function StarDisplay({ rating }) {
  return (
    <div className="flex gap-0.5">
      {[1,2,3,4,5].map(s => (
        <Star key={s} className={`w-3.5 h-3.5 ${s <= rating ? "fill-amber-400 text-amber-400" : "text-gray-200"}`} />
      ))}
    </div>
  );
}

const RATING_COLORS = {
  1: "bg-red-100 text-red-700",
  2: "bg-orange-100 text-orange-700",
  3: "bg-yellow-100 text-yellow-700",
  4: "bg-blue-100 text-blue-700",
  5: "bg-green-100 text-green-700",
};

const RATING_LABELS = { 1: "Poor", 2: "Fair", 3: "Good", 4: "Very Good", 5: "Excellent" };

export default function CustomerFeedback() {
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterRating, setFilterRating] = useState(0);

  useEffect(() => {
    base44.entities.CustomerFeedback.list("-submitted_at", 200).then(data => {
      setFeedback(data);
      setLoading(false);
    });
  }, []);

  const filtered = filterRating ? feedback.filter(f => f.rating === filterRating) : feedback;
  const avg = feedback.length ? (feedback.reduce((s, f) => s + f.rating, 0) / feedback.length) : 0;
  const dist = [5,4,3,2,1].map(r => ({ r, count: feedback.filter(f => f.rating === r).length }));

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customer Feedback</h1>
          <p className="text-gray-500 text-sm mt-1">Reviews collected from digital receipts</p>
        </div>

        {/* Stats */}
        {!loading && feedback.length > 0 && (
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center">
                <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{avg.toFixed(1)}</p>
                <p className="text-xs text-gray-400">Average Rating</p>
              </div>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-violet-50 flex items-center justify-center">
                <Users className="w-6 h-6 text-violet-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{feedback.length}</p>
                <p className="text-xs text-gray-400">Total Reviews</p>
              </div>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{feedback.filter(f => f.rating >= 4).length}</p>
                <p className="text-xs text-gray-400">Positive (4–5★)</p>
              </div>
            </div>
          </div>
        )}

        {/* Rating distribution + filter */}
        {!loading && feedback.length > 0 && (
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <p className="text-sm font-semibold text-gray-700 mb-3">Filter by Rating</p>
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => setFilterRating(0)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition ${filterRating === 0 ? "bg-gray-900 text-white border-gray-900" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
                All ({feedback.length})
              </button>
              {dist.map(({ r, count }) => (
                <button key={r} onClick={() => setFilterRating(r === filterRating ? 0 : r)}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-medium border transition ${filterRating === r ? "bg-amber-400 text-white border-amber-400" : "border-gray-200 text-gray-600 hover:bg-gray-50"}`}>
                  <Star className="w-3.5 h-3.5" /> {r} · {count}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* List */}
        <div className="space-y-3">
          {loading && <div className="text-center py-12 text-gray-400 text-sm">Loading feedback...</div>}
          {!loading && filtered.length === 0 && (
            <div className="text-center py-12 text-gray-400 text-sm">No feedback yet</div>
          )}
          {filtered.map(item => (
            <div key={item.id} className="bg-white rounded-2xl border border-gray-100 p-5 space-y-2">
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <StarDisplay rating={item.rating} />
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${RATING_COLORS[item.rating]}`}>
                      {RATING_LABELS[item.rating]}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">
                    {item.customer_name && <span className="font-medium text-gray-600">{item.customer_name} · </span>}
                    {item.order_number && <span>Order {item.order_number} · </span>}
                    {item.submitted_at && format(new Date(item.submitted_at), "MMM d, yyyy · HH:mm")}
                  </p>
                </div>
              </div>
              {item.comment && (
                <div className="flex items-start gap-2 bg-gray-50 rounded-xl p-3">
                  <MessageSquare className="w-3.5 h-3.5 text-gray-400 mt-0.5 shrink-0" />
                  <p className="text-sm text-gray-700">{item.comment}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}