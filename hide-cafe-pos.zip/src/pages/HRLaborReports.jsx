import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format, startOfMonth, endOfMonth, parseISO, eachDayOfInterval } from "date-fns";
import { TrendingUp, DollarSign, Clock, Users, AlertTriangle, RefreshCw } from "lucide-react";

export default function HRLaborReports() {
  const [staff, setStaff] = useState([]);
  const [timecards, setTimecards] = useState([]);
  const [orders, setOrders] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [endDate, setEndDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));

  useEffect(() => { loadData(); }, [startDate, endDate]);

  const loadData = async () => {
    setLoading(true);
    const [staffData, cardData, orderData, deptData] = await Promise.all([
      base44.entities.StaffMember.list(),
      base44.entities.StaffTimecard.filter({ status: "completed" }),
      base44.entities.Order.filter({ status: "paid" }),
      base44.entities.Department.list(),
    ]);
    setStaff(staffData);
    setTimecards(cardData.filter(tc => {
      if (!tc.clock_in) return false;
      const date = tc.clock_in.split("T")[0];
      return date >= startDate && date <= endDate;
    }));
    setOrders(orderData.filter(o => {
      if (!o.created_date) return false;
      const date = o.created_date.split("T")[0];
      return date >= startDate && date <= endDate;
    }));
    setDepartments(deptData);
    setLoading(false);
  };

  const getLaborCost = (tc) => {
    const member = staff.find(s => s.email === tc.staff_email || s.name === tc.staff_name);
    return ((member?.hourly_rate || 0) * (tc.duration_minutes || 0)) / 60;
  };

  const totalLaborCost = timecards.reduce((s, tc) => s + getLaborCost(tc), 0);
  const totalSales = orders.reduce((s, o) => s + (o.total || 0), 0);
  const totalHours = timecards.reduce((s, tc) => s + (tc.duration_minutes || 0), 0) / 60;
  const laborPct = totalSales > 0 ? (totalLaborCost / totalSales * 100) : 0;
  const overtimeCards = timecards.filter(tc => (tc.duration_minutes || 0) > 480);
  const totalOTHours = overtimeCards.reduce((s, tc) => s + Math.max(0, (tc.duration_minutes - 480) / 60), 0);
  const avgHoursPerStaff = staff.length > 0 ? totalHours / staff.filter(s => s.is_active !== false).length : 0;

  // Daily chart data
  const days = eachDayOfInterval({ start: parseISO(startDate), end: parseISO(endDate) }).slice(0, 31);
  const dailyData = days.map(day => {
    const ds = format(day, "yyyy-MM-dd");
    const dayCards = timecards.filter(tc => tc.clock_in?.startsWith(ds));
    const dayOrders = orders.filter(o => o.created_date?.startsWith(ds));
    return {
      date: format(day, "MMM d"),
      "Labor": Math.round(dayCards.reduce((s, tc) => s + getLaborCost(tc), 0)),
      "Sales": Math.round(dayOrders.reduce((s, o) => s + (o.total || 0), 0)),
    };
  });

  // Department breakdown
  const deptBreakdown = departments.map(d => {
    const deptStaff = staff.filter(s => s.department_id === d.id);
    const deptCards = timecards.filter(tc =>
      deptStaff.some(s => s.email === tc.staff_email || s.name === tc.staff_name)
    );
    return {
      ...d,
      hours: Math.round(deptCards.reduce((s, tc) => s + (tc.duration_minutes || 0), 0) / 60 * 10) / 10,
      cost: Math.round(deptCards.reduce((s, tc) => s + getLaborCost(tc), 0)),
      headcount: deptStaff.filter(s => s.is_active !== false).length,
      shiftCount: deptCards.length,
    };
  }).filter(d => d.shiftCount > 0).sort((a, b) => b.cost - a.cost);

  // Top workers by hours
  const workerStats = staff
    .filter(s => s.is_active !== false)
    .map(s => {
      const cards = timecards.filter(tc => tc.staff_email === s.email || tc.staff_name === s.name);
      const hours = cards.reduce((sum, tc) => sum + (tc.duration_minutes || 0), 0) / 60;
      const cost = cards.reduce((sum, tc) => sum + getLaborCost(tc), 0);
      return { ...s, hours: Math.round(hours * 10) / 10, cost: Math.round(cost), shiftCount: cards.length };
    })
    .filter(s => s.shiftCount > 0)
    .sort((a, b) => b.hours - a.hours)
    .slice(0, 8);

  const kpis = [
    { label: "Labor Cost", value: `AED ${totalLaborCost.toFixed(0)}`, icon: DollarSign, color: "bg-violet-50 text-violet-600", sub: "total for period" },
    { label: "Total Sales", value: `AED ${totalSales.toFixed(0)}`, icon: TrendingUp, color: "bg-green-50 text-green-600", sub: "paid orders" },
    { label: "Labor %", value: `${laborPct.toFixed(1)}%`, icon: TrendingUp, color: laborPct > 35 ? "bg-red-50 text-red-600" : "bg-blue-50 text-blue-600", sub: laborPct > 35 ? "⚠ above 35% target" : "of total sales" },
    { label: "Total Hours", value: `${totalHours.toFixed(0)}h`, icon: Clock, color: "bg-amber-50 text-amber-600", sub: `${totalOTHours.toFixed(1)}h overtime` },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 pt-6 pb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Labor Reports</h1>
            <p className="text-violet-200 text-sm mt-0.5">Workforce analytics and cost tracking</p>
          </div>
          <button onClick={loadData} className="p-2.5 bg-white/20 hover:bg-white/30 text-white rounded-xl transition">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="px-6 -mt-4 pb-8 space-y-5">
        {/* Date Filter */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex flex-wrap gap-3 items-center">
          <span className="text-sm font-semibold text-gray-600">Period:</span>
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400" />
          <span className="text-gray-400">to</span>
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
            className="border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400" />
          <p className="ml-auto text-xs text-gray-400 hidden md:block">
            Avg {avgHoursPerStaff.toFixed(1)}h/staff this period
          </p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {kpis.map(k => {
            const Icon = k.icon;
            return (
              <div key={k.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${k.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <p className="text-xs font-semibold text-gray-500 uppercase">{k.label}</p>
                </div>
                <p className="text-2xl font-bold text-gray-900">{k.value}</p>
                <p className="text-xs text-gray-400 mt-0.5">{k.sub}</p>
              </div>
            );
          })}
        </div>

        {loading ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm py-16 text-center text-gray-400 text-sm">
            Loading reports…
          </div>
        ) : (
          <>
            {/* Daily Chart */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-bold text-gray-900 mb-1">Labor Cost vs Sales — Daily</h3>
              <p className="text-xs text-gray-400 mb-4">Purple = Labor Cost · Light = Sales</p>
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyData} barCategoryGap="30%">
                    <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
                    <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `${v}`} />
                    <Tooltip formatter={(value, name) => [`AED ${value}`, name]} />
                    <Bar dataKey="Sales" fill="#EDE9FE" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="Labor" fill="#7C3AED" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Two columns: dept + top workers */}
            <div className="grid md:grid-cols-2 gap-5">
              {/* Department Breakdown */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-gray-100">
                  <h3 className="font-bold text-gray-900">Hours by Department</h3>
                </div>
                {deptBreakdown.length === 0 ? (
                  <p className="text-center text-gray-400 text-sm py-8">No department data — assign staff to departments first</p>
                ) : (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="text-left py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Dept</th>
                        <th className="text-right py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Staff</th>
                        <th className="text-right py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Hours</th>
                        <th className="text-right py-2.5 px-5 text-xs font-semibold text-gray-500 uppercase">Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {deptBreakdown.map(d => (
                        <tr key={d.id} className="hover:bg-gray-50">
                          <td className="py-3 px-5">
                            <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: d.color || "#7C3AED" }} />
                              <span className="font-semibold text-gray-900">{d.name}</span>
                            </div>
                          </td>
                          <td className="py-3 px-5 text-right text-gray-500">{d.headcount}</td>
                          <td className="py-3 px-5 text-right font-semibold text-gray-700">{d.hours}h</td>
                          <td className="py-3 px-5 text-right font-bold text-violet-700">AED {d.cost}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Top Workers */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-gray-100">
                  <h3 className="font-bold text-gray-900">Top Workers by Hours</h3>
                </div>
                {workerStats.length === 0 ? (
                  <p className="text-center text-gray-400 text-sm py-8">No timecard data for this period</p>
                ) : (
                  <div className="divide-y divide-gray-50">
                    {workerStats.map((w, idx) => (
                      <div key={w.id} className="flex items-center gap-3 px-5 py-3">
                        <span className="text-xs font-bold text-gray-400 w-5 text-right shrink-0">{idx + 1}</span>
                        <div className="w-7 h-7 rounded-full bg-violet-100 flex items-center justify-center text-xs font-bold text-violet-600 shrink-0">
                          {w.name?.[0]?.toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-900 truncate">{w.name}</p>
                          <p className="text-xs text-gray-400">{w.shiftCount} shifts</p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-sm font-bold text-gray-800">{w.hours}h</p>
                          {w.cost > 0 && <p className="text-xs text-violet-600">AED {w.cost}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Overtime Alerts */}
            {overtimeCards.length > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-amber-200 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <h3 className="font-bold text-amber-800">Overtime Shifts ({overtimeCards.length})</h3>
                  <span className="ml-auto text-xs text-amber-600 font-semibold">{totalOTHours.toFixed(1)}h total overtime</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-amber-200">
                        <th className="text-left py-2.5 px-5 text-xs font-semibold text-amber-700 uppercase">Employee</th>
                        <th className="text-left py-2.5 px-5 text-xs font-semibold text-amber-700 uppercase">Date</th>
                        <th className="text-right py-2.5 px-5 text-xs font-semibold text-amber-700 uppercase">Total Hours</th>
                        <th className="text-right py-2.5 px-5 text-xs font-semibold text-amber-700 uppercase">Overtime</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-100">
                      {overtimeCards.slice(0, 10).map(tc => {
                        const total = (tc.duration_minutes || 0) / 60;
                        const ot = Math.max(0, total - 8);
                        return (
                          <tr key={tc.id} className="hover:bg-amber-100/50">
                            <td className="py-2.5 px-5 font-semibold text-gray-900">{tc.staff_name}</td>
                            <td className="py-2.5 px-5 text-gray-600">{tc.clock_in?.split("T")[0]}</td>
                            <td className="py-2.5 px-5 text-right font-semibold text-gray-700">{total.toFixed(1)}h</td>
                            <td className="py-2.5 px-5 text-right font-bold text-amber-700">+{ot.toFixed(1)}h</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}