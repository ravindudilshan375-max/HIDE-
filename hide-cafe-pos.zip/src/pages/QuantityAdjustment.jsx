import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "@/components/inventory/PermissionsProvider";
import AccessDenied from "@/components/inventory/AccessDenied";

const ADJUSTMENT_REASONS = ["damage", "expiry", "loss", "recount", "return", "other"];

export default function QuantityAdjustment() {
  const { user: permUser, hasPermission, loading: permLoading } = usePermissions();
  const [adjustments, setAdjustments] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [adjustmentQty, setAdjustmentQty] = useState("");
  const [reason, setReason] = useState("damage");
  const [notes, setNotes] = useState("");
  const [adjustedBy, setAdjustedBy] = useState("");
  const [user, setUser] = useState(null);
  const [search, setSearch] = useState("");
  const [branch, setBranch] = useState(null);

  useEffect(() => {
    if (!permLoading) {
      if (!hasPermission("adjust_quantity")) return;
      loadData();
    }
  }, [permLoading, hasPermission]);

  const loadData = async () => {
    setLoading(true);
    const [adjs, items, currentUser, branches] = await Promise.all([
      base44.entities.InventoryQuantityAdjustment.list("-created_date", 50),
      base44.entities.MenuItem.list(),
      base44.auth.me().catch(() => null),
      base44.entities.Branch.list()
    ]);
    setAdjustments(adjs);
    setMenuItems(items);
    setUser(currentUser);
    setAdjustedBy(currentUser?.full_name || "");
    if (branches.length > 0) {
      setBranch(branches[0]);
    }
    setLoading(false);
  };

  const saveAdjustment = async () => {
    if (!selectedItem || adjustmentQty === "" || !reason) {
      toast.error("Fill in all required fields");
      return;
    }

    const qty = Number(adjustmentQty);
    const newQty = Math.max(0, (selectedItem.stock_quantity || 0) + qty);

    await base44.entities.InventoryQuantityAdjustment.create({
      date: new Date().toISOString().split('T')[0],
      menu_item_id: selectedItem.id,
      item_name: selectedItem.name,
      previous_quantity: selectedItem.stock_quantity || 0,
      adjustment_quantity: qty,
      new_quantity: newQty,
      reason: reason,
      notes: notes,
      adjusted_by: adjustedBy,
      branch_id: branch?.id || ""
    });

    // Update menu item stock
    await base44.entities.MenuItem.update(selectedItem.id, { stock_quantity: newQty });

    toast.success(`Stock adjusted by ${qty > 0 ? "+" : ""}${qty}`);
    setShowForm(false);
    setSelectedItem(null);
    setAdjustmentQty("");
    setNotes("");
    loadData();
  };

  const deleteAdjustment = async (id) => {
    await base44.entities.InventoryQuantityAdjustment.delete(id);
    toast.success("Adjustment deleted");
    loadData();
  };

  const filteredItems = menuItems.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  if (permLoading) return <div className="p-6 text-center text-gray-400">Loading...</div>;
  if (!hasPermission("adjust_quantity")) {
    return <AccessDenied feature="Quantity Adjustment" currentRole={permUser?.role || "unknown"} />;
  }
  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Quantity Adjustment</h1>
            <p className="text-gray-400 text-sm mt-0.5">Adjust stock for damage, expiry, or losses</p>
          </div>
          <Button
            onClick={() => {
              setShowForm(true);
              setSelectedItem(null);
              setSearch("");
            }}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Adjustment
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">Adjust Quantity</h2>

            {!selectedItem ? (
              <>
                <Input
                  placeholder="Search items..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />
                <div className="max-h-60 overflow-y-auto space-y-1.5">
                  {filteredItems.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-4">No items found</p>
                  ) : (
                    filteredItems.map(item => (
                      <button
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className="w-full text-left px-4 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg transition"
                      >
                        <p className="text-sm font-medium text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-400">Current: {item.stock_quantity || 0} units</p>
                      </button>
                    ))
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-sm font-medium text-gray-900">{selectedItem.name}</p>
                  <p className="text-xs text-gray-400 mt-1">Current stock: {selectedItem.stock_quantity || 0}</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block font-medium">Adjustment (+ or -)</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={adjustmentQty}
                      onChange={e => setAdjustmentQty(e.target.value)}
                      className="border-gray-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-600 mb-1 block font-medium">Reason</label>
                    <select
                      value={reason}
                      onChange={e => setReason(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
                    >
                      {ADJUSTMENT_REASONS.map(r => (
                        <option key={r} value={r}>{r.replace("_", " ")}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <Input
                  placeholder="Adjusted by"
                  value={adjustedBy}
                  onChange={e => setAdjustedBy(e.target.value)}
                  className="border-gray-200 rounded-xl"
                />

                <textarea
                  placeholder="Notes (optional)"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-violet-400"
                  rows="2"
                />

                <div className="flex gap-2">
                  <Button
                    onClick={() => setSelectedItem(null)}
                    variant="outline"
                    className="border-gray-200 rounded-xl flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={saveAdjustment}
                    className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
                  >
                    Save Adjustment
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        <div className="space-y-2">
          {adjustments.length === 0 ? (
            <p className="text-center text-gray-400 py-12">No adjustments yet</p>
          ) : (
            adjustments.map(adj => (
              <div key={adj.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-start justify-between">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{adj.item_name}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{adj.date} · {adj.adjusted_by}</p>
                  <div className="flex gap-4 mt-2 text-xs">
                    <span className="text-gray-600">{adj.previous_quantity} → {adj.new_quantity}</span>
                    <span className={adj.adjustment_quantity > 0 ? "text-green-600" : "text-red-600"}>
                      {adj.adjustment_quantity > 0 ? "+" : ""}{adj.adjustment_quantity}
                    </span>
                    <span className="text-gray-500 capitalize">{adj.reason}</span>
                  </div>
                  {adj.notes && <p className="text-xs text-gray-500 mt-1 italic">{adj.notes}</p>}
                </div>
                <button
                  onClick={() => deleteAdjustment(adj.id)}
                  className="text-gray-300 hover:text-red-500 transition p-2"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}