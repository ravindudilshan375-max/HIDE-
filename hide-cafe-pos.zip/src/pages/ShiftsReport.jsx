import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { format, startOfMonth, isAfter } from "date-fns";
import { Users, Clock, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function ShiftsReport() {
  const [schedules, setSchedules] = useState([]);
  const [branches, setBranches] = useState([]);
  const [selectedBranchId, setSelectedBranchId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.auth.me(),
      base44.entities.Branch.list(),
      base44.entities.StaffSchedule.list(),
    ]).then(([u, b, s]) => {
      setBranches(b);
      setSelectedBranchId(u?.branch_id || (b[0]?.id || null));
      setSchedules(s);
      setLoading(false);
    });
  }, []);

  const periodStart = useMemo(() => startOfMonth(new Date()), []);

  const filteredSchedules = useMemo(() => {
    return schedules.filter(s => 
      s.created_date && isAfter(new Date(s.created_date), periodStart) &&
      (!selectedBranchId || s.branch_id === selectedBranchId)
    );
  }, [schedules, periodStart, selectedBranchId]);

  const shiftsStats = useMemo(() => {
    const staffMap = {};
    const shiftsByRole = {};

    filteredSchedules.forEach(s => {
      if (!staffMap[s.staff_email]) {
        staffMap[s.staff_email] = { email: s.staff_email, name: s.staff_name, shifts: 0, hours: 0, role: s.role };
      }
      staffMap[s.staff_email].shifts += 1;

      const start = new Date(`2000-01-01 ${s.shift_start}`);
      const end = new Date(`2000-01-01 ${s.shift_end}`);
      const hours = (end - start) / 3600000;
      staffMap[s.staff_email].hours += hours;

      if (!shiftsByRole[s.role || "Unassigned"]) {
        shiftsByRole[s.role || "Unassigned"] = 0;
      }
      shiftsByRole[s.role || "Unassigned"] += 1;
    });

    const staff = Object.values(staffMap).sort((a, b) => b.shifts - a.shifts);
    const totalStaff = staff.length;
    const totalShifts = staff.reduce((s, st) => s + st.shifts, 0);
    const avgShiftsPerStaff = totalStaff ? totalShifts / totalStaff : 0;

    return { staff, totalStaff, totalShifts, avgShiftsPerStaff, shiftsByRole };
  }, [filteredSchedules]);

  const roleChartData = useMemo(() => {
    return Object.entries(shiftsStats.shiftsByRole).map(([role, count]) => ({ role, count }));
  }, [shiftsStats]);

  if (loading) return <div className="min-h-screen bg-[#f5f5fa] flex items-center justify-center"><p className="text-gray-400">Loading…</p></div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa]">
      <div className="px-6 py-5 border-b border-gray-100 bg-white">
        <h1 className="text-2xl font-bold text-gray-900">Shifts Report</h1>
        <p className="text-sm text-gray-400 mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="flex gap-3">
          {branches.length > 1 && (
            <select
              value={selectedBranchId || ""}
              onChange={e => setSelectedBranchId(e.target.value || null)}
              className="px-4 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-200 text-gray-700 hover:border-gray-300 focus:outline-none focus:border-violet-400"
            >
              <option value="">All Branches</option>
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          )}
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-3">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">{shiftsStats.totalStaff}</p>
            <p className="text-xs text-gray-400 mt-1">Staff Members</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center mb-3">
              <Clock className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">{shiftsStats.totalShifts}</p>
            <p className="text-xs text-gray-400 mt-1">Total Shifts</p>
          </div>

          <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
            <div className="w-10 h-10 bg-violet-50 rounded-xl flex items-center justify-center mb-3">
              <BarChart3 className="w-5 h-5 text-violet-600" />
            </div>
            <p className="text-2xl font-bold text-violet-600">{shiftsStats.avgShiftsPerStaff.toFixed(1)}</p>
            <p className="text-xs text-gray-400 mt-1">Avg Shifts/Staff</p>
          </div>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl p-5">
          <h3 className="font-semibold text-sm mb-4 text-gray-500">Shifts by Role</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={roleChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="role" tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <YAxis tick={{ fill: "#9ca3af", fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="count" fill="#7c3aed" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white border border-gray-100 shadow-sm rounded-2xl overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-100">
            <h3 className="font-semibold text-sm text-gray-500">Staff Shifts</h3>
          </div>
          <div className="px-5 py-3 border-b border-gray-100 text-xs text-gray-400 uppercase tracking-wider grid grid-cols-5">
            <span className="col-span-2">Staff</span><span className="text-center">Role</span><span className="text-right">Shifts</span><span className="text-right">Hours</span>
          </div>
          {shiftsStats.staff.map((staff, i) => (
            <div key={staff.email} className="grid grid-cols-5 px-5 py-3 border-b border-gray-50 hover:bg-gray-50 transition text-sm items-center">
              <div className="col-span-2 flex items-center gap-3">
                <span className="text-gray-300 w-5 text-xs">{i + 1}</span>
                <div>
                  <p className="font-medium text-gray-800">{staff.name}</p>
                  <p className="text-xs text-gray-400">{staff.email}</p>
                </div>
              </div>
              <span className="text-center text-gray-500 text-xs">{staff.role || "—"}</span>
              <span className="text-right text-violet-600 font-semibold">{staff.shifts}</span>
              <span className="text-right text-gray-500 text-xs">{staff.hours.toFixed(1)}h</span>
            </div>
          ))}
          {shiftsStats.staff.length === 0 && <p className="text-center py-10 text-gray-300 text-sm">No shifts found</p>}
        </div>
      </div>
    </div>
  );
}