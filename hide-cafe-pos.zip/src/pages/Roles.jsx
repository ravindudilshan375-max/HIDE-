import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Pencil, Search, Mail, Eye, Ban } from "lucide-react";
import { logAudit } from "@/components/audit/auditLogger";
import RoleFormModal, { DEFAULT_PERMISSIONS, PERMISSION_GROUPS } from "@/components/roles/RoleFormModal";

export default function Roles() {
  const [activeTab, setActiveTab] = useState("roles");
  const [roles, setRoles] = useState([]);
  const [users, setUsers] = useState([]);
  const [branches, setBranches] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    permissions: DEFAULT_PERMISSIONS,
    applicable_branches: [],
  });
  const [editingUser, setEditingUser] = useState(null);
  const [showUserForm, setShowUserForm] = useState(false);
  const [userFormData, setUserFormData] = useState({
    email: "",
    name: "",
    role_ids: [],
  });
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordData, setPasswordData] = useState({
    userId: "",
    password: "",
    confirmPassword: "",
  });
  const [updatingPassword, setUpdatingPassword] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteData, setInviteData] = useState({
    email: "",
    branch_id: "",
  });
  const [inviting, setInviting] = useState(false);
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [newUserData, setNewUserData] = useState({ name: "", email: "", phone: "", branch_id: "" });
  const [creatingUser, setCreatingUser] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [branchesData, usersData, rolesData] = await Promise.all([
        base44.entities.Branch.list(),
        base44.entities.User.list(),
        base44.entities.Role.list(),
      ]);
      setBranches(branchesData);
      setUsers(usersData);
      setRoles(rolesData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  const openForm = (role = null) => {
    if (role) {
      // Merge with DEFAULT_PERMISSIONS to ensure new keys are present
      setFormData({ ...role, permissions: { ...DEFAULT_PERMISSIONS, ...role.permissions } });
      setEditingId(role.id);
    } else {
      setFormData({
        name: "",
        description: "",
        permissions: { ...DEFAULT_PERMISSIONS },
        applicable_branches: [],
      });
      setEditingId(null);
    }
    setShowForm(true);
  };

  const saveRole = async () => {
    if (!formData.name.trim()) return;

    if (editingId) {
      const existing = roles.find(r => r.id === editingId);
      const updated = await base44.entities.Role.update(editingId, formData);
      setRoles(prev => prev.map(r => r.id === editingId ? updated : r));
      logAudit({ action: "update", entity_type: "Role", entity_id: editingId, entity_name: formData.name, description: `Updated role "${formData.name}"`, changes: { before: existing, after: formData }, severity: "info" });
    } else {
      const created = await base44.entities.Role.create(formData);
      setRoles(prev => [...prev, created]);
      logAudit({ action: "create", entity_type: "Role", entity_id: created.id, entity_name: created.name, description: `Created role "${created.name}"`, severity: "info" });
    }
    setShowForm(false);
  };

  const deleteRole = async (roleId) => {
    const role = roles.find(r => r.id === roleId);
    await base44.entities.Role.delete(roleId);
    setRoles(prev => prev.filter(r => r.id !== roleId));
    logAudit({ action: "delete", entity_type: "Role", entity_id: roleId, entity_name: role?.name, description: `Deleted role "${role?.name}"`, severity: "warning" });
  };

  const toggleBranch = (branchId) => {
    setFormData(prev => ({
      ...prev,
      applicable_branches: prev.applicable_branches.includes(branchId)
        ? prev.applicable_branches.filter(id => id !== branchId)
        : [...prev.applicable_branches, branchId]
    }));
  };

  const filteredRoles = roles.filter(role =>
    role.name.toLowerCase().includes(search.toLowerCase())
  );

  const filteredUsers = users.filter(user =>
    (user.full_name?.toLowerCase() || "").includes(search.toLowerCase()) ||
    (user.email?.toLowerCase() || "").includes(search.toLowerCase())
  );

  const saveUserRoles = async () => {
    if (!editingUser.email) return;
    await base44.entities.User.update(editingUser.id, { role_ids: userFormData.role_ids });
    setUsers(prev => prev.map(u => u.id === editingUser.id ? { ...u, role_ids: userFormData.role_ids } : u));
    logAudit({ action: "assign_role", entity_type: "User", entity_id: editingUser.id, entity_name: editingUser.full_name || editingUser.email, description: `Assigned roles to user "${editingUser.full_name || editingUser.email}"`, severity: "info" });
    setShowUserForm(false);
  };

  const openUserForm = (user) => {
    setEditingUser(user);
    setUserFormData({ email: user.email, name: user.full_name, role_ids: user.role_ids || [] });
    setShowUserForm(true);
  };

  const openPasswordModal = (user) => {
    setPasswordData({ userId: user.id, password: "", confirmPassword: "" });
    setShowPasswordModal(true);
  };

  const updatePassword = async () => {
    if (!passwordData.password.trim()) return;
    if (passwordData.password !== passwordData.confirmPassword) {
      alert("Passwords do not match");
      return;
    }
    if (passwordData.password.length < 6) {
      alert("Password must be at least 6 characters");
      return;
    }

    setUpdatingPassword(true);
    try {
      const targetUser = users.find(u => u.id === passwordData.userId);
      await base44.functions.invoke("setUserPassword", {
        userId: passwordData.userId,
        password: passwordData.password,
      });
      logAudit({ action: "set_password", entity_type: "User", entity_id: passwordData.userId, entity_name: targetUser?.full_name || targetUser?.email, description: `Password updated for user "${targetUser?.full_name || targetUser?.email}"`, severity: "warning" });
      setShowPasswordModal(false);
      setPasswordData({ userId: "", password: "", confirmPassword: "" });
      alert("Password updated successfully!");
    } catch (error) {
      alert("Error updating password: " + error.message);
    }
    setUpdatingPassword(false);
  };

  const toggleUserRole = (roleId) => {
    setUserFormData(prev => ({
      ...prev,
      role_ids: prev.role_ids.includes(roleId)
        ? prev.role_ids.filter(id => id !== roleId)
        : [...prev.role_ids, roleId]
    }));
  };

  const sendInvite = async () => {
    if (!inviteData.email.trim()) return;
    
    setInviting(true);
    try {
      await base44.users.inviteUser(inviteData.email, "user");
      logAudit({ action: "invite", entity_type: "User", entity_name: inviteData.email, description: `Invitation sent to "${inviteData.email}"`, severity: "info" });
      setInviteData({ email: "", branch_id: "" });
      setShowInviteModal(false);
      alert("Invitation sent successfully!");
    } catch (error) {
      alert("Failed to send invitation: " + error.message);
    }
    setInviting(false);
  };

  const createAndInviteUser = async () => {
    if (!newUserData.email.trim()) {
      alert("Please enter an email address");
      return;
    }

    setCreatingUser(true);
    try {
      await base44.users.inviteUser(newUserData.email, "user");
      logAudit({ action: "invite", entity_type: "User", entity_name: newUserData.email, description: `New user created and invited: "${newUserData.email}"`, severity: "info" });
      setNewUserData({ name: "", email: "", phone: "", branch_id: "" });
      setShowCreateUserModal(false);
      alert("User created and invitation sent successfully!");
      loadData();
    } catch (error) {
      alert("Error: " + error.message);
    }
    setCreatingUser(false);
  };

  if (loading) {
    return <div className="min-h-screen bg-gray-50 p-6 flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Roles & Users</h1>
            <p className="text-sm text-gray-500 mt-1">Define roles and manage staff assignments</p>
          </div>
          {activeTab === "roles" ? (
            <button
              onClick={() => openForm()}
              className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl px-4 py-2.5 transition"
            >
              <Plus className="w-4 h-4" />
              Create Role
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                onClick={() => setShowCreateUserModal(true)}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl px-4 py-2.5 transition"
              >
                <Plus className="w-4 h-4" />
                Add User
              </button>
              <button
                onClick={() => setShowInviteModal(true)}
                className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl px-4 py-2.5 transition"
              >
                <Mail className="w-4 h-4" />
                Invite User
              </button>
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="mb-6 flex gap-2 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("roles")}
            className={`px-4 py-3 font-semibold text-sm border-b-2 transition ${
              activeTab === "roles"
                ? "text-violet-600 border-violet-600"
                : "text-gray-600 border-transparent hover:text-gray-900"
            }`}
          >
            Roles
          </button>
          <button
            onClick={() => setActiveTab("users")}
            className={`px-4 py-3 font-semibold text-sm border-b-2 transition ${
              activeTab === "users"
                ? "text-violet-600 border-violet-600"
                : "text-gray-600 border-transparent hover:text-gray-900"
            }`}
          >
            Users
          </button>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              placeholder={activeTab === "roles" ? "Search roles..." : "Search users..."}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white border border-gray-200 rounded-xl pl-9 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none focus:border-violet-400"
            />
          </div>
        </div>

        {/* Roles Tab */}
        {activeTab === "roles" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRoles.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-400 text-sm">No roles found</p>
              </div>
            ) : (
                filteredRoles.map(role => (
                <div key={role.id} className="bg-white border border-gray-200 rounded-2xl p-5 hover:border-violet-400 hover:shadow-md transition-all group">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{role.name}</h3>
                      {role.description && (
                        <p className="text-xs text-gray-500 mt-1">{role.description}</p>
                      )}
                    </div>
                    <div className="opacity-0 group-hover:opacity-100 transition flex gap-1">
                      <button
                        onClick={() => openForm(role)}
                        className="p-2 text-gray-400 hover:text-violet-600 hover:bg-violet-50 rounded-lg transition"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteRole(role.id)}
                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Permissions Summary */}
                  <div className="space-y-2 pt-3 border-t border-gray-100">
                    <p className="text-xs font-semibold text-gray-600">Permissions</p>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(role.permissions || {}).filter(([_, v]) => v && v !== "none").length > 0 ? (
                        Object.entries(role.permissions || {})
                          .filter(([_, v]) => v && v !== "none")
                          .map(([key, level]) => (
                            <span key={key} className={`text-xs px-2 py-1 rounded-full flex items-center gap-1 ${level === "view" ? "bg-blue-100 text-blue-700" : "bg-violet-100 text-violet-700"}`}>
                              {level === "view" ? <Eye className="w-2.5 h-2.5" /> : <Pencil className="w-2.5 h-2.5" />}
                              {key.replace(/_/g, ' ')}
                            </span>
                          ))
                      ) : (
                        <span className="text-xs text-gray-400 flex items-center gap-1"><Ban className="w-3 h-3" /> No permissions</span>
                      )}
                    </div>
                  </div>

                  {/* Branches */}
                  {(role.applicable_branches || []).length > 0 && (
                    <div className="space-y-2 pt-3 border-t border-gray-100">
                      <p className="text-xs font-semibold text-gray-600">Branches</p>
                      <div className="flex flex-wrap gap-1">
                        {(role.applicable_branches || []).map(branchId => {
                          const branch = branches.find(b => b.id === branchId);
                          return branch ? (
                            <span key={branchId} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
                              {branch.name}
                            </span>
                          ) : null;
                        })}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Name</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Email</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Roles</th>
                  <th className="px-6 py-3 text-right text-sm font-semibold text-gray-700">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="px-6 py-12 text-center">
                      <p className="text-gray-400 text-sm">No users found</p>
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map(user => (
                    <tr key={user.id} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-3 text-sm font-medium text-gray-900">{user.full_name || "-"}</td>
                      <td className="px-6 py-3 text-sm text-gray-600">{user.email}</td>
                      <td className="px-6 py-3 text-sm">
                        <div className="flex flex-wrap gap-1">
                          {user.role_ids && user.role_ids.length > 0 ? (
                            user.role_ids.map(roleId => {
                              const role = roles.find(r => r.id === roleId);
                              return role ? (
                                <span key={roleId} className="text-xs bg-violet-100 text-violet-700 px-2 py-1 rounded-full">
                                  {role.name}
                                </span>
                              ) : null;
                            })
                          ) : (
                            <span className="text-xs text-gray-400">No roles assigned</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-3 text-right flex gap-3 justify-end">
                        <button
                          onClick={() => openUserForm(user)}
                          className="text-sm font-semibold text-violet-600 hover:text-violet-700 transition"
                        >
                          Assign Roles
                        </button>
                        <button
                          onClick={() => openPasswordModal(user)}
                          className="text-sm font-semibold text-blue-600 hover:text-blue-700 transition"
                        >
                          Set Password
                        </button>
                        <button
                          onClick={() => {
                            setInviteData({ email: user.email, branch_id: "" });
                            setShowInviteModal(true);
                          }}
                          className="text-sm font-semibold text-green-600 hover:text-green-700 transition"
                        >
                          Resend Invite
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* User Roles Modal */}
      {showUserForm && editingUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">
                Assign Roles to {editingUser.full_name}
              </h2>
              <button
                onClick={() => setShowUserForm(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                <p className="font-medium text-gray-900">{editingUser.email}</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Select Roles</label>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {roles.length === 0 ? (
                    <p className="text-sm text-gray-500">No roles created yet</p>
                  ) : (
                    roles.map(role => (
                      <label key={role.id} className="flex items-center gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={userFormData.role_ids.includes(role.id)}
                          onChange={() => toggleUserRole(role.id)}
                          className="w-4 h-4 rounded border-gray-300 text-violet-600 focus:ring-violet-500"
                        />
                        <div className="flex-1">
                          <span className="text-sm font-medium text-gray-700">{role.name}</span>
                          {role.description && (
                            <p className="text-xs text-gray-500">{role.description}</p>
                          )}
                        </div>
                      </label>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-6 flex gap-3">
              <button
                onClick={() => setShowUserForm(false)}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={saveUserRoles}
                className="flex-1 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 rounded-lg font-semibold text-white transition"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Password Management Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Set Password</h2>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">New Password</label>
                <input
                  type="password"
                  value={passwordData.password}
                  onChange={(e) => setPasswordData({ ...passwordData, password: e.target.value })}
                  placeholder="Enter new password"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-blue-400"
                />
                <p className="text-xs text-gray-500 mt-1">Minimum 6 characters</p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Confirm Password</label>
                <input
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                  placeholder="Confirm password"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-blue-400"
                />
              </div>
            </div>

            <div className="border-t border-gray-200 p-6 flex gap-3">
              <button
                onClick={() => setShowPasswordModal(false)}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={updatePassword}
                disabled={!passwordData.password.trim() || !passwordData.confirmPassword || updatingPassword}
                className="flex-1 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition"
              >
                {updatingPassword ? "Updating..." : "Update Password"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create New User Modal */}
      {showCreateUserModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Add New User</h2>
              <button
                onClick={() => setShowCreateUserModal(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Name *</label>
                <input
                  type="text"
                  value={newUserData.name}
                  onChange={(e) => setNewUserData({ ...newUserData, name: e.target.value })}
                  placeholder="Full name"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-400"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                <input
                  type="email"
                  value={newUserData.email}
                  onChange={(e) => setNewUserData({ ...newUserData, email: e.target.value })}
                  placeholder="user@example.com"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-400"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Phone</label>
                <input
                  type="tel"
                  value={newUserData.phone}
                  onChange={(e) => setNewUserData({ ...newUserData, phone: e.target.value })}
                  placeholder="+971 50 123 4567"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-400"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Branch *</label>
                <select
                  value={newUserData.branch_id}
                  onChange={(e) => setNewUserData({ ...newUserData, branch_id: e.target.value })}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-green-400"
                >
                  <option value="">Select a branch</option>
                  {branches.map(branch => (
                    <option key={branch.id} value={branch.id}>
                      {branch.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="border-t border-gray-200 p-6 flex gap-3">
              <button
                onClick={() => setShowCreateUserModal(false)}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={createAndInviteUser}
                disabled={!newUserData.email.trim() || creatingUser}
                className="flex-1 px-4 py-2.5 bg-green-600 hover:bg-green-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition"
              >
                {creatingUser ? "Creating..." : "Create & Invite"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Invite User Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Invite User</h2>
              <button
                onClick={() => setShowInviteModal(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                <input
                  type="email"
                  value={inviteData.email}
                  onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                  placeholder="user@example.com"
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Branch</label>
                <select
                  value={inviteData.branch_id}
                  onChange={(e) => setInviteData({ ...inviteData, branch_id: e.target.value })}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
                >
                  <option value="">Select a branch</option>
                  {branches.map(branch => (
                    <option key={branch.id} value={branch.id}>
                      {branch.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="border-t border-gray-200 p-6 flex gap-3">
              <button
                onClick={() => setShowInviteModal(false)}
                className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={sendInvite}
                disabled={!inviteData.email.trim() || inviting}
                className="flex-1 px-4 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition"
              >
                {inviting ? "Sending..." : "Send Invite"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create/Edit Role Modal */}
      {showForm && (
        <RoleFormModal
          editingId={editingId}
          formData={formData}
          setFormData={setFormData}
          branches={branches}
          roles={roles}
          onSave={saveRole}
          onClose={() => setShowForm(false)}
        />
      )}
    </div>
  );
}