import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Pencil, Trash2, Users, Building2 } from "lucide-react";

const DEPT_COLORS = [
  "#7C3AED", "#2563EB", "#059669", "#D97706", "#DC2626",
  "#0891B2", "#65A30D", "#EA580C", "#DB2777", "#4F46E5",
];

function DeptFormModal({ dept, staff, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: dept?.name || "",
    description: dept?.description || "",
    manager_name: dept?.manager_name || "",
    manager_email: dept?.manager_email || "",
    color: dept?.color || DEPT_COLORS[0],
    is_active: dept?.is_active !== false,
  });
  const [saving, setSaving] = useState(false);

  const activeStaff = staff.filter(s => s.is_active !== false);

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    if (dept?.id) {
      await base44.entities.Department.update(dept.id, form);
    } else {
      await base44.entities.Department.create(form);
    }
    onSaved();
    onClose();
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-xl">
        <div className="border-b border-gray-100 px-6 py-5 flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-900">{dept ? "Edit Department" : "Add Department"}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Department Name *</label>
            <input
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Kitchen, Bar, Service"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Description</label>
            <textarea
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
              rows={2}
              placeholder="Brief description…"
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400 resize-none"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Manager</label>
            <select
              value={form.manager_email}
              onChange={e => {
                const selected = activeStaff.find(s => s.email === e.target.value);
                setForm({ ...form, manager_email: e.target.value, manager_name: selected?.name || "" });
              }}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-violet-400"
            >
              <option value="">No manager assigned</option>
              {activeStaff.map(s => (
                <option key={s.id} value={s.email || s.id}>{s.name} ({s.role_type})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Color</label>
            <div className="flex gap-2 flex-wrap">
              {DEPT_COLORS.map(c => (
                <button
                  key={c}
                  onClick={() => setForm({ ...form, color: c })}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${form.color === c ? "border-gray-800 scale-110" : "border-transparent"}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
        </div>
        <div className="border-t border-gray-100 px-6 py-4 flex gap-3">
          <button onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50">Cancel</button>
          <button
            onClick={handleSave}
            disabled={!form.name.trim() || saving}
            className="flex-1 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 rounded-xl text-sm font-semibold text-white transition"
          >
            {saving ? "Saving…" : dept ? "Update" : "Create"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function HRDepartments() {
  const [departments, setDepartments] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formModal, setFormModal] = useState(null);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    const [depts, staffData] = await Promise.all([
      base44.entities.Department.list(),
      base44.entities.StaffMember.list(),
    ]);
    setDepartments(depts);
    setStaff(staffData);
    setLoading(false);
  };

  const deleteDept = async (id) => {
    if (!confirm("Delete this department? Staff will become unassigned.")) return;
    await base44.entities.Department.delete(id);
    setDepartments(prev => prev.filter(d => d.id !== id));
  };

  const getDeptStaff = (deptId) => staff.filter(s => s.department_id === deptId && s.is_active !== false);

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <p className="text-gray-400 text-sm">Loading departments…</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 pt-6 pb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Departments</h1>
            <p className="text-violet-200 text-sm mt-0.5">Organize your workforce into departments</p>
          </div>
          <button
            onClick={() => setFormModal("new")}
            className="flex items-center gap-2 bg-white text-violet-700 font-semibold rounded-xl px-4 py-2.5 text-sm hover:bg-violet-50 shadow-sm transition"
          >
            <Plus className="w-4 h-4" /> Add Department
          </button>
        </div>
      </div>

      {/* Stats row */}
      <div className="px-6 -mt-4 mb-5">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-5 py-4 grid grid-cols-3 divide-x divide-gray-100">
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{departments.length}</p>
            <p className="text-xs text-gray-500 mt-0.5">Departments</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{staff.filter(s => s.department_id && s.is_active !== false).length}</p>
            <p className="text-xs text-gray-500 mt-0.5">Assigned Staff</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-900">{staff.filter(s => !s.department_id && s.is_active !== false).length}</p>
            <p className="text-xs text-gray-500 mt-0.5">Unassigned</p>
          </div>
        </div>
      </div>

      <div className="px-6 pb-8">
        {departments.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-14 text-center">
            <Building2 className="w-14 h-14 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-700 font-semibold mb-1">No departments yet</p>
            <p className="text-sm text-gray-400 mb-5">Create departments to organize your team</p>
            <button onClick={() => setFormModal("new")} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition">
              Add First Department
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {departments.map(dept => {
              const deptStaff = getDeptStaff(dept.id);
              return (
                <div key={dept.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition group">
                  <div className="h-2" style={{ backgroundColor: dept.color || "#7C3AED" }} />
                  <div className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-900 text-lg">{dept.name}</h3>
                        {dept.description && <p className="text-xs text-gray-400 mt-0.5">{dept.description}</p>}
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <button onClick={() => setFormModal(dept)} className="p-1.5 text-gray-400 hover:text-violet-600 hover:bg-violet-50 rounded-lg transition">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => deleteDept(dept.id)} className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span className="text-sm font-semibold text-gray-700">{deptStaff.length} staff member{deptStaff.length !== 1 ? "s" : ""}</span>
                    </div>

                    {dept.manager_name && (
                      <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0" style={{ backgroundColor: dept.color || "#7C3AED" }}>
                          {dept.manager_name[0]?.toUpperCase()}
                        </div>
                        <span>Manager: <span className="font-semibold text-gray-700">{dept.manager_name}</span></span>
                      </div>
                    )}

                    {deptStaff.length > 0 && (
                      <div className="flex -space-x-1.5 flex-wrap gap-y-1">
                        {deptStaff.slice(0, 9).map(s => (
                          <div
                            key={s.id}
                            title={s.name}
                            className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center text-xs font-bold text-white shrink-0"
                            style={{ backgroundColor: dept.color || "#7C3AED" }}
                          >
                            {s.name?.[0]?.toUpperCase()}
                          </div>
                        ))}
                        {deptStaff.length > 9 && (
                          <div className="w-7 h-7 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center text-xs font-bold text-gray-500 shrink-0">
                            +{deptStaff.length - 9}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {formModal && (
        <DeptFormModal
          dept={formModal === "new" ? null : formModal}
          staff={staff}
          onClose={() => setFormModal(null)}
          onSaved={loadData}
        />
      )}
    </div>
  );
}