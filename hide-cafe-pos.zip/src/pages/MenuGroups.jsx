import React from "react";
import { Layers } from "lucide-react";

export default function MenuGroups() {
  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Groups</h1>
          <p className="text-sm text-gray-400 mt-0.5">Organize menu items into groups</p>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm flex flex-col items-center justify-center py-24">
          <Layers className="w-12 h-12 text-gray-200 mb-4" />
          <p className="text-gray-400 text-sm font-medium">No groups yet</p>
          <p className="text-gray-300 text-xs mt-1">Menu groups builder coming soon</p>
        </div>
      </div>
    </div>
  );
}