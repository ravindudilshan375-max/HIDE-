import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Printer, Wifi, WifiOff, Plus, Trash2, TestTube2,
  RefreshCw, CheckCircle2, AlertCircle, Loader2, Search
} from "lucide-react";
import { toast } from "sonner";

const PRINTER_TYPES = [
  { key: "receipt", label: "Receipt Printer" },
  { key: "kitchen", label: "Kitchen Printer" },
  { key: "bar", label: "Bar Printer" },
  { key: "dessert", label: "Dessert Printer" },
];

const DEFAULT_FORM = { name: "", ip_address: "", port: "9100", type: "receipt" };

export default function Devices() {
  const [printers, setPrinters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(DEFAULT_FORM);
  const [saving, setSaving] = useState(false);
  const [pingingId, setPingingId] = useState(null);
  const [testingId, setTestingId] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [scanResults, setScanResults] = useState([]);
  const [scanBase, setScanBase] = useState("10.39.1");

  useEffect(() => { loadPrinters(); }, []);

  const loadPrinters = async () => {
    setLoading(true);
    const data = await base44.entities.Device.filter({ device_type: "printer" });
    setPrinters(data);
    setLoading(false);
  };

  const handleSave = async () => {
    if (!form.name || !form.ip_address) {
      toast.error("Name and IP address are required");
      return;
    }
    setSaving(true);
    await base44.entities.Device.create({
      name: form.name,
      ip_address: form.ip_address,
      port: parseInt(form.port) || 9100,
      device_type: "printer",
      model: form.type,
      status: "offline",
    });
    toast.success("Printer added");
    setForm(DEFAULT_FORM);
    setShowForm(false);
    setSaving(false);
    loadPrinters();
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this printer?")) return;
    await base44.entities.Device.delete(id);
    toast.success("Printer deleted");
    loadPrinters();
  };

  const handlePing = async (printer) => {
    setPingingId(printer.id);
    try {
      const res = await base44.functions.invoke("pingDevice", {
        ip_address: printer.ip_address,
        port: printer.port || 9100,
        device_id: printer.id,
      });
      const status = res.data?.status || "offline";
      setPrinters(prev => prev.map(p => p.id === printer.id ? { ...p, status } : p));
      toast(status === "online" ? `✅ ${printer.name} is online` : `❌ ${printer.name} is offline`);
    } catch {
      toast.error("Ping failed");
    }
    setPingingId(null);
  };

  const handleTestPrint = async (printer) => {
    setTestingId(printer.id);
    try {
      const res = await base44.functions.invoke("printBill", {
        order: {
          order_number: "TEST-001",
          restaurant_name: "DENDAX POS",
          customer_name: "Test Print",
          items: [
            { name: "Latte", quantity: 1, price: 18, subtotal: 18 },
            { name: "Cake", quantity: 1, price: 24, subtotal: 24 },
          ],
          subtotal: 42,
          tax: 2.10,
          total: 44.10,
          payment_method: "cash",
        },
        printerIp: printer.ip_address,
        printerPort: String(printer.port || 9100),
        connectionType: "ethernet",
      });
      if (res.data?.success) {
        toast.success(`Test receipt sent to ${printer.name}`);
      } else {
        toast.error(res.data?.error || "Test print failed");
      }
    } catch (e) {
      toast.error(e.message || "Test print failed");
    }
    setTestingId(null);
  };

  const handleScan = async () => {
    setScanning(true);
    setScanResults([]);
    const found = [];
    // Scan .1 to .254 in batches of 20
    const ips = Array.from({ length: 254 }, (_, i) => `${scanBase}.${i + 1}`);
    const batchSize = 20;
    for (let i = 0; i < ips.length; i += batchSize) {
      const batch = ips.slice(i, i + batchSize);
      const results = await Promise.allSettled(
        batch.map(ip =>
          base44.functions.invoke("pingDevice", { ip_address: ip, port: 9100 }).then(r => ({ ip, status: r.data?.status }))
        )
      );
      for (const r of results) {
        if (r.status === "fulfilled" && r.value?.status === "online") {
          found.push(r.value.ip);
          setScanResults(prev => [...prev, r.value.ip]);
        }
      }
    }
    setScanning(false);
    if (found.length === 0) toast("No printers found on " + scanBase + ".x");
  };

  const addFromScan = (ip) => {
    setForm({ ...DEFAULT_FORM, ip_address: ip, name: `Printer ${ip}` });
    setShowForm(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Printers</h1>
            <p className="text-gray-500 text-sm mt-0.5">Direct LAN printing via TCP/IP · Port 9100</p>
          </div>
          <Button onClick={() => setShowForm(v => !v)} className="gap-2 bg-violet-600 hover:bg-violet-700">
            <Plus className="w-4 h-4" /> Add Printer
          </Button>
        </div>

        {/* Add Form */}
        {showForm && (
          <div className="bg-white rounded-2xl border border-gray-100 p-5 space-y-4">
            <h2 className="font-semibold text-gray-800">New Printer</h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Name</label>
                <Input placeholder="Receipt Printer" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Type</label>
                <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                  className="w-full border border-gray-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-400">
                  {PRINTER_TYPES.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">IP Address</label>
                <Input placeholder="10.39.1.201" value={form.ip_address} onChange={e => setForm(f => ({ ...f, ip_address: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Port</label>
                <Input placeholder="9100" value={form.port} onChange={e => setForm(f => ({ ...f, port: e.target.value }))} />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={saving} className="bg-violet-600 hover:bg-violet-700">
                {saving ? "Saving..." : "Save Printer"}
              </Button>
            </div>
          </div>
        )}

        {/* Printer List */}
        <div className="space-y-3">
          {loading && <div className="text-center py-10 text-gray-400 text-sm">Loading...</div>}
          {!loading && printers.length === 0 && (
            <div className="text-center py-10 text-gray-400 text-sm">
              <Printer className="w-8 h-8 mx-auto mb-2 opacity-30" />
              No printers configured. Add your first printer above.
            </div>
          )}
          {printers.map(printer => {
            const isOnline = printer.status === "online";
            const isPinging = pingingId === printer.id;
            const isTesting = testingId === printer.id;
            const typeLabel = PRINTER_TYPES.find(t => t.key === printer.model)?.label || printer.model || "Printer";
            return (
              <div key={printer.id} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-4">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${isOnline ? "bg-green-50" : "bg-gray-50"}`}>
                  <Printer className={`w-5 h-5 ${isOnline ? "text-green-600" : "text-gray-400"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-gray-800">{printer.name}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${isOnline ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                      {isOnline ? "Online" : "Offline"}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">{typeLabel} · {printer.ip_address}:{printer.port || 9100}</p>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button size="sm" variant="outline" onClick={() => handlePing(printer)} disabled={isPinging} className="gap-1.5 text-xs">
                    {isPinging ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wifi className="w-3.5 h-3.5" />}
                    Ping
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleTestPrint(printer)} disabled={isTesting} className="gap-1.5 text-xs">
                    {isTesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <TestTube2 className="w-3.5 h-3.5" />}
                    Test
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDelete(printer.id)} className="text-red-400 hover:text-red-600 hover:border-red-200">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Network Scanner */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5 space-y-4">
          <div>
            <h2 className="font-semibold text-gray-800">Auto Discover Printers</h2>
            <p className="text-xs text-gray-400 mt-0.5">Scan your LAN for printers on port 9100</p>
          </div>
          <div className="flex gap-2 items-center">
            <Input
              placeholder="10.39.1"
              value={scanBase}
              onChange={e => setScanBase(e.target.value)}
              className="max-w-[160px]"
            />
            <span className="text-gray-400 text-sm">.1 – .254</span>
            <Button onClick={handleScan} disabled={scanning} className="gap-2 bg-violet-600 hover:bg-violet-700 ml-auto">
              {scanning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              {scanning ? "Scanning..." : "Scan Network"}
            </Button>
          </div>
          {scanResults.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs text-gray-500 font-medium">Found {scanResults.length} printer(s):</p>
              {scanResults.map(ip => (
                <div key={ip} className="flex items-center justify-between bg-green-50 rounded-xl px-4 py-2.5">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-gray-700">{ip}:9100</span>
                  </div>
                  <Button size="sm" onClick={() => addFromScan(ip)} className="text-xs bg-violet-600 hover:bg-violet-700">
                    Add Printer
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Info box */}
        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 text-sm text-blue-700 space-y-1">
          <p className="font-semibold">Direct LAN Printing — No Bridge Required</p>
          <p className="text-blue-500 text-xs">POS → Backend → TCP Socket → Printer · Prints in ~0.3 seconds · ESC/POS protocol · Default port 9100</p>
        </div>
      </div>
    </div>
  );
}