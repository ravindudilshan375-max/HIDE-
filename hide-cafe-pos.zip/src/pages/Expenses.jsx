import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Search, Trash2, Edit2, Camera, X, Sparkles, CheckCircle2, Download, Eye, FileImage, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const PAYMENT_METHODS = ["Cash", "Card", "Bank Transfer", "Cheque", "Other"];

const EMPTY = {
  supplier_name: "", category: "", payment_method: "Cash",
  subtotal: "", tax: "", amount: "",
  date: new Date().toISOString().split("T")[0],
  receipt_url: "", notes: "", is_reimbursable: false, branch_id: "",
};

// ── Expense Form ──────────────────────────────────────────────────
function ExpenseForm({ form, setForm, categories, branches, onSave, onCancel, onScanReceipt, scanning, editingId }) {

  const updateSubtotal = (val) => {
    const sub = parseFloat(val) || 0;
    const tax = parseFloat(form.tax) || 0;
    setForm(f => ({ ...f, subtotal: val, amount: sub + tax > 0 ? (sub + tax).toFixed(2) : "" }));
  };

  const updateTax = (val) => {
    const tax = parseFloat(val) || 0;
    const sub = parseFloat(form.subtotal) || 0;
    setForm(f => ({ ...f, tax: val, amount: sub + tax > 0 ? (sub + tax).toFixed(2) : "" }));
  };

  const updateTotal = (val) => {
    const total = parseFloat(val) || 0;
    const tax = parseFloat(form.tax) || 0;
    const sub = total - tax;
    setForm(f => ({ ...f, amount: val, subtotal: sub > 0 ? sub.toFixed(2) : "" }));
  };

  const subtotalNum = parseFloat(form.subtotal) || 0;
  const taxNum = parseFloat(form.tax) || 0;
  const totalNum = parseFloat(form.amount) || 0;
  const isBalanced = totalNum > 0 && Math.abs(subtotalNum + taxNum - totalNum) < 0.01;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-lg max-h-[95vh] flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-gray-100">
          <h3 className="font-bold text-gray-900 text-lg">{editingId ? "Edit Expense" : "Add Expense"}</h3>
          <button onClick={onCancel}><X className="w-5 h-5 text-gray-400" /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">

          {/* Scan Receipt */}
          {form.receipt_url ? (
            <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-2xl">
              <img src={form.receipt_url} alt="receipt" className="w-14 h-14 object-cover rounded-xl border border-green-200 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-green-700 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Receipt scanned</p>
                <p className="text-xs text-green-600 mt-0.5">Data auto-filled. Please review below.</p>
              </div>
              <button onClick={() => setForm(f => ({ ...f, receipt_url: "" }))} className="text-green-400 hover:text-red-500 transition p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button onClick={onScanReceipt} disabled={scanning}
              className="w-full flex items-center justify-center gap-2 py-3.5 border-2 border-dashed border-violet-300 rounded-2xl text-violet-600 text-sm font-semibold hover:bg-violet-50 transition disabled:opacity-60">
              {scanning ? (
                <><Sparkles className="w-4 h-4 animate-pulse" /> Scanning invoice…</>
              ) : (
                <div className="flex flex-col items-center gap-0.5"><span className="flex items-center gap-2"><Camera className="w-4 h-4" /> 📷 Scan / Upload Invoice</span><span className="text-xs font-normal opacity-60">JPG, PNG, PDF supported</span></div>
              )}
            </button>
          )}

          {/* Supplier */}
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Supplier / Vendor</label>
            <Input value={form.supplier_name} onChange={e => setForm(f => ({ ...f, supplier_name: e.target.value }))}
              placeholder="e.g. Global Food Ind." className="border-gray-200 rounded-xl" />
          </div>

          {/* Category */}
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Category</label>
            <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
              className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-violet-400">
              <option value="">Select category</option>
              {categories.map(c => <option key={c.id} value={c.name}>{c.icon} {c.name}</option>)}
            </select>
          </div>

          {/* Subtotal / VAT / Total — the key section */}
          <div className="bg-gray-50 rounded-2xl p-4 space-y-3">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Invoice Breakdown</p>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">Subtotal</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 font-medium">AED</span>
                  <input
                    type="number" min="0" step="0.01"
                    value={form.subtotal}
                    onChange={e => updateSubtotal(e.target.value)}
                    placeholder="0.00"
                    className="w-full h-10 pl-10 pr-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:border-violet-400 text-right font-semibold"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">VAT / Tax</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 font-medium">AED</span>
                  <input
                    type="number" min="0" step="0.01"
                    value={form.tax}
                    onChange={e => updateTax(e.target.value)}
                    placeholder="0.00"
                    className="w-full h-10 pl-10 pr-2 border border-gray-200 rounded-xl text-sm bg-white focus:outline-none focus:border-violet-400 text-right font-semibold"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-gray-500 mb-1 block">
                  Total {isBalanced && <span className="text-green-500">✓</span>}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 font-medium">AED</span>
                  <input
                    type="number" min="0" step="0.01"
                    value={form.amount}
                    onChange={e => updateTotal(e.target.value)}
                    placeholder="0.00"
                    className={`w-full h-10 pl-10 pr-2 border rounded-xl text-sm bg-white focus:outline-none text-right font-bold ${
                      isBalanced ? "border-green-300 text-green-700 focus:border-green-400" : "border-violet-300 text-violet-700 focus:border-violet-400"
                    }`}
                  />
                </div>
              </div>
            </div>

            {/* Auto-calculation hint */}
            {(subtotalNum > 0 || taxNum > 0) && !isBalanced && totalNum > 0 && (
              <p className="text-xs text-orange-500 flex items-center gap-1">
                ⚠️ {subtotalNum.toFixed(2)} + {taxNum.toFixed(2)} = {(subtotalNum + taxNum).toFixed(2)} (expected {totalNum.toFixed(2)})
              </p>
            )}
            {subtotalNum > 0 && taxNum === 0 && totalNum > subtotalNum && (
              <button onClick={() => updateTax((totalNum - subtotalNum).toFixed(2))}
                className="text-xs text-violet-600 hover:text-violet-800 font-semibold">
                Auto-fill VAT = AED {(totalNum - subtotalNum).toFixed(2)}
              </button>
            )}
          </div>

          {/* Payment Method + Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-gray-500 mb-1 block">Payment Method</label>
              <select value={form.payment_method} onChange={e => setForm(f => ({ ...f, payment_method: e.target.value }))}
                className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none">
                {PAYMENT_METHODS.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 mb-1 block">Date</label>
              <Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} className="border-gray-200 rounded-xl" />
            </div>
          </div>

          {/* Branch */}
          {branches.length > 1 && (
            <div>
              <label className="text-xs font-medium text-gray-500 mb-1 block">Branch</label>
              <select value={form.branch_id} onChange={e => setForm(f => ({ ...f, branch_id: e.target.value }))}
                className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none">
                <option value="">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="text-xs font-medium text-gray-500 mb-1 block">Notes</label>
            <Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Optional notes…" className="border-gray-200 rounded-xl" />
          </div>

          {/* Reimbursable */}
          <div className="flex items-center justify-between py-1">
            <label className="text-sm text-gray-600">Reimbursable expense</label>
            <button onClick={() => setForm(f => ({ ...f, is_reimbursable: !f.is_reimbursable }))}
              className={`w-11 h-6 rounded-full transition-colors ${form.is_reimbursable ? "bg-violet-500" : "bg-gray-200"} relative`}>
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${form.is_reimbursable ? "translate-x-6" : "translate-x-1"}`} />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-gray-100 flex gap-3">
          <Button onClick={onCancel} variant="outline" className="flex-1 border-gray-200 rounded-xl">Cancel</Button>
          <Button onClick={onSave} className="flex-1 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl">
            {editingId ? "Update" : "Save Expense"}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────
export default function Expenses() {
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [scanning, setScanning] = useState(false);
  const [activeTab, setActiveTab] = useState("transactions");
  const [viewingReceipt, setViewingReceipt] = useState(null);

  useEffect(() => { load(); }, []);

  const load = () => {
    Promise.all([
      base44.entities.Expense.list("-date"),
      base44.entities.ExpenseCategory.list("name"),
      base44.entities.Branch.list(),
    ]).then(([exp, cats, brs]) => {
      setExpenses(exp); setCategories(cats); setBranches(brs); setLoading(false);
    });
  };

  const openNew = () => {
    setEditingId(null);
    setForm({ ...EMPTY, date: new Date().toISOString().split("T")[0] });
    setShowForm(true);
  };

  const openEdit = (e) => {
    setEditingId(e.id);
    setForm({
      supplier_name: e.supplier_name || "",
      category: e.category || "",
      payment_method: e.payment_method || "Cash",
      subtotal: e.subtotal ?? "",
      tax: e.tax ?? "",
      amount: e.amount ?? "",
      date: e.date || "",
      receipt_url: e.receipt_url || "",
      notes: e.notes || "",
      is_reimbursable: e.is_reimbursable || false,
      branch_id: e.branch_id || "",
    });
    setShowForm(true);
  };

  const handleScanReceipt = async () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*,.pdf,application/pdf";
    input.onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setScanning(true);
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `You are an expert invoice OCR system for UAE businesses. Carefully read this invoice/receipt and extract ALL financial fields.

IMPORTANT RULES:
1. supplier_name: Full company/vendor name (e.g. "Greens International Gen. Tr. LLC")
2. invoice_number: Invoice or bill reference number
3. items_subtotal: Sum of line item prices BEFORE any service charges or fees
4. service_charges: Any service fee, handling fee, delivery charge, or similar added charges (NOT VAT)
5. subtotal: The taxable amount = items_subtotal + service_charges. If only one subtotal line exists, use that.
6. vat: The VAT or tax amount (look for "VAT", "Tax", "5%")
7. total: Grand total / amount due (the final number to pay)
8. date: Invoice date in YYYY-MM-DD format
9. category: Best match from: Cost of Goods Sold, Payroll, Utilities, Rent, Marketing, Equipment, Transport, Advertising, Other
10. notes: Invoice number or any reference (e.g. "INV55313")

CALCULATION VERIFICATION:
- subtotal + vat = total (verify this holds true)
- If service_charges exist: items_subtotal + service_charges = subtotal

Return ONLY valid JSON. Return null for fields not found.`,
          file_urls: [file_url],
          response_json_schema: {
            type: "object",
            properties: {
              supplier_name: { type: "string" },
              invoice_number: { type: "string" },
              items_subtotal: { type: "number" },
              service_charges: { type: "number" },
              subtotal: { type: "number" },
              vat: { type: "number" },
              total: { type: "number" },
              date: { type: "string" },
              category: { type: "string" },
              notes: { type: "string" }
            }
          }
        });

        let { supplier_name, invoice_number, items_subtotal, service_charges, subtotal, vat, total, date, category, notes } = result;

        // Smart calculation: if service charges exist, subtotal = items + service charges
        if (items_subtotal != null && service_charges != null && !subtotal) {
          subtotal = items_subtotal + service_charges;
        }

        // Fill missing values from available data
        if (total && vat != null && !subtotal) subtotal = total - vat;
        if (total && subtotal != null && vat == null) vat = total - subtotal;
        if (subtotal != null && vat != null && !total) total = subtotal + vat;

        // Verify balance: if subtotal + vat != total, trust total and recalculate
        if (subtotal != null && vat != null && total != null) {
          const computed = Math.round((subtotal + vat) * 100) / 100;
          const reported = Math.round(total * 100) / 100;
          if (Math.abs(computed - reported) > 0.05) {
            // Trust total and subtotal, recalculate vat
            vat = Math.round((total - subtotal) * 100) / 100;
          }
        }

        const autoNotes = [invoice_number && `INV: ${invoice_number}`, notes].filter(Boolean).join(" | ");

        setForm(f => ({
          ...f,
          receipt_url: file_url,
          supplier_name: supplier_name || f.supplier_name,
          subtotal: subtotal != null ? subtotal.toFixed(2) : f.subtotal,
          tax: vat != null ? vat.toFixed(2) : f.tax,
          amount: total != null ? total.toFixed(2) : f.amount,
          date: date || f.date,
          category: category || f.category,
          notes: autoNotes || f.notes,
        }));
        toast.success("Invoice scanned! Please review and confirm the extracted data.");
      } catch {
        toast.error("Scan failed. Please fill in manually.");
      }
      setScanning(false);
    };
    input.click();
  };

  const save = async () => {
    if (!form.amount) { toast.error("Total amount is required"); return; }
    const data = {
      ...form,
      subtotal: parseFloat(form.subtotal) || 0,
      tax: parseFloat(form.tax) || 0,
      amount: parseFloat(form.amount) || 0,
    };
    if (editingId) {
      await base44.entities.Expense.update(editingId, data);
      toast.success("Updated");
    } else {
      await base44.entities.Expense.create(data);
      toast.success("Expense saved");
    }
    setShowForm(false);
    load();
  };

  const del = async (id) => {
    await base44.entities.Expense.delete(id);
    setExpenses(prev => prev.filter(e => e.id !== id));
    toast.success("Deleted");
  };

  const filtered = useMemo(() => expenses.filter(e => {
    const matchSearch = !search || e.supplier_name?.toLowerCase().includes(search.toLowerCase()) || e.category?.toLowerCase().includes(search.toLowerCase());
    const matchCat = catFilter === "all" || e.category === catFilter;
    const matchFrom = !dateFrom || e.date >= dateFrom;
    const matchTo = !dateTo || e.date <= dateTo;
    return matchSearch && matchCat && matchFrom && matchTo;
  }), [expenses, search, catFilter, dateFrom, dateTo]);

  const totalFiltered = filtered.reduce((s, e) => s + (e.amount || 0), 0);
  const scannedExpenses = useMemo(() => expenses.filter(e => e.receipt_url), [expenses]);

  const handleDownload = async (url, name) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = name || "receipt";
    a.target = "_blank";
    a.click();
  };

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-4 md:p-6">
      <div className="max-w-3xl mx-auto space-y-5">

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Transactions</h1>
            <p className="text-gray-400 text-sm">All expenses · AED {totalFiltered.toLocaleString("en-AE", { minimumFractionDigits: 2 })}</p>
          </div>
          <Button onClick={openNew} className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2">
            <Plus className="w-4 h-4" /> Add Expense
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white border border-gray-200 rounded-xl p-1 w-fit">
          <button onClick={() => setActiveTab("transactions")}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${activeTab === "transactions" ? "bg-violet-600 text-white" : "text-gray-500 hover:text-gray-700"}`}>
            <span className="flex items-center gap-2"><Receipt className="w-3.5 h-3.5" /> Transactions</span>
          </button>
          <button onClick={() => setActiveTab("invoices")}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${activeTab === "invoices" ? "bg-violet-600 text-white" : "text-gray-500 hover:text-gray-700"}`}>
            <span className="flex items-center gap-2"><FileImage className="w-3.5 h-3.5" /> Scanned Invoices {scannedExpenses.length > 0 && <span className={`px-1.5 py-0.5 rounded-full text-xs ${activeTab === "invoices" ? "bg-white/20" : "bg-violet-100 text-violet-700"}`}>{scannedExpenses.length}</span>}</span>
          </button>
        </div>

        {activeTab === "transactions" && (<>
        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input placeholder="Search supplier, category…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white border-gray-200 rounded-xl" />
          </div>
          <select value={catFilter} onChange={e => setCatFilter(e.target.value)}
            className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none">
            <option value="all">All Categories</option>
            {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
          </select>
          <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="bg-white border-gray-200 rounded-xl w-auto" title="From date" />
          <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="bg-white border-gray-200 rounded-xl w-auto" title="To date" />
          {(dateFrom || dateTo) && (
            <button onClick={() => { setDateFrom(""); setDateTo(""); }} className="text-xs text-gray-400 hover:text-red-500 px-2">✕ Clear</button>
          )}
        </div>

        {/* List */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          {loading ? <p className="text-center py-10 text-gray-300 text-sm">Loading…</p> :
           filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-300">
              <p className="text-sm font-medium">No expenses yet</p>
              <p className="text-xs mt-1">Tap "Add Expense" to start</p>
            </div>
          ) : filtered.map((e, i) => (
            <div key={e.id} className={`flex items-center gap-4 px-5 py-4 border-b border-gray-50 hover:bg-gray-50/50 transition group ${i === filtered.length - 1 ? "border-b-0" : ""}`}>
              {e.receipt_url
                ? <img src={e.receipt_url} alt="receipt" onClick={() => setViewingReceipt(e)} className="w-10 h-10 object-cover rounded-lg border border-gray-100 shrink-0 cursor-pointer hover:opacity-80 transition" />
                : <div className="w-10 h-10 bg-violet-50 rounded-lg flex items-center justify-center shrink-0 text-lg">{categories.find(c => c.name === e.category)?.icon || "📄"}</div>
              }
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-800 text-sm truncate">{e.supplier_name || "No supplier"}</p>
                <p className="text-xs text-gray-400 mt-0.5">{e.category || "—"} · {e.payment_method} · {e.date}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="font-bold text-gray-900">AED {(e.amount || 0).toFixed(2)}</p>
                {e.subtotal > 0 && e.tax > 0 && (
                  <p className="text-xs text-gray-400">{e.subtotal?.toFixed(2)} + {e.tax?.toFixed(2)} VAT</p>
                )}
                {e.tax > 0 && !e.subtotal && (
                  <p className="text-xs text-gray-400">+AED {e.tax.toFixed(2)} VAT</p>
                )}
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition">
                {e.receipt_url && <button onClick={() => setViewingReceipt(e)} className="p-1.5 text-gray-400 hover:text-blue-500"><Eye className="w-3.5 h-3.5" /></button>}
                <button onClick={() => openEdit(e)} className="p-1.5 text-gray-400 hover:text-violet-600"><Edit2 className="w-3.5 h-3.5" /></button>
                <button onClick={() => del(e.id)} className="p-1.5 text-gray-400 hover:text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
        </>)}

        {activeTab === "invoices" && (
          <div>
            {scannedExpenses.length === 0 ? (
              <div className="text-center py-20 text-gray-300">
                <FileImage className="w-12 h-12 mx-auto mb-3 text-gray-200" />
                <p className="text-sm font-medium">No scanned invoices yet</p>
                <p className="text-xs mt-1">Scan receipts when adding expenses</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {scannedExpenses.map(e => (
                  <div key={e.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden group">
                    <div className="relative">
                      <img src={e.receipt_url} alt="receipt" className="w-full h-40 object-cover" />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                        <button onClick={() => setViewingReceipt(e)} className="p-2 bg-white rounded-full shadow text-gray-700 hover:text-violet-600 transition">
                          <Eye className="w-4 h-4" />
                        </button>
                        <a href={e.receipt_url} download target="_blank" rel="noreferrer" className="p-2 bg-white rounded-full shadow text-gray-700 hover:text-green-600 transition">
                          <Download className="w-4 h-4" />
                        </a>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="font-semibold text-gray-800 text-sm truncate">{e.supplier_name || "No supplier"}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{e.date}</p>
                      <p className="text-sm font-bold text-violet-700 mt-1">AED {(e.amount || 0).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Receipt Viewer Modal */}
      {viewingReceipt && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setViewingReceipt(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <p className="font-bold text-gray-900">{viewingReceipt.supplier_name || "Receipt"}</p>
                <p className="text-xs text-gray-400">{viewingReceipt.date} · AED {(viewingReceipt.amount || 0).toFixed(2)}</p>
              </div>
              <div className="flex items-center gap-2">
                <a href={viewingReceipt.receipt_url} download target="_blank" rel="noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold rounded-xl transition">
                  <Download className="w-3.5 h-3.5" /> Download
                </a>
                <button onClick={() => setViewingReceipt(null)} className="text-gray-400 hover:text-gray-600 p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto p-4">
              <img src={viewingReceipt.receipt_url} alt="receipt" className="w-full rounded-xl border border-gray-100" />
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <ExpenseForm
          form={form} setForm={setForm}
          categories={categories} branches={branches}
          onSave={save} onCancel={() => setShowForm(false)}
          onScanReceipt={handleScanReceipt} scanning={scanning}
          editingId={editingId}
        />
      )}
    </div>
  );
}