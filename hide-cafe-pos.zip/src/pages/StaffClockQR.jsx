import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { QrCode, Printer, Copy, CheckCircle2, MapPin, ExternalLink } from "lucide-react";

function getClockUrl(branchId) {
  const base = window.location.origin;
  return `${base}/StaffTimeClock?branch=${branchId}`;
}

function getQrImageUrl(text) {
  return `https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=12&data=${encodeURIComponent(text)}`;
}

function BranchQRCard({ branch }) {
  const url = getClockUrl(branch.id);
  const qrUrl = getQrImageUrl(url);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    const win = window.open("", "_blank");
    win.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Time Clock QR — ${branch.name}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; background: white; }
            .card { text-align: center; padding: 48px; border: 2px solid #e5e7eb; border-radius: 24px; max-width: 360px; }
            h1 { font-size: 28px; font-weight: 900; color: #111; margin-bottom: 6px; }
            .branch { font-size: 16px; color: #6d28d9; font-weight: 600; margin-bottom: 32px; }
            img { width: 220px; height: 220px; margin: 0 auto 24px; display: block; }
            .instruction { font-size: 15px; color: #4b5563; margin-bottom: 6px; }
            .url { font-size: 11px; color: #9ca3af; word-break: break-all; margin-top: 16px; }
          </style>
        </head>
        <body>
          <div class="card">
            <h1>⏱ Staff Time Clock</h1>
            <div class="branch">${branch.name}</div>
            <img src="${qrUrl}" alt="QR Code" />
            <p class="instruction">Scan to clock in / out</p>
            <p class="instruction">Enter your PIN after scanning</p>
            <p class="url">${url}</p>
          </div>
          <script>window.onload = () => window.print();<\/script>
        </body>
      </html>
    `);
    win.document.close();
  };

  return (
    <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center"
          style={{ background: branch.color || "linear-gradient(135deg,#5B2CC0,#7C3AED)" }}>
          <MapPin className="w-4 h-4 text-white" />
        </div>
        <div>
          <p className="font-bold text-gray-900">{branch.name}</p>
          {branch.location && <p className="text-xs text-gray-400">{branch.location}</p>}
        </div>
      </div>

      {/* QR */}
      <div className="flex flex-col items-center px-6 py-6 gap-4">
        <img src={qrUrl} alt={`QR for ${branch.name}`}
          className="w-48 h-48 rounded-2xl border border-gray-100 shadow-sm" />
        <p className="text-xs text-gray-400 text-center">
          Staff scan this to open Time Clock<br />for <span className="font-semibold text-gray-600">{branch.name}</span>
        </p>

        {/* URL pill */}
        <div className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 flex items-center gap-2 overflow-hidden">
          <p className="text-xs text-gray-500 truncate flex-1 font-mono">{url}</p>
          <a href={url} target="_blank" rel="noreferrer"
            className="text-violet-500 hover:text-violet-700 shrink-0">
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Actions */}
        <div className="flex gap-2 w-full">
          <button onClick={handleCopy}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-700 hover:bg-gray-50 transition">
            {copied ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
            {copied ? "Copied!" : "Copy Link"}
          </button>
          <button onClick={handlePrint}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-violet-600 hover:bg-violet-700 rounded-xl text-sm font-semibold text-white transition">
            <Printer className="w-4 h-4" />
            Print QR
          </button>
        </div>
      </div>
    </div>
  );
}

export default function StaffClockQR() {
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Branch.list().then(data => {
      setBranches(data.filter(b => b.is_active !== false));
      setLoading(false);
    });
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-700 to-violet-500 px-6 py-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center">
            <QrCode className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Time Clock QR Codes</h1>
            <p className="text-violet-200 text-sm mt-0.5">Print and place at each branch for staff to scan</p>
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-6 bg-white/10 border border-white/20 rounded-2xl p-4">
          <p className="text-white/80 text-sm font-semibold mb-2">📌 How to use</p>
          <ol className="text-white/60 text-sm space-y-1 list-decimal list-inside">
            <li>Print the QR code for each branch</li>
            <li>Place it at the staff entrance or break room</li>
            <li>Staff scan with phone → opens Time Clock instantly</li>
            <li>Staff enter their PIN → Clock In / Break / Clock Out</li>
          </ol>
        </div>
      </div>

      {/* QR Cards */}
      <div className="p-6">
        {loading && (
          <div className="text-center py-20 text-gray-400">Loading branches…</div>
        )}
        {!loading && branches.length === 0 && (
          <div className="text-center py-20">
            <QrCode className="w-12 h-12 text-gray-200 mx-auto mb-3" />
            <p className="text-gray-400">No branches found. Add branches first.</p>
          </div>
        )}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {branches.map(branch => (
            <BranchQRCard key={branch.id} branch={branch} />
          ))}
        </div>
      </div>
    </div>
  );
}