import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "@/components/inventory/PermissionsProvider";
import AccessDenied from "@/components/inventory/AccessDenied";

export default function OrderTransaction() {
  const { user: permUser, hasPermission, loading: permLoading } = usePermissions();
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [supplierName, setSupplierName] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [status, setStatus] = useState("pending");
  const [items, setItems] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [qty, setQty] = useState("");
  const [qtyReceived, setQtyReceived] = useState("");
  const [unitCost, setUnitCost] = useState("");
  const [receivedBy, setReceivedBy] = useState("");
  const [user, setUser] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!permLoading) {
      if (!hasPermission("create_orders")) return;
      loadData();
    }
  }, [permLoading, hasPermission]);

  const loadData = async () => {
    setLoading(true);
    const [orders, items, currentUser] = await Promise.all([
      base44.entities.InventoryOrderTransaction.list("-created_date", 50),
      base44.entities.MenuItem.list(),
      base44.auth.me().catch(() => null)
    ]);
    setOrders(orders);
    setMenuItems(items);
    setUser(currentUser);
    setReceivedBy(currentUser?.full_name || "");
    setLoading(false);
  };

  const addItem = () => {
    if (!selectedItem || !qty || !unitCost) {
      toast.error("Select item, quantity, and cost");
      return;
    }
    const totalCost = Number(qty) * Number(unitCost);
    setItems([...items, {
      menu_item_id: selectedItem.id,
      item_name: selectedItem.name,
      quantity_ordered: Number(qty),
      quantity_received: qtyReceived ? Number(qtyReceived) : Number(qty),
      unit_cost: Number(unitCost),
      total_cost: totalCost
    }]);
    setSelectedItem(null);
    setQty("");
    setQtyReceived("");
    setUnitCost("");
    setSearch("");
  };

  const removeItem = (idx) => {
    setItems(items.filter((_, i) => i !== idx));
  };

  const saveOrder = async () => {
    if (!supplierName.trim() || !orderNumber.trim() || items.length === 0) {
      toast.error("Fill in supplier, order number, and add items");
      return;
    }

    const totalAmount = items.reduce((s, i) => s + i.total_cost, 0);
    await base44.entities.InventoryOrderTransaction.create({
      date: new Date().toISOString().split('T')[0],
      supplier_name: supplierName,
      order_number: orderNumber,
      items: items,
      status: status,
      total_amount: totalAmount,
      received_by: status === "received" || status === "partial" ? receivedBy : null,
      notes: ""
    });

    // Update stock if received
    if (status === "received" || status === "partial") {
      for (const item of items) {
        const menuItem = await base44.entities.MenuItem.filter({ id: item.menu_item_id }).then(arr => arr[0]);
        if (menuItem) {
          const newStock = (menuItem.stock_quantity || 0) + item.quantity_received;
          await base44.entities.MenuItem.update(item.menu_item_id, { stock_quantity: newStock });
        }
      }
    }

    toast.success("Order saved");
    setShowForm(false);
    setSupplierName("");
    setOrderNumber("");
    setItems([]);
    setStatus("pending");
    loadData();
  };

  const deleteOrder = async (id) => {
    await base44.entities.InventoryOrderTransaction.delete(id);
    toast.success("Order deleted");
    loadData();
  };

  const filteredItems = menuItems.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  if (permLoading) return <div className="p-6 text-center text-gray-400">Loading...</div>;
  if (!hasPermission("create_orders")) {
    return <AccessDenied feature="Order Transactions" currentRole={permUser?.role || "unknown"} />;
  }
  if (loading) return <div className="p-6 text-center text-gray-400">Loading...</div>;

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Order Transactions</h1>
            <p className="text-gray-400 text-sm mt-0.5">Track purchase orders and receipts</p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
          >
            <Plus className="w-4 h-4" /> New Order
          </Button>
        </div>

        {showForm && (
          <div className="bg-white border border-gray-100 rounded-2xl p-6 space-y-4">
            <h2 className="font-bold text-lg">Create Purchase Order</h2>

            <div className="grid grid-cols-2 gap-3">
              <Input
                placeholder="Supplier name"
                value={supplierName}
                onChange={e => setSupplierName(e.target.value)}
                className="border-gray-200 rounded-xl"
              />
              <Input
                placeholder="Order number"
                value={orderNumber}
                onChange={e => setOrderNumber(e.target.value)}
                className="border-gray-200 rounded-xl"
              />
            </div>

            <select
              value={status}
              onChange={e => setStatus(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-violet-400"
            >
              <option value="pending">Pending</option>
              <option value="received">Received</option>
              <option value="partial">Partial</option>
              <option value="cancelled">Cancelled</option>
            </select>

            {status !== "pending" && (
              <Input
                placeholder="Received by"
                value={receivedBy}
                onChange={e => setReceivedBy(e.target.value)}
                className="border-gray-200 rounded-xl"
              />
            )}

            <div className="border-t pt-4 space-y-3">
              <h3 className="font-medium text-gray-900 text-sm">Items</h3>

              {items.length > 0 && (
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-200">
                      <div className="flex-1 text-xs">
                        <p className="font-medium text-gray-900">{item.item_name}</p>
                        <p className="text-gray-400">{item.quantity_ordered} @ ${item.unit_cost.toFixed(2)}</p>
                      </div>
                      <div className="text-xs font-medium text-gray-900">${item.total_cost.toFixed(2)}</div>
                      <button onClick={() => removeItem(idx)} className="ml-2 text-red-500 hover:text-red-700">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-2 bg-gray-50 p-3 rounded-lg border border-gray-200">
                <Input
                  placeholder="Search items..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="border-gray-200 rounded-lg text-xs"
                />
                {search && filteredItems.length > 0 && (
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {filteredItems.map(item => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setSelectedItem(item);
                          setSearch("");
                        }}
                        className="w-full text-left text-xs px-2 py-1 bg-white hover:bg-gray-100 border border-gray-200 rounded transition"
                      >
                        {item.name}
                      </button>
                    ))}
                  </div>
                )}

                {selectedItem && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-gray-900">{selectedItem.name}</p>
                    <div className="grid grid-cols-3 gap-1.5">
                      <Input
                        type="number"
                        min="1"
                        placeholder="Qty"
                        value={qty}
                        onChange={e => setQty(e.target.value)}
                        className="border-gray-200 rounded-lg text-xs h-8"
                      />
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Cost"
                        value={unitCost}
                        onChange={e => setUnitCost(e.target.value)}
                        className="border-gray-200 rounded-lg text-xs h-8"
                      />
                      <Input
                        type="number"
                        min="0"
                        placeholder="Rcvd"
                        value={qtyReceived}
                        onChange={e => setQtyReceived(e.target.value)}
                        className="border-gray-200 rounded-lg text-xs h-8"
                      />
                    </div>
                    <Button
                      onClick={addItem}
                      size="sm"
                      className="w-full bg-violet-600 hover:bg-violet-700 text-white text-xs h-8 rounded-lg"
                    >
                      Add Item
                    </Button>
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => {
                  setShowForm(false);
                  setItems([]);
                  setSupplierName("");
                  setOrderNumber("");
                }}
                variant="outline"
                className="border-gray-200 rounded-xl flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={saveOrder}
                className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl flex-1"
              >
                Save Order
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-2">
          {orders.length === 0 ? (
            <p className="text-center text-gray-400 py-12">No orders yet</p>
          ) : (
            orders.map(order => (
              <div key={order.id} className="bg-white border border-gray-100 rounded-xl p-4 space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{order.supplier_name}</p>
                    <p className="text-xs text-gray-400">{order.order_number}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    order.status === "received" ? "bg-green-100 text-green-700" :
                    order.status === "partial" ? "bg-orange-100 text-orange-700" :
                    order.status === "cancelled" ? "bg-red-100 text-red-700" :
                    "bg-blue-100 text-blue-700"
                  }`}>
                    {order.status}
                  </span>
                </div>
                <p className="text-xs text-gray-500">{order.items?.length || 0} items · ${order.total_amount?.toFixed(2) || "0.00"}</p>
                <button
                  onClick={() => deleteOrder(order.id)}
                  className="text-gray-300 hover:text-red-500 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}