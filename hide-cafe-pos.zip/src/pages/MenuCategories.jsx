import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, X, Upload, SlidersHorizontal, Filter, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import MenuImportExport from "@/components/menu/MenuImportExport";

export default function MenuCategories() {
  const [categories, setCategories] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("all");
  const [selected, setSelected] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingCat, setEditingCat] = useState(null);
  const [showImportExport, setShowImportExport] = useState(false);
  const [branches, setBranches] = useState([]);
  const [form, setForm] = useState({ name: "", name_localized: "", reference: "", image: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    setLoading(true);
    const [cats, items, branchData] = await Promise.all([
      base44.entities.MenuCategory.list("reference"),
      base44.entities.MenuItem.list(),
      base44.entities.Branch.list(),
    ]);
    setCategories(cats);
    setMenuItems(items);
    setBranches(branchData);
    setLoading(false);
  };

  const productCountFor = (catName) =>
    menuItems.filter(i => i.category === catName).length;

  const openCreate = () => {
    setEditingCat(null);
    setForm({ name: "", name_localized: "", reference: "", image: "" });
    setShowForm(true);
  };

  const openEdit = (cat) => {
    setEditingCat(cat);
    setForm({ name: cat.name || "", name_localized: cat.name_localized || "", reference: cat.reference || "", image: cat.image || "" });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error("Category name is required"); return; }
    setSaving(true);
    if (editingCat) {
      await base44.entities.MenuCategory.update(editingCat.id, form);
      toast.success("Category updated");
    } else {
      await base44.entities.MenuCategory.create(form);
      toast.success("Category created");
    }
    setSaving(false);
    setShowForm(false);
    load();
  };

  const handleDelete = async (cat) => {
    if (!confirm(`Delete "${cat.name}"?`)) return;
    await base44.entities.MenuCategory.update(cat.id, { is_deleted: true });
    toast.success("Category deleted");
    load();
  };

  const toggleSelect = (id) =>
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const toggleAll = () => {
    const filtered = filteredCategories;
    if (selected.length === filtered.length) setSelected([]);
    else setSelected(filtered.map(c => c.id));
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "—";
    try { return format(new Date(dateStr), "MMM dd, yyyy"); } catch { return "—"; }
  };

  const filteredCategories = tab === "deleted"
    ? categories.filter(c => c.is_deleted)
    : categories.filter(c => !c.is_deleted);

  return (
    <div className="min-h-screen bg-[#f5f5fa] p-6">
      <div className="max-w-6xl mx-auto space-y-5">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Categories</h1>
            <p className="text-sm text-gray-400 mt-0.5">Manage menu categories</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm font-medium" onClick={() => setShowImportExport(true)}>
              <Upload className="w-4 h-4" />
              Import / Export
            </Button>
            <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm font-medium">
              <SlidersHorizontal className="w-4 h-4" />
              Sort Categories
            </Button>
            <Button
              onClick={openCreate}
              className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Category
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 pt-4 pb-0 border-b border-gray-100">
            <div className="flex gap-1">
              {["all", "deleted"].map(t => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`px-4 py-2 text-sm font-medium rounded-t-lg capitalize transition border-b-2 ${
                    tab === t
                      ? "border-violet-600 text-violet-700"
                      : "border-transparent text-gray-400 hover:text-gray-700"
                  }`}
                >
                  {t === "all" ? `All (${categories.filter(c => !c.is_deleted).length})` : "Deleted"}
                </button>
              ))}
            </div>
            <Button variant="outline" className="border-gray-200 rounded-xl gap-2 text-sm mb-2">
              <Filter className="w-4 h-4" />
              Filter
            </Button>
          </div>

          {loading ? (
            <div className="text-center py-16 text-gray-300 text-sm">Loading...</div>
          ) : filteredCategories.length === 0 ? (
            <div className="text-center py-16 text-gray-300 text-sm">No categories yet. Create one to get started.</div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="pl-5 py-3 w-8">
                    <input
                      type="checkbox"
                      className="rounded border-gray-300 text-violet-600"
                      checked={selected.length === filteredCategories.length && filteredCategories.length > 0}
                      onChange={toggleAll}
                    />
                  </th>
                  <th className="w-10 py-3" />
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Name</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Reference</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Products</th>
                  <th className="py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Created</th>
                  <th className="py-3 pr-5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredCategories.map((cat) => (
                  <tr key={cat.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition">
                    <td className="pl-5 py-3.5">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-violet-600"
                        checked={selected.includes(cat.id)}
                        onChange={() => toggleSelect(cat.id)}
                      />
                    </td>
                    <td className="py-3.5">
                      {cat.image ? (
                        <img src={cat.image} alt={cat.name} className="w-9 h-9 rounded-lg object-cover" />
                      ) : (
                        <div className="w-9 h-9 rounded-lg bg-violet-50 flex items-center justify-center text-violet-400 text-sm font-bold">
                          {cat.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 pr-4">
                      <p className="text-sm font-semibold text-gray-800">{cat.name}</p>
                      {cat.name_localized && <p className="text-xs text-gray-400">{cat.name_localized}</p>}
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-gray-500 font-mono">{cat.reference || "—"}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-violet-600 font-medium">{productCountFor(cat.name)}</span>
                    </td>
                    <td className="py-3.5 pr-4">
                      <span className="text-sm text-gray-400">{formatDate(cat.created_date)}</span>
                    </td>
                    <td className="py-3.5 pr-5">
                      <div className="flex items-center gap-1">
                        <button onClick={() => openEdit(cat)} className="p-1.5 rounded-lg text-gray-400 hover:text-violet-600 hover:bg-violet-50 transition">
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => handleDelete(cat)} className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showImportExport && (
        <MenuImportExport
          branches={branches}
          onClose={() => setShowImportExport(false)}
          onImportComplete={() => { load(); setShowImportExport(false); }}
        />
      )}

      {/* Create / Edit Category Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="font-bold text-gray-900 text-lg">{editingCat ? "Edit Category" : "Create Category"}</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-300 hover:text-gray-600 transition">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 block">Name <span className="text-red-500">*</span></label>
                <Input
                  placeholder="e.g. Desserts"
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  className="border-gray-200 rounded-xl text-gray-900"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 block">Localized Name</label>
                <Input
                  placeholder="Arabic or other language name"
                  value={form.name_localized}
                  onChange={e => setForm(f => ({ ...f, name_localized: e.target.value }))}
                  className="border-gray-200 rounded-xl text-gray-900"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1.5 block">Reference</label>
                <Input
                  placeholder="e.g. cat-2"
                  value={form.reference}
                  onChange={e => setForm(f => ({ ...f, reference: e.target.value }))}
                  className="border-gray-200 rounded-xl text-gray-900"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 px-6 py-4 border-t border-gray-100">
              <Button variant="outline" onClick={() => setShowForm(false)} className="rounded-xl border-gray-200">Cancel</Button>
              <Button
                onClick={handleSave}
                disabled={saving}
                className="bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl"
              >
                {saving ? "Saving..." : editingCat ? "Save Changes" : "Create Category"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}