import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Simple PIN hashing using SHA-256
async function hashPin(pin) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`DENDAX_PIN_SALT_${pin}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { staff_member_id, pin } = await req.json();

    if (!staff_member_id || !pin) {
      return Response.json({ error: 'staff_member_id and pin are required' }, { status: 400 });
    }

    if (String(pin).length < 4 || String(pin).length > 6) {
      return Response.json({ error: 'PIN must be 4–6 digits' }, { status: 400 });
    }

    if (!/^\d+$/.test(String(pin))) {
      return Response.json({ error: 'PIN must be numeric only' }, { status: 400 });
    }

    // Check PIN uniqueness within the branch
    const staffMember = await base44.asServiceRole.entities.StaffMember.filter({ id: staff_member_id });
    if (!staffMember || staffMember.length === 0) {
      return Response.json({ error: 'Staff member not found' }, { status: 404 });
    }

    const branch_id = staffMember[0].branch_id;
    const pinHash = await hashPin(pin);

    // Check if another staff in the same branch has this PIN
    const branchStaff = await base44.asServiceRole.entities.StaffMember.filter({ branch_id });
    const conflict = branchStaff.find(s => s.pin_hash === pinHash && s.id !== staff_member_id);
    if (conflict) {
      return Response.json({ error: 'This PIN is already used by another staff member in this branch. Please choose a different PIN.' }, { status: 409 });
    }

    // Update pin_hash and reset lockout
    await base44.asServiceRole.entities.StaffMember.update(staff_member_id, {
      pin_hash: pinHash,
      failed_attempts: 0,
      locked_until: null
    });

    await base44.asServiceRole.entities.StaffLoginLog.create({
      staff_member_id: staff_member_id,
      staff_name: staffMember[0].name,
      branch_id: branch_id,
      branch_name: staffMember[0].branch_name,
      event: 'pin_reset',
      timestamp: new Date().toISOString()
    });

    return Response.json({ success: true });

  } catch (error) {
    console.error('setStaffPin error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});