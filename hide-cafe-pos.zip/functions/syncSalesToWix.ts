import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// ⚠️ IMPORTANT: Before running this function, you must manually create a collection
// in your Wix CMS dashboard with the ID: DailyPOSSalesReports
// Fields needed: title (Text), date (Text), totalOrders (Number), totalRevenue (Number),
//   totalTax (Number), totalDiscount (Number), avgOrderValue (Number),
//   dineInCount (Number), takeawayCount (Number), paymentBreakdown (Text),
//   topSellingItems (Text), generatedAt (Text)

const WIX_COLLECTION_ID = 'DailyPOSSalesReports';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('wix');

    // Parse optional "date" from body (defaults to yesterday)
    let targetDate = null;
    try {
      const body = await req.clone().json();
      if (body.date) targetDate = new Date(body.date);
    } catch (_) {}

    const day = targetDate ? new Date(targetDate) : new Date();
    if (!targetDate) day.setUTCDate(day.getUTCDate() - 1);
    day.setUTCHours(0, 0, 0, 0);
    const endOfDay = new Date(day);
    endOfDay.setUTCHours(23, 59, 59, 999);
    const dateLabel = day.toISOString().split('T')[0];

    console.log(`Syncing sales for: ${dateLabel}`);

    // Fetch paid orders for the target day
    const allOrders = await base44.asServiceRole.entities.Order.filter({ status: 'paid' });
    const orders = allOrders.filter(o => {
      const d = new Date(o.created_date);
      return d >= day && d <= endOfDay;
    });

    console.log(`Found ${orders.length} paid orders for ${dateLabel}`);

    // Aggregate stats
    const totalRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);
    const totalOrders = orders.length;
    const totalTax = orders.reduce((s, o) => s + (o.tax || 0), 0);
    const totalDiscount = orders.reduce((s, o) => s + (o.discount || 0), 0);
    const dineIn = orders.filter(o => o.type === 'dine-in').length;
    const takeaway = orders.filter(o => o.type === 'takeaway').length;
    const avgOrderValue = totalOrders > 0 ? (totalRevenue / totalOrders) : 0;

    const paymentBreakdown = {};
    orders.forEach(o => {
      const method = o.payment_method || 'unknown';
      paymentBreakdown[method] = (paymentBreakdown[method] || 0) + (o.total || 0);
    });

    const itemCounts = {};
    orders.forEach(o => {
      (o.items || []).forEach(item => {
        const name = item.name || 'Unknown';
        itemCounts[name] = (itemCounts[name] || 0) + (item.quantity || 1);
      });
    });
    const topItems = Object.entries(itemCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, qty]) => `${name} (${qty})`);

    // Insert into Wix CMS collection via REST API
    const insertResp = await fetch('https://www.wixapis.com/wix-data/v2/items', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        dataCollectionId: WIX_COLLECTION_ID,
        dataItem: {
          data: {
            title: `Daily Sales Report — ${dateLabel}`,
            date: dateLabel,
            totalOrders,
            totalRevenue: parseFloat(totalRevenue.toFixed(2)),
            totalTax: parseFloat(totalTax.toFixed(2)),
            totalDiscount: parseFloat(totalDiscount.toFixed(2)),
            avgOrderValue: parseFloat(avgOrderValue.toFixed(2)),
            dineInCount: dineIn,
            takeawayCount: takeaway,
            paymentBreakdown: JSON.stringify(paymentBreakdown),
            topSellingItems: topItems.join(', ') || 'No items',
            generatedAt: new Date().toISOString(),
          },
        },
      }),
    });

    const insertData = await insertResp.json();
    console.log('Wix insert status:', insertResp.status);
    console.log('Wix insert body:', JSON.stringify(insertData));

    if (!insertResp.ok) {
      throw new Error(`Wix CMS insert failed (${insertResp.status}): ${JSON.stringify(insertData)}`);
    }

    return Response.json({
      success: true,
      date: dateLabel,
      orders: totalOrders,
      revenue: parseFloat(totalRevenue.toFixed(2)),
      wixItemId: insertData?.dataItem?.id,
    });
  } catch (error) {
    console.error('syncSalesToWix error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});