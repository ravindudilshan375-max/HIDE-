import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { order_id } = await req.json();
    if (!order_id) return Response.json({ error: 'order_id required' }, { status: 400 });

    const orders = await base44.entities.WeeklyOrderRequest.filter({ id: order_id });
    const order = orders[0];
    if (!order) return Response.json({ error: 'Order not found' }, { status: 404 });
    if (!order.vendor_email) return Response.json({ error: 'No vendor email set' }, { status: 400 });

    const weekLabel = order.week_start && order.week_end
      ? `${new Date(order.week_start).toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })} – ${new Date(order.week_end).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}`
      : '';

    const itemsText = (order.items || [])
      .map(i => `  • ${i.item_name} – ${i.requested_qty} ${i.unit} (AED ${(i.estimated_cost || 0).toFixed(2)})`)
      .join('\n');

    const body = `Dear ${order.vendor_name},

Please find our weekly stock order request from ${order.branch_name}.

Week: ${weekLabel}
Requested By: ${order.requested_by}

─────────────────────────────
ITEMS REQUESTED
─────────────────────────────
${itemsText}

─────────────────────────────
Estimated Total: AED ${(order.total_estimated_cost || 0).toFixed(2)}
─────────────────────────────
${order.notes ? `\nNotes: ${order.notes}\n` : ''}
Please confirm availability and expected delivery date.

Thank you,
${order.branch_name}`;

    await base44.integrations.Core.SendEmail({
      to: order.vendor_email,
      subject: `Weekly Order Request – ${order.branch_name} – ${weekLabel}`,
      body,
    });

    await base44.entities.WeeklyOrderRequest.update(order_id, {
      status: 'sent',
      email_sent_at: new Date().toISOString(),
    });

    console.log(`Email sent to ${order.vendor_email} for order ${order_id}`);
    return Response.json({ success: true });
  } catch (error) {
    console.error('sendWeeklyOrderEmail error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});