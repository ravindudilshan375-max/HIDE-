import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function hashPin(pin) {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin + "staff_pin_salt_dendax");
  return crypto.subtle.digest("SHA-256", data).then(buf => {
    const arr = Array.from(new Uint8Array(buf));
    return arr.map(x => x.toString(16).padStart(2, '0')).join('');
  });
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { pin, branch_id, latitude, longitude } = body;

    if (!pin || !branch_id || latitude === undefined || longitude === undefined) {
      return Response.json({ success: false, error: "Missing required fields" }, { status: 400 });
    }

    const user = await base44.auth.me().catch(() => null);
    if (!user) {
      return Response.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    // Hash PIN and find staff
    const hashedPin = await hashPin(pin);
    const staffMembers = await base44.entities.StaffMember.filter({ branch_id });
    const staff = staffMembers.find(s => s.pin_hash === hashedPin && s.is_active !== false);

    if (!staff) {
      return Response.json({ success: false, error: "Invalid PIN or staff not found" }, { status: 401 });
    }

    // Get branch details for geofencing
    const branch = await base44.entities.Branch.list().then(branches => 
      branches.find(b => b.id === branch_id)
    );

    if (!branch) {
      return Response.json({ success: false, error: "Branch not found" }, { status: 400 });
    }

    // Check geofence
    const distance = haversineDistance(branch.latitude, branch.longitude, latitude, longitude);
    const radiusMeters = branch.clock_in_radius_meters || 100;

    if (distance > radiusMeters) {
      return Response.json({ 
        success: false, 
        error: `Out of geofence. You are ${Math.round(distance)}m from branch (allowed: ${radiusMeters}m)` 
      }, { status: 403 });
    }

    // Get today's date
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    // Check if already clocked in today
    const existingAttendance = await base44.entities.Attendance.filter({ 
      staff_id: staff.id, 
      date: todayStr 
    }).catch(() => []);

    if (existingAttendance.length > 0 && existingAttendance[0].clock_in_time) {
      return Response.json({ 
        success: false, 
        error: "Already clocked in today" 
      }, { status: 400 });
    }

    // Get today's scheduled shift
    const scheduledShifts = await base44.entities.StaffSchedule.filter({ 
      staff_email: staff.staff_email || staff.email,
      date: todayStr 
    }).catch(() => []);

    let lateMinutes = 0;
    let status = "on_time";
    let deductionAmount = 0;
    let scheduledStart = "";
    let scheduledEnd = "";

    if (scheduledShifts.length > 0) {
      const shift = scheduledShifts[0];
      scheduledStart = shift.shift_start;
      scheduledEnd = shift.shift_end;

      // Parse shift start time (HH:MM)
      const [shiftHour, shiftMin] = shift.shift_start.split(':').map(Number);
      const shiftStart = new Date(now);
      shiftStart.setHours(shiftHour, shiftMin, 0, 0);

      // Calculate late minutes (after 5-min grace period)
      if (now > shiftStart) {
        const diffMs = now - shiftStart;
        const diffMinutes = Math.floor(diffMs / 60000);
        const graceMinutes = 5;

        if (diffMinutes > graceMinutes) {
          lateMinutes = diffMinutes - graceMinutes;
          status = "late";
          deductionAmount = lateMinutes * 1; // 1 AED per minute
        }
      }
    }

    // Create or update attendance record
    const attendanceData = {
      staff_id: staff.id,
      staff_email: staff.staff_email || staff.email,
      staff_name: staff.name,
      branch_id,
      date: todayStr,
      scheduled_shift_start: scheduledStart,
      scheduled_shift_end: scheduledEnd,
      clock_in_time: now.toISOString(),
      late_minutes: lateMinutes,
      status,
      deduction_amount: deductionAmount,
      gps_verified: true,
      gps_distance_meters: Math.round(distance),
    };

    if (existingAttendance.length > 0) {
      await base44.asServiceRole.entities.Attendance.update(existingAttendance[0].id, attendanceData);
    } else {
      await base44.asServiceRole.entities.Attendance.create(attendanceData);
    }

    return Response.json({ 
      success: true, 
      staff: {
        id: staff.id,
        name: staff.name,
        role_type: staff.role_type,
        branch_id,
        branch_name: branch.name
      },
      attendance: {
        status,
        late_minutes: lateMinutes,
        deduction_amount: deductionAmount,
        gps_verified: true,
        distance_meters: Math.round(distance)
      }
    });

  } catch (error) {
    console.error("Clock-in error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});