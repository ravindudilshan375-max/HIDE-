import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { order_id, order_number } = body;

    if (!order_id && !order_number) {
      return Response.json({ error: "order_id or order_number required" }, { status: 400 });
    }

    let o = null;

    // Prefer direct ID lookup (fast)
    if (order_id) {
      console.log("Looking up by ID:", order_id);
      o = await base44.asServiceRole.entities.Order.get(order_id);
    } else {
      // Fallback: scan by order_number (slower, for legacy links)
      console.log("Scanning by order_number:", order_number);
      const batch = await base44.asServiceRole.entities.Order.list("-created_date", 500);
      o = batch?.find(order => order.order_number === order_number);
    }

    console.log("Found:", o ? (o.order_number || o.id) : "none");

    if (!o) {
      return Response.json({ error: "not_found" }, { status: 404 });
    }

    return Response.json({
      order: {
        order_number: o.order_number,
        created_date: o.created_date,
        type: o.type,
        table_number: o.table_number,
        customer_name: o.customer_name,
        items: o.items,
        subtotal: o.subtotal,
        tax: o.tax,
        discount: o.discount,
        total: o.total,
        payment_method: o.payment_method,
        cashier_name: o.cashier_name,
        restaurant_name: o.restaurant_name,
        branch_name: o.branch_name,
      }
    });
  } catch (error) {
    console.error("Error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});