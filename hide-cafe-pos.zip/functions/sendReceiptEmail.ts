import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { email, order_number, order, receipt_url } = await req.json();

    if (!email || !order_number) {
      return Response.json({ error: "Missing email or order_number" }, { status: 400 });
    }

    const items = (order?.items || [])
      .filter(i => !i.is_voided)
      .map(i => `<tr>
        <td style="padding:6px 0;border-bottom:1px solid #f0f0f0;">${i.quantity}x ${i.name}</td>
        <td style="padding:6px 0;border-bottom:1px solid #f0f0f0;text-align:right;">AED ${(i.subtotal || 0).toFixed(2)}</td>
      </tr>`)
      .join("");

    const subtotal = (order?.subtotal || 0).toFixed(2);
    const tax = (order?.tax || 0).toFixed(2);
    const total = (order?.total || 0).toFixed(2);
    const paymentMethod = order?.payment_method || "";
    const tableNumber = order?.table_number ? `Table ${order.table_number}` : (order?.customer_name ? `Pickup — ${order.customer_name}` : "");

    const html = `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px;">
        <h2 style="color:#111;margin-bottom:4px;">Your Receipt</h2>
        <p style="color:#888;font-size:14px;margin:0 0 20px;">Order #${order_number} · ${tableNumber}</p>
        <table style="width:100%;border-collapse:collapse;font-size:14px;">
          ${items}
        </table>
        <table style="width:100%;margin-top:12px;font-size:14px;">
          <tr><td style="color:#888;padding:4px 0;">Subtotal</td><td style="text-align:right;padding:4px 0;">AED ${subtotal}</td></tr>
          <tr><td style="color:#888;padding:4px 0;">VAT 5%</td><td style="text-align:right;padding:4px 0;">AED ${tax}</td></tr>
          <tr><td style="font-weight:bold;padding:8px 0;font-size:16px;border-top:2px solid #111;">Total</td><td style="text-align:right;font-weight:bold;font-size:16px;border-top:2px solid #111;">AED ${total}</td></tr>
        </table>
        ${paymentMethod ? `<p style="color:#888;font-size:13px;margin-top:8px;">Paid via ${paymentMethod}</p>` : ""}
        ${receipt_url ? `<a href="${receipt_url}" style="display:inline-block;margin-top:20px;background:#7C3AED;color:#fff;padding:12px 24px;border-radius:10px;text-decoration:none;font-weight:bold;">View Digital Receipt</a>` : ""}
        <p style="color:#ccc;font-size:12px;margin-top:24px;">Thank you for your visit!</p>
      </div>
    `;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: email,
      subject: `Your Receipt — Order #${order_number}`,
      body: html,
    });

    return Response.json({ success: true });
  } catch (error) {
    console.error("sendReceiptEmail error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});