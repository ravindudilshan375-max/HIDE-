import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Triggered by entity automation on Order update events
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { event, data: order, old_data: oldOrder } = body;

    // Only act on status changes
    if (!order || !oldOrder || order.status === oldOrder.status) {
      return Response.json({ success: true, message: 'No status change, skipping.' });
    }

    const newStatus = order.status;
    const oldStatus = oldOrder.status;

    console.log(`[orderStatusNotification] Order #${order.order_number}: ${oldStatus} → ${newStatus}`);

    // Send email notification for "ready" status (kitchen done, waiter should serve)
    if (newStatus === 'ready') {
      const label = order.table_number
        ? `Table ${order.table_number}`
        : order.customer_name
        ? `Pickup — ${order.customer_name}`
        : `Order #${order.order_number}`;

      const itemLines = (order.items || [])
        .filter(i => !i.is_voided)
        .map(i => `<li>${i.quantity > 1 ? `${i.name} x${i.quantity}` : i.name}</li>`)
        .join('');

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: order.created_by || 'ravindudilshan0011@gmail.com',
        subject: `🍽️ Order Ready — ${label}`,
        body: `
          <div style="font-family:sans-serif;max-width:480px;margin:auto;padding:24px;">
            <h2 style="color:#16a34a;">Order Ready to Serve</h2>
            <p><strong>${label}</strong> — Order #${order.order_number}</p>
            <ul style="padding-left:16px;">${itemLines}</ul>
            <p style="margin-top:16px;color:#6b7280;font-size:13px;">
              Total: AED ${(order.total || 0).toFixed(2)}
            </p>
          </div>
        `,
      });

      console.log(`[orderStatusNotification] Email sent for order #${order.order_number}`);
    }

    return Response.json({ success: true, old_status: oldStatus, new_status: newStatus });
  } catch (error) {
    console.error('[orderStatusNotification] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});