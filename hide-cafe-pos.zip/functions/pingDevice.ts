import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { ip_address, port, device_id } = await req.json();

    if (!ip_address) {
      return Response.json({ error: "ip_address is required" }, { status: 400 });
    }

    const targetPort = port || 9100;
    let status = "offline";

    try {
      const conn = await Deno.connect({ hostname: ip_address, port: targetPort });
      conn.close();
      status = "online";
    } catch (_e) {
      status = "offline";
    }

    // Update device status in DB if device_id provided
    if (device_id) {
      await base44.asServiceRole.entities.Device.update(device_id, {
        status,
        last_pinged: new Date().toISOString(),
      });
    }

    return Response.json({ status, ip_address, port: targetPort });
  } catch (error) {
    console.error("pingDevice error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});