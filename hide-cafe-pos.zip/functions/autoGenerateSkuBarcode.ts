import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { branch_id } = body;

    if (!branch_id) {
      return Response.json({ error: 'branch_id is required' }, { status: 400 });
    }

    // Fetch all items for this branch (or all items if filtering by branch_id)
    const items = branch_id && branch_id !== "all" 
      ? await base44.asServiceRole.entities.InventoryItem.filter({ branch_id })
      : await base44.asServiceRole.entities.InventoryItem.list();

    let updatedCount = 0;

    for (const item of items) {
      const updates = {};
      let hasChanges = false;

      // Auto-generate SKU if empty
      if (!item.sku || item.sku.trim() === '') {
        updates.sku = 'SKU' + String(item.id).padStart(6, '0');
        hasChanges = true;
      }

      // Auto-generate Barcode if empty (200 prefix + 9-digit padded ID)
      if (!item.barcode || item.barcode.trim() === '') {
        updates.barcode = '200' + String(item.id).padStart(9, '0');
        hasChanges = true;
      }

      if (hasChanges) {
        await base44.asServiceRole.entities.InventoryItem.update(item.id, updates);
        updatedCount++;
      }
    }

    return Response.json({
      success: true,
      message: `Generated SKU/Barcode for ${updatedCount} items`,
      updated: updatedCount,
      total: items.length
    });
  } catch (error) {
    console.error('Error in autoGenerateSkuBarcode:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});