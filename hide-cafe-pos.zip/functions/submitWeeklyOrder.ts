import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { request_id } = await req.json();
    if (!request_id) return Response.json({ error: 'request_id is required' }, { status: 400 });

    const weeklyReq = await base44.asServiceRole.entities.WeeklyOrderRequest.get(request_id);
    if (!weeklyReq) return Response.json({ error: 'Weekly request not found' }, { status: 404 });

    // Mark the weekly request as pending
    await base44.asServiceRole.entities.WeeklyOrderRequest.update(request_id, { status: 'ready_to_receive' });

    // Generate PO reference
    const existing = await base44.asServiceRole.entities.PurchaseOrder.list('-created_date', 1);
    const last = existing[0]?.reference;
    let num = 1;
    if (last) {
      const match = last.match(/PO-(\d+)/);
      if (match) num = parseInt(match[1]) + 1;
    }
    const reference = `PO-${String(num).padStart(6, '0')}`;

    // Map weekly request items to PO items
    const poItems = (weeklyReq.items || []).map(i => ({
      inventory_item_id: i.inventory_item_id,
      item_name: i.item_name,
      sku: i.sku || '',
      available_quantity: i.current_stock || 0,
      unit: i.unit || '',
      cost_per_unit: i.unit_cost || 0,
      quantity: i.requested_qty || 0,
      total_cost: (i.requested_qty || 0) * (i.unit_cost || 0),
      received_quantity: 0,
    }));

    const subtotal = poItems.reduce((s, i) => s + (i.total_cost || 0), 0);
    const taxRate = 5;
    const taxAmount = subtotal * (taxRate / 100);
    const totalCost = subtotal + taxAmount;

    // Create draft PO
    const po = await base44.asServiceRole.entities.PurchaseOrder.create({
      reference,
      supplier_id: weeklyReq.vendor_id || '',
      supplier_name: weeklyReq.vendor_name || '—',
      supplier_email: weeklyReq.vendor_email || '',
      destination_branch_id: weeklyReq.branch_id,
      destination_branch_name: weeklyReq.branch_name,
      status: 'draft',
      business_date: new Date().toISOString().split('T')[0],
      delivery_date: weeklyReq.week_end || '',
      items: poItems,
      subtotal,
      tax_rate: taxRate,
      tax_amount: taxAmount,
      total_cost: totalCost,
      number_of_items: poItems.length,
      notes: `Auto-created from Weekly Request by ${weeklyReq.requested_by}.\n${weeklyReq.notes || ''}`.trim(),
      creator_name: weeklyReq.requested_by,
      branch_id: weeklyReq.branch_id,
    });

    // Link PO back to weekly request
    await base44.asServiceRole.entities.WeeklyOrderRequest.update(request_id, {
      po_id: po.id,
      po_reference: reference,
    });

    console.log(`Created PO ${reference} from weekly request ${request_id}`);
    return Response.json({ success: true, po_reference: reference, po_id: po.id });

  } catch (error) {
    console.error('submitWeeklyOrder error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});