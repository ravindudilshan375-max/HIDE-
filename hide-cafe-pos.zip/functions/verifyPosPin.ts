import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// This function verifies a staff PIN stored on the User entity's `pos_pin` field.
// The PIN is a 4-6 digit code set by an admin in the Users / Roles page.

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { userId, pin } = await req.json();

    if (!userId || !pin) {
      return Response.json({ error: 'userId and pin are required' }, { status: 400 });
    }

    // Fetch the user as service role to access the pos_pin field
    const users = await base44.asServiceRole.entities.User.list();
    const user = users.find(u => u.id === userId);

    if (!user) {
      return Response.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    // Check the PIN — stored as `pos_pin` on the User entity
    if (!user.pos_pin) {
      // If no PIN is set, allow any non-empty PIN (open access fallback)
      return Response.json({ success: true, user: { id: user.id, full_name: user.full_name, email: user.email } });
    }

    if (String(user.pos_pin) === String(pin)) {
      return Response.json({ success: true, user: { id: user.id, full_name: user.full_name, email: user.email } });
    } else {
      return Response.json({ success: false });
    }
  } catch (error) {
    console.error('verifyPosPin error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});