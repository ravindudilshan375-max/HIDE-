import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Only admins can delete all items
    if (user.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Get all inventory items
    const items = await base44.asServiceRole.entities.InventoryItem.list();
    
    // Delete all items
    let deletedCount = 0;
    for (const item of items) {
      await base44.asServiceRole.entities.InventoryItem.delete(item.id);
      deletedCount++;
    }

    return Response.json({ 
      success: true, 
      message: `Deleted ${deletedCount} inventory items` 
    });
  } catch (error) {
    console.error('Error deleting inventory items:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});