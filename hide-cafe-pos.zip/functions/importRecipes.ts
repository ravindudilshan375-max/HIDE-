import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { rows } = await req.json();
    if (!rows || !Array.isArray(rows)) return Response.json({ error: 'rows array required' }, { status: 400 });

    // Fetch all menu items and inventory items
    const [menuItems, inventoryItems] = await Promise.all([
      base44.entities.MenuItem.list(),
      base44.entities.InventoryItem.list(),
    ]);

    const menuBySku = {};
    for (const m of menuItems) {
      if (m.sku) menuBySku[m.sku.trim().toLowerCase()] = m;
    }
    const invBySku = {};
    for (const i of inventoryItems) {
      if (i.sku) invBySku[i.sku.trim().toLowerCase()] = i;
    }

    // Group rows by product_sku
    const grouped = {};
    for (const row of rows) {
      const pSku = (row.product_sku || '').trim().toLowerCase();
      if (!pSku) continue;
      if (!grouped[pSku]) grouped[pSku] = [];
      grouped[pSku].push(row);
    }

    let updated = 0;
    let skipped = 0;
    const notFound = [];

    for (const [pSku, ingredients] of Object.entries(grouped)) {
      const menuItem = menuBySku[pSku];
      if (!menuItem) {
        notFound.push(pSku);
        skipped++;
        continue;
      }

      const recipe = [];
      for (const row of ingredients) {
        const iSku = (row.inventory_item_sku || '').trim().toLowerCase();
        const invItem = invBySku[iSku];
        if (!invItem) {
          console.log(`Inventory item not found: ${row.inventory_item_sku} (${row.inventory_item_name})`);
          continue;
        }
        recipe.push({
          inventory_item_id: invItem.id,
          inventory_item_name: invItem.name,
          quantity: parseFloat(row.quantity) || 0,
          unit: row.unit || '',
        });
      }

      await base44.entities.MenuItem.update(menuItem.id, { recipe, costing_method: 'From Ingredients' });
      updated++;
    }

    return Response.json({ updated, skipped, notFound, total: Object.keys(grouped).length });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});