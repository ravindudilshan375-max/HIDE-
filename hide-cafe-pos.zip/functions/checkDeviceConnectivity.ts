import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const devices = await base44.asServiceRole.entities.Device.list();

    // Check all devices in parallel with a per-device timeout of 2s
    const results = await Promise.all(devices.map(async (device) => {
      const ip = device.ip_address;
      if (!ip) {
        return { id: device.id, name: device.name, status: 'skipped', reason: 'no_ip' };
      }

      const port = device.port || 9100;
      let online = false;

      try {
        const connectPromise = Deno.connect({ hostname: ip, port: parseInt(port) });
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error("timeout")), 2000)
        );
        const conn = await Promise.race([connectPromise, timeoutPromise]);
        conn.close();
        online = true;
      } catch {
        online = false;
      }

      const newStatus = online ? 'online' : 'offline';
      const now = new Date().toISOString();

      // Always update last_pinged; only log status changes
      if (device.status !== newStatus) {
        console.log(`[checkDeviceConnectivity] ${device.name} (${ip}:${port}) ${device.status} → ${newStatus}`);
      }

      await base44.asServiceRole.entities.Device.update(device.id, {
        status: newStatus,
        last_pinged: now,
      });

      return { id: device.id, name: device.name, ip, port, status: newStatus };
    }));

    console.log(`[checkDeviceConnectivity] Done. Checked ${results.length} devices.`);
    return Response.json({ success: true, checked: results.length, results });
  } catch (error) {
    console.error('[checkDeviceConnectivity] Error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});