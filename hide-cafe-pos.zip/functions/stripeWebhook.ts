import Stripe from "npm:stripe@14.21.0";
import { createClientFromRequest } from "npm:@base44/sdk@0.8.6";

Deno.serve(async (req) => {
  try {
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"));
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    const body = await req.text();
    const signature = req.headers.get("stripe-signature");

    let event;
    if (webhookSecret && signature) {
      event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
    } else {
      event = JSON.parse(body);
    }

    const base44 = createClientFromRequest(req);

    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const meta = session.metadata || {};

      // Create order record as paid
      const orderNumber = `ORD-${Date.now().toString().slice(-6)}`;
      await base44.asServiceRole.entities.Order.create({
        order_number: orderNumber,
        type: meta.order_type || "takeaway",
        table_number: meta.table_number || null,
        customer_name: meta.customer_name || null,
        status: "paid",
        payment_method: "card",
        total: session.amount_total / 100,
        subtotal: (session.amount_subtotal / 100) * (1 / 1.1),
        tax: (session.amount_subtotal / 100) * (0.1 / 1.1),
        cashier_name: meta.cashier || "",
        notes: `Stripe session: ${session.id}`,
      });

      console.log("Order created from Stripe webhook:", orderNumber);
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error("Webhook error:", error.message);
    return Response.json({ error: error.message }, { status: 400 });
  }
});