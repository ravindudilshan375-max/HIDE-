import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Simple PIN hashing using SHA-256
async function hashPin(pin) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`DENDAX_PIN_SALT_${pin}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { pin, branch_id, admin_mode, staff_id } = await req.json();

    if (!pin) {
      return Response.json({ error: 'pin is required' }, { status: 400 });
    }

    if (!admin_mode && !branch_id) {
      return Response.json({ error: 'branch_id is required for branch login' }, { status: 400 });
    }

    const pinHash = await hashPin(pin);

    let candidates = [];

    if (admin_mode) {
      // Admin mode: search all active staff with admin or manager role
      const allStaff = await base44.asServiceRole.entities.StaffMember.filter({ is_active: true });
      candidates = allStaff.filter(s => {
        const pinMatch = s.pin_hash === pinHash;
        const roleMatch = s.role_type === 'admin' || s.role_type === 'manager';
        const idMatch = staff_id ? s.staff_id === staff_id : true;
        return pinMatch && roleMatch && idMatch;
      });
    } else {
      // Branch mode: search active staff in this branch
      const allStaff = await base44.asServiceRole.entities.StaffMember.filter({
        branch_id: branch_id,
        is_active: true
      });
      candidates = allStaff.filter(s => s.pin_hash === pinHash);
    }

    const staffMember = candidates[0] || null;

    if (!staffMember) {
      await base44.asServiceRole.entities.StaffLoginLog.create({
        branch_id: branch_id || 'admin',
        event: 'login_failed',
        timestamp: new Date().toISOString()
      });

      if (admin_mode) {
        return Response.json({ success: false, error: 'Invalid PIN or insufficient permissions. Only Admin/Manager PINs work in this mode.' });
      }
      return Response.json({ success: false, error: 'Invalid PIN' });
    }

    // Check if locked
    if (staffMember.locked_until) {
      const lockedUntil = new Date(staffMember.locked_until);
      if (lockedUntil > new Date()) {
        const remainingMs = lockedUntil - new Date();
        const remainingMin = Math.ceil(remainingMs / 60000);
        await base44.asServiceRole.entities.StaffLoginLog.create({
          staff_member_id: staffMember.id,
          staff_name: staffMember.name,
          branch_id: staffMember.branch_id,
          branch_name: staffMember.branch_name,
          event: 'login_locked',
          timestamp: new Date().toISOString()
        });
        return Response.json({ success: false, locked: true, locked_minutes: remainingMin, error: `Account locked for ${remainingMin} more minute(s)` });
      }
    }

    // Success — reset failed attempts, update last_login
    await base44.asServiceRole.entities.StaffMember.update(staffMember.id, {
      failed_attempts: 0,
      locked_until: null,
      last_login: new Date().toISOString()
    });

    await base44.asServiceRole.entities.StaffLoginLog.create({
      staff_member_id: staffMember.id,
      staff_name: staffMember.name,
      branch_id: staffMember.branch_id,
      branch_name: staffMember.branch_name,
      event: 'login_success',
      timestamp: new Date().toISOString()
    });

    return Response.json({
      success: true,
      staff: {
        id: staffMember.id,
        name: staffMember.name,
        staff_id: staffMember.staff_id,
        branch_id: staffMember.branch_id,
        branch_name: staffMember.branch_name,
        role_id: staffMember.role_id,
        role_name: staffMember.role_name,
        role_type: staffMember.role_type
      }
    });

  } catch (error) {
    console.error('verifyStaffPin error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});