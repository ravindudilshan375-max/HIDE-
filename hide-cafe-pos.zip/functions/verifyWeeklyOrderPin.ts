import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

async function hashPin(pin) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`DENDAX_PIN_SALT_${pin}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { pin } = await req.json();

    if (!pin) {
      return Response.json({ error: 'pin is required' }, { status: 400 });
    }

    const pinHash = await hashPin(pin);

    const allStaff = await base44.asServiceRole.entities.StaffMember.filter({ is_active: true });
    const staffMember = allStaff.find(s => s.pin_hash === pinHash);

    if (!staffMember) {
      console.log('PIN not matched for any active staff');
      return Response.json({ success: false, error: 'Invalid PIN. Please try again.' });
    }

    console.log(`Weekly Orders login success: ${staffMember.name}`);

    return Response.json({
      success: true,
      staff: {
        id: staffMember.id,
        name: staffMember.name,
        branch_id: staffMember.branch_id,
        branch_name: staffMember.branch_name,
        role_type: staffMember.role_type,
      }
    });

  } catch (error) {
    console.error('verifyWeeklyOrderPin error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});