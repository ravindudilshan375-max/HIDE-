import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    let body;
    
    try {
      body = await req.json();
    } catch (e) {
      console.error('JSON parse error:', e);
      return Response.json({ error: 'Invalid JSON payload' }, { status: 400 });
    }

    const { csvData } = body;

    if (!csvData || !Array.isArray(csvData)) {
      console.log('Invalid CSV data:', typeof csvData, Array.isArray(csvData));
      return Response.json({ error: 'Invalid CSV data format' }, { status: 400 });
    }

    console.log(`Processing ${csvData.length} rows`);

    // Group ingredients by product SKU
    const productRecipes = {};
    csvData.forEach((row, idx) => {
      try {
        const productSku = String(row.product_sku || '').trim();
        const inventoryItemSku = String(row.inventory_item_sku || '').trim();
        const inventoryItemName = String(row.inventory_item_name || '').trim();
        const quantity = parseFloat(row.quantity) || 0;
        const unit = String(row.unit || '').trim();

        if (!productSku || !inventoryItemSku) return;

        if (!productRecipes[productSku]) {
          productRecipes[productSku] = {
            productName: String(row.product_name || '').trim(),
            ingredients: []
          };
        }

        productRecipes[productSku].ingredients.push({
          inventory_item_id: inventoryItemSku,
          inventory_item_name: inventoryItemName,
          quantity,
          unit
        });
      } catch (e) {
        console.error(`Row ${idx} error:`, e);
      }
    });

    console.log(`Grouped into ${Object.keys(productRecipes).length} products`);

    // Get all menu items
    let menuItems = [];
    try {
      menuItems = await base44.entities.MenuItem.list();
      console.log(`Found ${menuItems.length} menu items`);
    } catch (e) {
      console.error('Error fetching menu items:', e);
      return Response.json({ error: 'Failed to fetch menu items' }, { status: 500 });
    }

    let updatedCount = 0;
    let errorCount = 0;

    // Update each product
    for (const [productSku, recipeData] of Object.entries(productRecipes)) {
      const menuItem = menuItems.find(item => item.sku === productSku);
      
      if (menuItem) {
        try {
          await base44.entities.MenuItem.update(menuItem.id, {
            recipe: recipeData.ingredients
          });
          updatedCount++;
        } catch (e) {
          console.error(`Error updating ${productSku}:`, e);
          errorCount++;
        }
      } else {
        console.log(`Product not found: ${productSku}`);
        errorCount++;
      }
    }

    console.log(`Update complete: ${updatedCount} updated, ${errorCount} failed`);

    return Response.json({
      success: true,
      updated: updatedCount,
      skipped: errorCount,
      total: Object.keys(productRecipes).length
    });
  } catch (error) {
    console.error('Bulk update error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});