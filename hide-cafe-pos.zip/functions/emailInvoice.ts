import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { email, order, signature } = body;

    if (!email || !order) {
      return Response.json({ error: 'Missing email or order data' }, { status: 400 });
    }

    // Build PDF
    const doc = new jsPDF({ unit: 'mm', format: [80, 200], orientation: 'portrait' });
    const pageW = 80;
    let y = 10;
    const cx = pageW / 2;

    const addCentered = (text, size, bold = false) => {
      doc.setFontSize(size);
      doc.setFont('helvetica', bold ? 'bold' : 'normal');
      doc.text(text, cx, y, { align: 'center' });
      y += size * 0.45 + 1.5;
    };

    const addLine = (left, right, size = 8, bold = false) => {
      doc.setFontSize(size);
      doc.setFont('helvetica', bold ? 'bold' : 'normal');
      doc.text(left, 5, y);
      doc.text(right, pageW - 5, y, { align: 'right' });
      y += size * 0.42 + 1.5;
    };

    const addDivider = () => {
      doc.setDrawColor(200);
      doc.line(5, y, pageW - 5, y);
      y += 3;
    };

    // Header
    addCentered(order.restaurant_name || 'Restaurant', 13, true);
    if (order.branch_name) addCentered(order.branch_name, 7);
    y += 2;
    addDivider();

    // Order info
    addCentered(`INVOICE`, 10, true);
    addCentered(order.order_number || '', 8);
    const now = new Date().toLocaleString('en-AE', { timeZone: 'Asia/Dubai' });
    addCentered(now, 7);
    y += 2;
    addDivider();

    if (order.customer_name) addLine('Customer:', order.customer_name, 8);
    if (order.cashier_name) addLine('Cashier:', order.cashier_name, 8);
    if (order.table_number) addLine('Table:', order.table_number, 8);
    addLine('Type:', order.type === 'dine-in' ? 'Dine-In' : 'Takeaway', 8);
    y += 1;
    addDivider();

    // Items
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('Item', 5, y);
    doc.text('Qty', pageW - 22, y);
    doc.text('Total', pageW - 5, y, { align: 'right' });
    y += 5;
    doc.setFont('helvetica', 'normal');

    for (const item of (order.items || [])) {
      if (item.is_voided) continue;
      const name = item.name?.length > 22 ? item.name.substring(0, 22) + '…' : item.name;
      const itemTotal = (item.subtotal ?? item.price * item.quantity).toFixed(2);
      doc.setFontSize(8);
      doc.text(name, 5, y);
      doc.text(String(item.quantity), pageW - 22, y);
      doc.text(`AED ${itemTotal}`, pageW - 5, y, { align: 'right' });
      y += 5;
      if (item.notes) {
        doc.setFontSize(6.5);
        doc.setTextColor(120);
        doc.text(`  Note: ${item.notes}`, 5, y);
        doc.setTextColor(0);
        y += 4;
      }
    }

    y += 1;
    addDivider();

    // Totals
    addLine('Subtotal:', `AED ${(order.subtotal || 0).toFixed(2)}`, 8);
    addLine('Tax:', `AED ${(order.tax || 0).toFixed(2)}`, 8);
    if (order.discount > 0) {
      addLine('Discount:', `-AED ${(order.discount || 0).toFixed(2)}`, 8);
    }
    y += 1;
    addLine('TOTAL:', `AED ${(order.total || 0).toFixed(2)}`, 10, true);
    addLine('Payment:', (order.payment_method || '').toUpperCase(), 8);
    y += 2;
    addDivider();

    // Signature section
    if (signature?.signature_image) {
      addCentered('AUTHORIZED SIGNATURE', 7, true);
      y += 1;
      try {
        const imgData = signature.signature_image;
        doc.addImage(imgData, 'PNG', 10, y, pageW - 20, 20);
        y += 22;
      } catch {}
      addCentered(signature.signed_by_name || '', 7);
      const sigTime = signature.signed_at ? new Date(signature.signed_at).toLocaleString('en-AE', { timeZone: 'Asia/Dubai' }) : '';
      if (sigTime) addCentered(sigTime, 6);
      if (signature.trigger_reason) {
        const reasonLabels = { foc: 'FOC Order', high_discount: 'High Discount', refund: 'Refund', manual: 'Manual' };
        addCentered(`Reason: ${reasonLabels[signature.trigger_reason] || signature.trigger_reason}`, 6);
      }
      addDivider();
    }

    addCentered('Thank you for your visit!', 8);
    y += 2;
    addCentered('This is your official invoice.', 7);

    // Resize page to content
    const pdfBase64 = doc.output('datauristring').split(',')[1];

    // Send email via Base44
    await base44.asServiceRole.integrations.Core.SendEmail({
      to: email,
      subject: `Your Invoice – ${order.order_number || 'Receipt'}`,
      body: `
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; color: #333;">
          <h2 style="color: #5B2CC0;">${order.restaurant_name || 'Restaurant'}</h2>
          <p>Dear ${order.customer_name || 'Valued Customer'},</p>
          <p>Thank you for your visit! Please find your invoice attached.</p>
          <table style="width:100%; border-collapse:collapse; margin: 16px 0; font-size:14px;">
            <tr><td style="padding:4px 0; color:#666;">Order Number</td><td style="text-align:right; font-weight:bold;">${order.order_number || '—'}</td></tr>
            <tr><td style="padding:4px 0; color:#666;">Total</td><td style="text-align:right; font-weight:bold; color:#5B2CC0;">AED ${(order.total || 0).toFixed(2)}</td></tr>
            <tr><td style="padding:4px 0; color:#666;">Payment Method</td><td style="text-align:right;">${(order.payment_method || '').toUpperCase()}</td></tr>
          </table>
          <p style="color:#999; font-size:12px;">The full PDF invoice is attached to this email.</p>
          <hr style="border:none; border-top:1px solid #eee; margin: 20px 0;" />
          <p style="color:#bbb; font-size:11px;">Powered by DENDAX Restaurant OS</p>
        </div>
      `,
    });

    console.log(`Invoice emailed to ${email} for order ${order.order_number}`);
    return Response.json({ success: true });

  } catch (error) {
    console.error('emailInvoice error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});