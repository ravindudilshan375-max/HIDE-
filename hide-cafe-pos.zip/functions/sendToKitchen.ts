Deno.serve(async (req) => {
  try {
    const { items, orderType, orderNumber, tableNumber, customerName, printerIp, printerPort, stationName } = await req.json();

    if (!printerIp) return Response.json({ error: 'No kitchen printer configured' }, { status: 400 });

    const port = parseInt(printerPort || "9100");
    const headerLabel = stationName ? stationName.toUpperCase() : "KITCHEN ORDER";

    // Build ESC/POS ticket text
    const lines = [];
    lines.push("\x1B\x40"); // Initialize printer
    lines.push("\x1B\x61\x01"); // Center align
    lines.push("\x1B\x21\x10"); // Double height
    lines.push(`${headerLabel}\n`);
    lines.push("\x1B\x21\x00"); // Normal
    lines.push("--------------------------------\n");
    lines.push("\x1B\x61\x00"); // Left align

    const now = new Date();
    lines.push(`Time: ${now.toLocaleTimeString()}\n`);
    if (orderNumber) lines.push(`Order #: ${orderNumber}\n`);
    if (orderType === "dine-in" && tableNumber) {
      lines.push(`Table: ${tableNumber}\n`);
    } else {
      lines.push(`Type: Takeaway${customerName ? ` - ${customerName}` : ""}\n`);
    }
    lines.push("--------------------------------\n");

    for (const item of items) {
      lines.push(`\x1B\x21\x08`); // Bold
      lines.push(`${item.quantity}x ${item.name}\n`);
      lines.push("\x1B\x21\x00"); // Normal
      if (item.notes) lines.push(`   >> ${item.notes}\n`);
    }

    lines.push("--------------------------------\n");
    lines.push("\n\n\n");
    lines.push("\x1D\x56\x41"); // Cut paper

    const ticketData = lines.join("");
    const encoder = new TextEncoder();
    const bytes = encoder.encode(ticketData);

    // Connect to printer via TCP
    const conn = await Deno.connect({ hostname: printerIp, port, transport: "tcp" });
    await conn.write(bytes);
    conn.close();

    return Response.json({ success: true });
  } catch (error) {
    console.error("Kitchen print error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});