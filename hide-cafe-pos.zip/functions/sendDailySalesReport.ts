import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Get config from user settings
    const settings = await base44.auth.me();
    if (!settings) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const reportConfig = settings.sales_report_config || {};
    const recipientEmails = reportConfig.recipient_emails || [];

    if (!recipientEmails || recipientEmails.length === 0) {
      return Response.json({ error: 'No recipient emails configured' }, { status: 400 });
    }

    // Get yesterday's orders
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);
    
    const today = new Date(yesterday);
    today.setDate(today.getDate() + 1);

    const orders = await base44.asServiceRole.entities.Order.filter({
      status: 'paid'
    });

    // Filter orders from yesterday
    const yesterdayOrders = orders.filter(o => {
      const orderDate = new Date(o.created_date);
      return orderDate >= yesterday && orderDate < today;
    });

    // Calculate totals
    const totalSales = yesterdayOrders.reduce((sum, o) => sum + (o.total || 0), 0);
    const totalOrders = yesterdayOrders.length;
    const totalItems = yesterdayOrders.reduce((sum, o) => sum + (o.items?.length || 0), 0);
    const totalTax = yesterdayOrders.reduce((sum, o) => sum + (o.tax || 0), 0);
    const totalDiscount = yesterdayOrders.reduce((sum, o) => sum + (o.discount || 0), 0);

    // Group by payment method
    const paymentMethods = {};
    yesterdayOrders.forEach(o => {
      const method = o.payment_method || 'unknown';
      if (!paymentMethods[method]) paymentMethods[method] = { count: 0, total: 0 };
      paymentMethods[method].count += 1;
      paymentMethods[method].total += o.total || 0;
    });

    const paymentMethodsHtml = Object.entries(paymentMethods)
      .map(([method, data]) => `<tr><td style="padding: 8px; border-bottom: 1px solid #eee;">${method.charAt(0).toUpperCase() + method.slice(1)}</td><td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">$${data.total.toFixed(2)}</td><td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">${data.count}</td></tr>`)
      .join('');

    const dateStr = yesterday.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    const htmlBody = `
<html>
  <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
      <h1 style="color: #5B2CC0;">Daily Sales Report</h1>
      <p style="color: #666; margin-bottom: 20px;">Report for ${dateStr}</p>

      <div style="background-color: #f5f5fa; border-radius: 8px; padding: 20px; margin-bottom: 20px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div>
            <p style="color: #999; font-size: 12px; margin: 0;">Total Sales</p>
            <p style="font-size: 24px; font-weight: bold; color: #5B2CC0; margin: 5px 0;">$${totalSales.toFixed(2)}</p>
          </div>
          <div>
            <p style="color: #999; font-size: 12px; margin: 0;">Total Orders</p>
            <p style="font-size: 24px; font-weight: bold; color: #5B2CC0; margin: 5px 0;">${totalOrders}</p>
          </div>
          <div>
            <p style="color: #999; font-size: 12px; margin: 0;">Total Items Sold</p>
            <p style="font-size: 24px; font-weight: bold; color: #5B2CC0; margin: 5px 0;">${totalItems}</p>
          </div>
          <div>
            <p style="color: #999; font-size: 12px; margin: 0;">Average Order</p>
            <p style="font-size: 24px; font-weight: bold; color: #5B2CC0; margin: 5px 0;">$${(totalSales / Math.max(totalOrders, 1)).toFixed(2)}</p>
          </div>
        </div>
      </div>

      <h3 style="color: #333; margin-bottom: 10px;">Revenue Breakdown</h3>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
        <thead>
          <tr style="background-color: #f0f0f0;">
            <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">Category</th>
            <th style="padding: 8px; text-align: right; border-bottom: 2px solid #ddd;">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr><td style="padding: 8px; border-bottom: 1px solid #eee;">Subtotal</td><td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">$${(totalSales - totalTax + totalDiscount).toFixed(2)}</td></tr>
          <tr><td style="padding: 8px; border-bottom: 1px solid #eee;">Tax</td><td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">$${totalTax.toFixed(2)}</td></tr>
          <tr><td style="padding: 8px; border-bottom: 1px solid #eee;">Discount</td><td style="padding: 8px; border-bottom: 1px solid #eee; text-align: right;">-$${totalDiscount.toFixed(2)}</td></tr>
          <tr style="background-color: #f5f5fa; font-weight: bold;"><td style="padding: 8px;">Total</td><td style="padding: 8px; text-align: right;">$${totalSales.toFixed(2)}</td></tr>
        </tbody>
      </table>

      <h3 style="color: #333; margin-bottom: 10px;">Payment Methods</h3>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
        <thead>
          <tr style="background-color: #f0f0f0;">
            <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">Method</th>
            <th style="padding: 8px; text-align: right; border-bottom: 2px solid #ddd;">Amount</th>
            <th style="padding: 8px; text-align: right; border-bottom: 2px solid #ddd;">Count</th>
          </tr>
        </thead>
        <tbody>
          ${paymentMethodsHtml}
        </tbody>
      </table>

      <p style="color: #999; font-size: 12px; text-align: center; margin-top: 30px;">This is an automated report. Do not reply to this email.</p>
    </div>
  </body>
</html>
    `.trim();

    // Send via built-in email integration
    for (const email of recipientEmails) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: `Daily Sales Report - ${dateStr}`,
        body: htmlBody,
      });
    }

    return Response.json({ success: true, emails_sent: recipientEmails.length, orders_count: totalOrders });
  } catch (error) {
    console.error('Error in sendDailySalesReport:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});