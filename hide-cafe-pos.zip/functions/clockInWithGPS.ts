import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Haversine formula to calculate distance between two coordinates in meters
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371000; // Earth radius in meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in meters
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { pin, branch_id, latitude, longitude } = await req.json();

    // Validate input
    if (!pin || !branch_id || latitude === undefined || longitude === undefined) {
      return Response.json(
        { success: false, error: 'Missing pin, branch_id, latitude, or longitude' },
        { status: 400 }
      );
    }

    // Hash the PIN
    async function hashPin(pinStr) {
      const encoder = new TextEncoder();
      const data = encoder.encode(`DENDAX_PIN_SALT_${pinStr}`);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }

    const pinHash = await hashPin(pin);

    // Verify staff PIN
    const allStaff = await base44.asServiceRole.entities.StaffMember.filter({
      branch_id: branch_id,
      is_active: true
    });

    const staffMember = allStaff.find(s => s.pin_hash === pinHash);

    if (!staffMember) {
      console.log('PIN verification failed for branch:', branch_id);
      return Response.json({ success: false, error: 'Invalid PIN' }, { status: 401 });
    }

    // Get branch geofence coordinates
    const branch = await base44.asServiceRole.entities.Branch.filter({ id: branch_id });
    const branchData = branch[0];

    if (!branchData) {
      console.log('Branch not found:', branch_id);
      return Response.json({ success: false, error: 'Branch not found' }, { status: 404 });
    }

    // Check geofence (default 100m if not set)
    const geofenceRadius = branchData.clock_in_radius_meters || 100;
    let gpsVerified = false;
    let distanceMeters = 0;

    if (branchData.latitude && branchData.longitude) {
      distanceMeters = getDistance(
        branchData.latitude,
        branchData.longitude,
        latitude,
        longitude
      );

      gpsVerified = distanceMeters <= geofenceRadius;
    }

    // Reject if GPS fails geofence check
    if (!gpsVerified) {
      console.log('Geofence check failed. Distance:', distanceMeters, 'meters. Required:', geofenceRadius);
      return Response.json({
        success: false,
        error: `You are ${Math.round(distanceMeters)}m away. Required distance: ${geofenceRadius}m`,
        distance_meters: Math.round(distanceMeters),
        required_radius: geofenceRadius
      }, { status: 403 });
    }

    // Clock in with GPS verification
    const now = new Date();
    const nowIso = now.toISOString();
    const todayStr = now.toISOString().split('T')[0];

    // Get today's scheduled shift for late detection
    const scheduledShifts = await base44.asServiceRole.entities.StaffSchedule.filter({ 
      staff_email: staffMember.email || staffMember.name,
      date: todayStr 
    }).catch(() => []);

    let lateMinutes = 0;
    let attendanceStatus = "on_time";
    let deductionAmount = 0;
    let scheduledStart = "";
    let scheduledEnd = "";

    if (scheduledShifts.length > 0) {
      const shift = scheduledShifts[0];
      scheduledStart = shift.shift_start;
      scheduledEnd = shift.shift_end;

      // Parse shift start time (HH:MM)
      const [shiftHour, shiftMin] = shift.shift_start.split(':').map(Number);
      const shiftStart = new Date(now);
      shiftStart.setHours(shiftHour, shiftMin, 0, 0);

      // Calculate late minutes (after 5-min grace period)
      if (now > shiftStart) {
        const diffMs = now - shiftStart;
        const diffMinutes = Math.floor(diffMs / 60000);
        const graceMinutes = 5;

        if (diffMinutes > graceMinutes) {
          lateMinutes = diffMinutes - graceMinutes;
          attendanceStatus = "late";
          deductionAmount = lateMinutes * 1; // 1 AED per minute
        }
      }
    }

    const timecard = await base44.asServiceRole.entities.StaffTimecard.create({
      staff_email: staffMember.staff_id || staffMember.name,
      staff_name: staffMember.name,
      branch_id: branch_id,
      branch_name: branchData.name || '',
      clock_in: nowIso,
      status: 'active',
      clock_in_method: 'pin_gps',
      gps_verified: true,
      gps_distance_meters: Math.round(distanceMeters),
      late_minutes: lateMinutes,
      deduction_amount: deductionAmount,
      breaks: [],
      break_minutes: 0
    });

    // Create attendance record
    await base44.asServiceRole.entities.Attendance.create({
      staff_id: staffMember.id,
      staff_email: staffMember.email || staffMember.name,
      staff_name: staffMember.name,
      branch_id: branch_id,
      date: todayStr,
      scheduled_shift_start: scheduledStart,
      scheduled_shift_end: scheduledEnd,
      clock_in_time: nowIso,
      late_minutes: lateMinutes,
      status: attendanceStatus,
      deduction_amount: deductionAmount,
      gps_verified: true,
      gps_distance_meters: Math.round(distanceMeters),
    });

    // Log successful clock-in
    await base44.asServiceRole.entities.StaffLoginLog.create({
      staff_member_id: staffMember.id,
      staff_name: staffMember.name,
      branch_id: branch_id,
      branch_name: branchData.name,
      event: 'clock_in_gps',
      latitude: latitude,
      longitude: longitude,
      distance_meters: Math.round(distanceMeters),
      timestamp: nowIso
    });

    return Response.json({
      success: true,
      timecard: {
        id: timecard.id,
        staff_name: staffMember.name,
        clock_in: nowIso,
        gps_verified: true,
        distance_meters: Math.round(distanceMeters),
        late_minutes: lateMinutes,
        deduction_amount: deductionAmount,
        attendance_status: attendanceStatus
      }
    });

  } catch (error) {
    console.error('clockInWithGPS error:', error.message);
    return Response.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
});