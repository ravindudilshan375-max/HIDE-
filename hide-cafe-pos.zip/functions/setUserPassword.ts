import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userId, password } = await req.json();

    if (!userId || !password) {
      return Response.json({ error: 'Missing userId or password' }, { status: 400 });
    }

    if (password.length < 6) {
      return Response.json({ error: 'Password must be at least 6 characters' }, { status: 400 });
    }

    // Update password using the service role entities API with _password field
    await base44.asServiceRole.entities.User.update(userId, { _password: password });

    return Response.json({ success: true, message: 'Password updated successfully' });
  } catch (error) {
    console.error('Error setting password:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});