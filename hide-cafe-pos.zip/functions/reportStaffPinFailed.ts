import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Called when PIN doesn't match ANY staff in the branch (we only know branch_id)
// But also used when we want to track a specific staff member's failed attempts

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { staff_member_id } = await req.json();

    if (!staff_member_id) {
      return Response.json({ error: 'staff_member_id is required' }, { status: 400 });
    }

    const staffList = await base44.asServiceRole.entities.StaffMember.filter({ id: staff_member_id });
    const staff = staffList[0];
    if (!staff) return Response.json({ error: 'Not found' }, { status: 404 });

    const newAttempts = (staff.failed_attempts || 0) + 1;
    const updates = { failed_attempts: newAttempts };

    if (newAttempts >= 5) {
      // Lock for 15 minutes
      const lockUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      updates.locked_until = lockUntil;

      await base44.asServiceRole.entities.StaffLoginLog.create({
        staff_member_id: staff.id,
        staff_name: staff.name,
        branch_id: staff.branch_id,
        branch_name: staff.branch_name,
        event: 'login_locked',
        timestamp: new Date().toISOString()
      });
    } else {
      await base44.asServiceRole.entities.StaffLoginLog.create({
        staff_member_id: staff.id,
        staff_name: staff.name,
        branch_id: staff.branch_id,
        branch_name: staff.branch_name,
        event: 'login_failed',
        timestamp: new Date().toISOString()
      });
    }

    await base44.asServiceRole.entities.StaffMember.update(staff_member_id, updates);

    return Response.json({ success: true, failed_attempts: newAttempts, locked: newAttempts >= 5 });

  } catch (error) {
    console.error('reportStaffPinFailed error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});