import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { attendance_id, adjustment_amount, reason } = await req.json();

    if (!attendance_id || adjustment_amount === undefined) {
      return Response.json({ success: false, error: "Missing required fields" }, { status: 400 });
    }

    const user = await base44.auth.me().catch(() => null);
    if (!user) {
      return Response.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const attendance = await base44.asServiceRole.entities.Attendance.filter({ id: attendance_id });
    
    if (!attendance || attendance.length === 0) {
      return Response.json({ success: false, error: "Attendance record not found" }, { status: 404 });
    }

    const record = attendance[0];
    const finalDeduction = (record.deduction_amount || 0) + adjustment_amount;

    await base44.asServiceRole.entities.Attendance.update(attendance_id, {
      adjustment_amount,
      adjustment_reason: reason,
      adjusted_by: user.email,
      final_deduction: Math.max(0, finalDeduction)
    });

    return Response.json({ 
      success: true,
      adjustment_amount,
      final_deduction: Math.max(0, finalDeduction)
    });

  } catch (error) {
    console.error("Adjustment error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});