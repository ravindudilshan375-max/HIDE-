import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { days = 7, branchId = null } = body;

    // Fetch all data in parallel
    const [items, orders, menuItems] = await Promise.all([
      base44.entities.InventoryItem.list(),
      base44.entities.Order.list('-created_date', 500),
      base44.entities.MenuItem.list(),
    ]);

    // Calculate sales velocity (units used per day for each inventory item)
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    const recentOrders = orders.filter(o => new Date(o.created_date) >= cutoffDate);

    // Map inventory items to menu items via recipes
    const inventoryUsage = {};
    
    recentOrders.forEach(order => {
      order.items?.forEach(orderItem => {
        const menuItem = menuItems.find(m => m.id === orderItem.menu_item_id);
        if (menuItem?.recipe) {
          menuItem.recipe.forEach(ingredient => {
            const key = ingredient.inventory_item_id;
            const unitsUsed = (orderItem.quantity || 1) * (ingredient.quantity || 0);
            
            if (!inventoryUsage[key]) {
              inventoryUsage[key] = { totalUsed: 0, ordersCount: 0 };
            }
            inventoryUsage[key].totalUsed += unitsUsed;
            inventoryUsage[key].ordersCount += 1;
          });
        }
      });
    });

    // Generate suggestions
    const suggestions = items
      .filter(item => !branchId || item.branch_id === branchId)
      .map(item => {
        const usage = inventoryUsage[item.id] || { totalUsed: 0, ordersCount: 0 };
        const currentQty = item.current_quantity || 0;
        const parLevel = item.par_level || item.minimum_level || 0;
        const maxLevel = item.maximum_level || parLevel * 1.5;
        
        const dailyUsage = usage.totalUsed / Math.max(days, 1);
        const daysUntilStockout = dailyUsage > 0 ? currentQty / dailyUsage : 999;
        
        const suggestedQuantity = Math.max(0, parLevel - currentQty);
        
        let priority = 'normal';
        if (daysUntilStockout <= 3) priority = 'urgent';
        else if (daysUntilStockout <= 7) priority = 'high';
        else if (currentQty > maxLevel) priority = 'overstock';
        
        return {
          id: item.id,
          name: item.name,
          sku: item.sku,
          supplier: item.supplier_name,
          currentQty,
          parLevel,
          minLevel: item.minimum_level,
          maxLevel,
          dailyUsage: parseFloat(dailyUsage.toFixed(2)),
          daysUntilStockout: parseFloat(daysUntilStockout.toFixed(1)),
          suggestedQuantity: Math.round(suggestedQuantity),
          totalCost: suggestedQuantity * (item.unit_cost || 0),
          priority,
          unit: item.unit,
          storageUnit: item.storage_unit,
          factor: item.factor,
        };
      })
      .filter(item => {
        // Only show items that need action
        return item.priority === 'urgent' || 
               item.priority === 'high' || 
               item.daysUntilStockout <= 7 ||
               item.suggestedQuantity > 0;
      })
      .sort((a, b) => {
        const priorityOrder = { urgent: 0, high: 1, normal: 2, overstock: 3 };
        const priorityDiff = (priorityOrder[a.priority] || 999) - (priorityOrder[b.priority] || 999);
        if (priorityDiff !== 0) return priorityDiff;
        return a.daysUntilStockout - b.daysUntilStockout;
      });

    return Response.json({ suggestions });
  } catch (error) {
    console.error('Replenishment error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});