import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get today's date
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    // Get all scheduled shifts for today
    const todaySchedules = await base44.asServiceRole.entities.StaffSchedule.filter({ 
      date: todayStr 
    });

    if (!todaySchedules || todaySchedules.length === 0) {
      return Response.json({ success: true, message: "No shifts scheduled for today" });
    }

    const absent = [];

    for (const schedule of todaySchedules) {
      // Parse shift start time
      const [shiftHour, shiftMin] = schedule.shift_start.split(':').map(Number);
      const shiftStart = new Date(now);
      shiftStart.setHours(shiftHour, shiftMin, 0, 0);

      // Mark absent if current time > shift start + 60 minutes AND no attendance record
      const absenceThreshold = new Date(shiftStart.getTime() + 60 * 60000);

      if (now > absenceThreshold) {
        // Check if staff already has attendance record
        const existingAttendance = await base44.asServiceRole.entities.Attendance.filter({
          staff_id: schedule.staff_id || schedule.staff_email,
          date: todayStr
        }).catch(() => []);

        if (!existingAttendance || existingAttendance.length === 0) {
          // Create absent record
          const staffEmail = schedule.staff_email;
          
          // Get staff details
          const staffMembers = await base44.asServiceRole.entities.StaffMember.filter({
            email: staffEmail
          }).catch(() => []);

          const staffName = staffMembers.length > 0 ? staffMembers[0].name : "Unknown";

          const attendanceRecord = {
            staff_id: schedule.staff_email,
            staff_email: staffEmail,
            staff_name: staffName,
            branch_id: schedule.branch_id,
            date: todayStr,
            scheduled_shift_start: schedule.shift_start,
            scheduled_shift_end: schedule.shift_end,
            status: "absent",
            late_minutes: 0,
            deduction_amount: 0,
            gps_verified: false,
            notes: "Auto-marked absent - no clock-in within 60 minutes of shift start"
          };

          await base44.asServiceRole.entities.Attendance.create(attendanceRecord);
          absent.push({ staff_email: staffEmail, staff_name: staffName });
        }
      }
    }

    return Response.json({ 
      success: true, 
      message: `Absent detection completed. ${absent.length} staff marked absent.`,
      absent_staff: absent
    });

  } catch (error) {
    console.error("Absent detection error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});