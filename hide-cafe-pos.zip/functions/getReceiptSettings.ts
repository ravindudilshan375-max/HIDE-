import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const branchId = body.branch_id || null;

    const query = branchId ? { branch_id: branchId } : {};
    const records = await base44.asServiceRole.entities.ReceiptSettings.filter(query, '-updated_date', 1);

    if (!records || records.length === 0) {
      return Response.json({ settings: null });
    }

    return Response.json({ settings: records[0] });
  } catch (error) {
    console.error("getReceiptSettings error:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});