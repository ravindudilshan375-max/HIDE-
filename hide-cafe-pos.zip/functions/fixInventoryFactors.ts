import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

// Standard unit conversions: if storage_unit is X and ingredient unit is Y, factor should be Z
const KNOWN_CONVERSIONS = {
  // Weight: KG → smaller
  "kg:g": 1000, "kg:gram": 1000, "kg:gm": 1000, "kg:grams": 1000,
  "kilo:g": 1000, "kilo:gram": 1000, "kilo:gm": 1000,
  // Volume: L/Litre → smaller
  "l:ml": 1000, "litre:ml": 1000, "liter:ml": 1000, "lt:ml": 1000,
  "litre:milliliter": 1000, "liter:milliliter": 1000,
  // Common packaging
  "ctn:pcs": null, "box:pcs": null, "pack:pcs": null, "can:ml": null,
};

function getExpectedFactor(storageUnit, ingredientUnit) {
  if (!storageUnit || !ingredientUnit) return null;
  const key = `${storageUnit.toLowerCase().trim()}:${ingredientUnit.toLowerCase().trim()}`;
  const factor = KNOWN_CONVERSIONS[key];
  return factor ?? null;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const dryRun = body.dry_run !== false; // default to dry run for safety

    const items = await base44.entities.InventoryItem.list();
    
    const fixes = [];
    const skipped = [];

    for (const item of items) {
      const expectedFactor = getExpectedFactor(item.storage_unit, item.unit);
      
      if (expectedFactor === null) {
        skipped.push({ id: item.id, name: item.name, reason: "No known conversion for these units", storage_unit: item.storage_unit, unit: item.unit, factor: item.factor });
        continue;
      }

      const currentFactor = item.factor || 1;

      if (Math.abs(currentFactor - expectedFactor) < 0.001) {
        // Already correct
        continue;
      }

      fixes.push({
        id: item.id,
        name: item.name,
        storage_unit: item.storage_unit,
        unit: item.unit,
        old_factor: currentFactor,
        new_factor: expectedFactor,
        old_cost_per_unit: (item.unit_cost || 0) / currentFactor,
        new_cost_per_unit: (item.unit_cost || 0) / expectedFactor,
      });

      if (!dryRun) {
        await base44.entities.InventoryItem.update(item.id, { factor: expectedFactor });
      }
    }

    return Response.json({
      dry_run: dryRun,
      total_items: items.length,
      fixes_needed: fixes.length,
      skipped: skipped.length,
      fixes,
      skipped_items: skipped,
      message: dryRun
        ? `DRY RUN: Found ${fixes.length} items needing factor fix. Call with dry_run=false to apply.`
        : `Applied ${fixes.length} factor fixes.`
    });
  } catch (error) {
    console.error('Error fixing factors:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});