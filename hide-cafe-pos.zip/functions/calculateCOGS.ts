import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    
    // Handle automation trigger (order update event)
    let order_id = payload.order_id || payload.data?.id;
    
    if (!order_id && payload.event) {
      // It's an automation payload
      order_id = payload.event.entity_id;
    }

    if (!order_id) {
      return Response.json({ error: 'order_id is required' }, { status: 400 });
    }

    // Fetch the order
    const orders = await base44.asServiceRole.entities.Order.filter({ id: order_id });
    const order = orders?.[0];
    if (!order) {
      return Response.json({ error: 'Order not found' }, { status: 404 });
    }

    // Fetch all menu items (to get recipes)
    const allMenuItems = await base44.asServiceRole.entities.MenuItem.list();
    const menuItemMap = Object.fromEntries(allMenuItems.map(m => [m.id, m]));

    // Fetch all inventory items (to get costs)
    const allInventoryItems = await base44.asServiceRole.entities.InventoryItem.list();
    const inventoryMap = Object.fromEntries(allInventoryItems.map(i => [i.id, i]));

    let totalCOGS = 0;
    const itemsBreakdown = [];

    // Process each order item
    for (const orderItem of order.items || []) {
      const menuItem = menuItemMap[orderItem.menu_item_id];
      if (!menuItem) continue;

      let itemCOGS = 0;
      const ingredientsBreakdown = [];

      // Process each ingredient in the recipe
      for (const recipe of menuItem.recipe || []) {
        const ingredient = inventoryMap[recipe.inventory_item_id];
        if (!ingredient) continue;

        // Calculate cost: quantity_used * (unit_cost / factor) * order_quantity
        // factor converts storage unit → recipe unit (e.g. 1 KG=1000g → factor=1000)
        const costPerRecipeUnit = ingredient.unit_cost / (ingredient.factor || 1);
        const totalCost = recipe.quantity * costPerRecipeUnit * orderItem.quantity;
        itemCOGS += totalCost;

        ingredientsBreakdown.push({
          ingredient_id: recipe.inventory_item_id,
          ingredient_name: recipe.inventory_item_name || ingredient.name,
          quantity_used: recipe.quantity * orderItem.quantity,
          unit_cost: costPerRecipeUnit,
          total_cost: totalCost
        });
      }

      totalCOGS += itemCOGS;

      itemsBreakdown.push({
        menu_item_id: orderItem.menu_item_id,
        menu_item_name: orderItem.name,
        quantity: orderItem.quantity,
        item_cogs: itemCOGS,
        ingredients: ingredientsBreakdown
      });
    }

    // Create OrderCOGS record
    const cogsRecord = await base44.asServiceRole.entities.OrderCOGS.create({
      order_id: order_id,
      order_number: order.order_number,
      branch_id: order.branch_id,
      cogs_amount: totalCOGS,
      items_breakdown: itemsBreakdown,
      created_at_date: new Date().toISOString().split('T')[0]
    });

    return Response.json({
      success: true,
      cogs_amount: totalCOGS,
      items_breakdown: itemsBreakdown,
      cogs_record_id: cogsRecord.id
    });
  } catch (error) {
    console.error('Error calculating COGS:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});