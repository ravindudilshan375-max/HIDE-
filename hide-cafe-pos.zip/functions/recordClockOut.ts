import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { attendance_id } = await req.json();

    if (!attendance_id) {
      return Response.json({ success: false, error: "Missing attendance_id" }, { status: 400 });
    }

    const attendance = await base44.asServiceRole.entities.Attendance.filter({ id: attendance_id });
    
    if (!attendance || attendance.length === 0) {
      return Response.json({ success: false, error: "Attendance record not found" }, { status: 404 });
    }

    const record = attendance[0];
    const now = new Date();
    const nowIso = now.toISOString();

    // Calculate worked minutes
    const clockInTime = new Date(record.clock_in_time);
    const workedMs = now - clockInTime;
    const workedMinutes = Math.floor(workedMs / 60000);

    // Update attendance with clock-out
    await base44.asServiceRole.entities.Attendance.update(attendance_id, {
      clock_out_time: nowIso,
      worked_minutes: workedMinutes,
      final_deduction: record.deduction_amount + (record.adjustment_amount || 0)
    });

    return Response.json({ 
      success: true, 
      worked_minutes: workedMinutes,
      clock_out_time: nowIso
    });

  } catch (error) {
    console.error("Clock-out error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});