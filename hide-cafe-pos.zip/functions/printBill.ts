import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const { order, printerIp, printerPort, connectionType } = await req.json();

    if (!order || !printerIp || !printerPort) {
      return Response.json({ error: 'Missing required fields: order, printerIp, printerPort' }, { status: 400 });
    }

    // Generate ESC/POS commands for receipt printing
    const billContent = generateESCPOS(order);

    if (connectionType === 'usb') {
      // USB printing would require device-level access, not possible from backend
      return Response.json(
        { error: 'USB printing must be handled from the device. Please use browser printing.' },
        { status: 400 }
      );
    }

    // Validate IP format
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(printerIp) || printerIp.split('.').some(n => parseInt(n) > 255)) {
      return Response.json({ error: 'Invalid printer IP' }, { status: 400 });
    }

    const port = parseInt(printerPort);
    if (isNaN(port) || port < 1 || port > 65535) {
      return Response.json({ error: 'Invalid printer port' }, { status: 400 });
    }

    // Send to network printer with retry logic
    const encoder = new TextEncoder();
    const buffer = encoder.encode(billContent);
    const MAX_RETRIES = 3;
    const TIMEOUT_MS = 5000;
    let lastError = null;

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const connectPromise = Deno.connect({ hostname: printerIp, port });
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('timeout')), TIMEOUT_MS)
        );
        const socket = await Promise.race([connectPromise, timeoutPromise]);

        await socket.write(buffer);
        await new Promise(resolve => setTimeout(resolve, 300));
        socket.close();

        console.log(`[printBill] Sent ${buffer.length} bytes to ${printerIp}:${port} (attempt ${attempt})`);
        return Response.json({ success: true, message: 'Bill sent to printer' });
      } catch (err) {
        lastError = err;
        console.warn(`[printBill] Attempt ${attempt} failed for ${printerIp}:${port} — ${err.message}`);
        if (attempt < MAX_RETRIES) await new Promise(r => setTimeout(r, 500));
      }
    }

    // Classify the final error into a readable message
    const msg = lastError?.message || "";
    let friendlyError = 'Printer not reachable';
    if (msg.includes('timeout')) friendlyError = 'Connection timeout';
    else if (msg.includes('refused') || msg.includes('ECONNREFUSED')) friendlyError = 'Printer not reachable';
    else if (msg.includes('invalid') || msg.includes('hostname')) friendlyError = 'Invalid printer IP';

    console.error(`[printBill] All retries failed for ${printerIp}:${port} — ${msg}`);
    return Response.json({ error: friendlyError }, { status: 200 });
  } catch (error) {
    console.error('Print bill error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function generateESCPOS(order) {
  const lines = [];
  const W = 32; // receipt width chars

  const pad = (left, right, width) => {
    const space = width - left.length - right.length;
    return left + ' '.repeat(Math.max(1, space)) + right;
  };

  // Initialize printer
  lines.push('\x1B\x40'); // Reset
  lines.push('\x1B\x61\x01'); // Center

  // Restaurant / Branch name header
  lines.push('\x1B\x45\x01\x1B\x21\x10'); // Bold + double height
  lines.push((order.restaurant_name || 'RESTAURANT').toUpperCase());
  lines.push('\n');
  lines.push('\x1B\x21\x00\x1B\x45\x00'); // Normal
  if (order.branch_name) {
    lines.push(order.branch_name);
    lines.push('\n');
  }

  // Date & time
  const now = new Date();
  lines.push(`${now.toLocaleDateString('en-AE')} ${now.toLocaleTimeString('en-AE', { hour: '2-digit', minute: '2-digit' })}`);
  lines.push('\n');
  lines.push('================================\n');

  // Left alignment
  lines.push('\x1B\x61\x00');

  if (order.order_number) { lines.push(`Order #: ${order.order_number}\n`); }
  if (order.table_number) { lines.push(`Table:   ${order.table_number}\n`); }
  if (order.customer_name) { lines.push(`Customer: ${order.customer_name}\n`); }
  if (order.cashier_name) { lines.push(`Cashier: ${order.cashier_name}\n`); }
  lines.push('--------------------------------\n');

  // Items header
  lines.push('\x1B\x45\x01');
  lines.push(pad('Item', 'Total', W));
  lines.push('\n\x1B\x45\x00');

  const items = order.items || [];
  items.forEach(item => {
    const name = (item.name || '').substring(0, 18);
    const qty = `x${item.quantity || 1}`;
    const price = `AED ${((item.subtotal ?? (item.price * item.quantity)) || 0).toFixed(2)}`;
    lines.push(`${name.padEnd(18)} ${qty.padStart(2)} ${price}\n`);
    if (item.modifiers?.length > 0) {
      lines.push(`  + ${item.modifiers.map(m => m.name).join(', ')}\n`);
    }
    if (item.notes) { lines.push(`  > ${item.notes}\n`); }
  });

  lines.push('================================\n');

  // Totals
  const subtotal = (order.subtotal || 0).toFixed(2);
  const tax = (order.tax || 0).toFixed(2);
  const discount = (order.discount || 0).toFixed(2);
  const total = (order.total || 0).toFixed(2);

  lines.push(pad('Subtotal:', `AED ${subtotal}`, W) + '\n');
  if (parseFloat(discount) > 0) {
    lines.push(pad('Discount:', `-AED ${discount}`, W) + '\n');
  }
  lines.push(pad('VAT:', `AED ${tax}`, W) + '\n');
  lines.push('--------------------------------\n');
  lines.push('\x1B\x45\x01');
  lines.push(pad('TOTAL:', `AED ${total}`, W) + '\n');
  lines.push('\x1B\x45\x00');

  if (order.payment_method) {
    const method = order.payment_method.charAt(0).toUpperCase() + order.payment_method.slice(1);
    lines.push(pad('Payment:', method, W) + '\n');
  }

  // Footer
  lines.push('\n\x1B\x61\x01');
  lines.push('Thank you for your visit!\n');
  lines.push('* * * * * * * * * * * * * * * *\n');
  lines.push('\n\n');

  // Cut paper
  lines.push('\x1D\x56\x00');

  return lines.join('');
}