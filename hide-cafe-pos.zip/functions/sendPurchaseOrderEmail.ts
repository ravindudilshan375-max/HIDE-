import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { po_id } = await req.json();
    if (!po_id) return Response.json({ error: 'po_id is required' }, { status: 400 });

    const po = await base44.asServiceRole.entities.PurchaseOrder.get(po_id);
    if (!po) return Response.json({ error: 'Purchase order not found' }, { status: 404 });

    if (!po.supplier_email) {
      return Response.json({ error: 'No supplier email on this purchase order' }, { status: 400 });
    }

    const items = po.items || [];
    const subtotal = items.reduce((s, i) => s + (i.total_cost || 0), 0) + (po.additional_cost || 0);
    const taxRate = po.tax_rate ?? 5;
    const taxAmount = subtotal * (taxRate / 100);
    const total = subtotal + taxAmount;

    const fmtDate = (d) => {
      if (!d) return '—';
      try {
        return new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      } catch { return d; }
    };

    const subject = `Purchase Order ${po.reference || ''} from Hide Cafe LLC`;

    const itemRowsHtml = items.map(i => `
      <tr>
        <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;">
          <strong>${i.item_name || ''}</strong>${i.sku ? `<br/><span style="color:#999;font-size:12px;">${i.sku}</span>` : ''}
        </td>
        <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;text-align:center;">${i.quantity} ${i.unit || ''}</td>
        <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;text-align:right;">AED ${(i.cost_per_unit || 0).toFixed(2)}</td>
        <td style="padding:10px 12px;border-bottom:1px solid #f0f0f0;text-align:right;font-weight:600;">AED ${(i.total_cost || 0).toFixed(2)}</td>
      </tr>`).join('');

    const body = `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"/></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:30px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        
        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,#5B2CC0,#7C3AED);padding:30px 32px;">
            <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700;">Purchase Order</h1>
            <p style="margin:6px 0 0;color:#d4b8ff;font-size:15px;">${po.reference || ''}</p>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding:28px 32px;">
            <p style="margin:0 0 20px;color:#333;font-size:15px;">Dear <strong>${po.supplier_name || 'Supplier'}</strong>,</p>
            <p style="margin:0 0 24px;color:#555;font-size:14px;line-height:1.6;">
              You have received a new Purchase Order from <strong>Hide Cafe LLC</strong>. Please review the details below and confirm receipt at your earliest convenience.
            </p>

            <!-- PO Info -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9f7ff;border-radius:8px;margin-bottom:24px;">
              <tr>
                <td style="padding:14px 16px;border-bottom:1px solid #ede8ff;">
                  <span style="color:#888;font-size:12px;display:block;">PO Number</span>
                  <strong style="color:#222;font-size:14px;">${po.reference || '—'}</strong>
                </td>
                <td style="padding:14px 16px;border-bottom:1px solid #ede8ff;">
                  <span style="color:#888;font-size:12px;display:block;">Branch</span>
                  <strong style="color:#222;font-size:14px;">${po.destination_branch_name || '—'}</strong>
                </td>
              </tr>
              <tr>
                <td style="padding:14px 16px;">
                  <span style="color:#888;font-size:12px;display:block;">PO Date</span>
                  <strong style="color:#222;font-size:14px;">${fmtDate(po.business_date)}</strong>
                </td>
                <td style="padding:14px 16px;">
                  <span style="color:#888;font-size:12px;display:block;">Delivery Date</span>
                  <strong style="color:#222;font-size:14px;">${fmtDate(po.delivery_date)}</strong>
                </td>
              </tr>
            </table>

            <!-- Items Table -->
            <h3 style="margin:0 0 12px;font-size:14px;color:#333;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;">Items Ordered</h3>
            <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #f0f0f0;border-radius:8px;overflow:hidden;margin-bottom:20px;">
              <thead>
                <tr style="background:#f8f8f8;">
                  <th style="padding:10px 12px;text-align:left;font-size:12px;color:#888;font-weight:600;">Item</th>
                  <th style="padding:10px 12px;text-align:center;font-size:12px;color:#888;font-weight:600;">Qty</th>
                  <th style="padding:10px 12px;text-align:right;font-size:12px;color:#888;font-weight:600;">Unit Cost</th>
                  <th style="padding:10px 12px;text-align:right;font-size:12px;color:#888;font-weight:600;">Total</th>
                </tr>
              </thead>
              <tbody>${itemRowsHtml}</tbody>
            </table>

            <!-- Totals -->
            <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
              <tr>
                <td style="padding:6px 0;color:#555;font-size:14px;">Subtotal</td>
                <td style="padding:6px 0;text-align:right;color:#555;font-size:14px;">AED ${subtotal.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding:6px 0;color:#555;font-size:14px;">VAT (${taxRate}%)</td>
                <td style="padding:6px 0;text-align:right;color:#555;font-size:14px;">AED ${taxAmount.toFixed(2)}</td>
              </tr>
              <tr>
                <td style="padding:10px 0 6px;border-top:2px solid #eee;font-size:16px;font-weight:700;color:#222;">TOTAL</td>
                <td style="padding:10px 0 6px;border-top:2px solid #eee;text-align:right;font-size:16px;font-weight:700;color:#5B2CC0;">AED ${total.toFixed(2)}</td>
              </tr>
            </table>

            ${po.notes ? `<div style="background:#fffbea;border:1px solid #f0e080;border-radius:8px;padding:14px 16px;margin-bottom:20px;"><p style="margin:0;font-size:13px;color:#7a6000;"><strong>Notes:</strong> ${po.notes}</p></div>` : ''}

            <p style="margin:0;color:#555;font-size:14px;line-height:1.6;">
              Please reply to this email to confirm receipt and advise on the expected delivery schedule.
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#f9f7ff;padding:20px 32px;text-align:center;border-top:1px solid #ede8ff;">
            <p style="margin:0;color:#888;font-size:12px;">Hide Cafe LLC &nbsp;·&nbsp; hide.uae@gmail.com</p>
            <p style="margin:4px 0 0;color:#bbb;font-size:11px;">This is an automated purchase order email.</p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

    console.log(`Sending PO email to: ${po.supplier_email} for PO: ${po.reference}`);

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: po.supplier_email,
      subject,
      body,
    });

    // Update status to sent
    const sentDate = new Date().toISOString();
    await base44.asServiceRole.entities.PurchaseOrder.update(po_id, {
      status: 'sent',
      sent_date: sentDate,
    });

    console.log(`PO email sent successfully to ${po.supplier_email}`);
    return Response.json({ success: true, sent_to: po.supplier_email });

  } catch (error) {
    console.error('sendPurchaseOrderEmail error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});